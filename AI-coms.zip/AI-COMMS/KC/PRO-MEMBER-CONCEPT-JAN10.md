# Pro Member Concept

**Date:** January 10, 2026  
**Status:** Brainstorm/Planning  
**Author:** Dave + Replit Agent

---

## Overview

Create a paid "Pro Member" tier for individual Kingdom Connects users. The subscription is intentionally cheap ($2.99/month) because the real revenue comes from merch sales. Pro Members can create and sell custom merchandise, with profits that can offset or exceed their subscription cost.

---

## Pricing

| Tier | Monthly Cost | Annual Option |
|------|--------------|---------------|
| Free Member | $0 | N/A |
| Pro Member | $2.99/mo | TBD |

**Philosophy:** Keep it cheap to maximize signups. The merch profit share is where real revenue comes from.

---

## Pro Member Features

### Creator Tools
- **Merch Builder** - Use QR Gear product generator to create custom t-shirts, hats, mugs, etc. with their own graphics
- **Sell on Static Page** - Merch displayed and sold from their public member page (`/member/slug`)
- **Profit Share** - 25% of profit on each sale (admin-configurable in `pricing_settings/default`)

### Visibility
- **Public Member Profile Page** - `/member/[slug]` with their info, reviews, photo gallery, merch shop
- **Custom Avatar** - Displayed on their reviews and profile
- **"Pro Member" Gold Badge** - Shows on all their reviews
- **Homepage Spotlight** - Eligible for featured member rotation

### Social Media (Pro Only)
- **Share Reviews** - Post reviews to Facebook/Twitter/LinkedIn
- **Share Merch Links** - Drive traffic to their page to sell merch

### Content
- **Photo Gallery** - Upload event photos, ministry pics, personal images
- **Event Announcements** - Post events to their page (optional/future)

### Perks
- **Unlimited Favorites** - Free tier gets capped (5-10)
- **Direct Message Businesses** - Contact form to reach businesses
- **Early Access** - New features before general release

---

## Free vs Pro Comparison

| Feature | Free | Pro ($2.99/mo) |
|---------|------|----------------|
| Browse directories | Yes | Yes |
| Save favorites | 5-10 limit | Unlimited |
| Write reviews | Yes | Yes + Pro badge |
| Avatar on reviews | No | Yes |
| Public profile page | No | Yes |
| Photo gallery | No | Yes |
| Social media sharing | No | Yes |
| Merch builder | No | Yes |
| Sell merch | No | Yes (25% profit) |
| Direct message businesses | No | Yes |
| Homepage spotlight | No | Eligible |

---

## Merch Profit Model

**Example: $25 T-Shirt Sale**

| Item | Amount |
|------|--------|
| Print/ship cost | ~$12 |
| Profit | ~$13 |
| Creator gets (25%) | $3.25 |
| KC keeps (75%) | $9.75 |

**Self-funding subscription:**
- Selling 1 t-shirt = covers subscription for 1+ months
- Active sellers make money, not just break even

**Admin Control:**
- `merch_creator_profit_percent` stored in `pricing_settings/default`
- Adjustable from admin panel without code changes
- Future: different rates per product, volume bonuses, promo periods

---

## Integration with QR Gear

QR Gear already has a product generator that:
1. Takes a t-shirt (or other item) template
2. Overlays custom graphics/text
3. Displays the finished product preview

This same engine powers Pro Member merch creation. Pro Members:
1. Upload their design/logo
2. Preview on available products
3. Save to their merch catalog
4. Products appear on their static page for sale

---

## Technical Notes

### New Firestore Fields (users collection)
```
member_pro_status: "pro" | null
member_pro_started_at: timestamp
member_pro_expires_at: timestamp
member_pro_subscription_id: string (Stripe)
```

### New Firestore Collections (future)
```
merch_products - Pro member product catalog
merch_orders - Order tracking, fulfillment status
merch_payouts - Commission tracking, disbursements
```

### Admin Settings (pricing_settings/default)
```
pro_member_monthly_price: 2.99
merch_creator_profit_percent: 25
```

---

## Key Business Insights

1. **Churches never pay** - Churches stay free. Pro is for individuals and businesses only.

2. **Low barrier = volume play** - $2.99 is an impulse buy. Even non-sellers generate recurring revenue.

3. **Merch is the flywheel:**
   - Pro Member creates merch
   - Shares to social media (Pro-only feature)
   - Drives traffic to KC
   - Sells merch, earns profit
   - KC gets subscription + merch margin
   - Traffic brings new users

4. **Pro Businesses already exist** - This adds a parallel track for individuals who aren't business owners but want to sell their own branded items (ministry, worship team, bible study, fundraisers, etc.)

---

## Next Steps

1. Finalize feature list with Dave
2. Design Firestore schema updates
3. Build Stripe subscription product for Pro Member
4. Integrate QR Gear merch builder
5. Create Pro Member dashboard/profile pages
6. Build admin controls for profit percentage
7. Connect to print-on-demand fulfillment (Printful or similar)

---

## Questions to Resolve

- Annual discount for Pro Member? (e.g., $29.99/year = 2 months free)
- Minimum payout threshold for merch earnings?
- Which products to offer at MVP? (t-shirts, hats, mugs?)
- Approval workflow for uploaded designs?
