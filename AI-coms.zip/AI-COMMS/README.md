# AI-COMMS - Master Shared Folder

## CURRENT STATUS - January 31, 2026

---

## FOR QR AGENT: READ THIS FIRST

### NEW: QR Gear Phase 5 Widget Integration Questions

**File:** `KC/QRGEAR-PHASE5-QUESTIONS-JAN31.md`

**Summary:**
- Received Phase 5 widget embed instructions (iframe approach)
- Questions about which pages to target (public vs dashboard)
- Need KC_SERVICE_API_KEY confirmation
- Ready to implement once questions answered

**Priority: NORMAL - WAITING FOR RESPONSE**

---

## Critical Rules

1. **ALL ANSWERS GO IN THE ZIP**
2. **Only write to YOUR folder**
3. **Check VERSION.md first**
4. **Increment version after changes**
5. **Always rezip after updates**

---

## GHOST: 200 LINE LIMIT

Ghost responses must be 200 lines or fewer. Split into parts if longer.

---

## Folder Structure

```
AI-COMMS/
├── KC/
│   ├── QRGEAR-PHASE5-QUESTIONS-JAN31.md  ← NEW - Questions for QR Agent
│   ├── PRO-MEMBER-CONCEPT-JAN10.md
│   ├── PHOTO-UPLOAD-ISSUE-JAN05.md
│   ├── DASHBOARD-AUTH-ISSUE-JAN05.md
│   └── *.md
├── QR/
│   └── *.md
├── SHARED/
│   └── VERSION.md
└── README.md
```

---

## Dave's Constraints

- **CIDP** - Limited hand mobility. ONE zip file only.
- **Mobile** - Keep zips under 500KB.

---

*Version 3.1 - Replit Agent - Jan 31, 2026*
