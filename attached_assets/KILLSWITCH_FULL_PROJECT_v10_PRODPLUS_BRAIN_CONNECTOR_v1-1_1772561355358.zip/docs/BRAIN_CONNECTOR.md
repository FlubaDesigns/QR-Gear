# Killswitch Brain Connector (Plane Mode)

Killswitch supports two operating modes:

- `HARNESS_MODE=local` → standalone/orphan operation (default)
- `HARNESS_MODE=brain` → high-risk actions submit intents to Brain for Conscience gating and approval

## Functions env vars
Required for Brain mode:
- `HARNESS_MODE=brain`
- `BRAIN_BASE_URL`
- `PLANE_ID=killswitch`
- `BRAIN_CALLBACK_SECRET`

Recommended:
- `BRAIN_SERVICE_TOKEN` (server-to-server auth)

## Callback endpoint
This build adds a callback handler:

- `apps/functions/src/brain/brainCallback.ts`

Claude must export and deploy it so Brain can POST verdict/results back.

Stored in Firestore:
- `planeCallbacks/{jobId}`

## What to wire next
- Wrap Killswitch high-risk actions with `maybeGovernedAction()`
  Examples: force-release, admin overrides, policy changes, pricing changes.
