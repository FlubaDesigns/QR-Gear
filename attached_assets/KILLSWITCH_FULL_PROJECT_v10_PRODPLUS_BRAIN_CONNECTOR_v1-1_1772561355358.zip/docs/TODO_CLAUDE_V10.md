# TODO for Claude — Killswitch v10 (Prod+Brain Connector)

## 1) Deploy + secrets (Resend + Stripe)
- Set STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET
- Set RESEND_API_KEY / RESEND_FROM_EMAIL
- Set APP_BASE_URL

## 2) Brain connector wiring (optional now, required for governed mode)
- Set HARNESS_MODE=brain (only when ready)
- Set BRAIN_BASE_URL, PLANE_ID=killswitch
- Set BRAIN_CALLBACK_SECRET
- (Recommended) set BRAIN_SERVICE_TOKEN
- Ensure exported function `brainCallback` is deployed and reachable
- Register planeId + callbackUrl in Brain plane registry

## 3) Wrap high-risk actions
Use: `apps/functions/src/brain/governance.ts`
Wrap: admin overrides, force release, policy edits, pricing edits.

## 4) Observability
- Optionally surface `systemEvents` + `deadLetterQueue` in admin UI later
