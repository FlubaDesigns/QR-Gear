# TODO — You (Owner)

## 1) Firebase + Hosting
- [ ] Create/choose Firebase project
- [ ] Enable Firestore, Functions, Hosting, Auth
- [ ] Set `.firebaserc` project id
- [ ] Paste web config into `apps/web/src/firebase.ts`
- [ ] Run `npm install`

## 2) Secrets
- [ ] Set functions config keys:
  - app.base_url (your hosted URL)
  - app.support_email
  - resend.key
  - stripe.secret
  - stripe.webhook_secret
  - (optional) twilio.sid/token/from

## 3) Admin claim
- [ ] Sign in once, copy UID (shown on Dashboard)
- [ ] Set admin custom claim: role=admin
- [ ] Sign out/in

## 4) Stripe products/prices
- [ ] Create products (Personal/Family/Professional/Business)
- [ ] Create monthly prices
- [ ] Put Price IDs into Firestore `systemConfig/global.stripe.*`
- [ ] Configure webhook endpoint to `stripeWebhook` function

## 5) End-to-end test
- [ ] Create protocol from Dashboard
- [ ] Add release recipients + verification contacts
- [ ] Request contact consent (sends consent link)
- [ ] Accept consent on `/verify`
- [ ] Force `nextCheckInAt` into the past and watch scheduler move states
- [ ] Confirm email contains **portal link** (not raw content)
- [ ] Open portal link `/portal?tokenId=...&token=...`
- [ ] Test check-in cancel during buffer (Protocol page)

## 6) Production checklist
- [ ] Confirm scheduled jobs exist in Cloud Console
- [ ] Confirm audit logs are writing
- [ ] Confirm delivery queue retries + alerts
- [ ] Confirm admin monitoring page shows alerts + health counters
## Vault encryption (v8)
- [ ] Decide how you want to share the vault passphrase with next-of-kin (offline only).
- [ ] Add at least 1 encrypted vault item to a protocol.
- [ ] Trigger a release and confirm the portal shows the encrypted items and decrypts locally.
