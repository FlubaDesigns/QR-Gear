# Killswitch Production Environment (Resend + Stripe)

## Web (Vite) env vars (apps/web)
Required:
- VITE_FIREBASE_API_KEY
- VITE_FIREBASE_AUTH_DOMAIN
- VITE_FIREBASE_PROJECT_ID
- VITE_FIREBASE_APP_ID

Optional:
- VITE_FIREBASE_STORAGE_BUCKET
- VITE_FIREBASE_MESSAGING_SENDER_ID

## Functions secrets / env (apps/functions)
Required:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PORTAL_RETURN_URL (or your app base url)
- RESEND_API_KEY
- RESEND_FROM_EMAIL

Recommended:
- APP_BASE_URL (used for links)
- OWNER_UID (bootstrap/admin setup)
