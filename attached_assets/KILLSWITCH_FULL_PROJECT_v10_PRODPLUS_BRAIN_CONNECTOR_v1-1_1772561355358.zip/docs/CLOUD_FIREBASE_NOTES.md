# Cloud + Firebase Notes (Killswitch)

## Firebase Services
- Firestore
- Cloud Functions (Node 18)
- Cloud Scheduler via scheduled Functions (PubSub schedules)
- Firebase Hosting
- Firebase Auth (admin custom claims)

## Scheduled Functions
- `engineTick` (every 15 minutes) — protocol state transitions + portal link creation + delivery queue
- `deliveryQueueTick` (every 5 minutes) — sends + retries
- `metricsTick` (every 60 minutes) — aggregates basic health counters for admin

## Secrets (functions config)
- app.base_url
- app.support_email
- resend.key
- twilio.sid/token/from (optional)
- stripe.secret
- stripe.webhook_secret

## Stripe Webhook
Stripe → Developers → Webhooks
Endpoint:
`https://<REGION>-<PROJECT>.cloudfunctions.net/stripeWebhook`
Events:
- checkout.session.completed
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted

## Resend
- Verify domain
- Use verified From address in sendEmail.js

## Twilio
- Purchase/verify number
- Add to config twilio.from
