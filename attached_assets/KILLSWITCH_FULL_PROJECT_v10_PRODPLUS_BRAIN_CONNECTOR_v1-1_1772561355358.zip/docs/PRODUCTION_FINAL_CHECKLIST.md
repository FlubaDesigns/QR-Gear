# FINAL PRODUCTION CHECKLIST — Killswitch (Resend + Stripe)

## Phase 0 — Pre-checks
[ ] `npm ci` works at repo root
[ ] `npm run build` works for web + functions
[ ] Firestore rules deployed and locked (no public writes)
[ ] Stripe webhook signature verified (test event)
[ ] Admin claim/role set for owner UID

## Phase 1 — Deploy (Firebase)
[ ] Deploy Functions (Stripe webhooks + scheduled ticks)
[ ] Deploy Firestore rules + indexes
[ ] Deploy Hosting (web)
[ ] Verify `/healthz` equivalent if present (or basic ping page loads)

## Phase 2 — Payments (Stripe)
[ ] Create products/prices if required by config
[ ] Confirm checkout works end-to-end
[ ] Confirm customer portal link works
[ ] Confirm webhook is idempotent (same event twice does not duplicate)

## Phase 3 — Email (Resend)
[ ] Confirm transactional email sends (test address)
[ ] Confirm links use correct APP_BASE_URL
[ ] Confirm bounce/complaint handling policy (at least monitoring)

## Production complete when
[ ] A full “create → schedule → verify → release” flow works
[ ] Admin UI can see queues/metrics
[ ] Logs show no repeated failures on scheduled ticks
