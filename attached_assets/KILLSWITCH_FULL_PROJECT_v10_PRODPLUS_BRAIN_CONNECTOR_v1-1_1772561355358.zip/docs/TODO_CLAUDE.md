# TODO — Claude (Builder)

## A) UI polish
- [ ] Replace minimal UI with full mobile-first styling (cards, steps, clear CTAs)
- [ ] Add validation (emails/phones, required fields)
- [ ] Add “military free” onboarding flow UX (verify .mil OR manual override)

## B) Vault packaging
- [ ] Build vault item creation UI (encrypt client-side, store ciphertext in vaultItems)
- [ ] Release bundling: portal displays vault items neatly (videos, files, messages)

## C) Engine upgrades
- [ ] Add multi-stage warning cadence (Day 0 warning, Day 1 warning, etc.)
- [ ] Add recipient preference: portal-only vs portal+summary email
- [ ] Add prevention logic: user check-in resets state and cancels queue

## D) Observability
- [ ] Add charts for metricsDaily (queue size, send success rate)
- [ ] Add per-protocol audit viewer
- [ ] Add admin export button for audit logs

## E) Security tightening
- [ ] Add App Check (recommended)
- [ ] Add callable rate limiting (basic throttles)
- [ ] Add contact PII minimization in logs (already mostly minimal)
