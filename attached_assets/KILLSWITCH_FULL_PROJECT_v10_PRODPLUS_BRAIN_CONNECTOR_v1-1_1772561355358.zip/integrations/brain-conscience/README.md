# Brain + Conscience Integration (Scaffold)

This folder defines how Killswitch can plug into a broader orchestration/governance plane.

## Goals
- Allow **Brain** to coordinate actions across projects (e.g., AI-COMMS, Guardrails)
- Allow **Conscience** to enforce immutable policy (no raw release, disclaimers, rate-limits, etc.)
- Keep Killswitch independently safe even if the integration is offline

## Event Out (Killswitch → Brain/Conscience)
Collection: `integrationEvents`
- minimal PII
- never includes token secrets
- never includes vault content
- includes stable IDs, timestamps, and event types

Example event types:
- `protocol_state_transition`
- `release_portal_created`
- `delivery_job_sent`
- `verification_ping_queued`
- `portal_link_opened`

## Decision In (Brain/Conscience → Killswitch)
Collection: `integrationDecisions` (future)
Examples:
- `pause_release`
- `extend_buffer`
- `require_human_confirm`
- `override_military_free`

## Security model (future)
- Signed decisions (HMAC/public key)
- Admin-only approval for applying high-impact decisions


## Canon sourcing (external)
Canon is intentionally NOT shipped inside the Killswitch product bundle.
If Brain/Conscience requires policy text, source it from your external governance system (AI Guardrails / AI Socket).
Killswitch only provides the hook: events out + optional signed decisions in.
