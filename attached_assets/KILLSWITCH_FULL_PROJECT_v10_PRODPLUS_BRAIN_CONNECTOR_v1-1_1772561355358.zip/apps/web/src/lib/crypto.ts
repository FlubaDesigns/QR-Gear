/**
 * Client-side vault encryption (Web Crypto)
 * - AES-GCM encryption
 * - Key derived from user passphrase via PBKDF2
 * - Only ciphertext + iv + salt stored in Firestore
 * - Passphrase NEVER stored in Firestore
 *
 * Recipients decrypt in the portal by entering the passphrase.
 * This preserves Rule #1: never release raw content by email/SMS.
 */

const te = new TextEncoder();
const td = new TextDecoder();

function b64(u8: Uint8Array): string {
  let s = "";
  for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
  return btoa(s);
}
function unb64(s: string): Uint8Array {
  const bin = atob(s);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const baseKey = await crypto.subtle.importKey(
    "raw",
    te.encode(passphrase),
    "PBKDF2",
    false,
    ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt,
      iterations: 210_000,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

export type VaultCipher = {
  algo: "AES-GCM";
  kdf: "PBKDF2-SHA256";
  iterations: number;
  saltB64: string;
  ivB64: string;
  ciphertextB64: string;
};

export async function encryptText(passphrase: string, plaintext: string): Promise<VaultCipher> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(passphrase, salt);
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, te.encode(plaintext));
  return {
    algo: "AES-GCM",
    kdf: "PBKDF2-SHA256",
    iterations: 210_000,
    saltB64: b64(salt),
    ivB64: b64(iv),
    ciphertextB64: b64(new Uint8Array(ct)),
  };
}

export async function decryptText(passphrase: string, cipher: VaultCipher): Promise<string> {
  const salt = unb64(cipher.saltB64);
  const iv = unb64(cipher.ivB64);
  const key = await deriveKey(passphrase, salt);
  const pt = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    key,
    unb64(cipher.ciphertextB64)
  );
  return td.decode(pt);
}
