import React, { useEffect, useMemo, useState } from 'react';
import { Routes, Route, Link, useNavigate, useSearchParams, useParams } from 'react-router-dom';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { collection, addDoc, doc, getDoc, getDocs, query, where, updateDoc } from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { auth, db, fn } from '../firebase';
import { encryptText, decryptText, type VaultCipher } from '../lib/crypto';
import { card, page, btnPrimary, btnGhost, badge } from './styles';

function useUID() {
  const [uid, setUid] = useState('');
  useEffect(() => {
    (async () => { await signInAnonymously(auth); })();
    const unsub = onAuthStateChanged(auth, (u) => setUid(u?.uid ?? ''));
    return () => unsub();
  }, []);
  return uid;
}

function Home() {
  const uid = useUID();
  const [protocols, setProtocols] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const nav = useNavigate();

  async function load() {
    if (!uid) return;
    const qy = query(collection(db, 'protocols'), where('ownerUid', '==', uid));
    const snap = await getDocs(qy);
    setProtocols(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  }
  useEffect(() => { load(); }, [uid]);

  async function createProtocol() {
    if (!uid) return;
    setBusy(true);
    const now = Date.now();
    const id = await addDoc(collection(db, 'protocols'), {
      ownerUid: uid,
      senderName: 'You',
      state: 'ACTIVE',
      verificationEnabled: true,
      executionBufferHours: 12,
      safeConfirmDelayDays: 7,
      maxDelaysPerCycle: 2,
      delaysUsedThisCycle: 0,
      // next check-in default 24h
      nextCheckInAt: new Date(now + 24*60*60*1000),
      releaseRecipients: [],
      createdAt: new Date(),
      updatedAt: new Date()
    });
    setBusy(false);
    nav(`/protocol/${id.id}`);
  }

  return (
    <div style={page}>
      <h1 style={{ margin: 0 }}>Killswitch</h1>
      <div style={{ marginTop: 8, color:'#666' }}>
        UID: {uid || '…'} &nbsp;|&nbsp; <Link to="/admin">Admin</Link>
      </div>

      <div style={card}>
        <div style={{ display:'flex', justifyContent:'space-between', gap: 10, flexWrap:'wrap' }}>
          <div>
            <div style={{ fontWeight: 800 }}>Peace of mind</div>
            <div style={{ color:'#666', fontSize: 13 }}>
              Keep check-ins current. If you miss them, the system escalates safely with verification fallbacks and a buffer window.
            </div>
          </div>
          <button disabled={busy || !uid} onClick={createProtocol} style={btnPrimary}>Create Protocol</button>
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Your protocols</h2>
        {protocols.length === 0 ? (
          <div style={{ color:'#666' }}>No protocols yet. Create one.</div>
        ) : (
          <div style={{ display:'grid', gap: 10 }}>
            {protocols.map(p => (
              <div key={p.id} style={{ border:'1px solid #eee', borderRadius: 14, padding: 12 }}>
                <div style={{ display:'flex', justifyContent:'space-between', gap: 10, flexWrap:'wrap' }}>
                  <div>
                    <div style={{ fontWeight: 700 }}>{p.senderName || 'Protocol'}</div>
                    <div style={{ color:'#666', fontSize: 13 }}>
                      State: <span style={badge()}>{p.state || 'ACTIVE'}</span>
                    </div>
                  </div>
                  <div style={{ display:'flex', gap: 10 }}>
                    <Link to={`/preview/${p.id}`} style={{ ...btnGhost, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Preview</Link>
                    <Link to={`/protocol/${p.id}`} style={{ ...btnPrimary, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Open</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProtocolPage() {
  const uid = useUID();
  const { id } = useParams();
  const [p, setP] = useState<any>(null);
  const [status, setStatus] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactName, setContactName] = useState('');
  const [busy, setBusy] = useState(false);

  async function load() {
    if (!id) return;
    const snap = await getDoc(doc(db, 'protocols', id));
    setP(snap.exists() ? { id, ...snap.data() } : null);
  }
  useEffect(() => { load(); }, [id]);

  async function checkInCancel() {
    if (!id || !p) return;
    setBusy(true);
    setStatus('Checking in…');
    try {
      // Cancel execution buffer by moving to ACTIVE and setting new nextCheckInAt
      await updateDoc(doc(db, 'protocols', id), {
        state: 'ACTIVE',
        nextCheckInAt: new Date(Date.now() + 24*60*60*1000),
        delaysUsedThisCycle: 0,
        updatedAt: new Date()
      });
      setStatus('Check-in recorded. Execution cancelled (if it was pending).');
      await load();
    } catch (e:any) {
      setStatus('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function addRecipient() {
    if (!id || !recipientEmail) return;
    setBusy(true);
    const next = [...(p.releaseRecipients || []), { email: recipientEmail }];
    await updateDoc(doc(db, 'protocols', id), { releaseRecipients: next, updatedAt: new Date() });
    setRecipientEmail('');
    await load();
    setBusy(false);
  }

  async function addContact() {
    if (!uid || !id || !contactEmail) return;
    setBusy(true);
    await addDoc(collection(db, 'verificationContacts'), {
      ownerUid: uid,
      protocolId: id,
      ownerName: p?.senderName || 'Owner',
      name: contactName || 'Contact',
      email: contactEmail,
      phone: '',
      consentStatus: 'pending',
      createdAt: new Date()
    });
    setContactEmail('');
    setContactName('');
    await load();
    setBusy(false);
  }

  async function requestConsentLatest() {
    setBusy(true);
    setStatus('Queuing consent request…');
    try {
      // Find last contact for this protocol and request consent
      const qy = query(collection(db, 'verificationContacts'), where('ownerUid','==', uid), where('protocolId','==', id));
      const snap = await getDocs(qy);
      const last = snap.docs[snap.docs.length - 1];
      if (!last) { setStatus('No contacts yet. Add one first.'); setBusy(false); return; }
      const call = httpsCallable(fn, 'requestContactConsent');
      const res:any = await call({ contactId: last.id });
      setStatus(res.data?.message || 'Consent request queued.');
    } catch (e:any) {
      setStatus('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  if (!p) return <div style={page}>Loading…</div>;

  const timeline = [
    'ACTIVE','MISSED_CHECKIN','ESCALATING','CONTACT_VERIFYING','FINAL_WARNING','EXECUTION_BUFFER','EXECUTED'
  ];
  const idx = timeline.indexOf(p.state || 'ACTIVE');

  return (
    <div style={page}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <h1 style={{ margin:'0 0 6px 0' }}>Protocol</h1>
          <div style={{ color:'#666' }}>State: <span style={badge()}>{p.state || 'ACTIVE'}</span></div>
        </div>
        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          <Link to={`/preview/${p.id}`} style={{ ...btnGhost, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Preview</Link>
          <Link to="/" style={{ ...btnGhost, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Back</Link>
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Timeline</h2>
        <div style={{ display:'flex', flexWrap:'wrap', gap: 8 }}>
          {timeline.map((t, i) => (
            <span key={t} style={badge(i <= idx ? '#dff1ff' : '#f5f5f5')}>{t}</span>
          ))}
        </div>
        <div style={{ marginTop: 12, color:'#666', fontSize: 13 }}>
          Next check-in: {String(p.nextCheckInAt?.toDate ? p.nextCheckInAt.toDate() : p.nextCheckInAt || '')}
        </div>
        <div style={{ marginTop: 12, display:'flex', gap: 10, flexWrap:'wrap' }}>
          <button disabled={busy} onClick={checkInCancel} style={btnPrimary}>I’m OK (Check-in)</button>
          <span style={{ alignSelf:'center', color:'#555' }}>{status}</span>
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Release recipients</h2>
        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          <input value={recipientEmail} onChange={e=>setRecipientEmail(e.target.value)} placeholder="email@example.com"
                 style={{ padding:10, borderRadius:12, border:'1px solid #ddd', minWidth: 240 }} />
          <button disabled={busy} onClick={addRecipient} style={btnGhost}>Add recipient</button>
        </div>
        <div style={{ marginTop: 10, color:'#666', fontSize: 13 }}>
          {(p.releaseRecipients || []).length === 0 ? 'No recipients yet.' : (p.releaseRecipients || []).map((r:any, i:number)=>(<div key={i}>{r.email || r.phone}</div>))}
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Verification contacts</h2>
        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          <input value={contactName} onChange={e=>setContactName(e.target.value)} placeholder="Contact name"
                 style={{ padding:10, borderRadius:12, border:'1px solid #ddd', minWidth: 180 }} />
          <input value={contactEmail} onChange={e=>setContactEmail(e.target.value)} placeholder="contact@email.com"
                 style={{ padding:10, borderRadius:12, border:'1px solid #ddd', minWidth: 240 }} />
          <button disabled={busy} onClick={addContact} style={btnGhost}>Add contact</button>
          <button disabled={busy} onClick={requestConsentLatest} style={btnPrimary}>Request consent</button>
        </div>
        <div style={{ marginTop: 10, color:'#666', fontSize: 13 }}>
          Consent requests are emailed. Accepted contacts receive safety-check pings during escalation.
        </div>
      </div>

<div style={card}>
  <h2 style={{ marginTop: 0 }}>Secure vault</h2>
  <div style={{ color:'#666', fontSize: 13 }}>
    Vault items are encrypted in your browser and stored as ciphertext. Recipients decrypt in the portal with a passphrase you share offline.
  </div>

  <VaultSection uid={uid} protocolId={p.id} senderName={p.senderName || 'Someone'} />
</div>

    </div>
  );
}

function PreviewPage() {
  const { id } = useParams();
  const [p, setP] = useState<any>(null);

  async function load() {
    if (!id) return;
    const snap = await getDoc(doc(db, 'protocols', id));
    setP(snap.exists() ? { id, ...snap.data() } : null);
  }
  useEffect(() => { load(); }, [id]);

  if (!p) return <div style={page}>Loading…</div>;

  const recipientCount = (p.releaseRecipients || []).length;
  const verificationEnabled = !!p.verificationEnabled;
  const bufferHours = p.executionBufferHours || 12;

  return (
    <div style={page}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h1 style={{ margin:0 }}>Release preview</h1>
        <div style={{ display:'flex', gap: 10 }}>
          <Link to={`/protocol/${p.id}`} style={{ ...btnGhost, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Back</Link>
          <Link to="/" style={{ ...btnGhost, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Home</Link>
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Simulation</h2>
        <div style={{ color:'#666', fontSize: 13 }}>
          This is a **simulation** of what the system will do after a missed check-in.
        </div>
        <ol style={{ marginTop: 12, color:'#222' }}>
          <li>Check-in missed → state becomes <b>MISSED_CHECKIN</b></li>
          <li>Escalation begins → <b>ESCALATING</b></li>
          {verificationEnabled ? (
            <li>Verification pings are sent to <b>accepted</b> contacts → <b>CONTACT_VERIFYING</b></li>
          ) : (
            <li>Verification disabled → skip contact pings</li>
          )}
          <li>Final warning is sent to recipients</li>
          <li>Execution buffer window: <b>{bufferHours} hours</b> (you can cancel with a check-in)</li>
          <li>Release executes: recipients receive a **secure portal link**</li>
        </ol>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Recipients</h2>
        <div style={{ color:'#666', fontSize: 13 }}>Count: {recipientCount}</div>
        <div style={{ marginTop: 10 }}>
          {(p.releaseRecipients || []).map((r:any, i:number) => (
            <div key={i} style={{ border:'1px solid #eee', borderRadius: 12, padding: 10, marginTop: 8 }}>
              {r.email || r.phone}
            </div>
          ))}
          {recipientCount === 0 && <div style={{ color:'#666' }}>Add recipients in Protocol page.</div>}
        </div>
      </div>
    </div>
  );
}

function VerifyPage() {
  const [params] = useSearchParams();
  const tokenId = params.get('tokenId') || '';
  const token = params.get('token') || '';
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  async function submitConsent(action: 'ACCEPT'|'DECLINE') {
    setBusy(true); setMsg('Submitting…');
    try {
      const call = httpsCallable(fn, 'submitConsent');
      const res:any = await call({ tokenId, token, action });
      setMsg(res.data?.message || 'Done.');
    } catch (e:any) {
      setMsg('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function submitStatus(action: 'SAFE'|'UNSURE'|'EMERGENCY') {
    setBusy(true); setMsg('Submitting…');
    try {
      const call = httpsCallable(fn, 'verifyTokenAction');
      const res:any = await call({ tokenId, token, action });
      setMsg(res.data?.message || 'Done.');
    } catch (e:any) {
      setMsg('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={page}>
      <h1 style={{ margin: 0 }}>Verification</h1>
      <div style={{ marginTop: 8, color:'#666' }}>
        This is automated. It does not confirm emergency. If concerned, verify through trusted channels.
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Consent</h2>
        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          <button disabled={busy} onClick={() => submitConsent('ACCEPT')} style={btnPrimary}>Accept</button>
          <button disabled={busy} onClick={() => submitConsent('DECLINE')} style={btnGhost}>Decline</button>
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Safety status</h2>
        <div style={{ display:'grid', gap: 10, marginTop: 12 }}>
          <button disabled={busy} onClick={() => submitStatus('SAFE')} style={btnPrimary}>SAFE</button>
          <button disabled={busy} onClick={() => submitStatus('UNSURE')} style={btnGhost}>UNSURE</button>
          <button disabled={busy} onClick={() => submitStatus('EMERGENCY')} style={{...btnGhost, borderColor:'#b00020', color:'#b00020'}}>EMERGENCY</button>
        </div>
      </div>

      <div style={{ marginTop: 12, color:'#555' }}>{msg}</div>
    </div>
  );
}

function PortalPage() {
  const [params] = useSearchParams();
  const tokenId = params.get('tokenId') || '';
  const token = params.get('token') || '';
  const [busy, setBusy] = useState(false);
  const [content, setContent] = useState<any>(null);
  const [msg, setMsg] = useState('');

  async function open() {
    setBusy(true); setMsg('Opening…');
    try {
      const call = httpsCallable(fn, 'openPortalLink');
      const res:any = await call({ tokenId, token });
      setContent(res.data?.content || null);
      setMsg(res.data?.message || 'Opened.');
    } catch (e:any) {
      setMsg('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={page}>
      <h1 style={{ margin:0 }}>Secure portal</h1>
      <div style={{ marginTop: 8, color:'#666' }}>
        Portal links are one-time and expire. If this fails, request a resend from the sender’s family.
      </div>

      <div style={card}>
        <button disabled={busy} onClick={open} style={btnPrimary}>Open content</button>
        <div style={{ marginTop: 12, color:'#555' }}>{msg}</div>
      </div>

{content && (
  <div style={card}>
    <h2 style={{ marginTop: 0 }}>Released content</h2>

    {content.text && (
      <div style={{ whiteSpace:'pre-wrap', marginBottom: 14 }}>{content.text}</div>
    )}

    {Array.isArray(content.vaultItems) && content.vaultItems.length > 0 && (
      <PortalVault items={content.vaultItems} />
    )}

    <div style={{ marginTop: 12, fontSize: 12, color:'#666' }}>
      Automated release notice: This does not confirm injury, death, or emergency.
    </div>
  </div>
)}
    </div>
  );
}

function AdminPage() {
  const uid = useUID();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  async function startCheckout(plan: 'personal'|'family'|'professional'|'business') {
    setBusy(true); setMsg('Starting checkout…');
    try {
      const call = httpsCallable(fn, 'createCheckoutSession');
      const res:any = await call({ plan });
      const url = res.data?.url;
      if (url) window.location.href = url;
      else setMsg('No checkout URL returned.');
    } catch (e:any) {
      setMsg('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function refreshMetrics() {
    setBusy(true); setMsg('Loading metrics…');
    try {
      const call = httpsCallable(fn, 'getAdminMetrics');
      const res:any = await call({});
      setMsg(JSON.stringify(res.data, null, 2));
    } catch (e:any) {
      setMsg('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={page}>
      <h1 style={{ margin:0 }}>Admin</h1>
      <div style={{ marginTop: 8, color:'#666' }}>UID: {uid || '…'}</div>

      <div style={card}>
        <h2 style={{ marginTop:0 }}>Checkout tests</h2>
        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          <button disabled={busy} onClick={() => startCheckout('personal')} style={btnPrimary}>Personal</button>
          <button disabled={busy} onClick={() => startCheckout('family')} style={btnGhost}>Family</button>
          <button disabled={busy} onClick={() => startCheckout('professional')} style={btnGhost}>Professional</button>
          <button disabled={busy} onClick={() => startCheckout('business')} style={btnGhost}>Business</button>
        </div>
      </div>

      <div style={card}>
        <h2 style={{ marginTop:0 }}>Monitoring</h2>
        <button disabled={busy} onClick={refreshMetrics} style={btnPrimary}>Refresh metrics</button>
        <pre style={{ marginTop: 12, background:'#fafafa', padding: 12, borderRadius: 12, overflow:'auto' }}>{msg}</pre>
      </div>

      <div style={{ marginTop: 14 }}>
        <Link to="/" style={{ ...btnGhost, textDecoration:'none', display:'inline-flex', alignItems:'center' }}>Back</Link>
      </div>
    </div>
  );
}

function VaultSection({ uid, protocolId, senderName }: { uid: string; protocolId: string; senderName: string }) {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [pass, setPass] = useState('');
  const [vaultKeyHint, setVaultKeyHint] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [items, setItems] = useState<any[]>([]);
  const [decryptPass, setDecryptPass] = useState('');
  const [openId, setOpenId] = useState<string>('');
  const [openText, setOpenText] = useState<string>('');

  async function load() {
    if (!uid || !protocolId) return;
    const qy = query(collection(db, 'vaultItems'), where('ownerUid','==', uid), where('protocolId','==', protocolId));
    const snap = await getDocs(qy);
    setItems(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  }

  useEffect(() => { load(); }, [uid, protocolId]);

  async function addItem() {
    if (!uid || !protocolId) return;
    if (!title.trim() || !body.trim() || !pass.trim()) { setMsg('Title, body, and passphrase required.'); return; }
    setBusy(true); setMsg('Encrypting…');
    try {
      const cipher = await encryptText(pass.trim(), body);
      await addDoc(collection(db, 'vaultItems'), {
        ownerUid: uid,
        protocolId,
        title: title.trim(),
        kind: 'text',
        cipher,
        hint: vaultKeyHint.trim() || null,
        createdAt: new Date()
      });
      setTitle(''); setBody(''); setPass(''); setVaultKeyHint('');
      setMsg('Saved (encrypted).');
      await load();
    } catch (e:any) {
      setMsg('Failed: ' + e.message);
    } finally {
      setBusy(false);
    }
  }

  async function decryptItem(item: any) {
    setBusy(true); setMsg('Decrypting…');
    try {
      const pt = await decryptText(decryptPass.trim(), item.cipher as VaultCipher);
      setOpenId(item.id);
      setOpenText(pt);
      setMsg('Decrypted locally (not uploaded).');
    } catch (e:any) {
      setMsg('Failed: wrong key or corrupted data.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ marginTop: 12 }}>
      <div style={{ display:'grid', gap: 10 }}>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Vault item title"
          style={{ padding:10, borderRadius:12, border:'1px solid #ddd' }} />
        <textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="Write the message to be released…"
          style={{ padding:10, borderRadius:12, border:'1px solid #ddd', minHeight: 110 }} />
        <input value={pass} onChange={e=>setPass(e.target.value)} placeholder="Encryption passphrase (share offline)"
          style={{ padding:10, borderRadius:12, border:'1px solid #ddd' }} />
        <input value={vaultKeyHint} onChange={e=>setVaultKeyHint(e.target.value)} placeholder="Optional hint (shown in portal)"
          style={{ padding:10, borderRadius:12, border:'1px solid #ddd' }} />

        <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
          <button disabled={busy} onClick={addItem} style={btnPrimary}>Add encrypted vault item</button>
          <span style={{ alignSelf:'center', color:'#555' }}>{msg}</span>
        </div>
      </div>

      <div style={{ marginTop: 16 }}>
        <div style={{ fontWeight: 800 }}>Stored items</div>
        <div style={{ color:'#666', fontSize: 13, marginTop: 6 }}>
          These are encrypted blobs in Firestore. Nothing raw is stored.
        </div>

        {items.length === 0 ? (
          <div style={{ marginTop: 10, color:'#666' }}>No vault items yet.</div>
        ) : (
          <div style={{ display:'grid', gap: 10, marginTop: 10 }}>
            {items.map((it) => (
              <div key={it.id} style={{ border:'1px solid #eee', borderRadius: 14, padding: 12 }}>
                <div style={{ display:'flex', justifyContent:'space-between', gap:10, flexWrap:'wrap' }}>
                  <div>
                    <div style={{ fontWeight: 700 }}>{it.title}</div>
                    <div style={{ color:'#666', fontSize: 12 }}>Type: {it.kind} &nbsp;|&nbsp; Hint: {it.hint || '—'}</div>
                  </div>
                  <div style={{ display:'flex', gap: 10, flexWrap:'wrap' }}>
                    <input value={decryptPass} onChange={e=>setDecryptPass(e.target.value)} placeholder="Passphrase to decrypt"
                      style={{ padding:10, borderRadius:12, border:'1px solid #ddd', minWidth: 200 }} />
                    <button disabled={busy} onClick={() => decryptItem(it)} style={btnGhost}>Decrypt</button>
                  </div>
                </div>

                {openId === it.id && (
                  <div style={{ marginTop: 10, background:'#fafafa', borderRadius: 12, padding: 12, whiteSpace:'pre-wrap' }}>
                    {openText}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PortalVault({ items }: { items: any[] }) {
  const [pass, setPass] = useState('');
  const [open, setOpen] = useState<Record<string,string>>({});
  const [msg, setMsg] = useState('');

  async function decryptOne(it: any) {
    setMsg('Decrypting…');
    try {
      const pt = await decryptText(pass.trim(), it.cipher as VaultCipher);
      setOpen(prev => ({ ...prev, [it.id]: pt }));
      setMsg('Decrypted locally.');
    } catch {
      setMsg('Failed: wrong passphrase or corrupted data.');
    }
  }

  return (
    <div>
      <div style={{ fontWeight: 800, marginTop: 10 }}>Vault items</div>
      <div style={{ color:'#666', fontSize: 13, marginTop: 6 }}>
        Enter the passphrase shared with you by the sender (offline).
      </div>
      <input value={pass} onChange={e=>setPass(e.target.value)} placeholder="Enter passphrase to decrypt"
        style={{ padding:10, borderRadius:12, border:'1px solid #ddd', marginTop: 10, width:'100%', maxWidth: 420 }} />

      <div style={{ display:'grid', gap: 10, marginTop: 12 }}>
        {items.map((it:any) => (
          <div key={it.id} style={{ border:'1px solid #eee', borderRadius: 14, padding: 12 }}>
            <div style={{ display:'flex', justifyContent:'space-between', gap:10, flexWrap:'wrap' }}>
              <div>
                <div style={{ fontWeight: 700 }}>{it.title || 'Vault item'}</div>
                <div style={{ color:'#666', fontSize: 12 }}>Hint: {it.hint || '—'}</div>
              </div>
              <button onClick={() => decryptOne(it)} style={btnGhost}>Decrypt</button>
            </div>
            {open[it.id] && (
              <div style={{ marginTop: 10, background:'#fafafa', borderRadius: 12, padding: 12, whiteSpace:'pre-wrap' }}>
                {open[it.id]}
              </div>
            )}
          </div>
        ))}
      </div>

      <div style={{ marginTop: 10, color:'#555', fontSize: 13 }}>{msg}</div>
    </div>
  );
}



export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/protocol/:id" element={<ProtocolPage />} />
      <Route path="/preview/:id" element={<PreviewPage />} />
      <Route path="/verify" element={<VerifyPage />} />
      <Route path="/portal" element={<PortalPage />} />
      <Route path="/admin" element={<AdminPage />} />
          </Routes>
  );
}
