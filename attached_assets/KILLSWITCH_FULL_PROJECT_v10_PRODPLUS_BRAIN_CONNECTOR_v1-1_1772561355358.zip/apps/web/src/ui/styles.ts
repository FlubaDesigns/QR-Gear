export const card: React.CSSProperties = { border:'1px solid #e7e7e7', borderRadius: 16, padding: 16, marginTop: 14, background:'#fff' };
export const page: React.CSSProperties = { maxWidth: 980, margin:'0 auto', padding: 18, fontFamily:'system-ui, -apple-system, Segoe UI, Roboto, Arial' };
export const btnPrimary: React.CSSProperties = { padding:'10px 14px', borderRadius: 12, border:'1px solid #0b57d0', background:'#0b57d0', color:'#fff', cursor:'pointer' };
export const btnGhost: React.CSSProperties = { padding:'10px 14px', borderRadius: 12, border:'1px solid #ddd', background:'#fff', color:'#111', cursor:'pointer' };
export const badge = (bg='#f5f5f5') => ({ display:'inline-block', padding:'2px 10px', borderRadius: 999, background:bg, fontSize: 12 });
