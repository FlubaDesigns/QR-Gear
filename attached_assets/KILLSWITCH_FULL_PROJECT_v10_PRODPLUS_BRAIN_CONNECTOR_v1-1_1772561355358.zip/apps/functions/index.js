const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

const { ensureDefaultSystemConfig } = require('./src/systemConfig/ensureDefaultSystemConfig');
const { processDeliveryQueue } = require('./src/delivery/processDeliveryQueue');
const { verifyTokenAction } = require('./src/verification/verifyTokenAction');
const { requestContactConsent } = require('./src/verification/requestContactConsent');
const { submitConsent } = require('./src/verification/submitConsent');
const { engineTick } = require('./src/engine/engineTick');
const { createCheckoutSession } = require('./src/stripe/createCheckoutSession');
const { stripeWebhook } = require('./src/stripe/stripeWebhook');
const { openPortalLink } = require('./src/portal/openPortalLink');
const { getAdminMetrics } = require('./src/admin/getAdminMetrics');
const { metricsTick } = require('./src/admin/metricsTick');

exports.initSystemConfig = functions.pubsub.schedule('every 24 hours').onRun(async () => {
  await ensureDefaultSystemConfig();
  return null;
});

exports.deliveryQueueTick = functions.pubsub.schedule('every 5 minutes').onRun(async () => {
  await processDeliveryQueue();
  return null;
});

exports.engineTick = functions.pubsub.schedule('every 15 minutes').onRun(async () => {
  await engineTick();
  return null;
});

exports.metricsTick = functions.pubsub.schedule('every 60 minutes').onRun(async () => {
  await metricsTick();
  return null;
});

exports.verifyTokenAction = verifyTokenAction;
exports.requestContactConsent = requestContactConsent;
exports.submitConsent = submitConsent;

exports.createCheckoutSession = createCheckoutSession;
exports.stripeWebhook = stripeWebhook;

exports.openPortalLink = openPortalLink;
exports.getAdminMetrics = getAdminMetrics;
