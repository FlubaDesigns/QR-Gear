const admin = require('firebase-admin');
const { redactEmail, redactPhone, hash } = require('../system/redact');

function sanitizeMetadata(metadata = {}) {
  const out = {};
  for (const [k, v] of Object.entries(metadata || {})) {
    if (v == null) { out[k] = v; continue; }
    const lk = k.toLowerCase();
    if (lk.includes('email')) out[k] = redactEmail(v);
    else if (lk.includes('phone')) out[k] = redactPhone(v);
    else if (lk.includes('token')) out[k] = '[redacted]';
    else if (lk.includes('secret')) out[k] = '[redacted]';
    else if (typeof v === 'string' && v.length > 300) out[k] = v.slice(0, 300) + '…';
    else out[k] = v;
  }
  return out;
}

exports.logAudit = async function logAudit({ ownerUid, protocolId=null, eventType, metadata={} }) {
  const db = admin.firestore();
  await db.collection('auditLogs').add({
    ownerUidHash: hash(ownerUid),
    ownerUid: ownerUid === 'system' ? 'system' : '[redacted]',
    protocolId,
    eventType,
    metadata: sanitizeMetadata(metadata),
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
};
