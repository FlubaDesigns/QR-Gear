const crypto = require('crypto');
exports.randomToken = function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
};
exports.sha256 = function sha256(text) {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
};
