const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { sha256 } = require('../crypto/tokens');
const { logAudit } = require('../audit/logAudit');

exports.submitConsent = functions.https.onCall({ enforceAppCheck: true }, async (data, context) => {
  const { enforceRateLimit } = require('../system/rateLimit');
  if (context.auth) await enforceRateLimit({ uid: context.auth.uid, key: 'submitConsent', maxPerMinute: 30 });

  const tokenId = String(data.tokenId || '');
  const token = String(data.token || '');
  const action = String(data.action || '');
  if (!tokenId || !token || !action) throw new functions.https.HttpsError('invalid-argument', 'Missing tokenId/token/action');
  if (!['ACCEPT','DECLINE'].includes(action)) throw new functions.https.HttpsError('invalid-argument', 'Invalid action');

  const db = admin.firestore();
  const ref = db.doc(`verificationTokens/${tokenId}`);
  const snap = await ref.get();
  if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Token not found');

  const t = snap.data();
  const now = admin.firestore.Timestamp.now();

  if (t.kind !== 'CONSENT') throw new functions.https.HttpsError('failed-precondition', 'Not a consent token');
  if (t.consumedAt) throw new functions.https.HttpsError('failed-precondition', 'Token already used');
  if (t.expiresAt && t.expiresAt.toMillis() < now.toMillis()) throw new functions.https.HttpsError('failed-precondition', 'Token expired');

  if (sha256(token) !== t.tokenHash) throw new functions.https.HttpsError('permission-denied', 'Invalid token');

  await ref.update({ consumedAt: now, action, actionAt: now });
  const cRef = db.doc(`verificationContacts/${t.contactId}`);
  await cRef.set({ consentStatus: action === 'ACCEPT' ? 'accepted' : 'declined', consentedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });

  await logAudit({ ownerUid: t.ownerUid, protocolId: t.protocolId, eventType: 'contact_consent_submitted', metadata: { tokenId, contactId: t.contactId, action } });

  return { ok: true, message: action === 'ACCEPT' ? 'Consent accepted. Thank you.' : 'Consent declined. Thank you.' };
});
