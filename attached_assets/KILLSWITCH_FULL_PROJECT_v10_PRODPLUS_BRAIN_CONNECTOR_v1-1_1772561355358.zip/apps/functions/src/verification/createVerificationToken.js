const admin = require('firebase-admin');
const functions = require('firebase-functions');
const { randomToken, sha256 } = require('../crypto/tokens');
const { logAudit } = require('../audit/logAudit');

exports.createVerificationToken = async function createVerificationToken({ ownerUid, protocolId, contactId, kind, expiresMinutes = 60*24*3 }) {
  const db = admin.firestore();
  const tokenSecret = randomToken(32);
  const tokenHash = sha256(tokenSecret);
  const ref = db.collection('verificationTokens').doc();
  const expiresAt = admin.firestore.Timestamp.fromMillis(Date.now() + expiresMinutes*60*1000);

  await ref.set({ ownerUid, protocolId, contactId, kind, tokenHash, expiresAt, consumedAt: null, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  await logAudit({ ownerUid, protocolId, eventType: 'verification_token_created', metadata: { tokenId: ref.id, kind, expiresMinutes } });

  const baseUrl = (functions.config().app && functions.config().app.base_url) || '';
  const url = `${baseUrl}/verify?tokenId=${encodeURIComponent(ref.id)}&token=${encodeURIComponent(tokenSecret)}`;
  return { tokenId: ref.id, tokenSecret, url };
};
