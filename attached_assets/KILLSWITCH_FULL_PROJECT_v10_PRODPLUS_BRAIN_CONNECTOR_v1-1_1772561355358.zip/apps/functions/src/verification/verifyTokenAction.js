const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { sha256 } = require('../crypto/tokens');
const { logAudit } = require('../audit/logAudit');

exports.verifyTokenAction = functions.https.onCall({ enforceAppCheck: true }, async (data, context) => {
  const { enforceRateLimit } = require('../system/rateLimit');
  if (context.auth) await enforceRateLimit({ uid: context.auth.uid, key: 'verifyTokenAction', maxPerMinute: 30 });

  const tokenId = String(data.tokenId || '');
  const token = String(data.token || '');
  const action = String(data.action || '');

  if (!tokenId || !token || !action) throw new functions.https.HttpsError('invalid-argument', 'Missing tokenId/token/action');
  if (!['SAFE','UNSURE','EMERGENCY'].includes(action)) throw new functions.https.HttpsError('invalid-argument', 'Invalid action');

  const db = admin.firestore();
  const ref = db.doc(`verificationTokens/${tokenId}`);
  const snap = await ref.get();
  if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Token not found');
  const t = snap.data();
  const now = admin.firestore.Timestamp.now();

  if (t.kind !== 'STATUS') throw new functions.https.HttpsError('failed-precondition', 'Not a status token');
  if (t.consumedAt) throw new functions.https.HttpsError('failed-precondition', 'Token already used');
  if (t.expiresAt && t.expiresAt.toMillis() < now.toMillis()) throw new functions.https.HttpsError('failed-precondition', 'Token expired');
  if (sha256(token) !== t.tokenHash) throw new functions.https.HttpsError('permission-denied', 'Invalid token');

  await ref.update({ consumedAt: now, action, actionAt: now });

  const pRef = db.doc(`protocols/${t.protocolId}`);
  const pSnap = await pRef.get();
  if (pSnap.exists) {
    const p = pSnap.data() || {};
    const cfgSnap = await db.doc('systemConfig/global').get();
    const cfg = cfgSnap.exists ? cfgSnap.data() : {};
    const safeDelayDays = (p.safeConfirmDelayDays ?? (cfg.safety?.default_safe_delay_days ?? 7));
    const unsureDelayHours = (cfg.safety?.unsure_delay_hours ?? 48);
    const maxDelays = (p.maxDelaysPerCycle ?? (cfg.safety?.max_delays_per_cycle ?? 2));
    const delaysUsed = (p.delaysUsedThisCycle ?? 0);

    let applied = 'proceed';
    if (action === 'SAFE' && delaysUsed < maxDelays) {
      const delayMs = safeDelayDays * 24*60*60*1000;
      applied = 'delayed_safe';
      await pRef.update({ delaysUsedThisCycle: delaysUsed + 1, nextCheckInAt: admin.firestore.Timestamp.fromMillis(Date.now() + delayMs), lastVerificationAction: action, lastVerificationAt: now, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    } else if (action === 'UNSURE') {
      const delayMs = unsureDelayHours * 60*60*1000;
      applied = 'delayed_unsure';
      await pRef.update({ nextCheckInAt: admin.firestore.Timestamp.fromMillis(Date.now() + delayMs), lastVerificationAction: action, lastVerificationAt: now, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    } else {
      applied = action === 'EMERGENCY' ? 'proceed_emergency' : 'safe_delay_limit_reached';
      await pRef.update({ lastVerificationAction: action, lastVerificationAt: now, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    }

    await logAudit({ ownerUid: t.ownerUid, protocolId: t.protocolId, eventType: 'verification_action_applied', metadata: { tokenId, action, applied } });
  }

  return { ok: true, message: 'Response recorded. Thank you.' };
});
