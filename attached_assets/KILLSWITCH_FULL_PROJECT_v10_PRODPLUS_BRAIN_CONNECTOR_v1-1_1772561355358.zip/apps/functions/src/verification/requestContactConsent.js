const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { createVerificationToken } = require('./createVerificationToken');
const { enqueueDelivery } = require('../delivery/enqueueDelivery');
const { logAudit } = require('../audit/logAudit');

exports.requestContactConsent = functions.https.onCall({ enforceAppCheck: true }, async (data, context) => {
  const { enforceRateLimit } = require('../system/rateLimit');
  if (context.auth) await enforceRateLimit({ uid: context.auth.uid, key: 'requestContactConsent', maxPerMinute: 30 });

  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Sign in required');
  const ownerUid = context.auth.uid;
  const contactId = String(data.contactId || '');
  if (!contactId) throw new functions.https.HttpsError('invalid-argument', 'Missing contactId');

  const db = admin.firestore();
  const cRef = db.doc(`verificationContacts/${contactId}`);
  const cSnap = await cRef.get();
  if (!cSnap.exists) throw new functions.https.HttpsError('not-found', 'Contact not found');
  const c = cSnap.data();
  if (c.ownerUid !== ownerUid) throw new functions.https.HttpsError('permission-denied', 'Not your contact');

  const protocolId = c.protocolId || null;
  const { url, tokenId } = await createVerificationToken({ ownerUid, protocolId, contactId, kind: 'CONSENT', expiresMinutes: 60*24*7 });

  const subject = 'Consent request: verification contact (Killswitch)';
  const html = `
    <p>${escapeHtml(c.ownerName || 'Someone')} added you as an optional verification contact.</p>
    <p>If you accept, you may be asked in the future to confirm whether they are safe if they miss check-ins.</p>
    <p><strong>You can decline.</strong></p>
    <p><a href="${url}">Open consent page</a></p>
    <p style="font-size:12px;color:#666;">This is a consent request only. It does not indicate an emergency.</p>
  `;

  await enqueueDelivery({
    ownerUid, protocolId,
    channel: 'email', to: c.email, subject, html,
    noticeIncluded: false, templateVersion: 'consent-v1',
    idempotencyKey: `consent:${contactId}:${tokenId}`
  });

  await cRef.set({ consentStatus: 'pending', lastConsentRequestedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  await logAudit({ ownerUid, protocolId, eventType: 'contact_consent_requested', metadata: { contactId, tokenId } });

  return { ok: true, message: 'Consent request queued.' };
});

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
