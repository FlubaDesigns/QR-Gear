exports.DEFAULT_SYSTEM_CONFIG = {
  pricing: {
    personal_monthly: 5, personal_yearly: 49,
    family_monthly: 12, family_yearly: 120,
    professional_monthly: 19, professional_yearly: 190,
    business_monthly: 49, business_yearly: 490
  },
  military: {
    free_active_duty: true,
    allow_veterans: false,
    military_email_domains: ['.mil'],
    manual_override_enabled: true
  },
  safety: {
    default_safe_delay_days: 7,
    max_delays_per_cycle: 2,
    grace_window_hours: 48,
    execution_buffer_hours: 12,
    min_execution_buffer_hours: 6,
    unsure_delay_hours: 48
  },
  portal: {
    portal_link_expires_hours: 168, // 7 days
    portal_link_one_time: true
  },
  features: {
    sms_delivery: false,
    email_delivery: true,
    secure_portal: true,
    verification_contacts: true
  },
  stripe: {
    price_personal_monthly: "",
    price_family_monthly: "",
    price_professional_monthly: "",
    price_business_monthly: ""
  }
};
