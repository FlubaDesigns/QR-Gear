const admin = require('firebase-admin');
const { DEFAULT_SYSTEM_CONFIG } = require('./defaultConfig');

function deepMerge(defaults, current) {
  if (Array.isArray(defaults) || Array.isArray(current)) return current ?? defaults;
  if (defaults && typeof defaults === 'object') {
    const out = { ...defaults };
    for (const k of Object.keys(current || {})) {
      out[k] = (k in defaults) ? deepMerge(defaults[k], current[k]) : current[k];
    }
    return out;
  }
  return current ?? defaults;
}

exports.ensureDefaultSystemConfig = async function ensureDefaultSystemConfig() {
  const db = admin.firestore();
  const ref = db.doc('systemConfig/global');
  const snap = await ref.get();
  if (!snap.exists) {
    await ref.set({ ...DEFAULT_SYSTEM_CONFIG,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    return;
  }
  const merged = deepMerge(DEFAULT_SYSTEM_CONFIG, snap.data() || {});
  await ref.set({ ...merged, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
};
