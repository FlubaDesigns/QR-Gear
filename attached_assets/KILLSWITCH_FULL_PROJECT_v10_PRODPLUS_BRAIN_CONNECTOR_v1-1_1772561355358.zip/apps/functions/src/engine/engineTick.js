const admin = require('firebase-admin');
const { logAudit } = require('../audit/logAudit');
const { raiseAlert } = require('../system/alerts');
const { claimIdempotency } = require('../system/idempotency');
const { createVerificationToken } = require('../verification/createVerificationToken');
const { enqueueDelivery } = require('../delivery/enqueueDelivery');
const { buildDeliveryPayload } = require('../delivery/buildDeliveryPayload');
const { createPortalLink } = require('../portal/createPortalLink');
const { emitIntegrationEvent } = require('../integrations/emitIntegrationEvent');

exports.engineTick = async function engineTick() {
  const db = admin.firestore();
  const now = admin.firestore.Timestamp.now();

  const due = await db.collection('protocols')
    .where('nextCheckInAt', '<=', now)
    .limit(50)
    .get();

  for (const doc of due.docs) {
    const p = doc.data() || {};
    const protocolId = doc.id;
    const ownerUid = p.ownerUid;
    const state = p.state || 'ACTIVE';

    try {
      const windowKey = Math.floor(Date.now() / (15*60*1000));
      const idem = await claimIdempotency(`engine:${protocolId}:${state}:${windowKey}`, 60);
      if (!idem) continue;

      // If user already checked in and set ACTIVE, skip engine actions.
      if (state === 'ACTIVE') {
        // ACTIVE due means missed check-in
        await doc.ref.update({ state: 'MISSED_CHECKIN', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'ACTIVE', to:'MISSED_CHECKIN' } });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'ACTIVE', to:'MISSED_CHECKIN' } });
        continue;
      }

      if (state === 'MISSED_CHECKIN') {
        await doc.ref.update({ state: 'ESCALATING', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'MISSED_CHECKIN', to:'ESCALATING' } });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'MISSED_CHECKIN', to:'ESCALATING' } });
        continue;
      }

      if (state === 'ESCALATING') {
        if (p.verificationEnabled) {
          await doc.ref.update({ state: 'CONTACT_VERIFYING', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
          await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'ESCALATING', to:'CONTACT_VERIFYING' } });
          await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'ESCALATING', to:'CONTACT_VERIFYING' } });

          const contacts = await db.collection('verificationContacts')
            .where('ownerUid', '==', ownerUid)
            .where('protocolId', '==', protocolId)
            .where('consentStatus', '==', 'accepted')
            .limit(10)
            .get();

          for (const cDoc of contacts.docs) {
            const c = cDoc.data();
            const { url, tokenId } = await createVerificationToken({ ownerUid, protocolId, contactId: cDoc.id, kind: 'STATUS', expiresMinutes: 60*24*2 });
            const subject = `Safety check request for ${escapeHtml(p.senderName || 'a contact')}`;
            const html = `
              <p>This is an automated request because ${escapeHtml(p.senderName || 'a contact')} missed scheduled check-ins.</p>
              <p>This does <strong>not</strong> confirm an emergency.</p>
              <p>Please respond:</p>
              <p><a href="${url}">Open response page</a></p>
            `;
            await enqueueDelivery({
              ownerUid, protocolId, channel:'email', to:c.email, subject, html,
              noticeIncluded:false, templateVersion:'verify-ping-v1',
              idempotencyKey:`statusping:${protocolId}:${cDoc.id}:${tokenId}`
            });
            await logAudit({ ownerUid, protocolId, eventType:'verification_ping_queued', metadata:{ contactId:cDoc.id, tokenId }});
          }

          await doc.ref.update({ nextCheckInAt: admin.firestore.Timestamp.fromMillis(Date.now() + 2*60*60*1000) });
          continue;
        }

        await doc.ref.update({ state: 'FINAL_WARNING', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'ESCALATING', to:'FINAL_WARNING' } });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'ESCALATING', to:'FINAL_WARNING' } });
        continue;
      }

      if (state === 'CONTACT_VERIFYING') {
        await doc.ref.update({ state: 'FINAL_WARNING', updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'CONTACT_VERIFYING', to:'FINAL_WARNING' } });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'CONTACT_VERIFYING', to:'FINAL_WARNING' } });
        continue;
      }

      if (state === 'FINAL_WARNING') {
        const recipients = Array.isArray(p.releaseRecipients) ? p.releaseRecipients : [];
        for (const r of recipients) {
          if (!r.email) continue;
          const payload = buildDeliveryPayload({
            senderName: p.senderName || 'Someone',
            subject: 'Automated release warning (Killswitch)',
            bodyHtml: `<p>This is a final automated warning. A release will occur after the buffer window unless a check-in is recorded.</p>`
          });
          await enqueueDelivery({
            ownerUid, protocolId, channel:'email', to:r.email,
            subject: payload.subject, html: payload.html,
            noticeIncluded: payload.noticeIncluded, templateVersion: payload.templateVersion,
            idempotencyKey: `finalwarn:${protocolId}:${r.email}`
          });
        }

        const cfgSnap = await db.doc('systemConfig/global').get();
        const cfg = cfgSnap.exists ? cfgSnap.data() : {};
        const bufferHours = p.executionBufferHours || cfg.safety?.execution_buffer_hours || 12;
        await doc.ref.update({
          state: 'EXECUTION_BUFFER',
          bufferEndsAt: admin.firestore.Timestamp.fromMillis(Date.now() + bufferHours*60*60*1000),
          nextCheckInAt: admin.firestore.Timestamp.fromMillis(Date.now() + bufferHours*60*60*1000),
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'FINAL_WARNING', to:'EXECUTION_BUFFER', bufferHours } });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'FINAL_WARNING', to:'EXECUTION_BUFFER', bufferHours } });
        continue;
      }

      if (state === 'EXECUTION_BUFFER') {
        // If state changed by user to ACTIVE, we won't be here. Buffer expired -> execute.
        await doc.ref.update({ state: 'EXECUTED', executedAt: admin.firestore.FieldValue.serverTimestamp(), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
        await logAudit({ ownerUid, protocolId, eventType: 'state_transition', metadata: { from:'EXECUTION_BUFFER', to:'EXECUTED' } });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'protocol_state_transition', details:{ from:'EXECUTION_BUFFER', to:'EXECUTED' } });

        // Bundle vault items (ciphertext only). Never send raw content by email/SMS.
const vaultSnap = await db.collection('vaultItems')
  .where('ownerUid', '==', ownerUid)
  .where('protocolId', '==', protocolId)
  .orderBy('createdAt', 'asc')
  .limit(20)
  .get();

const vaultItems = vaultSnap.docs.map(d => {
  const v = d.data() || {};
  return {
    id: d.id,
    title: v.title || 'Vault item',
    kind: v.kind || 'text',
    hint: v.hint || null,
    cipher: v.cipher || null
  };
});

const portalPayload = {
  text: `This message was released automatically for ${p.senderName || 'a contact'}.`,
  vaultItems
};

        const portal = await createPortalLink({ ownerUid, protocolId, payload: portalPayload });
        await emitIntegrationEvent({ ownerUid, protocolId, type:'release_portal_created', details:{ portalId: portal.portalId } });

        // Send recipients a portal link (rather than raw content)
        const recipients = Array.isArray(p.releaseRecipients) ? p.releaseRecipients : [];
        for (const r of recipients) {
          if (r.email) {
            const payload = buildDeliveryPayload({
              senderName: p.senderName || 'Someone',
              subject: 'Automated message release (secure portal)',
              bodyHtml: `<p>A secure portal has been created for the released message.</p>
                         <p><a href="${portal.url}">Open secure portal</a></p>`
            });
            await enqueueDelivery({
              ownerUid, protocolId, channel:'email', to:r.email,
              subject: payload.subject, html: payload.html,
              noticeIncluded: payload.noticeIncluded, templateVersion: payload.templateVersion,
              idempotencyKey: `release:${protocolId}:${r.email}`,
              fallbackToSms: r.phone ? { phone: r.phone, message: `Killswitch: secure portal available for ${p.senderName||'a contact'}. Verify directly if concerned.` } : null
            });
          }
        }

        continue;
      }

    } catch (err) {
      const msg = (err && err.message) ? err.message : String(err);
      await raiseAlert({ severity:'critical', title:'engineTick failure', details:{ protocolId, error: msg.substring(0,500) } });
      try { await logAudit({ ownerUid: ownerUid || 'unknown', protocolId, eventType:'engine_tick_error', metadata:{ error: msg.substring(0,300) } }); } catch {}
    }
  }
};

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
