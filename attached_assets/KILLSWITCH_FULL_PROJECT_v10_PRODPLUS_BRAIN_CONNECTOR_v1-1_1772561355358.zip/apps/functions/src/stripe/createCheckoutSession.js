const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Stripe = require('stripe');
const { logAudit } = require('../audit/logAudit');

exports.createCheckoutSession = functions.https.onCall({ enforceAppCheck: true }, async (data, context) => {
  const { enforceRateLimit } = require('../system/rateLimit');
  if (context.auth) await enforceRateLimit({ uid: context.auth.uid, key: 'createCheckoutSession', maxPerMinute: 30 });

  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Sign in required');
  const ownerUid = context.auth.uid;
  const plan = String(data.plan || '');
  if (!['personal','family','professional','business'].includes(plan)) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid plan');
  }

  const stripeSecret = functions.config().stripe && functions.config().stripe.secret;
  if (!stripeSecret) throw new Error('Missing stripe.secret in functions config');
  const stripe = Stripe(stripeSecret);

  const db = admin.firestore();
  const cfgSnap = await db.doc('systemConfig/global').get();
  const cfg = cfgSnap.exists ? cfgSnap.data() : {};
  const priceId = cfg?.stripe?.[`price_${plan}_monthly`];
  if (!priceId) throw new functions.https.HttpsError('failed-precondition', `Missing Stripe price id for ${plan}`);

  const baseUrl = (functions.config().app && functions.config().app.base_url) || '';
  const success_url = `${baseUrl}/?checkout=success`;
  const cancel_url = `${baseUrl}/?checkout=cancel`;

  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [{ price: priceId, quantity: 1 }],
    success_url,
    cancel_url,
    subscription_data: { metadata: { ownerUid, plan } },
    metadata: { ownerUid, plan }
  });

  await logAudit({ ownerUid, eventType:'stripe_checkout_session_created', metadata:{ plan, sessionId: session.id } });
  return { url: session.url };
});
