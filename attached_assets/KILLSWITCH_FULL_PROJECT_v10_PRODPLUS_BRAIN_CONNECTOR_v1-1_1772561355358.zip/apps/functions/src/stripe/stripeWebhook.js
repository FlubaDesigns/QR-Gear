const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Stripe = require('stripe');
const { logAudit } = require('../audit/logAudit');
const { raiseAlert } = require('../system/alerts');

exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const secret = functions.config().stripe && functions.config().stripe.webhook_secret;
  const stripeSecret = functions.config().stripe && functions.config().stripe.secret;
  if (!secret || !stripeSecret) return res.status(500).send('Stripe secrets not configured');

  const stripe = Stripe(stripeSecret);
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, secret);
  } catch (err) {
    try { await logAudit({ ownerUid:'system', eventType:'stripe_webhook_invalid_signature', metadata:{ error: err.message } }); } catch {}
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  const db = admin.firestore();
  try {
    if (event.type === 'checkout.session.completed') {
      const sess = event.data.object;
      if (sess.customer && sess.metadata && sess.metadata.ownerUid) {
        await db.doc(`stripeCustomers/${String(sess.customer)}`).set({
          ownerUid: String(sess.metadata.ownerUid),
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
      }
      await logAudit({ ownerUid: sess.metadata?.ownerUid || 'unknown', eventType:'stripe_checkout_completed', metadata:{ sessionId: String(sess.id) } });
    }

    if (event.type.startsWith('customer.subscription.')) {
      const sub = event.data.object;
      const ownerUid = sub.metadata?.ownerUid || 'unknown';
      await db.collection('subscriptions').doc(String(sub.id)).set({
        ownerUid,
        stripeCustomerId: String(sub.customer),
        status: String(sub.status),
        plan: sub.metadata?.plan || null,
        current_period_end: sub.current_period_end ? Number(sub.current_period_end) : null,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });

      await logAudit({ ownerUid, eventType:'stripe_subscription_upserted', metadata:{ subId: String(sub.id), status: String(sub.status) } });
    }

    res.json({ received: true });
  } catch (err) {
    await raiseAlert({ severity:'critical', title:'Stripe webhook handler error', details:{ eventType: event.type, error: (err.message||String(err)).substring(0,400) } });
    try { await logAudit({ ownerUid:'system', eventType:'stripe_webhook_handler_error', metadata:{ eventType: event.type, error: err.message } }); } catch {}
    res.status(500).send('Webhook handler error');
  }
});
