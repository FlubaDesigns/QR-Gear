const admin = require('firebase-admin');
const { logAudit } = require('../audit/logAudit');

exports.metricsTick = async function metricsTick() {
  const db = admin.firestore();
  const now = new Date();
  const dayId = now.toISOString().slice(0,10);

  const qQueued = await db.collection('deliveryQueue').where('status','==','queued').get();
  const qAlerts = await db.collection('systemAlerts').get();

  await db.doc(`metricsDaily/${dayId}`).set({
    deliveryQueueQueued: qQueued.size,
    systemAlertsTotal: qAlerts.size,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });

  await logAudit({ ownerUid:'system', eventType:'metrics_tick', metadata:{ dayId, deliveryQueueQueued: qQueued.size, systemAlertsTotal: qAlerts.size } });
};
