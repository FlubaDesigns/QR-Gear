const functions = require('firebase-functions');
const admin = require('firebase-admin');

exports.getAdminMetrics = functions.https.onCall({ enforceAppCheck: true }, async (data, context) => {
  const { enforceRateLimit } = require('../system/rateLimit');
  if (context.auth) await enforceRateLimit({ uid: context.auth.uid, key: 'getAdminMetrics', maxPerMinute: 30 });

  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Sign in required');
  const isAdmin = context.auth.token && context.auth.token.role === 'admin';
  if (!isAdmin) throw new functions.https.HttpsError('permission-denied', 'Admin only');

  const db = admin.firestore();
  const now = new Date().toISOString().slice(0,10);
  const mSnap = await db.doc(`metricsDaily/${now}`).get();
  const alertsSnap = await db.collection('systemAlerts').orderBy('createdAt','desc').limit(10).get();

  return {
    day: now,
    metrics: mSnap.exists ? mSnap.data() : {},
    recentAlerts: alertsSnap.docs.map(d => ({ id: d.id, ...d.data() }))
  };
});
