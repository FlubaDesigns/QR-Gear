import { getFirestore, FieldValue } from "firebase-admin/firestore";

/**
 * Idempotency guard.
 * Stores a key under `idempotencyKeys/{key}`.
 * Returns true if acquired, false if already exists.
 */
export async function acquireIdempotencyKey(key: string, ttlHours = 168): Promise<boolean> {
  const db = getFirestore();
  const ref = db.collection("idempotencyKeys").doc(key);
  const snap = await ref.get();
  if (snap.exists) return false;
  await ref.set({
    key,
    createdAt: FieldValue.serverTimestamp(),
    expiresAt: FieldValue.serverTimestamp(), // optional: replaced by scheduler cleanup later
    ttlHours,
  });
  return true;
}
