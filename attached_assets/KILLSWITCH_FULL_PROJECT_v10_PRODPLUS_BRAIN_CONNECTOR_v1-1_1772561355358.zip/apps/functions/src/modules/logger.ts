export type LogLevel = "debug" | "info" | "warn" | "error";

export function log(level: LogLevel, msg: string, ctx: Record<string, any> = {}) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    msg,
    ...ctx,
  };
  // Firebase Functions reads console.* into Cloud Logging
  if (level === "error") console.error(JSON.stringify(entry));
  else if (level === "warn") console.warn(JSON.stringify(entry));
  else console.log(JSON.stringify(entry));
}

export function withTiming<T>(name: string, fn: () => Promise<T>, ctx: Record<string, any> = {}): Promise<T> {
  const start = Date.now();
  return fn().then((result) => {
    log("info", name, { ...ctx, ok: true, ms: Date.now() - start });
    return result;
  }).catch((err) => {
    log("error", name, { ...ctx, ok: false, ms: Date.now() - start, err: String(err?.message || err) });
    throw err;
  });
}
