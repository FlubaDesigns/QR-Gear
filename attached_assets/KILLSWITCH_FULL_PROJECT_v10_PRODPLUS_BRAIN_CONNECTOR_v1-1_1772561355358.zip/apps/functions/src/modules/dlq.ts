import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { writeSystemEvent } from "./systemEvents";

export async function pushToDLQ(kind: string, payload: Record<string, any>, err?: any) {
  const db = getFirestore();
  const doc = {
    kind,
    payload,
    err: err ? String(err?.message || err) : null,
    createdAt: FieldValue.serverTimestamp(),
    retryCount: 0,
    status: "failed",
  };
  await db.collection("deadLetterQueue").add(doc);
  await writeSystemEvent({
    type: "dlq_push",
    severity: "error",
    message: `DLQ push: ${kind}`,
    context: { kind },
  });
}
