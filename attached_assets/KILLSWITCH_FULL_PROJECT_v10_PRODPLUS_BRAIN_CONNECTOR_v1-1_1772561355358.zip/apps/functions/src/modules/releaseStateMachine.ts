export type ReleaseState =
  | "draft"
  | "scheduled"
  | "armed"
  | "verification_sent"
  | "verified"
  | "released"
  | "cancelled"
  | "expired"
  | "failed";

const allowed: Record<ReleaseState, ReleaseState[]> = {
  draft: ["scheduled", "cancelled"],
  scheduled: ["armed", "cancelled", "expired"],
  armed: ["verification_sent", "cancelled", "expired"],
  verification_sent: ["verified", "cancelled", "expired", "failed"],
  verified: ["released", "cancelled", "failed"],
  released: [],
  cancelled: [],
  expired: [],
  failed: ["cancelled"], // allow manual cleanup
};

export function canTransition(from: ReleaseState, to: ReleaseState): boolean {
  return (allowed[from] || []).includes(to);
}

export function assertTransition(from: ReleaseState, to: ReleaseState) {
  if (!canTransition(from, to)) {
    throw new Error(`Invalid state transition: ${from} -> ${to}`);
  }
}
