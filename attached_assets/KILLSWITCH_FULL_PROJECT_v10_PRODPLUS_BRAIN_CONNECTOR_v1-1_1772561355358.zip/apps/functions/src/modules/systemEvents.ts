import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { log } from "./logger";

export type SystemEvent = {
  type: string;
  severity: "info" | "warn" | "error";
  message: string;
  context?: Record<string, any>;
  createdAt?: any;
};

export async function writeSystemEvent(evt: SystemEvent) {
  const db = getFirestore();
  const doc = {
    ...evt,
    context: evt.context || {},
    createdAt: FieldValue.serverTimestamp(),
  };
  await db.collection("systemEvents").add(doc);
  log(evt.severity === "error" ? "error" : evt.severity, `systemEvent:${evt.type}`, { message: evt.message });
}
