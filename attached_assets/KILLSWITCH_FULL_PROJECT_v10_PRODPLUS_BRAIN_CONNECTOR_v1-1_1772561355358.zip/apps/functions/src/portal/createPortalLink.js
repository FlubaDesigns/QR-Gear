const admin = require('firebase-admin');
const functions = require('firebase-functions');
const { randomToken, sha256 } = require('../crypto/tokens');
const { logAudit } = require('../audit/logAudit');

exports.createPortalLink = async function createPortalLink({ ownerUid, protocolId, payload }) {
  const db = admin.firestore();
  const cfgSnap = await db.doc('systemConfig/global').get();
  const cfg = cfgSnap.exists ? cfgSnap.data() : {};
  const expiresHours = cfg.portal?.portal_link_expires_hours ?? 168;
  const oneTime = cfg.portal?.portal_link_one_time ?? true;

  const tokenSecret = randomToken(32);
  const tokenHash = sha256(tokenSecret);
  const ref = db.collection('portalLinks').doc();
  const expiresAt = admin.firestore.Timestamp.fromMillis(Date.now() + expiresHours*60*60*1000);

  await ref.set({
    ownerUid,
    protocolId,
    tokenHash,
    oneTime,
    expiresAt,
    consumedAt: null,
    payload,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });

  await logAudit({ ownerUid, protocolId, eventType: 'portal_link_created', metadata: { portalId: ref.id, expiresHours, oneTime } });

  const baseUrl = (functions.config().app && functions.config().app.base_url) || '';
  const url = `${baseUrl}/portal?tokenId=${encodeURIComponent(ref.id)}&token=${encodeURIComponent(tokenSecret)}`;
  return { portalId: ref.id, tokenSecret, url };
};
