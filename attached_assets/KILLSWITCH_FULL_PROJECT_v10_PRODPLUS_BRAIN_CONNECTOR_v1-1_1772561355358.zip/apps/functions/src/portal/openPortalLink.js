const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { sha256 } = require('../crypto/tokens');
const { logAudit } = require('../audit/logAudit');
const { emitIntegrationEvent } = require('../integrations/emitIntegrationEvent');

exports.openPortalLink = functions.https.onCall(async (data, context) => {
  const tokenId = String(data.tokenId || '');
  const token = String(data.token || '');
  if (!tokenId || !token) throw new functions.https.HttpsError('invalid-argument', 'Missing token');

  // Recipient is not authenticated. We allow this callable to run without auth,
  // but strictly validate token+expiry+one-time.
  const db = admin.firestore();
  // rate limit portal opens (anti-abuse). Not using UID (recipients may be unauthenticated).
  const crypto = require('crypto');
  const admin = require('firebase-admin');
  const bucket = Math.floor(Date.now()/60000);
  const rlId = crypto.createHash('sha256').update(String(tokenId)).digest('hex').slice(0,16) + ':' + bucket;
  const rlRef = db.doc(`portalOpenLimits/${rlId}`);
  await db.runTransaction(async (tx)=>{ const s=await tx.get(rlRef); const c=(s.exists?(s.data().count||0):0)+1; tx.set(rlRef,{count:c,createdAt: admin.firestore.FieldValue.serverTimestamp()},{merge:true}); if(c>60) throw new functions.https.HttpsError('resource-exhausted','Too many attempts'); });

  const ref = db.doc(`portalLinks/${tokenId}`);
  const snap = await ref.get();
  if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Link not found');

  const rec = snap.data();
  const now = admin.firestore.Timestamp.now();

  if (rec.expiresAt && rec.expiresAt.toMillis() < now.toMillis()) {
    await logAudit({ ownerUid: rec.ownerUid, protocolId: rec.protocolId, eventType:'portal_link_expired', metadata:{ portalId: tokenId } });
    throw new functions.https.HttpsError('failed-precondition', 'Link expired');
  }
  if (rec.oneTime && rec.consumedAt) {
    await logAudit({ ownerUid: rec.ownerUid, protocolId: rec.protocolId, eventType:'portal_link_reuse_blocked', metadata:{ portalId: tokenId } });
    throw new functions.https.HttpsError('failed-precondition', 'Link already used');
  }
  if (sha256(token) !== rec.tokenHash) {
    await logAudit({ ownerUid: rec.ownerUid, protocolId: rec.protocolId, eventType:'portal_link_invalid', metadata:{ portalId: tokenId } });
    throw new functions.https.HttpsError('permission-denied', 'Invalid token');
  }

  if (rec.oneTime) {
    await ref.update({ consumedAt: now });
  }

  await logAudit({ ownerUid: rec.ownerUid, protocolId: rec.protocolId, eventType:'portal_link_opened', metadata:{ portalId: tokenId } });
  await emitIntegrationEvent({ ownerUid: rec.ownerUid, protocolId: rec.protocolId, type:'portal_link_opened', details:{ portalId: tokenId } });

  return { ok: true, message: 'Opened.', content: rec.payload || null };
});
