const crypto = require('crypto');

exports.redactEmail = function redactEmail(email) {
  if (!email) return null;
  const e = String(email).trim().toLowerCase();
  const parts = e.split('@');
  if (parts.length !== 2) return hash(e);
  const [u, d] = parts;
  const u2 = u.length <= 2 ? u[0] + '*' : u.slice(0, 2) + '***';
  return `${u2}@${d}`;
};

exports.redactPhone = function redactPhone(phone) {
  if (!phone) return null;
  const p = String(phone).replace(/\D/g, '');
  if (p.length < 4) return '***';
  return `***${p.slice(-4)}`;
};

exports.hash = function hash(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, 16);
};
