const admin = require('firebase-admin');
const { logAudit } = require('../audit/logAudit');

exports.raiseAlert = async function raiseAlert({ severity='critical', title, details={} }) {
  const db = admin.firestore();
  await db.collection('systemAlerts').add({
    severity,
    title,
    details,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  try { await logAudit({ ownerUid: 'system', eventType: 'system_alert_raised', metadata: { severity, title } }); } catch {}
};
