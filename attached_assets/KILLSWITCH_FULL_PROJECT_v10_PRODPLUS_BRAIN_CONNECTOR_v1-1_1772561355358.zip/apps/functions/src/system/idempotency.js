const admin = require('firebase-admin');
exports.claimIdempotency = async function claimIdempotency(key, ttlMinutes=1440) {
  const db = admin.firestore();
  const ref = db.doc(`idempotencyKeys/${key}`);
  const snap = await ref.get();
  if (snap.exists) return false;
  const expiresAt = admin.firestore.Timestamp.fromMillis(Date.now() + ttlMinutes*60*1000);
  await ref.set({ createdAt: admin.firestore.FieldValue.serverTimestamp(), expiresAt });
  return true;
};
