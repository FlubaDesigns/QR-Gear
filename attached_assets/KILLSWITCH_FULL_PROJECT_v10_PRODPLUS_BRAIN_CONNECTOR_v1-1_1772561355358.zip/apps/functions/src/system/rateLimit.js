const admin = require('firebase-admin');

/**
 * Simple per-UID rate limiter using Firestore.
 * - Counts requests in rolling windows (per minute).
 * - Keeps minimal fields.
 */
exports.enforceRateLimit = async function enforceRateLimit({ uid, key, maxPerMinute = 30 }) {
  const db = admin.firestore();
  const minuteBucket = Math.floor(Date.now() / 60000);
  const docId = `${uid}:${key}:${minuteBucket}`;
  const ref = db.doc(`rateLimits/${docId}`);

  const res = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const cur = snap.exists ? (snap.data().count || 0) : 0;
    const next = cur + 1;
    tx.set(ref, {
      uidHash: hashUid(uid),
      key,
      minuteBucket,
      count: next,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });
    return next;
  });

  if (res > maxPerMinute) {
    const err = new Error('Rate limit exceeded');
    err.code = 'RATE_LIMIT';
    throw err;
  }
};

function hashUid(uid) {
  // short hash to avoid logging raw UID everywhere
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(String(uid)).digest('hex').slice(0, 16);
}
