const admin = require('firebase-admin');
const { hash } = require('../system/redact');

exports.emitIntegrationEvent = async function emitIntegrationEvent({ ownerUid, protocolId=null, type, details={} }) {
  const db = admin.firestore();
  await db.collection('integrationEvents').add({
    ownerUidHash: hash(ownerUid),
    protocolId,
    type,
    details, // must be minimal PII
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
};
