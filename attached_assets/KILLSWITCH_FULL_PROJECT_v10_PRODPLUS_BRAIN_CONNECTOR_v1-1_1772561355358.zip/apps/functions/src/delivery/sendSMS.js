const functions = require('firebase-functions');
const twilio = require('twilio');

exports.sendSMS = async function sendSMS({ to, message }) {
  const sid = functions.config().twilio && functions.config().twilio.sid;
  const token = functions.config().twilio && functions.config().twilio.token;
  const from = functions.config().twilio && functions.config().twilio.from;
  if (!sid || !token || !from) throw new Error('Missing Twilio config (twilio.sid/token/from)');
  const client = twilio(sid, token);
  return await client.messages.create({ body: message, from, to });
};
