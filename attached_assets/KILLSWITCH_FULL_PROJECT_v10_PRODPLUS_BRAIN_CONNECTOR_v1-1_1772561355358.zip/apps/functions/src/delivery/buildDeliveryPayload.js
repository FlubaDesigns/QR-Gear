exports.buildDeliveryPayload = function buildDeliveryPayload({ senderName, subject, bodyHtml }) {
  const banner = `
<div style="background:#f5f5f5;padding:12px;border-left:4px solid #999;font-family:Arial, sans-serif;">
<strong>Automated Message Notice</strong><br>
This message was released automatically because we were unable to confirm contact with <strong>${escapeHtml(senderName)}</strong> after multiple attempts.<br><br>
This does <strong>not</strong> confirm injury, death, or an emergency.<br>
You may wish to verify their status directly or through family members.
</div>`;
  const footer = `<div style="margin-top:24px;font-size:12px;color:#666;font-family:Arial, sans-serif;">
This message was released automatically after missed check-ins. This does not confirm injury, death, or emergency.
</div>`;
  const html = `${banner}<div style="margin-top:18px;font-family:Arial, sans-serif;">${bodyHtml}</div>${footer}`;
  return { subject, html, noticeIncluded: true, templateVersion: 'notice-v1' };
};

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}
