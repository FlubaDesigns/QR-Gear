const admin = require('firebase-admin');
const { logAudit } = require('../audit/logAudit');

exports.enqueueDelivery = async function enqueueDelivery({
  ownerUid, protocolId=null, channel, to,
  subject=null, html=null, message=null,
  noticeIncluded=true, templateVersion='notice-v1',
  idempotencyKey=null, fallbackToSms=null
}) {
  const db = admin.firestore();

  if (idempotencyKey) {
    const idemRef = db.doc(`idempotencyKeys/${idempotencyKey}`);
    const idemSnap = await idemRef.get();
    if (idemSnap.exists) return null;
    await idemRef.set({ createdAt: admin.firestore.FieldValue.serverTimestamp() });
  }

  const ref = await db.collection('deliveryQueue').add({
    ownerUid, protocolId, channel, to, subject, html, message,
    noticeIncluded, templateVersion,
    fallbackToSms, // { phone, message } optional
    status: 'queued',
    attempts: 0,
    nextAttemptAt: admin.firestore.Timestamp.now(),
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  });

  await logAudit({ ownerUid, protocolId, eventType: 'delivery_queued', metadata: { jobId: ref.id, channel } });
  return ref.id;
};
