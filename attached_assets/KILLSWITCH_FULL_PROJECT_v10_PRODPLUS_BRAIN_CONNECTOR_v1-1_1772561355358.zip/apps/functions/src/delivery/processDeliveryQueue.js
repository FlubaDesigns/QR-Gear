const admin = require('firebase-admin');
const { sendEmail } = require('./sendEmail');
const { sendSMS } = require('./sendSMS');
const { logAudit } = require('../audit/logAudit');
const { raiseAlert } = require('../system/alerts');

function backoffMinutes(attempts) {
  const base = Math.min(Math.pow(2, attempts), 60);
  const jitter = Math.floor(Math.random() * 3);
  return base + jitter;
}

exports.processDeliveryQueue = async function processDeliveryQueue() {
  const db = admin.firestore();
  const now = admin.firestore.Timestamp.now();

  const snap = await db.collection('deliveryQueue')
    .where('nextAttemptAt', '<=', now)
    .where('status', '==', 'queued')
    .limit(25)
    .get();

  for (const doc of snap.docs) {
    const job = doc.data();
    const attempts = job.attempts || 0;

    try {
      if (job.channel === 'email') {
        await sendEmail({ to: job.to, subject: job.subject, html: job.html });
      } else if (job.channel === 'sms') {
        await sendSMS({ to: job.to, message: job.message });
      } else {
        throw new Error('Unknown channel: ' + job.channel);
      }

      await doc.ref.update({
        status: 'sent',
        sentAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });

      await logAudit({ ownerUid: job.ownerUid, protocolId: job.protocolId || null, eventType: 'delivery_sent', metadata: { jobId: doc.id, channel: job.channel, attempts } });

    } catch (err) {
      const msg = (err && err.message) ? err.message : String(err);
      const nextMins = backoffMinutes(attempts + 1);

      await doc.ref.update({
        attempts: attempts + 1,
        lastError: msg.substring(0, 800),
        nextAttemptAt: admin.firestore.Timestamp.fromMillis(Date.now() + nextMins * 60 * 1000),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });

      await logAudit({ ownerUid: job.ownerUid, protocolId: job.protocolId || null, eventType: 'delivery_failed_retry_scheduled', metadata: { jobId: doc.id, channel: job.channel, attempts: attempts + 1, nextAttemptMinutes: nextMins } });

      // Failover: after 3 failed email attempts, optionally enqueue SMS
      if (job.channel === 'email' && (attempts + 1) >= 3 && job.fallbackToSms && job.fallbackToSms.phone) {
        await db.collection('deliveryQueue').add({
          ownerUid: job.ownerUid,
          protocolId: job.protocolId || null,
          channel: 'sms',
          to: job.fallbackToSms.phone,
          message: job.fallbackToSms.message || 'Automated Killswitch message. Verify directly.',
          noticeIncluded: true,
          templateVersion: 'sms-failover-v1',
          status: 'queued',
          attempts: 0,
          nextAttemptAt: admin.firestore.Timestamp.now(),
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        await logAudit({ ownerUid: job.ownerUid, protocolId: job.protocolId || null, eventType: 'delivery_failover_sms_queued', metadata: { originalJobId: doc.id } });
      }

      if ((attempts + 1) >= 5) {
        await raiseAlert({ severity:'critical', title:'Delivery failing repeatedly', details: { jobId: doc.id, channel: job.channel, to: job.to, attempts: attempts + 1 } });
      }
    }
  }
};
