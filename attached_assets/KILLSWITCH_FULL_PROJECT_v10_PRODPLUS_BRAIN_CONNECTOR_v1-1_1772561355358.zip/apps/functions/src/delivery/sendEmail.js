const functions = require('firebase-functions');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

exports.sendEmail = async function sendEmail({ to, subject, html }) {
  const key = functions.config().resend && functions.config().resend.key;
  const support = (functions.config().app && functions.config().app.support_email) || 'support@example.com';
  if (!key) throw new Error('Missing Resend key (functions config resend.key)');
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: `Killswitch <${support}>`, to, subject, html })
  });
  if (!res.ok) throw new Error(`Resend error: ${res.status} ${await res.text()}`);
  return await res.json();
};
