import * as functions from "firebase-functions";
import { env } from "./brainClient";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

/**
 * Brain → Killswitch callback endpoint.
 * Brain MUST include header: x-brain-callback-secret matching BRAIN_CALLBACK_SECRET
 *
 * Stores callback payloads in: planeCallbacks/{jobId}
 */
export const brainCallback = functions.https.onRequest(async (req, res) => {
  const expected = env("BRAIN_CALLBACK_SECRET", true)!;
  const got = String(req.header("x-brain-callback-secret") || "");
  if (!got || got !== expected) return res.status(403).json({ error: "forbidden" });
  if (req.method !== "POST") return res.status(405).json({ error: "method_not_allowed" });

  const body = req.body || {};
  const jobId = String(body.jobId || body.id || "");
  if (!jobId) return res.status(400).json({ error: "missing_jobId" });

  const db = getFirestore();
  await db.collection("planeCallbacks").doc(jobId).set({
    ...body,
    planeId: env("PLANE_ID") || "killswitch",
    receivedAt: FieldValue.serverTimestamp(),
  }, { merge: true });

  return res.status(200).json({ ok: true });
});
