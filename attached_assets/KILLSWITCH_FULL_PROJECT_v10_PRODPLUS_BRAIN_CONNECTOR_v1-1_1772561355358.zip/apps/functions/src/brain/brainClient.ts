import fetch from "node-fetch";
import { log } from "../modules/logger";

/**
 * Killswitch → Brain connector.
 *
 * Modes:
 * - HARNESS_MODE=local : no Brain calls (standalone)
 * - HARNESS_MODE=brain : submit intents to Brain and await verdict/result (callback or polling)
 *
 * Env (functions):
 * - HARNESS_MODE=local|brain
 * - BRAIN_BASE_URL=https://...
 * - PLANE_ID=killswitch
 * - BRAIN_SERVICE_TOKEN=... (recommended)
 * - BRAIN_CALLBACK_SECRET=... (used to authenticate Brain → Plane callbacks)
 */
export function env(name: string, required = false): string | undefined {
  const v = process.env[name];
  if (required && !v) throw new Error(`Missing env var: ${name}`);
  return v;
}

export function isBrainMode(): boolean {
  return (process.env.HARNESS_MODE || "local").toLowerCase() === "brain";
}

export type BrainResponse = { jobId: string; status: string };

export async function submitIntentToBrain(intent: any): Promise<BrainResponse> {
  const base = env("BRAIN_BASE_URL", true)!;
  const url = `${base.replace(/\/$/,"")}/brain/intents`;

  const headers: Record<string,string> = {
    "content-type": "application/json",
    "x-plane-id": env("PLANE_ID") || "killswitch",
  };
  const token = env("BRAIN_SERVICE_TOKEN");
  if (token) headers["authorization"] = `Bearer ${token}`;
  const cb = env("BRAIN_CALLBACK_SECRET");
  if (cb) headers["x-brain-callback-secret"] = cb;

  const res = await fetch(url, { method: "POST", headers, body: JSON.stringify(intent) });
  if (!res.ok) {
    const body = await res.text().catch(()=> "");
    log("error", "brain_submit_failed", { status: res.status, body });
    throw new Error(`Brain submit failed (${res.status})`);
  }
  const json = (await res.json()) as any;
  return { jobId: String(json.jobId || json.id || ""), status: String(json.status || "accepted") };
}
