import { isBrainMode, submitIntentToBrain, env } from "./brainClient";

/**
 * Wrap a high-risk action so it can run locally OR be governed by Brain.
 */
export async function maybeGovernedAction<T>(opts: {
  action: string;
  actor: { uid?: string; role?: string };
  payload: Record<string, any>;
  localExecutor: () => Promise<T>;
}): Promise<T | { jobId: string; status: string }> {
  if (!isBrainMode()) return opts.localExecutor();

  const intent = {
    schemaVersion: "brain_intent_v1",
    planeId: env("PLANE_ID") || "killswitch",
    requestId: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
    createdAtISO: new Date().toISOString(),
    actor: opts.actor || {},
    action: opts.action,
    payload: opts.payload || {},
  };

  return submitIntentToBrain(intent);
}
