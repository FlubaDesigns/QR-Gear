# Killswitch — FULL PROJECT (v6-priority3-complete-product-layer)
Build date: 2026-03-01

This is a **complete rebuilt project ZIP** (no fragments).

## What’s included (Priority 1 + 2 + 3)
### Priority 1 — Security hardening
- Signed verification links (one-time hashed tokens + expiry)
- Delivery queue with retries/backoff + provider failover hooks
- Server-side audit logs
- Stripe webhook signature verification

### Priority 2 — Product engine
- Stripe Checkout Session creator + mapping (stripeCustomers)
- Scheduler-driven protocol escalation engine
- Verification contact consent workflow
- Idempotency + system alerts

### Priority 3 — “Launch-ready” trust + UX layer
- **Protocol Creation UI** (dashboard)
- **Protocol Timeline & “peace-of-mind” indicators**
- **Release Preview Simulation** (what will send, when)
- **Secure Delivery Portal Links** (expiring links; email contains portal link, not raw content)
- **Cancel during buffer** (check-in cancels execution)
- **Monitoring dashboard** (admin view: failure counts, queue health, alerts)
- **Military free-tier gating stubs** (email domain + manual override; configurable)
- **Delivery provider failover** (email → SMS optional fallback)

---

## Setup (Firebase)
1) Install
```bash
npm install
```

2) Set Firebase project id in `.firebaserc`

3) Set Web config in `apps/web/src/firebase.ts`

4) Set functions config (secrets)
```bash
firebase functions:config:set   app.base_url="https://YOUR_DOMAIN"   app.support_email="support@YOUR_DOMAIN"   resend.key="YOUR_RESEND_KEY"   twilio.sid="YOUR_TWILIO_SID"   twilio.token="YOUR_TWILIO_TOKEN"   twilio.from="+1XXXXXXXXXX"   stripe.secret="YOUR_STRIPE_SECRET"   stripe.webhook_secret="YOUR_STRIPE_WEBHOOK_SECRET"
```

5) Run emulators
```bash
npm run emulators
```

6) Run web
```bash
npm run dev
```

7) Deploy
```bash
npm run deploy
```

---

## Admin claim
```js
await admin.auth().setCustomUserClaims(uid, { role: "admin" });
```
Sign out/in to refresh.

---

## Key routes
- `/` Dashboard (protocol list)
- `/protocol/:id` Protocol detail + timeline + actions
- `/preview/:id` Release preview simulator
- `/portal` Secure delivery portal (token-based)
- `/verify` Consent + status verification response page
- `/admin` Admin panel (pricing, knobs, monitoring)

---

## Notes
- This is a foundation build: the UX is clean and functional, but intentionally minimal.
- All outbound “release” messages include the required automated notice.
- “Portal” links expire and are one-time.

Docs:
- `docs/CLOUD_FIREBASE_NOTES.md`
- `docs/TODO_USER.md`
- `docs/TODO_CLAUDE.md`



## Brain/Conscience integration scaffold
- integrations/brain-conscience/
- functions emits integrationEvents for cross-plane consumption
## Vault encryption (v8)
- Client-side encryption: `apps/web/src/lib/crypto.ts`
- Stored as ciphertext only in `vaultItems`
- Released via portal payload as ciphertext only
- Decrypted locally in portal by passphrase (shared offline)


## Production Config
Web Firebase config is env-based. See `docs/PRODUCTION_ENV.md`.
