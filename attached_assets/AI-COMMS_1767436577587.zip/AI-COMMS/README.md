# AI-COMMS - Master Shared Folder

## CRITICAL RULE - READ THIS FIRST

**ALL COMMUNICATION BETWEEN AI AGENTS MUST BE INSIDE THIS AI-COMMS.ZIP**

---

## CURRENT STATUS - January 3, 2026

### NEW FILES FOR HANDOFF:

| Priority | File | Contents |
|----------|------|----------|
| **1** | **`KC/KC-SEGMENT-MAPPING-JAN03.md`** | **KC SEGMENT ID MAPPING SYSTEM** |
| **2** | **`QR/WIDGET-EMBEDDING-JAN03.md`** | **WIDGET EMBEDDING SYSTEM FOR KC** |
| 3 | `QR/DATABASE-CONTENTS-DEC28.md` | Actual data in all tables |
| 4 | `QR/SITEMAP-DEC28.md` | All 61 pages with routes |
| 5 | `QR/PROJECT-STRUCTURE-DEC28.md` | Complete file/folder map |
| 6 | `KC/INTEGRATION-SPEC.md` | Full integration spec |
| 7 | `KC/INTEGRATION-RESPONSE.md` | KC's answers and requirements |

### Latest Update: KC Segment Mapping System
- Segment ID format: `KC-{TYPE}-{slug}` (e.g., KC-BIZ-joes-plumbing)
- Cloud Function: `generateQrGearToken` for JWT generation
- Helper modules: `segment-mapper.js` and `widget-embed.js`

### Previous Update: Widget Embedding System
- Embeddable widgets for KC pages (homepage, dashboard, listing)
- Segment filtering (Religious, Business, Custom)
- Context-aware tokens (homepage/dashboard/listing)
- Business slug support for `/business/{slug}.htm` pages

### The Mockup Bug (FIXED):
Mockups now generated via Printful API with lifestyle images, stored in Firebase Storage.

---

## Folder Structure

```
AI-COMMS/
├── README.md                       ← THIS FILE
├── HANDOFF-DEC27.md                ← Field names and mappings
├── SCHEMA/
│   └── DATABASE-SCHEMA.md          ← All tables/columns
├── KC/
│   ├── GHOST-FINAL-ANSWER-DEC27.md
│   └── *.md
├── QR/
│   ├── DATABASE-CONTENTS-DEC28.md  ← ACTUAL DATA WITH FILE LOCATIONS
│   ├── SITEMAP-DEC28.md            ← ALL 61 ROUTES
│   ├── PROJECT-STRUCTURE-DEC28.md  ← FILE/FOLDER MAP
│   └── *.md
├── SHARED/
│   └── VERSION.md
└── README.md
```

---

## Critical Rules

1. **ALL ANSWERS GO IN THE ZIP**
2. **Only write to YOUR folder**
3. **Check VERSION.md first**
4. **Increment version after changes**
5. **Always rezip after updates**

---

*Last updated: Dec 27, 2025*
*Version 2.8*
