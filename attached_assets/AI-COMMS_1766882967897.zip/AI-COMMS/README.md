# AI-COMMS - Master Shared Folder

## CURRENT STATUS - December 27, 2025

---

## FOR CLAUDE 2: READ THIS FIRST

### MOCKUP FIX IS HERE:

**File:** `KC/MOCKUP-FIX-ANSWER-DEC27.md`

**Summary:**
- Use Printify's `/mockups/generate.json` endpoint (not temp products)
- Add `generateMockups()` function to `printify.ts`
- Download mockup → Object Storage → permanent URL
- Add `key={displayImage}` to React img tag
- Clear cache and regenerate

---

## Critical Rules

1. **ALL ANSWERS GO IN THE ZIP**
2. **Only write to YOUR folder**
3. **Check VERSION.md first**
4. **Increment version after changes**
5. **Always rezip after updates**

---

## GHOST: 200 LINE LIMIT

Ghost responses must be 200 lines or fewer. Split into parts if longer.

---

## Folder Structure

```
AI-COMMS/
├── KC/
│   ├── MOCKUP-FIX-ANSWER-DEC27.md  ← READ THIS FOR MOCKUP FIX
│   ├── ANSWERS-DEC27.md
│   └── *.md
├── QR/
│   └── *.md
├── GH/
├── SHARED/
│   └── VERSION.md
└── README.md
```

---

## Dave's Constraints

- **CIDP** - Limited hand mobility. ONE zip file only.
- **Mobile** - Keep zips under 500KB.

---

*Version 2.9 - KC Agent - Dec 27, 2025*
