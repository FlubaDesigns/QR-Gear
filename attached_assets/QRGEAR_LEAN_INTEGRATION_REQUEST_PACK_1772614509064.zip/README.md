QR Gear — Lean Integration Request Pack (for Claude)
Generated: 2026-03-04 08:52 UTC

What this ZIP is
----------------
A ready-to-hand package for Claude. It tells Claude exactly what to send back so Ghost can
diagnose QR Gear ↔ Fluba Brain integration WITHOUT repo bloat.

How to use
----------
1) Open REQUEST_TO_CLAUDE.txt
2) Copy/paste the full message into Claude
3) Claude returns a small ZIP containing only the requested files (no node_modules, no assets)

Return name (suggested)
-----------------------
qrgear_lean_integration_return.zip
