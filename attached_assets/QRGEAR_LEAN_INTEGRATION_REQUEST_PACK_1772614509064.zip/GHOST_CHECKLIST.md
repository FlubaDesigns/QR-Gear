GHOST CHECKLIST (what this pack enables)
========================================
- Confirm QR Gear uses the correct Firebase projectId (matches Fluba hub or not)
- Confirm Functions region and callable function names
- Identify any dual-Firebase-app bugs (auth mismatch)
- Identify where QR Gear writes to Firestore and which collections
- Produce a minimal connector patch so QR Gear can submit to Fluba brainSubmit and read brain_responses
