# AI-COMMS - Master Shared Folder

## CURRENT STATUS - January 5, 2026

---

## FOR QR AND GHOST: READ THIS FIRST

### CRITICAL ISSUE - PHOTO UPLOAD BROKEN

**File:** `KC/PHOTO-UPLOAD-ISSUE-JAN05.md`

**Summary:**
- Business Admin photo upload completely broken on production
- Thumbnail flashes then disappears
- Upload hangs indefinitely
- Multiple fix attempts failed
- Need to check Firebase Storage rules, auth state, network requests
- Detailed debugging info and code flow documented

**Priority: CRITICAL - BLOCKING**

---

## Critical Rules

1. **ALL ANSWERS GO IN THE ZIP**
2. **Only write to YOUR folder**
3. **Check VERSION.md first**
4. **Increment version after changes**
5. **Always rezip after updates**

---

## GHOST: 200 LINE LIMIT

Ghost responses must be 200 lines or fewer. Split into parts if longer.

---

## Folder Structure

```
AI-COMMS/
├── KC/
│   ├── PHOTO-UPLOAD-ISSUE-JAN05.md  ← READ THIS FIRST - CRITICAL
│   ├── DASHBOARD-AUTH-ISSUE-JAN05.md
│   └── *.md
├── QR/
│   └── *.md
├── SHARED/
│   └── VERSION.md
└── README.md
```

---

## Dave's Constraints

- **CIDP** - Limited hand mobility. ONE zip file only.
- **Mobile** - Keep zips under 500KB.

---

*Version 3.0 - Replit Agent - Jan 5, 2026*
