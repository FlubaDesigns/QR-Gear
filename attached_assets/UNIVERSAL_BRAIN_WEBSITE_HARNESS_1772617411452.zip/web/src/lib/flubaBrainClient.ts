import { httpsCallable } from "firebase/functions";
import { doc, onSnapshot } from "firebase/firestore";
import type { Unsubscribe } from "firebase/firestore";

export type BrainSubmitInput = {
  siteId: string;
  action: string;
  payload?: Record<string, any>;
  idempotencyKey?: string;
  traceId?: string;
};

export type BrainSubmitResult = {
  requestId: string;
  traceId?: string;
  status: string;
  deduped?: boolean;
};

export function makeFlubaBrainClient(opts: {
  siteId: string;
  functions: any; // Firebase Functions instance
  db: any;        // Firestore instance
}) {
  const { siteId, functions, db } = opts;

  async function submitToBrain(input: Omit<BrainSubmitInput, "siteId">): Promise<BrainSubmitResult> {
    const call = httpsCallable(functions, "brainSubmit");
    const res: any = await call({
      siteId,
      action: input.action,
      payload: input.payload || {},
      idempotencyKey: input.idempotencyKey || null,
      traceId: input.traceId || null,
    });
    return res.data as BrainSubmitResult;
  }

  function listenToBrainResponse(requestId: string, cb: (data: any) => void): Unsubscribe {
    const ref = doc(db, "brain_responses", requestId);
    return onSnapshot(ref, (snap) => {
      if (!snap.exists()) return;
      cb(snap.data());
    });
  }

  return { submitToBrain, listenToBrainResponse };
}
