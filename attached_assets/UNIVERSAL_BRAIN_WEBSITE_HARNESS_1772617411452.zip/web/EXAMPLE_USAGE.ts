/**
 * Example usage in a website:
 *
 * import { getFirestore } from "firebase/firestore";
 * import { getFunctions } from "firebase/functions";
 * import { makeFlubaBrainClient } from "./lib/flubaBrainClient";
 * import { app } from "./lib/firebase";
 *
 * const db = getFirestore(app);
 * const functions = getFunctions(app, "us-central1");
 * const brain = makeFlubaBrainClient({ siteId: import.meta.env.VITE_SITE_ID, db, functions });
 *
 * const { requestId } = await brain.submitToBrain({ action:"ask_brain", payload:{ prompt:"hello" } });
 * const unsub = brain.listenToBrainResponse(requestId, (resp) => console.log(resp));
 */
