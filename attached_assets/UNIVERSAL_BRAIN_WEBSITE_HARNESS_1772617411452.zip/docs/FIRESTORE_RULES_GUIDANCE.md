FIRESTORE RULES GUIDANCE (MVP)
==============================

Clients:
- may READ brain_responses (at least for admins)
- may NOT WRITE brain_inbox, brain_responses, sites, admins from client

All writes happen via Cloud Functions (Admin SDK bypasses rules).

If you need per-user response visibility later:
- store requestedByUid in responses and allow read if requestor uid matches OR admin.
