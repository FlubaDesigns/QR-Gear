FIRESTORE SEED (required)
========================

1) Admin enable (your uid):
admins/<YOUR_UID>
{ "enabled": true }

2) Site registry (repeat per site):
sites/ai-rails
{ "name":"AI-Rails", "status":"active", "allowedActions":["ask_brain","recommend_toggles"] }

sites/qr-gear
{ "name":"QR Gear", "status":"active", "allowedActions":["ask_brain","recommend_toggles"] }
