QUICK TEST
==========
1) Deploy Fluba functions (brainSubmit + processBrainInbox)
2) Create admins/<uid> enabled=true
3) Create sites/<siteId> active=true allowedActions includes ask_brain
4) In any website, set VITE_SITE_ID and Firebase config to Fluba project
5) Run website, sign in, submit ask_brain prompt
6) Confirm Firestore:
   - brain_inbox/<id> created, then status done
   - brain_responses/<id> created with result.message = "Brain online"
