UNIVERSAL BRAIN ↔ WEBSITE HARNESS (Fluba Hub + Any Website Spoke)
Generated: 2026-03-04 09:29 UTC

This IS what you asked for:
---------------------------
One universal harness that sits BETWEEN:
- the Brain (in Fluba Functions/Firestore)
- any website (AI-Rails, QR Gear, KC, Pollsit, etc.)

All websites use the SAME client harness API:
- submitToBrain({ action, payload })
- listenToBrainResponse(requestId)

And Fluba provides the SAME server gateway:
- callable function: brainSubmit
- processor: processBrainInbox (MVP echo included; swap to real Brain router later)

Folder layout in this zip
-------------------------
/fluba/   -> drop into Fluba repo
/web/     -> drop into any website repo (AI-Rails, QR Gear, etc.)
/docs/    -> Firestore seed + rules guidance + quick test steps

Definition of Done
------------------
1) Website calls brainSubmit (callable)
2) Fluba writes brain_inbox/{requestId}
3) Fluba processor writes brain_responses/{requestId}
4) Website UI receives response

Critical rules
--------------
- No provider API keys in websites.
- Provider connectors live ONLY in Fluba Functions.
- Websites identify themselves via VITE_SITE_ID.
