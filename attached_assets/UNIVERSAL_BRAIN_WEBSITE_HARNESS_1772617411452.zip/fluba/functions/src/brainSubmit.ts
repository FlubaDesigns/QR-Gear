import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

initializeApp();

async function isAdmin(uid: string): Promise<boolean> {
  const db = getFirestore();
  const doc = await db.doc(`admins/${uid}`).get();
  return doc.exists && doc.data()?.enabled === true;
}

export const brainSubmit = onCall({ region: "us-central1" }, async (req) => {
  const auth = req.auth;
  if (!auth?.uid) throw new HttpsError("unauthenticated", "Sign in required.");

  const { siteId, action, payload, idempotencyKey, traceId } = req.data || {};
  if (!siteId || typeof siteId !== "string") throw new HttpsError("invalid-argument", "siteId required");
  if (!action || typeof action !== "string") throw new HttpsError("invalid-argument", "action required");

  // MVP: admin-only submission (safe). Expand later per-site operator roles.
  if (!(await isAdmin(auth.uid))) throw new HttpsError("permission-denied", "Admin required.");

  const db = getFirestore();

  // Validate site registry
  const siteRef = db.doc(`sites/${siteId}`);
  const siteSnap = await siteRef.get();
  if (!siteSnap.exists) throw new HttpsError("failed-precondition", `Unknown siteId: ${siteId}`);
  if (siteSnap.data()?.status !== "active") throw new HttpsError("failed-precondition", `Site not active: ${siteId}`);

  const allowedActions: string[] = siteSnap.data()?.allowedActions || [];
  if (Array.isArray(allowedActions) && allowedActions.length && !allowedActions.includes(action)) {
    throw new HttpsError("permission-denied", `Action not allowed for site: ${action}`);
  }

  // Idempotency (optional)
  if (idempotencyKey) {
    const existing = await db.collection("brain_inbox")
      .where("siteId", "==", siteId)
      .where("idempotencyKey", "==", String(idempotencyKey))
      .limit(1)
      .get();
    if (!existing.empty) {
      return { requestId: existing.docs[0].id, traceId: traceId || null, deduped: true };
    }
  }

  const requestId = db.collection("brain_inbox").doc().id;
  const tId = (typeof traceId === "string" && traceId) ? traceId : `trace_${Date.now()}_${Math.random().toString(16).slice(2)}`;

  await db.doc(`brain_inbox/${requestId}`).set({
    siteId,
    action,
    payload: payload || {},
    idempotencyKey: idempotencyKey || null,
    traceId: tId,
    status: "accepted",
    requestedByUid: auth.uid,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });

  return { requestId, traceId: tId, status: "accepted" };
});
