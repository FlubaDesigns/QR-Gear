import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

initializeApp();

// MVP processor: echoes payload.prompt back.
// Replace this body with your real Brain router when ready.
export const processBrainInbox = onDocumentCreated({ region: "us-central1", document: "brain_inbox/{requestId}" }, async (event) => {
  const requestId = event.params.requestId;
  const data = event.data?.data();
  if (!data) return;

  const db = getFirestore();
  const inboxRef = db.doc(`brain_inbox/${requestId}`);
  const respRef = db.doc(`brain_responses/${requestId}`);

  await inboxRef.update({ status: "processing", updatedAt: FieldValue.serverTimestamp() });

  const prompt = data?.payload?.prompt ?? null;

  // Echo response proof
  const result = {
    message: "Brain online",
    siteId: data.siteId,
    action: data.action,
    echo: data.payload || {},
    prompt,
  };

  await respRef.set({
    siteId: data.siteId,
    action: data.action,
    traceId: data.traceId,
    status: "done",
    result,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });

  await inboxRef.update({ status: "done", updatedAt: FieldValue.serverTimestamp() });
});
