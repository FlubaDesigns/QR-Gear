# Fluba Production Environment

This build removes placeholder Firebase config and requires Vite env vars:

## Required
- VITE_FIREBASE_API_KEY
- VITE_FIREBASE_AUTH_DOMAIN
- VITE_FIREBASE_PROJECT_ID

## Optional
- VITE_FIREBASE_APP_ID
- VITE_FIREBASE_STORAGE_BUCKET
- VITE_FIREBASE_MESSAGING_SENDER_ID

Set these in your hosting provider (Firebase Hosting with env via build pipeline, or Cloud Run, etc.)
Do not commit real values into source.
