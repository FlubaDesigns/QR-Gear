# Fluba Designs — Unified Control Plane (No Execution Engine)

This is the full, runnable Fluba Designs control plane site, including:
- Website + company brief
- Investor area (gated)
- Admin control panel (gated)
- Bills (ABCD) daily-use system (Firestore-backed, inline edit)
- Budget module
- Health / exercise module
- Connector module + control-center panels
- Firebase config + Cloud Functions (connectorHandshake, runSystemsCheck, submitPatchRequest)

## Run (web)
cd web
npm install
npm run dev

## Firebase (optional)
firebase deploy
