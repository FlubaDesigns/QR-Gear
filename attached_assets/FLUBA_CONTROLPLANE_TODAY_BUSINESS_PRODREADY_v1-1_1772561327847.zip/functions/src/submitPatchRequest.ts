import { onCall } from "firebase-functions/v2/https";
import { getFirestore } from "firebase-admin/firestore";
import { initializeApp } from "firebase-admin/app";
import * as admin from "firebase-admin";

initializeApp();

export const submitPatchRequest = onCall(
  {
    region: "us-central1",
    enforceAppCheck: true,
  },
  async (req) => {
    const db = getFirestore();

    const cfgSnap = await db.collection("aicomms_connector").doc("config").get();
    const cfg = cfgSnap.exists ? (cfgSnap.data() as any) : {};

    if (!cfg?.enabled) {
      throw new Error("AICOMMS connector is disabled on this site.");
    }

    const ownerUid = cfg?.owner_uid || null;
    const callerUid = req.auth?.uid || null;

    // For now, only owner can create patch requests on-site.
    if (ownerUid && callerUid !== ownerUid) {
      throw new Error("Not authorized.");
    }

    const title = String(req.data?.title || "").trim();
    const description = String(req.data?.description || "").trim();
    const priority = String(req.data?.priority || "normal");
    const target = String(req.data?.target || "fluba-site");

    if (!title || title.length < 3) throw new Error("Missing title.");
    if (!description || description.length < 10) throw new Error("Missing description.");

    const requestId = `req_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

    await db.collection("aicomms_requests").doc(requestId).set({
      requestId,
      title,
      description,
      priority,
      target,
      status: "queued",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      createdByUid: callerUid,
      source: "fluba-site",
    });

    return { ok: true, requestId };
  }
);
