import { onCall } from "firebase-functions/v2/https";
import { getFirestore } from "firebase-admin/firestore";
import { initializeApp } from "firebase-admin/app";

initializeApp();

type CheckResult = {
  id: string;
  ok: boolean;
  severity: "info" | "warn" | "high" | "critical";
  message: string;
  details?: any;
};

type SystemsCheckResponse = {
  reportId: string;
  ok: boolean;
  summary: { total: number; passed: number; failed: number };
  results: CheckResult[];
};

async function getConnectorConfig() {
  const db = getFirestore();
  const snap = await db.collection("aicomms_connector").doc("config").get();
  return snap.exists ? (snap.data() as any) : {};
}

// NOTE: AICOMMS dictates what checks to run.
// This endpoint is a generic runner and logger.
export const runSystemsCheck = onCall(
  {
    region: "us-central1",
    enforceAppCheck: true,
  },
  async (req): Promise<SystemsCheckResponse> => {
    const db = getFirestore();
    const cfg = await getConnectorConfig();

    if (!cfg?.enabled) {
      throw new Error("AICOMMS connector is disabled on this site.");
    }

    // Optional: allow owner to run without token; otherwise require signed requests later.
    const ownerUid = cfg?.owner_uid || null;
    const callerUid = req.auth?.uid || null;
    if (ownerUid && callerUid && callerUid !== ownerUid) {
      throw new Error("Not authorized.");
    }

    const checkpackId = String(req.data?.checkpackId || "core-v1");
    const requestedChecks = Array.isArray(req.data?.checks) ? req.data.checks.map(String) : null;

    const results: CheckResult[] = [];

    // Minimal baseline checks (AICOMMS can request more later)
    const checksToRun = requestedChecks || [
      "connector_enabled",
      "firestore_reachable",
      "functions_runtime_ok",
    ];

    for (const id of checksToRun) {
      if (id === "connector_enabled") {
        results.push({
          id,
          ok: true,
          severity: "info",
          message: "Connector enabled.",
          details: { checkpackId },
        });
        continue;
      }

      if (id === "firestore_reachable") {
        try {
          await db.collection("aicomms_connector").doc("config").get();
          results.push({ id, ok: true, severity: "info", message: "Firestore reachable." });
        } catch (e: any) {
          results.push({ id, ok: false, severity: "critical", message: "Firestore unreachable.", details: e?.message });
        }
        continue;
      }

      if (id === "functions_runtime_ok") {
        results.push({ id, ok: true, severity: "info", message: "Functions runtime OK." });
        continue;
      }

      // Unknown check id: log as warn (AICOMMS can evolve checkpacks without breaking runner)
      results.push({
        id,
        ok: false,
        severity: "warn",
        message: "Unknown check id (not implemented in runner).",
      });
    }

    const failed = results.filter(r => !r.ok).length;
    const reportOk = failed === 0;

    const reportId = `rep_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

    await db.collection("aicomms_reports").doc(reportId).set({
      reportId,
      checkpackId,
      requestedChecks: checksToRun,
      ok: reportOk,
      results,
      createdAt: new Date(),
      createdByUid: req.auth?.uid || null,
      app: "fluba-site",
    });

    return {
      reportId,
      ok: reportOk,
      summary: { total: results.length, passed: results.length - failed, failed },
      results,
    };
  }
);
