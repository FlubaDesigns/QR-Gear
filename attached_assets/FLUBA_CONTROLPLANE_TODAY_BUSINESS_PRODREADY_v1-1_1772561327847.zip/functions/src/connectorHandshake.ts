import { onCall } from "firebase-functions/v2/https";
import { getFirestore } from "firebase-admin/firestore";
import { initializeApp } from "firebase-admin/app";

initializeApp();

type ConnectorConfig = {
  enabled?: boolean;
  owner_uid?: string;
  allowed_actions?: string[];
  updatedAt?: any;
};

export const connectorHandshake = onCall(
  {
    region: "us-central1",
    enforceAppCheck: true,
  },
  async (req) => {
    const db = getFirestore();
    const snap = await db.collection("aicomms_connector").doc("config").get();
    const cfg = (snap.exists ? (snap.data() as ConnectorConfig) : {}) || {};

    // If disabled, return minimal metadata but do not allow actions.
    const enabled = !!cfg.enabled;

    return {
      ok: true,
      app: "fluba-site",
      connectorEnabled: enabled,
      allowedActions: enabled ? (cfg.allowed_actions || []) : [],
      ownerUid: cfg.owner_uid || null,
      serverTime: Date.now(),
    };
  }
);
