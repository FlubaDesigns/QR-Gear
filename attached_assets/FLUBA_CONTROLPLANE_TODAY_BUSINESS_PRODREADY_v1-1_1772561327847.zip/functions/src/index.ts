import { setGlobalOptions } from "firebase-functions/v2";
setGlobalOptions({ region: "us-central1" });

export { connectorHandshake } from "./connectorHandshake";
export { runSystemsCheck } from "./runSystemsCheck";
export { submitPatchRequest } from "./submitPatchRequest";
