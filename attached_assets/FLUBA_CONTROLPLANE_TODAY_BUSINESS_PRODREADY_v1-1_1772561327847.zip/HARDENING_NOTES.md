# HARDENING_NOTES (Fluba Control Plane)
Date: 2026-03-02

Changes:
- submitPatchRequest: switched createdAt to serverTimestamp (admin.firestore.FieldValue.serverTimestamp()).

Recommended:
- Keep enforceAppCheck enabled (already set).
- Ensure admin gating for UI reads/writes; keep Firestore default deny rules (already present).
