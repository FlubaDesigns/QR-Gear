import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "../firebase";

import TodayModule from "../admin/TodayModule";
import ConnectorModule from "../admin/ConnectorModule";
import BillsModule from "../admin/BillsModule";
import BudgetModule from "../admin/BudgetModule";
import HealthModule from "../admin/HealthModule";
import BusinessModule from "../admin/BusinessModule";
import AiSeatsModule from "../admin/AiSeatsModule";

type GateState = "loading" | "signed_out" | "denied" | "ok";

export default function Admin() {
  const [gate, setGate] = useState<GateState>("loading");
  const [tab, setTab] = useState<"today" | "connector" | "bills" | "budget" | "health" | "business" | "ai">("today");

  useEffect(() => {
    (async () => {
      const u = auth.currentUser;
      if (!u) return setGate("signed_out");
      const snap = await getDoc(doc(db, "admins", u.uid));
      setGate(snap.exists() ? "ok" : "denied");
    })();
  }, []);

  if (gate === "loading") {
    return <main className="container"><p className="p">Loading…</p></main>;
  }

  if (gate === "signed_out") {
    return (
      <main className="container">
        <section className="section">
          <h1 className="h1">Control Panel</h1>
          <p className="p">Please sign in to access the admin tools.</p>
          <Link className="btnPrimary" to="/login">Sign in</Link>
        </section>
      </main>
    );
  }

  if (gate === "denied") {
    return (
      <main className="container">
        <section className="section">
          <h1 className="h1">Access denied</h1>
          <p className="p">Your account is not approved for admin access.</p>
          <Link className="btnPrimary" to="/">Return Home</Link>
        </section>
      </main>
    );
  }

  return (
    <main className="container">
      <section className="section">
        <h1 className="h1">Control Panel</h1>
        <p className="p">Operations, financials, and routines — designed for phone-first control.</p>

        <div className="tabs">
          <button className={tab==="today" ? "tab active" : "tab"} onClick={()=>setTab("today")}>Today</button>
          <button className={tab==="connector" ? "tab active" : "tab"} onClick={()=>setTab("connector")}>Connector</button>
          <button className={tab==="bills" ? "tab active" : "tab"} onClick={()=>setTab("bills")}>Bills</button>
          <button className={tab==="budget" ? "tab active" : "tab"} onClick={()=>setTab("budget")}>Budget</button>
          <button className={tab==="health" ? "tab active" : "tab"} onClick={()=>setTab("health")}>Health</button>
          <button className={tab==="business" ? "tab active" : "tab"} onClick={()=>setTab("business")}>Business</button>
          <button className={tab==="ai" ? "tab active" : "tab"} onClick={()=>setTab("ai")}>AI Seats</button>
        </div>

        <div style={{marginTop: "14px"}}>
          {tab === "today" && <TodayModule onGo={(t)=>setTab(t)} />}
          {tab === "connector" && <ConnectorModule />}
          {tab === "bills" && <BillsModule />}
          {tab === "budget" && <BudgetModule />}
          {tab === "health" && <HealthModule />}
          {tab === "business" && <BusinessModule />}
          {tab === "ai" && <AiSeatsModule />}
        </div>
      </section>
    </main>
  );
}
