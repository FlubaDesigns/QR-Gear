import { useEffect, useState } from "react";
import { auth, db } from "../firebase";
import { doc, getDoc } from "firebase/firestore";
import { Link } from "react-router-dom";

type AccessStatus = "loading" | "signed_out" | "none" | "pending" | "approved" | "denied" | "expired";

export default function Investors() {
  const [status, setStatus] = useState<AccessStatus>("loading");

  useEffect(() => {
    (async () => {
      const user = auth.currentUser;
      if (!user) return setStatus("signed_out");

      const ref = doc(db, "investor_access", user.uid);
      const snap = await getDoc(ref);

      if (!snap.exists()) return setStatus("none");

      const data = snap.data() as any;
      if (data.status === "denied") return setStatus("denied");
      if (data.status === "pending") return setStatus("pending");

      if (data.expiresAt?.toDate) {
        const exp = data.expiresAt.toDate().getTime();
        if (Date.now() > exp) return setStatus("expired");
      }

      setStatus("approved");
    })();
  }, []);

  if (status === "loading") return <main className="container"><p className="p">Loading…</p></main>;

  if (status === "signed_out") {
    return (
      <main className="container">
        <section className="section">
          <h1 className="h1">Investor Access</h1>
          <p className="p">Please sign in to request access.</p>
          <div className="ctaRow">
            <Link className="btnPrimary" to="/login">Sign In</Link>
            <Link className="btnSecondary" to="/">Back</Link>
          </div>
        </section>
      </main>
    );
  }

  if (status === "none") {
    return (
      <main className="container">
        <section className="section">
          <h1 className="h1">Investor Access</h1>
          <p className="p">This section is permissioned. Request access below.</p>
          <div className="ctaRow">
            <Link className="btnPrimary" to="/request-access">Request Access</Link>
            <Link className="btnSecondary" to="/">Back</Link>
          </div>
        </section>
      </main>
    );
  }

  if (status === "pending") {
    return (
      <main className="container">
        <section className="section">
          <h1 className="h1">Request Pending</h1>
          <p className="p">Your request is under review.</p>
        </section>
      </main>
    );
  }

  if (status === "denied" || status === "expired") {
    return (
      <main className="container">
        <section className="section">
          <h1 className="h1">{status === "expired" ? "Access Expired" : "Access Denied"}</h1>
          <p className="p">If you believe this is an error, request access again.</p>
          <div className="ctaRow">
            <Link className="btnPrimary" to="/request-access">Request Access</Link>
            <Link className="btnSecondary" to="/">Back</Link>
          </div>
        </section>
      </main>
    );
  }

  // APPROVED VIEW
  return (
    <main className="container">
      <section className="hero">
        <div className="badge">INVESTOR PORTAL</div>
        <h1 className="heroTitle">Fluba Designs</h1>
        <p className="heroSub">
          Private materials for approved angel investors: thesis, portfolio structure,
          capital plan, and milestone targets.
        </p>
      </section>

      <section className="section">
        <h2 className="h2">Executive Overview</h2>
        <div className="card">
          <p className="p">
            Fluba Designs operates independent digital platforms under a unified infrastructure framework.
            Our flagship platform, AICOMMS, targets structured AI governance and drift control in multi-agent environments.
          </p>
        </div>
      </section>

      <section className="section">
        <h2 className="h2">Capital Plan</h2>
        <div className="card">
          <p className="p"><strong>Target Raise:</strong> $75,000–$100,000</p>
          <ul className="list">
            <li>Finalize AICOMMS production deployment</li>
            <li>Accelerate beta onboarding and validation</li>
            <li>Extend infrastructure runway</li>
            <li>Operationalize governance automation cycles</li>
          </ul>
        </div>
      </section>

      <section className="section">
        <h2 className="h2">Milestones Unlocked</h2>
        <div className="card">
          <ul className="list">
            <li>AICOMMS public beta launch</li>
            <li>First 10 paying clients</li>
            <li>Governance automation cycle operational</li>
            <li>Portfolio stabilization + controlled expansion</li>
          </ul>
        </div>
      </section>
    </main>
  );
}