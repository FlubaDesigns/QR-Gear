import { auth } from "../firebase";
import { GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Login() {
  const [email, setEmail] = useState<string | null>(null);
  const nav = useNavigate();

  useEffect(() => {
    const u = auth.currentUser;
    setEmail(u?.email ?? null);
  }, []);

  const login = async () => {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
    nav("/investors");
  };

  const logout = async () => {
    await signOut(auth);
    setEmail(null);
  };

  return (
    <main className="container">
      <section className="section">
        <h1 className="h1">Sign In</h1>
        <p className="p">Investor access requires approval.</p>

        {email ? (
          <>
            <div className="card">
              <div className="p"><strong>Signed in:</strong> {email}</div>
              <div className="ctaRow">
                <Link to="/investors" className="btnPrimary">Go to Investors</Link>
                <button onClick={logout} className="btnSecondary">Sign Out</button>
              </div>
            </div>
          </>
        ) : (
          <div className="ctaRow">
            <button onClick={login} className="btnPrimary">Sign in with Google</button>
            <Link to="/" className="btnSecondary">Back Home</Link>
          </div>
        )}
      </section>
    </main>
  );
}