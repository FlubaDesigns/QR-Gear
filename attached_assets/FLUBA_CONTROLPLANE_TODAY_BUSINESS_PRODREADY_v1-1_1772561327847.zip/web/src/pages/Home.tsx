import { Link } from "react-router-dom";

export default function Home() {
  return (
    <main className="container">

      {/* HERO */}
      <section className="hero">
        <h1>Fluba Designs</h1>
        <h2>Independent Platforms. Unified Infrastructure.</h2>
        <p>
          We build and operate structured digital systems across AI governance,
          community commerce, and public engagement.
        </p>
        <div className="cta-group">
          <Link to="/#platforms" className="btn-primary">Explore Platforms</Link>
          <Link to="/investors" className="btn-secondary">Investor Access</Link>
        </div>
      </section>

      {/* OPERATING MODEL */}
      <section className="section">
        <h2>Structured by Design</h2>
        <p>
          Fluba Designs operates independent digital platforms under a shared
          infrastructure framework.
        </p>
        <p>
          Each platform maintains its own brand, revenue model, and operational focus,
          while benefiting from centralized architectural discipline, security standards,
          and development strategy.
        </p>
      </section>

      {/* PLATFORMS */}
      <section id="platforms" className="section">
        <h2>Our Operating Platforms</h2>

        <div className="platform flagship">
          <h3>AICOMMS</h3>
          <p className="tagline">AI Governance Infrastructure</p>
          <p>
            AICOMMS enforces structured execution across AI workflows.
            It addresses drift, scope control, and auditability in multi-agent environments.
          </p>
          <p><strong>Revenue Model:</strong> Tiered SaaS</p>
          <p><strong>Stage:</strong> Pre-Launch</p>
          <a href="https://aicomms.yourdomain.com" target="_blank" rel="noreferrer">
            Visit AICOMMS
          </a>
        </div>

        <div className="platform">
          <h3>Kingdom Connects</h3>
          <p className="tagline">Community Commerce Platform</p>
          <p>
            A structured marketplace enabling church communities to support member
            businesses through listings and coordinated commerce tools.
          </p>
          <p><strong>Revenue Model:</strong> Tiered listings</p>
          <p><strong>Stage:</strong> Development Nearing Completion</p>
        </div>

        <div className="platform">
          <h3>Pollsit</h3>
          <p className="tagline">Real-Time Public Signal Platform</p>
          <p>
            Structured polling infrastructure with dynamic results,
            engagement tools, and sponsored signal placement.
          </p>
          <p><strong>Revenue Model:</strong> Sponsored polls</p>
          <p><strong>Stage:</strong> Early Development</p>
        </div>

        <div className="platform">
          <h3>QR Gear</h3>
          <p className="tagline">QR-Based Commerce Utility</p>
          <p>
            Transforms physical products into evolving digital experiences
            through structured QR composition and controlled content orchestration.
          </p>
          <p><strong>Revenue Model:</strong> Product + digital add-ons</p>
          <p><strong>Stage:</strong> Experimental</p>
        </div>
      </section>

      {/* PHILOSOPHY */}
      <section className="section">
        <h2>Infrastructure Over Hype</h2>
        <p>
          We prioritize structure, capital efficiency, and controlled execution.
          Platforms scale independently while sharing core systems where appropriate.
        </p>
      </section>

      {/* INVESTOR */}
      <section className="section">
        <h2>Investor Access</h2>
        <p>
          Fluba Designs is preparing for an angel-level capital raise to
          accelerate AICOMMS deployment and portfolio stabilization.
        </p>
        <Link to="/investors" className="btn-primary">
          Request Investor Access
        </Link>
      </section>

    </main>
  );
}