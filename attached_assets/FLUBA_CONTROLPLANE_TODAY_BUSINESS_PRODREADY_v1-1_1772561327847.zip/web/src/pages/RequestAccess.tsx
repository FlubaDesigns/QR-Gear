import { auth, db } from "../firebase";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { Link, useNavigate } from "react-router-dom";

export default function RequestAccess() {
  const nav = useNavigate();

  const submit = async () => {
    const user = auth.currentUser;
    if (!user) return nav("/login");

    await setDoc(
      doc(db, "investor_access", user.uid),
      {
        email: user.email,
        status: "pending",
        requestedAt: serverTimestamp(),
      },
      { merge: true }
    );

    alert("Request submitted.");
    nav("/investors");
  };

  return (
    <main className="container">
      <section className="section">
        <h1 className="h1">Request Investor Access</h1>
        <p className="p">Access requires approval. Sign in, then submit your request.</p>
        <div className="ctaRow">
          <button onClick={submit} className="btnPrimary">Submit Request</button>
          <Link to="/" className="btnSecondary">Back</Link>
        </div>
      </section>
    </main>
  );
}