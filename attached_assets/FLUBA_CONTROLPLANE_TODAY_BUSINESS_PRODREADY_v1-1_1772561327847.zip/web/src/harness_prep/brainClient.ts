// Harness Prep (not wired).
// Purpose: Provide strongly-typed contracts + a Brain client adapter
// so Claude can wire endpoints without UI drift.

export type AlertSeverity = "low" | "medium" | "high" | "critical";

export type BrainIntentV1 = {
  schemaVersion: "brain_intent_v1";
  requestId: string;
  planeId: string;
  intentType: string;
  sourceApp: string;
  actorUid?: string;
  payload: unknown;
  billingContext?: unknown;
  createdAtISO: string;
};

export type PolicyDecisionV1 = {
  schemaVersion: "policy_decision_v1";
  allow: boolean;
  requireApproval: boolean;
  decisionId: string;
  reason: string;
  riskScore?: number;
};

export type BrainResultV1 = {
  schemaVersion: "brain_result_v1";
  jobId: string;
  requestId: string;
  planeId: string;
  intentType: string;
  status: "queued" | "blocked" | "pending_approval" | "running" | "succeeded" | "failed";
  decisionId?: string;
  message?: string;
  createdAtISO: string;
};

export async function brainGet<T>(baseUrl: string, path: string, idToken?: string): Promise<T> {
  const res = await fetch(`${baseUrl}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
    },
  });
  if (!res.ok) throw new Error(`Brain GET ${path} failed: ${res.status}`);
  return res.json();
}

export async function brainPost<T>(baseUrl: string, path: string, body: unknown, idToken?: string): Promise<T> {
  const res = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Brain POST ${path} failed: ${res.status}`);
  return res.json();
}
