# Harness Prep
Not wired. Used to prevent drift.
