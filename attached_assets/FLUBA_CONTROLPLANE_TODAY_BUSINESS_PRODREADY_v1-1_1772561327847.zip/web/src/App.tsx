import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Investors from "./pages/Investors";
import RequestAccess from "./pages/RequestAccess";
import Admin from "./pages/Admin";
import Login from "./pages/Login";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/investors" element={<Investors />} />
      <Route path="/request-access" element={<RequestAccess />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}