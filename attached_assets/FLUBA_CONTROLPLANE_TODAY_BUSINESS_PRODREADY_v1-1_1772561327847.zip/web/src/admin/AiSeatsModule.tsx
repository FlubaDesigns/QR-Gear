import { useEffect, useState } from "react";
import { auth, db } from "../firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { brainGet } from "../harness_prep/brainClient";

type SeatScorecard = {
  seatId: string;
  seatType?: string;
  provider?: string | null;
  model?: string | null;
  rollingScore?: number;
  jobsGraded?: number;
  failuresCount?: number;
  avgLatencyMs?: number | null;
  updatedAtISO?: string;
};

type SeatReport = {
  reportId?: string;
  jobId: string;
  seatId: string;
  seatType: string;
  stage: string;
  score: number;
  failures?: string[];
  createdAtISO: string;
};

type SeatReportsResponse = {
  schemaVersion: string;
  seatId: string;
  reports: SeatReport[];
};

type ScorecardsResponse = {
  schemaVersion: string;
  generatedAtISO: string;
  seats: SeatScorecard[];
};

type JobTimelineStage = {
  seatId: string;
  seatType: string;
  stage: string;
  score: number;
  durationMs?: number | null;
  createdAtISO: string;
};

type JobTimelineResponse = {
  schemaVersion: string;
  jobId: string;
  stages: JobTimelineStage[];
  outcome: any | null;
};

type BrainCfg = { baseUrl: string };

export default function AiSeatsModule() {
  const [cfg, setCfg] = useState<BrainCfg>({ baseUrl: "" });
  const [cfgSaving, setCfgSaving] = useState(false);
  const [cfgMsg, setCfgMsg] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [scorecards, setScorecards] = useState<SeatScorecard[]>([]);
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);
  const [reports, setReports] = useState<SeatReport[]>([]);

  const [jobId, setJobId] = useState("");
  const [timeline, setTimeline] = useState<JobTimelineResponse | null>(null);

  async function loadCfg() {
    const ref = doc(db, "brain_control", "config");
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const d = snap.data() as any;
      setCfg({ baseUrl: String(d.baseUrl || "") });
    }
  }

  async function saveCfg() {
    setCfgSaving(true);
    setCfgMsg(null);
    try {
      await setDoc(doc(db, "brain_control", "config"), { baseUrl: cfg.baseUrl }, { merge: true });
      setCfgMsg("Saved.");
    } catch (e: any) {
      setCfgMsg(e?.message || "Save failed.");
    } finally {
      setCfgSaving(false);
    }
  }

  async function fetchScorecards() {
    setErr(null);
    setLoading(true);
    try {
      const u = auth.currentUser;
      const token = u ? await u.getIdToken() : undefined;
      const data = await brainGet<ScorecardsResponse>(cfg.baseUrl, "/control/seats/scorecards", token);
      setScorecards(data.seats || []);
    } catch (e: any) {
      setErr(e?.message || "Failed to load scorecards.");
    } finally {
      setLoading(false);
    }
  }

  async function fetchReports(seatId: string) {
    setErr(null);
    setLoading(true);
    try {
      const u = auth.currentUser;
      const token = u ? await u.getIdToken() : undefined;
      const data = await brainGet<SeatReportsResponse>(cfg.baseUrl, `/control/seats/${encodeURIComponent(seatId)}/reports?limit=30`, token);
      setReports(data.reports || []);
    } catch (e: any) {
      setErr(e?.message || "Failed to load seat reports.");
    } finally {
      setLoading(false);
    }
  }

  async function fetchTimeline() {
    setErr(null);
    setLoading(true);
    setTimeline(null);
    try {
      const u = auth.currentUser;
      const token = u ? await u.getIdToken() : undefined;
      const data = await brainGet<JobTimelineResponse>(cfg.baseUrl, `/control/jobs/${encodeURIComponent(jobId)}/timeline`, token);
      setTimeline(data);
    } catch (e: any) {
      setErr(e?.message || "Failed to load job timeline.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCfg();
  }, []);

  useEffect(() => {
    if (!selectedSeat) return;
    fetchReports(selectedSeat);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedSeat]);

  return (
    <div className="card">
      <h2 className="h2">AI Seats</h2>
      <p className="p">
        View Brain seat scorecards and per-seat reports. Fluba calls Brain control endpoints (no direct Firestore reads).
      </p>

      <div className="cardInner" style={{ marginTop: 10 }}>
        <h3 className="h3">Brain Control API</h3>
        <label className="label">Brain base URL</label>
        <input
          className="input"
          placeholder="https://your-brain-control-api.example.com"
          value={cfg.baseUrl}
          onChange={(e) => setCfg({ baseUrl: e.target.value })}
        />
        <div style={{ display: "flex", gap: 10, marginTop: 10, flexWrap: "wrap" }}>
          <button className="btnPrimary" onClick={saveCfg} disabled={cfgSaving}>
            {cfgSaving ? "Saving…" : "Save"}
          </button>
          <button className="btn" onClick={fetchScorecards} disabled={!cfg.baseUrl || loading}>
            Refresh scorecards
          </button>
        </div>
        {cfgMsg && <p className="p" style={{ marginTop: 8 }}>{cfgMsg}</p>}
      </div>

      {err && (
        <div className="cardInner" style={{ marginTop: 10 }}>
          <p className="p" style={{ color: "var(--warn)" }}>{err}</p>
        </div>
      )}

      <div className="grid2" style={{ marginTop: 12 }}>
        <div className="cardInner">
          <h3 className="h3">Scorecards</h3>
          {loading && scorecards.length === 0 ? (
            <p className="p">Loading…</p>
          ) : scorecards.length === 0 ? (
            <p className="p">No scorecards yet. Run jobs through Brain to generate reports.</p>
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {scorecards
                .slice()
                .sort((a, b) => (Number(b.rollingScore || 0) - Number(a.rollingScore || 0)))
                .map((s) => (
                  <button
                    key={s.seatId}
                    className={selectedSeat === s.seatId ? "tile active" : "tile"}
                    onClick={() => setSelectedSeat(s.seatId)}
                    style={{ textAlign: "left" }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <strong>{s.seatId}</strong>
                      <span>{s.rollingScore ?? "—"}</span>
                    </div>
                    <div className="small">
                      {s.provider || "provider?"}{s.model ? ` • ${s.model}` : ""}
                      {typeof s.jobsGraded === "number" ? ` • jobs ${s.jobsGraded}` : ""}
                      {typeof s.avgLatencyMs === "number" ? ` • avg ${s.avgLatencyMs}ms` : ""}
                    </div>
                  </button>
                ))}
            </div>
          )}
        </div>

        <div className="cardInner">
          <h3 className="h3">Seat Reports {selectedSeat ? `— ${selectedSeat}` : ""}</h3>
          {!selectedSeat ? (
            <p className="p">Select a seat to view recent reports.</p>
          ) : reports.length === 0 ? (
            <p className="p">No reports found for this seat yet.</p>
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {reports.map((r, idx) => (
                <div key={`${r.jobId}_${idx}`} className="row">
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                    <div>
                      <div><strong>{r.stage}</strong></div>
                      <div className="small">job: {r.jobId}</div>
                      <div className="small">{new Date(r.createdAtISO).toLocaleString()}</div>
                    </div>
                    <div style={{ fontSize: 18, fontWeight: 800 }}>{r.score}</div>
                  </div>
                  {r.failures && r.failures.length > 0 && (
                    <div className="small" style={{ marginTop: 6 }}>
                      Failures: {r.failures.slice(0, 2).join(" • ")}{r.failures.length > 2 ? " …" : ""}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="cardInner" style={{ marginTop: 12 }}>
        <h3 className="h3">Job Timeline</h3>
        <p className="p">Paste a jobId to view the seat-by-seat timeline and outcome.</p>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <input className="input" placeholder="job_123…" value={jobId} onChange={(e)=>setJobId(e.target.value)} />
          <button className="btn" onClick={fetchTimeline} disabled={!cfg.baseUrl || !jobId || loading}>Fetch timeline</button>
        </div>

        {timeline && (
          <div style={{ marginTop: 10, display: "grid", gap: 10 }}>
            {timeline.outcome && (
              <div className="row">
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <strong>Outcome</strong>
                  <span>{timeline.outcome.outcome || "—"} • score {timeline.outcome.score ?? "—"}</span>
                </div>
              </div>
            )}

            {timeline.stages?.map((s, i) => (
              <div key={i} className="row">
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                  <div>
                    <div><strong>{s.stage}</strong> <span className="small">({s.seatType})</span></div>
                    <div className="small">{s.seatId} • {new Date(s.createdAtISO).toLocaleString()}</div>
                  </div>
                  <div style={{ fontSize: 18, fontWeight: 800 }}>{s.score}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
