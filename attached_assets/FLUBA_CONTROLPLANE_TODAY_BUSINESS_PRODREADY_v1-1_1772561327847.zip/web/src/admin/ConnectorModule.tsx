import { useEffect, useMemo, useState } from "react";
import { auth, db, functions } from "../firebase";
import { httpsCallable } from "firebase/functions";
import {
  doc,
  getDoc,
  setDoc,
  collection,
  getDocs,
  orderBy,
  limit,
  query,
} from "firebase/firestore";

type Handshake = {
  ok: boolean;
  app: string;
  connectorEnabled: boolean;
  allowedActions: string[];
  ownerUid: string | null;
  serverTime: number;
};

type SystemsCheckResult = {
  id: string;
  ok: boolean;
  severity: "info" | "warn" | "high" | "critical";
  message: string;
  details?: any;
};

type SystemsCheckResponse = {
  reportId: string;
  ok: boolean;
  summary: { total: number; passed: number; failed: number };
  results: SystemsCheckResult[];
};

export default function ConnectorModule() {
  const [loading, setLoading] = useState(true);
  const [handshake, setHandshake] = useState<Handshake | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // Config editing
  const [cfgEnabled, setCfgEnabled] = useState(false);
  const [cfgOwnerUid, setCfgOwnerUid] = useState("");
  const [cfgAllowedActions, setCfgAllowedActions] = useState("systems_check,patch_request");

  // Run check
  const [checkRunning, setCheckRunning] = useState(false);
  const [checkResp, setCheckResp] = useState<SystemsCheckResponse | null>(null);

  // Patch request
  const [reqTitle, setReqTitle] = useState("");
  const [reqDesc, setReqDesc] = useState("");
  const [reqPriority, setReqPriority] = useState("normal");
  const [reqTarget, setReqTarget] = useState("fluba-site");
  const [reqStatus, setReqStatus] = useState<string | null>(null);

  // Recent items
  const [recentReports, setRecentReports] = useState<any[]>([]);
  const [recentRequests, setRecentRequests] = useState<any[]>([]);

  const allowedActionsParsed = useMemo(() => {
    return cfgAllowedActions
      .split(",")
      .map(s => s.trim())
      .filter(Boolean);
  }, [cfgAllowedActions]);

  async function refresh() {
    setLoading(true);
    setErr(null);

    try {
      // Load config from Firestore (admin-write)
      const cfgSnap = await getDoc(doc(db, "aicomms_connector", "config"));
      const cfg = cfgSnap.exists() ? (cfgSnap.data() as any) : {};
      setCfgEnabled(!!cfg.enabled);
      setCfgOwnerUid(String(cfg.owner_uid || ""));
      setCfgAllowedActions(Array.isArray(cfg.allowed_actions) ? cfg.allowed_actions.join(",") : "systems_check,patch_request");

      // Call handshake (tests callable path)
      const fn = httpsCallable(functions, "connectorHandshake");
      const res: any = await fn({});
      setHandshake(res.data as Handshake);
    } catch (e: any) {
      setErr(e?.message || "Failed to refresh connector status.");
    } finally {
      setLoading(false);
    }

    try {
      const repQ = query(collection(db, "aicomms_reports"), orderBy("createdAt", "desc"), limit(10));
      const repSnap = await getDocs(repQ);
      setRecentReports(repSnap.docs.map(d => d.data()));
    } catch {
      // ignore (rules may block or indexes missing)
    }

    try {
      const reqQ = query(collection(db, "aicomms_requests"), orderBy("createdAt", "desc"), limit(10));
      const reqSnap = await getDocs(reqQ);
      setRecentRequests(reqSnap.docs.map(d => d.data()));
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function saveConfig() {
    setErr(null);
    try {
      await setDoc(
        doc(db, "aicomms_connector", "config"),
        {
          enabled: !!cfgEnabled,
          owner_uid: cfgOwnerUid.trim() || null,
          allowed_actions: allowedActionsParsed,
          updatedAt: new Date(),
          updatedByUid: auth.currentUser?.uid || null,
        },
        { merge: true }
      );
      await refresh();
    } catch (e: any) {
      setErr(e?.message || "Failed to save config.");
    }
  }

  async function runCheck() {
    setErr(null);
    setCheckResp(null);
    setCheckRunning(true);
    try {
      const fn = httpsCallable(functions, "runSystemsCheck");
      const res: any = await fn({ checkpackId: "core-v1" });
      setCheckResp(res.data as SystemsCheckResponse);
      await refresh();
    } catch (e: any) {
      setErr(e?.message || "Systems check failed.");
    } finally {
      setCheckRunning(false);
    }
  }

  async function submitRequest() {
    setErr(null);
    setReqStatus(null);
    try {
      const fn = httpsCallable(functions, "submitPatchRequest");
      const res: any = await fn({
        title: reqTitle,
        description: reqDesc,
        priority: reqPriority,
        target: reqTarget,
      });
      setReqStatus(`Queued: ${res.data?.requestId || "ok"}`);
      setReqTitle("");
      setReqDesc("");
      await refresh();
    } catch (e: any) {
      setErr(e?.message || "Request failed.");
    }
  }

  return (
    <div>
      <h2>System Connector Control Panel</h2>
      <p>
        This does <b>not</b> embed the Execution Engine. It controls the Execution Engine via the AICOMMS connector
        bridge (Firestore + Cloud Functions). Execution Engine runs separately and consumes requests.
      </p>

      {loading ? <p>Loading…</p> : null}
      {err ? <p style={{ color: "crimson" }}>{err}</p> : null}

      <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
        <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: 12 }}>
          <h3>Status</h3>
          {handshake ? (
            <ul>
              <li><b>Connector enabled:</b> {String(handshake.connectorEnabled)}</li>
              <li><b>Allowed actions:</b> {(handshake.allowedActions || []).join(", ") || "(none)"}</li>
              <li><b>Owner UID:</b> {handshake.ownerUid || "(not set)"}</li>
            </ul>
          ) : (
            <p>No handshake yet.</p>
          )}
          <button className="btnPrimary" onClick={refresh}>Refresh</button>
        </div>

        <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: 12 }}>
          <h3>Connector Config (site-side)</h3>
          <p className="p">Edits Firestore: <code>aicomms_connector/config</code></p>

          <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
            <input type="checkbox" checked={cfgEnabled} onChange={(e) => setCfgEnabled(e.target.checked)} />
            Enable connector on this site
          </label>

          <div style={{ display: "grid", gap: 8, maxWidth: 520 }}>
            <label>
              Owner UID (optional — if set, only this UID can run checks / submit requests)
              <input
                value={cfgOwnerUid}
                onChange={(e) => setCfgOwnerUid(e.target.value)}
                placeholder="Firebase Auth UID"
                style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "inherit" }}
              />
            </label>

            <label>
              Allowed actions (comma-separated)
              <input
                value={cfgAllowedActions}
                onChange={(e) => setCfgAllowedActions(e.target.value)}
                placeholder="systems_check,patch_request"
                style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "inherit" }}
              />
            </label>

            <button className="btnPrimary" onClick={saveConfig}>Save Config</button>
          </div>
        </div>

        <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: 12 }}>
          <h3>Run Systems Check</h3>
          <p className="p">Calls Cloud Function: <code>runSystemsCheck</code> (writes a report to <code>aicomms_reports</code>).</p>
          <button className="btnPrimary" disabled={checkRunning} onClick={runCheck}>
            {checkRunning ? "Running…" : "Run Check"}
          </button>

          {checkResp ? (
            <div style={{ marginTop: 10 }}>
              <p><b>Report:</b> {checkResp.reportId} — <b>OK:</b> {String(checkResp.ok)}</p>
              <p><b>Summary:</b> {checkResp.summary.passed}/{checkResp.summary.total} passed</p>
              <ul>
                {checkResp.results.map((r) => (
                  <li key={r.id}><b>{r.id}</b> — {r.ok ? "OK" : "FAIL"} ({r.severity}) — {r.message}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>

        <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: 12 }}>
          <h3>Submit Patch/Action Request (for Execution Engine)</h3>
          <p className="p">Calls Cloud Function: <code>submitPatchRequest</code> (writes to <code>aicomms_requests</code>).</p>

          <div style={{ display: "grid", gap: 8, maxWidth: 680 }}>
            <label>
              Title
              <input
                value={reqTitle}
                onChange={(e) => setReqTitle(e.target.value)}
                placeholder="e.g., Update investor deck copy"
                style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "inherit" }}
              />
            </label>

            <label>
              Description (10+ chars)
              <textarea
                value={reqDesc}
                onChange={(e) => setReqDesc(e.target.value)}
                placeholder="Describe what you want the Execution Engine/AICOMMS to do. The Execution Engine processes and writes back results."
                rows={4}
                style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "inherit" }}
              />
            </label>

            <label>
              Priority
              <select
                value={reqPriority}
                onChange={(e) => setReqPriority(e.target.value)}
                style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "inherit" }}
              >
                <option value="low">low</option>
                <option value="normal">normal</option>
                <option value="high">high</option>
                <option value="critical">critical</option>
              </select>
            </label>

            <label>
              Target
              <input
                value={reqTarget}
                onChange={(e) => setReqTarget(e.target.value)}
                placeholder="fluba-site"
                style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid rgba(255,255,255,0.12)", background: "transparent", color: "inherit" }}
              />
            </label>

            <button className="btnPrimary" onClick={submitRequest}>Submit Request</button>
            {reqStatus ? <p>{reqStatus}</p> : null}
          </div>
        </div>

        <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: 12 }}>
          <h3>Recent Connector Reports</h3>
          {recentReports.length ? (
            <ul>
              {recentReports.map((r, idx) => (
                <li key={idx}>
                  <b>{r.reportId}</b> — OK: {String(r.ok)} — {r.checkpackId || "?"}
                </li>
              ))}
            </ul>
          ) : (
            <p>No reports loaded (or none exist yet).</p>
          )}
        </div>

        <div style={{ border: "1px solid rgba(255,255,255,0.12)", borderRadius: 12, padding: 12 }}>
          <h3>Recent Execution Engine Requests</h3>
          {recentRequests.length ? (
            <ul>
              {recentRequests.map((r, idx) => (
                <li key={idx}>
                  <b>{r.requestId}</b> — {r.status || "?"} — {r.title || "(no title)"}
                </li>
              ))}
            </ul>
          ) : (
            <p>No requests loaded (or none exist yet).</p>
          )}
        </div>
      </div>
    </div>
  );
}
