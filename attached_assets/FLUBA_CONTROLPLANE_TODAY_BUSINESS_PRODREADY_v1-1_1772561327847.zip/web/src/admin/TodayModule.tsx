
import { useEffect, useMemo, useState } from "react";
import { db } from "../firebase";
import {
  collection,
  doc,
  getDocs,
  query,
  setDoc,
  where,
} from "firebase/firestore";

type Bill = {
  id: string;
  name: string;
  defaultAmount: number;
  dueDay?: number;
  category?: string;
  autopay?: boolean;
  active?: boolean;
};

type MonthStatus = {
  id: string; // YYYY-MM__billId
  billId: string;
  month: string;
  paid: boolean;
  paidDate?: string | null;
};

type Routine = {
  id: string;
  name: string;
  active: boolean;
  schedule?: Record<string,string>;
};

type RoutineDay = {
  id: string;
  routineId: string;
  dayKey: string;
  title: string;
  blocks?: any[];
};

type WorkoutLog = {
  id: string;
  dateKey: string;
  routineId?: string;
  routineDayId?: string;
  blocks?: { completed?: boolean }[];
};

type BizExpense = {
  id: string;
  dateKey: string;
  amount: number;
  company: string;
  category: string;
  vendor?: string;
};

function monthKey(d = new Date()) {
  return d.toISOString().slice(0, 7);
}
function todayKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}
function dayName(d = new Date()){
  const map = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  return map[d.getDay()];
}
function clamp(n:number, a:number, b:number){ return Math.max(a, Math.min(b, n)); }

function dueInfo(dueDay?: number){
  if(!dueDay) return { delta: null as number | null, cls: "ok" as "ok"|"soon"|"urgent"|"overdue", label: "No due day" };
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth();
  const due = new Date(y, m, dueDay);
  const delta = Math.floor((due.getTime() - new Date(y,m,now.getDate()).getTime()) / (1000*60*60*24));
  if(delta < 0) return { delta, cls: "overdue", label: "Overdue" };
  if(delta <= 2) return { delta, cls: "urgent", label: delta === 0 ? "Due today" : `Due in ${delta}d` };
  if(delta <= 5) return { delta, cls: "soon", label: `Due in ${delta}d` };
  return { delta, cls: "ok", label: `Due in ${delta}d` };
}

export default function TodayModule({ onGo }:{ onGo:(tab:"bills"|"budget"|"health"|"business"|"connector")=>void }) {
  const [bills, setBills] = useState<Bill[]>([]);
  const [status, setStatus] = useState<Record<string, MonthStatus>>({});
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [routineDays, setRoutineDays] = useState<RoutineDay[]>([]);
  const [logs, setLogs] = useState<WorkoutLog[]>([]);
  const [expenses, setExpenses] = useState<BizExpense[]>([]);

  const mk = monthKey();
  const tk = todayKey();
  const dn = dayName();

  useEffect(() => {
    (async () => {
      // Bills + statuses
      const billsSnap = await getDocs(query(collection(db, "bills"), where("active", "in", [true, null])));
      const billRows = billsSnap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as Bill[];
      setBills(billRows);

      const ids = billRows.map(b => b.id);
      const st: Record<string, MonthStatus> = {};
      if (ids.length) {
        const statusSnap = await getDocs(query(collection(db, "bill_month_status"), where("month", "==", mk)));
        statusSnap.docs.forEach(d => {
          const v = d.data() as any;
          st[v.billId] = { id: d.id, ...(v as any) };
        });
      }
      setStatus(st);

      // Exercise / routines / logs (for Today snapshot)
      const rSnap = await getDocs(collection(db, "routines"));
      setRoutines(rSnap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as Routine[]);
      const rdSnap = await getDocs(collection(db, "routine_days"));
      setRoutineDays(rdSnap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as RoutineDay[]);
      const lSnap = await getDocs(collection(db, "workout_logs"));
      setLogs(lSnap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as WorkoutLog[]);

      // Business expenses (month)
      const eSnap = await getDocs(query(collection(db, "business_expenses"), where("month", "==", mk)));
      setExpenses(eSnap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as BizExpense[]);
    })();
  }, [mk]);

  const activeBills = useMemo(() => bills.filter(b => b.active !== false), [bills]);

  const totals = useMemo(() => {
    let total = 0;
    let paid = 0;
    for (const b of activeBills) {
      total += Number(b.defaultAmount || 0);
      if (status[b.id]?.paid) paid += Number(b.defaultAmount || 0);
    }
    return { total, paid, remaining: Math.max(0, total - paid), pct: total ? clamp((paid / total) * 100, 0, 100) : 0 };
  }, [activeBills, status]);

  const dueSoon = useMemo(() => {
    const list = activeBills
      .map(b => ({ b, info: dueInfo(b.dueDay) }))
      .filter(x => x.info.delta !== null && x.info.delta >= 0 && x.info.delta <= 7)
      .sort((a, c) => (a.info.delta! - c.info.delta!));
    return list.slice(0, 8);
  }, [activeBills]);

  const activeRoutine = useMemo(() => routines.find(r => r.active), [routines]);
  const todayRoutineDayId = activeRoutine?.schedule?.[dn] || "";
  const todayRoutineDay = useMemo(
    () => routineDays.find(rd => rd.id === todayRoutineDayId) || null,
    [routineDays, todayRoutineDayId]
  );
  const todayLog = useMemo(() => logs.find(l => l.dateKey === tk) || null, [logs, tk]);
  const todayBlocksDone = useMemo(() => (todayLog?.blocks || []).filter(b => b.completed).length, [todayLog]);
  const todayBlocksTotal = useMemo(() => (todayLog?.blocks || []).length, [todayLog]);

  const bizMonthTotal = useMemo(() => expenses.reduce((a, e) => a + Number(e.amount || 0), 0), [expenses]);

  // Quick action: mark everything paid? no. Keep safe.
  async function quickMarkPaid(billId: string){
    const b = activeBills.find(x => x.id === billId);
    if(!b) return;
    const id = `${mk}__${billId}`;
    await setDoc(doc(db, "bill_month_status", id), {
      billId,
      month: mk,
      paid: true,
      paidDate: new Date().toISOString().slice(0,10),
    }, { merge: true });
    setStatus(prev => ({ ...prev, [billId]: { id, billId, month: mk, paid: true, paidDate: new Date().toISOString().slice(0,10) } }));
  }

  return (
    <div>
      <div className="grid2">
        <div className="card">
          <div className="row" style={{justifyContent:"space-between"}}>
            <div>
              <div className="label">THIS MONTH</div>
              <div style={{fontSize:18, fontWeight:800, marginTop:6}}>Bills Snapshot</div>
            </div>
            <button className="btn" onClick={()=>onGo("bills")}>Open Bills</button>
          </div>

          <div className="grid3" style={{marginTop:12}}>
            <div>
              <div className="label">Total</div>
              <div className="money">${totals.total.toFixed(2)}</div>
            </div>
            <div>
              <div className="label">Paid</div>
              <div className="money">${totals.paid.toFixed(2)}</div>
            </div>
            <div>
              <div className="label">Remaining</div>
              <div className="money">${totals.remaining.toFixed(2)}</div>
            </div>
          </div>

          <div style={{marginTop:12}} className="progress">
            <div className="progressFill" style={{width: `${totals.pct.toFixed(0)}%`}} />
          </div>
          <div className="small" style={{marginTop:8}}>{totals.pct.toFixed(0)}% paid</div>
        </div>

        <div className="card">
          <div className="row" style={{justifyContent:"space-between"}}>
            <div>
              <div className="label">HEALTH</div>
              <div style={{fontSize:18, fontWeight:800, marginTop:6}}>Today&apos;s Routine</div>
            </div>
            <button className="btn" onClick={()=>onGo("health")}>Open Health</button>
          </div>

          {!activeRoutine ? (
            <p className="p" style={{marginTop:12}}>No active routine yet. Create one in Health.</p>
          ) : !todayRoutineDay ? (
            <p className="p" style={{marginTop:12}}>No routine linked for <strong>{dn}</strong>. Link it in Health.</p>
          ) : (
            <div style={{marginTop:12}}>
              <div style={{fontWeight:800}}>{todayRoutineDay.title}</div>
              <div className="small">{todayLog ? `${todayBlocksDone}/${todayBlocksTotal} blocks complete` : "Not started"}</div>
              <div className="small" style={{marginTop:10}}>
                Tip: pace yourself. Consistency beats intensity.
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid2" style={{marginTop:14}}>
        <div className="card">
          <div className="row" style={{justifyContent:"space-between"}}>
            <div>
              <div className="label">DUE SOON</div>
              <div style={{fontSize:18, fontWeight:800, marginTop:6}}>Next 7 Days</div>
            </div>
            <button className="btn" onClick={()=>onGo("bills")}>View All</button>
          </div>

          {dueSoon.length === 0 ? (
            <p className="p" style={{marginTop:12}}>No bills due in the next 7 days.</p>
          ) : (
            <div style={{marginTop:12, display:"grid", gap:10}}>
              {dueSoon.map(({b, info}) => (
                <div key={b.id} className={`billRow ${status[b.id]?.paid ? "paid" : ""}`}>
                  <div>
                    <div style={{fontWeight:800}}>{b.name}</div>
                    <div className="small">
                      ${Number(b.defaultAmount||0).toFixed(2)} • due day {b.dueDay ?? "—"} {b.autopay ? "• autopay" : ""}
                    </div>
                  </div>
                  <div style={{display:"flex", gap:8, alignItems:"center"}}>
                    <span className={`dueTag ${info.cls}`}>{info.label}</span>
                    {!status[b.id]?.paid && (
                      <button className="btn" onClick={()=>quickMarkPaid(b.id)}>Mark Paid</button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <div className="row" style={{justifyContent:"space-between"}}>
            <div>
              <div className="label">BUSINESS</div>
              <div style={{fontSize:18, fontWeight:800, marginTop:6}}>Expenses This Month</div>
            </div>
            <button className="btn" onClick={()=>onGo("business")}>Open Business</button>
          </div>

          <div style={{marginTop:12}}>
            <div className="label">Total spent</div>
            <div className="money">${bizMonthTotal.toFixed(2)}</div>
          </div>

          <div style={{marginTop:12}} className="small">
            {expenses.length ? `Recent items: ${expenses.slice(0,3).map(e=>`${e.company} $${Number(e.amount||0).toFixed(0)}`).join(" • ")}` : "No expenses logged for this month yet."}
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:14}}>
        <div className="row" style={{justifyContent:"space-between"}}>
          <div>
            <div className="label">SYSTEM</div>
            <div style={{fontSize:18, fontWeight:800, marginTop:6}}>Control Plane</div>
          </div>
          <button className="btn" onClick={()=>onGo("connector")}>Open Connector</button>
        </div>
        <p className="p" style={{marginTop:12}}>
          This dashboard is your daily landing page: money, health, business, and system control — one glance.
        </p>
      </div>
    </div>
  );
}
