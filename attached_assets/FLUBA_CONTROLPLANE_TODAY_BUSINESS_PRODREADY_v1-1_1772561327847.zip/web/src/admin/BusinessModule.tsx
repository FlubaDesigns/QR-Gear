import { useEffect, useMemo, useState } from "react";
import { db } from "../firebase";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";

type Expense = {
  id: string;
  dateKey: string; // YYYY-MM-DD
  month: string;   // YYYY-MM
  amount: number;
  company: string;
  category: string;
  vendor?: string;
  notes?: string;
  createdAt?: any;
};

function monthKey(d = new Date()) {
  return d.toISOString().slice(0, 7);
}
function todayKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

const DEFAULT_COMPANIES = [
  "Fluba Designs",
  "AI-COMMS",
  "Kingdom Connects",
  "Pollsit",
  "QR Gear",
];

const DEFAULT_CATEGORIES = [
  "Software/Subscriptions",
  "Hosting/Firebase",
  "Marketing/Ads",
  "Design/Creative",
  "Hardware/Equipment",
  "Office/Supplies",
  "Travel/Mileage",
  "Professional Services",
  "Other",
];

export default function BusinessModule() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [filterCompany, setFilterCompany] = useState<string>("All");
  const [filterMonth, setFilterMonth] = useState<string>(monthKey());

  // Add form
  const [dateKey, setDateKey] = useState<string>(todayKey());
  const [amount, setAmount] = useState<string>("");
  const [company, setCompany] = useState<string>(DEFAULT_COMPANIES[0]);
  const [category, setCategory] = useState<string>(DEFAULT_CATEGORIES[0]);
  const [vendor, setVendor] = useState<string>("");
  const [notes, setNotes] = useState<string>("");

  const [editId, setEditId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<Partial<Expense>>({});

  useEffect(() => {
    (async () => {
      const q = query(collection(db, "business_expenses"), where("month", "==", filterMonth));
      const snap = await getDocs(q);
      const rows = snap.docs
        .map(d => ({ id: d.id, ...(d.data() as any) })) as Expense[];
      // manual sort by dateKey desc (safer if date stored as string)
      rows.sort((a,b)=> (b.dateKey||"").localeCompare(a.dateKey||""));
      setExpenses(rows);
    })();
  }, [filterMonth]);

  const visible = useMemo(() => {
    if (filterCompany === "All") return expenses;
    return expenses.filter(e => e.company === filterCompany);
  }, [expenses, filterCompany]);

  const totals = useMemo(() => {
    const total = visible.reduce((a, e) => a + Number(e.amount || 0), 0);
    const byCompany: Record<string, number> = {};
    for (const e of visible) {
      byCompany[e.company] = (byCompany[e.company] || 0) + Number(e.amount || 0);
    }
    return { total, byCompany };
  }, [visible]);

  async function addExpense() {
    const amt = Number(amount);
    if (!dateKey || !isFinite(amt) || amt <= 0) return;
    const mk = dateKey.slice(0, 7);
    await addDoc(collection(db, "business_expenses"), {
      dateKey,
      month: mk,
      amount: amt,
      company,
      category,
      vendor: vendor.trim(),
      notes: notes.trim(),
      createdAt: serverTimestamp(),
    });
    // refresh local
    setAmount(""); setVendor(""); setNotes("");
    setFilterMonth(mk); // keep in month
    const snap = await getDocs(query(collection(db, "business_expenses"), where("month", "==", mk)));
    const rows = snap.docs.map(d => ({ id: d.id, ...(d.data() as any) })) as Expense[];
    rows.sort((a,b)=> (b.dateKey||"").localeCompare(a.dateKey||""));
    setExpenses(rows);
  }

  function startEdit(e: Expense) {
    setEditId(e.id);
    setEditDraft({ ...e });
  }

  async function saveEdit() {
    if (!editId) return;
    const draft = editDraft;
    const amt = Number(draft.amount);
    if (!draft.dateKey || !isFinite(amt) || amt <= 0) return;
    const mk = String(draft.dateKey).slice(0, 7);
    await updateDoc(doc(db, "business_expenses", editId), {
      dateKey: draft.dateKey,
      month: mk,
      amount: amt,
      company: String(draft.company || DEFAULT_COMPANIES[0]),
      category: String(draft.category || DEFAULT_CATEGORIES[0]),
      vendor: String(draft.vendor || ""),
      notes: String(draft.notes || ""),
      updatedAt: serverTimestamp(),
    });
    setEditId(null);
    setEditDraft({});
    // refresh month if needed
    setFilterMonth(mk);
  }

  async function removeExpense(id: string) {
    await deleteDoc(doc(db, "business_expenses", id));
    setExpenses(prev => prev.filter(x => x.id !== id));
  }

  return (
    <div className="card">
      <div className="row" style={{justifyContent:"space-between"}}>
        <div>
          <h2 className="h2" style={{margin:"0 0 6px"}}>Business Expenses</h2>
          <p className="p" style={{margin:0}}>
            Log business costs per company for taxes, profit clarity, and investor readiness.
          </p>
        </div>
      </div>

      <div className="grid2" style={{marginTop:14}}>
        <div className="card">
          <div className="label">ADD EXPENSE</div>

          <div style={{display:"grid", gap:10, marginTop:10}}>
            <label>
              <div className="small">Date</div>
              <input value={dateKey} onChange={e=>setDateKey(e.target.value)} placeholder="YYYY-MM-DD" />
            </label>

            <label>
              <div className="small">Amount</div>
              <input value={amount} onChange={e=>setAmount(e.target.value)} placeholder="e.g., 19.99" />
            </label>

            <label>
              <div className="small">Company</div>
              <select value={company} onChange={e=>setCompany(e.target.value)}>
                {DEFAULT_COMPANIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>

            <label>
              <div className="small">Category</div>
              <select value={category} onChange={e=>setCategory(e.target.value)}>
                {DEFAULT_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>

            <label>
              <div className="small">Vendor (optional)</div>
              <input value={vendor} onChange={e=>setVendor(e.target.value)} placeholder="e.g., Google, Adobe, Amazon" />
            </label>

            <label>
              <div className="small">Notes (optional)</div>
              <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="receipt note, reason, etc." />
            </label>

            <button className="btnPrimary" onClick={addExpense}>Add Expense</button>
          </div>
        </div>

        <div className="card">
          <div className="label">THIS MONTH</div>
          <div className="money" style={{marginTop:10}}>${totals.total.toFixed(2)}</div>
          <div className="small" style={{marginTop:6}}>Filter month: {filterMonth}</div>

          <div style={{display:"grid", gap:10, marginTop:12}}>
            <label>
              <div className="small">Month (YYYY-MM)</div>
              <input value={filterMonth} onChange={e=>setFilterMonth(e.target.value)} />
            </label>
            <label>
              <div className="small">Company filter</div>
              <select value={filterCompany} onChange={e=>setFilterCompany(e.target.value)}>
                <option value="All">All</option>
                {DEFAULT_COMPANIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>
          </div>

          <div style={{marginTop:12}}>
            <div className="small" style={{opacity:0.9}}>Totals by company</div>
            <div style={{display:"grid", gap:8, marginTop:8}}>
              {Object.entries(totals.byCompany).sort((a,b)=>b[1]-a[1]).map(([k,v]) => (
                <div key={k} className="billRow">
                  <div style={{fontWeight:800}}>{k}</div>
                  <div className="money" style={{fontSize:16}}>${v.toFixed(2)}</div>
                </div>
              ))}
              {Object.keys(totals.byCompany).length===0 && (
                <div className="small">No expenses logged for this month.</div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="card" style={{marginTop:14}}>
        <div className="row" style={{justifyContent:"space-between"}}>
          <div>
            <div className="label">ENTRIES</div>
            <div className="small">Showing {visible.length} items</div>
          </div>
        </div>

        {visible.length === 0 ? (
          <p className="p" style={{marginTop:12}}>No expenses for the selected month/filter.</p>
        ) : (
          <div style={{display:"grid", gap:10, marginTop:12}}>
            {visible.slice(0, 80).map(e => {
              const isEditing = editId === e.id;
              return (
                <div key={e.id} className={`billRow ${isEditing ? "editing" : ""}`}>
                  {!isEditing ? (
                    <>
                      <div>
                        <div style={{fontWeight:800}}>{e.company} • {e.category}</div>
                        <div className="small">{e.dateKey} {e.vendor ? `• ${e.vendor}` : ""} {e.notes ? `• ${e.notes}` : ""}</div>
                      </div>
                      <div style={{display:"flex", gap:8, alignItems:"center"}}>
                        <div className="money" style={{fontSize:16}}>${Number(e.amount||0).toFixed(2)}</div>
                        <button className="btn" onClick={()=>startEdit(e)}>Edit</button>
                        <button className="btn" onClick={()=>removeExpense(e.id)}>Delete</button>
                      </div>
                    </>
                  ) : (
                    <div style={{width:"100%"}}>
                      <div className="grid2" style={{gap:10}}>
                        <label>
                          <div className="small">Date</div>
                          <input value={String(editDraft.dateKey||"")} onChange={ev=>setEditDraft(d=>({...d, dateKey: ev.target.value}))} />
                        </label>
                        <label>
                          <div className="small">Amount</div>
                          <input value={String(editDraft.amount ?? "")} onChange={ev=>setEditDraft(d=>({...d, amount: Number(ev.target.value)}))} />
                        </label>
                        <label>
                          <div className="small">Company</div>
                          <select value={String(editDraft.company||DEFAULT_COMPANIES[0])} onChange={ev=>setEditDraft(d=>({...d, company: ev.target.value}))}>
                            {DEFAULT_COMPANIES.map(c => <option key={c} value={c}>{c}</option>)}
                          </select>
                        </label>
                        <label>
                          <div className="small">Category</div>
                          <select value={String(editDraft.category||DEFAULT_CATEGORIES[0])} onChange={ev=>setEditDraft(d=>({...d, category: ev.target.value}))}>
                            {DEFAULT_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                          </select>
                        </label>
                        <label>
                          <div className="small">Vendor</div>
                          <input value={String(editDraft.vendor||"")} onChange={ev=>setEditDraft(d=>({...d, vendor: ev.target.value}))} />
                        </label>
                        <label>
                          <div className="small">Notes</div>
                          <input value={String(editDraft.notes||"")} onChange={ev=>setEditDraft(d=>({...d, notes: ev.target.value}))} />
                        </label>
                      </div>

                      <div style={{display:"flex", gap:8, marginTop:10, flexWrap:"wrap"}}>
                        <button className="btnPrimary" onClick={saveEdit}>Save</button>
                        <button className="btn" onClick={()=>{setEditId(null); setEditDraft({});}}>Cancel</button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
