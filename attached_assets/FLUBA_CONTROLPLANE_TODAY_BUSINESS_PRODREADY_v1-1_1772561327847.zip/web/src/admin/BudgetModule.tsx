
export default function BudgetModule(){
  return (
    <div>
      <h2>Budget</h2>
      <p>Track spending vs budget and payees.</p>
    </div>
  );
}
