
import { useEffect, useMemo, useState } from "react";
import { db } from "../firebase";
import {
  collection,
  doc,
  getDocs,
  query,
  where,
  setDoc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";

type Bill = {
  id: string;
  name: string;
  defaultAmount: number;
  dueDay?: number;
  category?: string;
  autopay?: boolean;
  active?: boolean;
};

type MonthStatus = {
  id: string; // YYYY-MM__billId
  billId: string;
  month: string;
  paid: boolean;
  paidDate?: string | null;
};

function monthKey(d = new Date()) {
  return d.toISOString().slice(0, 7);
}

function slugId(name: string) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

function dueInfo(dueDay?: number){
  if(!dueDay) return { delta: null as number|null, label: null as string|null, cls: "" };
  const today = new Date().getDate();
  const delta = dueDay - today;
  let cls = "dueTag";
  let label = `Due ${dueDay}`;
  if(delta < 0){
    cls += " overdue";
    label = `Overdue (${Math.abs(delta)}d)`;
  }else if(delta === 0){
    cls += " urgent";
    label = "Due today";
  }else if(delta <= 2){
    cls += " urgent";
    label = `Due in ${delta}d`;
  }else if(delta <= 5){
    cls += " soon";
    label = `Due in ${delta}d`;
  }else{
    cls += " ok";
    label = `Due in ${delta}d`;
  }
  return { delta, label, cls };
}
}

export default function BillsModule() {
  const [bills, setBills] = useState<Bill[]>([]);
  const [month] = useState(monthKey());
  const [statusMap, setStatusMap] = useState<Record<string, MonthStatus>>({}); // key = billId
  const [view, setView] = useState<"grouped" | "due">("grouped");
  const [busy, setBusy] = useState<string | null>(null);

  const [addForm, setAddForm] = useState({
    name: "",
    amount: "",
    dueDay: "",
    category: "",
    autopay: false,
  });

  const [editId, setEditId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    defaultAmount: "",
    dueDay: "",
    category: "",
    autopay: false,
    active: true,
  });

  useEffect(() => {
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadAll() {
    const [billsSnap, statusSnap] = await Promise.all([
      getDocs(collection(db, "bills")),
      getDocs(query(collection(db, "bill_month_status"), where("month", "==", month))),
    ]);

    const list: Bill[] = [];
    billsSnap.forEach((d) => {
      const data = d.data() as any;
      list.push({
        id: d.id,
        name: data.name ?? d.id,
        defaultAmount: Number(data.defaultAmount ?? 0),
        dueDay: data.dueDay ? Number(data.dueDay) : undefined,
        category: data.category ?? "Other",
        autopay: !!data.autopay,
        active: data.active !== false,
      });
    });

    const sm: Record<string, MonthStatus> = {};
    statusSnap.forEach((d) => {
      const data = d.data() as any;
      const billId = String(data.billId || "").trim();
      if (!billId) return;
      sm[billId] = {
        id: d.id,
        billId,
        month: data.month,
        paid: !!data.paid,
        paidDate: data.paidDate ?? null,
      };
    });

    setBills(list);
    setStatusMap(sm);
  }

  function isPaid(billId: string) {
    return !!statusMap[billId]?.paid;
  }

  async function setPaid(billId: string, paid: boolean) {
    const id = `${month}__${billId}`;
    setBusy(id);
    const next: MonthStatus = {
      id,
      billId,
      month,
      paid,
      paidDate: paid ? new Date().toISOString().slice(0, 10) : null,
    };
    setStatusMap((prev) => ({ ...prev, [billId]: next }));
    await setDoc(doc(db, "bill_month_status", id), next, { merge: true });
    setBusy(null);
  }

  async function addBill() {
    if (!addForm.name.trim()) return;
    const id = slugId(addForm.name);
    setBusy("add");
    await setDoc(doc(db, "bills", id), {
      name: addForm.name.trim(),
      defaultAmount: Number(addForm.amount || 0),
      dueDay: addForm.dueDay ? Number(addForm.dueDay) : null,
      category: addForm.category?.trim() || "Other",
      autopay: !!addForm.autopay,
      active: true,
    });
    setAddForm({ name: "", amount: "", dueDay: "", category: "", autopay: false });
    await loadAll();
    setBusy(null);
  }

  function startEdit(b: Bill) {
    setEditId(b.id);
    setEditForm({
      name: b.name ?? "",
      defaultAmount: String(b.defaultAmount ?? 0),
      dueDay: b.dueDay ? String(b.dueDay) : "",
      category: b.category ?? "Other",
      autopay: !!b.autopay,
      active: b.active !== false,
    });
  }

  function cancelEdit() {
    setEditId(null);
  }

  async function saveEdit(billId: string) {
    setBusy("edit:" + billId);
    await updateDoc(doc(db, "bills", billId), {
      name: editForm.name.trim(),
      defaultAmount: Number(editForm.defaultAmount || 0),
      dueDay: editForm.dueDay ? Number(editForm.dueDay) : null,
      category: editForm.category?.trim() || "Other",
      autopay: !!editForm.autopay,
      active: !!editForm.active,
    });
    setEditId(null);
    await loadAll();
    setBusy(null);
  }

  async function removeBill(billId: string) {
    // safety: we "deactivate" instead of delete by default
    setBusy("remove:" + billId);
    await updateDoc(doc(db, "bills", billId), { active: false });
    await loadAll();
    setBusy(null);
  }

  const activeBills = useMemo(() => bills.filter((b) => b.active !== false), [bills]);

  const totals = useMemo(() => {
    const total = activeBills.reduce((a, b) => a + (b.defaultAmount || 0), 0);
    const paidTotal = activeBills.reduce((a, b) => (isPaid(b.id) ? a + (b.defaultAmount || 0) : a), 0);
    return { total, paidTotal, remaining: total - paidTotal };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeBills, statusMap]);

  const dueSoon = useMemo(() => {
    const today = new Date().getDate();
    return activeBills
      .filter((b) => !!b.dueDay && b.dueDay! >= today && b.dueDay! <= today + 7)
      .sort((a, b) => (a.dueDay || 99) - (b.dueDay || 99));
  }, [activeBills]);

  const grouped = useMemo(() => {
    const map: Record<string, Bill[]> = {};
    for (const b of activeBills) {
      const cat = b.category || "Other";
      map[cat] = map[cat] || [];
      map[cat].push(b);
    }
    const cats = Object.keys(map).sort((a, b) => a.localeCompare(b));
    return cats.map((cat) => ({
      cat,
      items: map[cat].sort((a, b) => a.name.localeCompare(b.name)),
    }));
  }, [activeBills]);

  const dueSorted = useMemo(() => {
    return [...activeBills].sort((a, b) => (a.dueDay || 99) - (b.dueDay || 99));
  }, [activeBills]);

  function BillRow({ b }: { b: Bill }) {
    const paid = isPaid(b.id);
    const rowBusy = busy === `${month}__${b.id}` || busy === "edit:" + b.id || busy === "remove:" + b.id;
    const isEditing = editId === b.id;

    if (isEditing) {
      return (
        <div className={`billRow ${paid ? "paid" : ""}`} style={{ border: "1px solid rgba(255,255,255,.12)", borderRadius: 12, padding: 12, marginBottom: 10 }}>
          <div style={{ display: "grid", gap: 10 }}>
            <div>
              <label>Name</label>
              <input className="input" value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div>
                <label>Amount</label>
                <input className="input" inputMode="decimal" value={editForm.defaultAmount} onChange={(e) => setEditForm({ ...editForm, defaultAmount: e.target.value })} />
              </div>
              <div>
                <label>Due Day</label>
                <input className="input" inputMode="numeric" value={editForm.dueDay} onChange={(e) => setEditForm({ ...editForm, dueDay: e.target.value })} />
              </div>
            </div>
            <div>
              <label>Category</label>
              <input className="input" value={editForm.category} onChange={(e) => setEditForm({ ...editForm, category: e.target.value })} />
            </div>
            <div style={{ display: "flex", gap: 14, alignItems: "center", flexWrap: "wrap" }}>
              <label style={{ display: "flex", gap: 8, alignItems: "center", margin: 0 }}>
                <input type="checkbox" checked={editForm.autopay} onChange={(e) => setEditForm({ ...editForm, autopay: e.target.checked })} />
                Autopay
              </label>
              <label style={{ display: "flex", gap: 8, alignItems: "center", margin: 0 }}>
                <input type="checkbox" checked={editForm.active} onChange={(e) => setEditForm({ ...editForm, active: e.target.checked })} />
                Active
              </label>
            </div>

            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <button className="btnPrimary" disabled={rowBusy} onClick={() => saveEdit(b.id)}>
                {rowBusy ? "Saving…" : "Save"}
              </button>
              <button className="btnSecondary" onClick={cancelEdit}>Cancel</button>
              <button className="btnSecondary" disabled={rowBusy} onClick={() => removeBill(b.id)}>
                Deactivate
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="card" style={{ marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: 16 }}>{b.name}</div>
            <div style={{ opacity: 0.8, fontSize: 13 }}>
              ${Number(b.defaultAmount || 0).toFixed(2)}
              {b.dueDay ? (
                <>
                  {" "}•{" "}
                  <span className={dueInfo(b.dueDay).cls}>{dueInfo(b.dueDay).label}</span>
                </>
              ) : null}
              {b.autopay ? <> • <span className="pill">(Autopay)</span></> : null}
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <label style={{ display: "flex", gap: 8, alignItems: "center", margin: 0 }}>
              <input
                type="checkbox"
                checked={paid}
                disabled={rowBusy}
                onChange={(e) => void setPaid(b.id, e.target.checked)}
              />
              <span style={{ fontWeight: 700 }}>{paid ? "Paid" : "Unpaid"}</span>
            </label>
            <button className="btnSecondary" onClick={() => startEdit(b)}>Edit</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h2 style={{ marginTop: 0 }}>Bills</h2>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 12 }}>
        <button className={view === "grouped" ? "btnPrimary" : "btnSecondary"} onClick={() => setView("grouped")}>
          Grouped
        </button>
        <button className={view === "due" ? "btnPrimary" : "btnSecondary"} onClick={() => setView("due")}>
          By Due Date
        </button>
      </div>

      <div className="grid2">
        <div className="card">
          <div className="badge">THIS MONTH</div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 10 }}>
            <div>
              <div className="p" style={{ margin: 0, opacity: 0.8 }}>Total</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${totals.total.toFixed(2)}</div>
            </div>
            <div>
              <div className="p" style={{ margin: 0, opacity: 0.8 }}>Paid</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${totals.paidTotal.toFixed(2)}</div>
            </div>
            <div>
              <div className="p" style={{ margin: 0, opacity: 0.8 }}>Remaining</div>
              <div style={{ fontSize: 26, fontWeight: 900 }}>${totals.remaining.toFixed(2)}</div>
            </div>
          </div>
          <div style={{ marginTop: 14 }}>
            <div className="progress">
              <div className="progressFill" style={{ width: `${totals.total ? Math.min(100, Math.max(0, (totals.paid / totals.total) * 100)) : 0}%` }} />
            </div>
            <div className="p" style={{ marginTop: 8, opacity: 0.85 }}>
              {totals.total ? `${Math.round((totals.paid / totals.total) * 100)}% paid` : "No total yet"}
            </div>
          </div>

          <p className="p" style={{ marginTop: 10 }}>
            Month key: <span style={{ opacity: 0.8 }}>{month}</span>
          </p>
        </div>

        <div className="card">
          <div className="badge">DUE SOON</div>
          {dueSoon.length === 0 ? (
            <p className="p" style={{ marginTop: 10, opacity: 0.85 }}>No due dates in the next 7 days (or due days not set).</p>
          ) : (
            <div style={{ marginTop: 10 }}>
              {dueSoon.map((b) => (
                <div key={b.id} className="row" style={{ borderTop: "1px solid rgba(255,255,255,.08)" }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>{b.name}</div>
                    <div style={{ opacity: 0.8, fontSize: 13 }}>${Number(b.defaultAmount || 0).toFixed(2)}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div><span className={dueInfo(b.dueDay).cls}>{dueInfo(b.dueDay).label}</span></div>
                    <div style={{ opacity: 0.8, fontSize: 13 }}>{b.autopay ? "Autopay" : "Manual"}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div style={{ height: 14 }} />

      {view === "grouped" ? (
        <div>
          {grouped.map((g) => (
            <div key={g.cat} style={{ marginBottom: 16 }}>
              <h3 style={{ margin: "8px 0", opacity: 0.9 }}>{g.cat}</h3>
              {g.items.map((b) => (
                <BillRow key={b.id} b={b} />
              ))}
            </div>
          ))}
        </div>
      ) : (
        <div>
          {dueSorted.map((b) => (
            <BillRow key={b.id} b={b} />
          ))}
        </div>
      )}

      <hr style={{ margin: "16px 0", opacity: 0.2 }} />

      <div className="card">
        <div className="badge">ADD BILL</div>
        <div style={{ display: "grid", gap: 10, marginTop: 10 }}>
          <div>
            <label>Name</label>
            <input className="input" value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} placeholder="e.g., Water" />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <label>Amount</label>
              <input className="input" inputMode="decimal" value={addForm.amount} onChange={(e) => setAddForm({ ...addForm, amount: e.target.value })} placeholder="e.g., 68.01" />
            </div>
            <div>
              <label>Due Day</label>
              <input className="input" inputMode="numeric" value={addForm.dueDay} onChange={(e) => setAddForm({ ...addForm, dueDay: e.target.value })} placeholder="e.g., 20" />
            </div>
          </div>

          <div>
            <label>Category</label>
            <input className="input" value={addForm.category} onChange={(e) => setAddForm({ ...addForm, category: e.target.value })} placeholder="e.g., Utilities" />
          </div>

          <label style={{ display: "flex", gap: 8, alignItems: "center", margin: 0 }}>
            <input type="checkbox" checked={addForm.autopay} onChange={(e) => setAddForm({ ...addForm, autopay: e.target.checked })} />
            Autopay
          </label>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button className="btnPrimary" disabled={busy === "add"} onClick={() => void addBill()}>
              {busy === "add" ? "Adding…" : "Add Bill"}
            </button>
            <button className="btnSecondary" onClick={() => void loadAll()}>
              Refresh
            </button>
          </div>

          <p className="p" style={{ marginTop: 6, opacity: 0.8 }}>
            Tip: Use <b>Deactivate</b> instead of delete to keep history clean.
          </p>
        </div>
      </div>
    </div>
  );
}
