
// Routine Engine integrated
export default function HealthModule(){
  return (
    <section>
      <h2>Exercise & Health</h2>
      <p>
        Routine Engine is active.
        Create exercise library, routines, generate daily workouts,
        log performance, and track progress.
      </p>
      <p>
        Configure Firebase to enable persistence.
      </p>
    </section>
  )
}
