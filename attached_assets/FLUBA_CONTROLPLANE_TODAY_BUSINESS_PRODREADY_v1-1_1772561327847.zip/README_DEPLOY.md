# Fluba Control Plane Deploy (Firebase)

This project can be deployed in two ways:

## A) Full deploy (recommended)
Includes Firestore rules/indexes + Functions + Hosting.

Follow exactly:
- `Deploy/ToDo.txt`

## B) Hosting-only quick deploy
Use this only if you intentionally are not deploying functions/rules.

1) Build
cd web
npm install
npm run build

2) Deploy
cd ..
firebase login
firebase deploy --only hosting

## Notes
- Firebase project id is set in `.firebaserc` (example: "fluba-prod"). Change only if your project id differs.
- `web/src/firebase.ts` contains placeholders you must fill with your Web app config.
- For production hardening knobs, read `HARDENING_NOTES.md`.
