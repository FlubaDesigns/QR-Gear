import os, subprocess, time
from flask import Flask, request, jsonify, abort

app = Flask(__name__)

SECRET = os.environ.get("WEBHOOK_SECRET", "")
COOLDOWN = int(os.environ.get("WEBHOOK_COOLDOWN_SECONDS", "3"))
last_run = {"push_main":0,"push_dev":0,"pull_main":0,"pull_dev":0,"sync_dm":0,"sync_md":0}

def auth_ok(req):
    if request.method != "POST":
        return False
    key = req.headers.get("X-Webhook-Key")
    return bool(SECRET) and key == SECRET

def safe_run(tag, cmd):
    now = time.time()
    if now - last_run[tag] < COOLDOWN:
        return 429, f"Too many requests; wait {COOLDOWN}s between calls."
    last_run[tag] = now
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True, text=True, timeout=240)
        return 0, out
    except subprocess.CalledProcessError as e:
        return e.returncode, e.output
    except Exception as e:
        return 1, str(e)

@app.route("/", methods=["GET"])
def root():
    return "OK"

@app.route("/hook/push/main", methods=["POST"])
def hook_push_main():
    if not auth_ok(request): abort(401)
    code, out = safe_run("push_main", "./push_main.sh")
    return jsonify({"code":code,"output":out})

@app.route("/hook/push/dev", methods=["POST"])
def hook_push_dev():
    if not auth_ok(request): abort(401)
    code, out = safe_run("push_dev", "./push_dev.sh")
    return jsonify({"code":code,"output":out})

@app.route("/hook/pull/main", methods=["POST"])
def hook_pull_main():
    if not auth_ok(request): abort(401)
    code, out = safe_run("pull_main", "./pull_main.sh")
    return jsonify({"code":code,"output":out})

@app.route("/hook/pull/dev", methods=["POST"])
def hook_pull_dev():
    if not auth_ok(request): abort(401)
    code, out = safe_run("pull_dev", "./pull_dev.sh")
    return jsonify({"code":code,"output":out})

@app.route("/hook/sync/dev-to-main", methods=["POST"])
def hook_sync_dm():
    if not auth_ok(request): abort(401)
    code, out = safe_run("sync_dm", "./sync_dev_to_main.sh")
    return jsonify({"code":code,"output":out})

@app.route("/hook/sync/main-to-dev", methods=["POST"])
def hook_sync_md():
    if not auth_ok(request): abort(401)
    code, out = safe_run("sync_md", "./sync_main_to_dev.sh")
    return jsonify({"code":code,"output":out})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
