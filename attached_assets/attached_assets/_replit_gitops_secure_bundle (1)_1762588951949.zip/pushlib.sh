#!/usr/bin/env bash
set -Eeuo pipefail

GITHUB_USER="KingdomConnects"
REPO="kingdom-connects-app"
REMOTE_NAME="origin"

require_token() {
  if [[ -z "${GITHUB_TOKEN:-}" ]]; then
    echo "ERROR: GITHUB_TOKEN not set."
    exit 1
  fi
}

setup_git() {
  git config user.name  "Replit Bot"
  git config user.email "replit@users.noreply.github.com"
  [[ -d .git ]] || git init
  local url="https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${REPO}.git"
  if git remote | grep -q "^${REMOTE_NAME}$"; then
    git remote set-url "${REMOTE_NAME}" "${url}"
  else
    git remote add "${REMOTE_NAME}" "${url}" || true
  fi
}

ensure_branch() {
  local branch="$1"
  git fetch "${REMOTE_NAME}" "${branch}" || true
  if git rev-parse --verify "${branch}" >/dev/null 2>&1; then
    git checkout "${branch}"
  else
    if git ls-remote --exit-code --heads "${REMOTE_NAME}" "${branch}" >/dev/null 2>&1; then
      git checkout -b "${branch}" --track "${REMOTE_NAME}/${branch}"
    else
      git checkout -b "${branch}"
    fi
  fi
}

pull_rebase() {
  local branch="$1"
  git checkout "${branch}"
  git fetch "${REMOTE_NAME}" "${branch}" || true
  git pull --rebase "${REMOTE_NAME}" "${branch}" || true
}

commit_and_push() {
  local branch="$1"
  local msg="${2:-chore(replit): sync $(date -u '+%Y-%m-%d %H:%M:%S UTC')}"
  git add -A
  if git diff --cached --quiet; then
    git commit --allow-empty -m "${msg}"
  else
    git commit -m "${msg}"
  fi
  git push -u "${REMOTE_NAME}" "${branch}"
}

ff_merge() {
  local FROM="$1" TO="$2"
  git checkout "$TO"
  git fetch "${REMOTE_NAME}" "$FROM" || true
  git merge --ff-only "$FROM"
  git push -u "${REMOTE_NAME}" "$TO"
}
