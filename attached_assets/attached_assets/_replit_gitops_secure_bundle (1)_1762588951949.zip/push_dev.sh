#!/usr/bin/env bash
set -Eeuo pipefail
source ./pushlib.sh
require_token; setup_git
ensure_branch "dev"
pull_rebase "dev"
commit_and_push "dev" "${1:-feat: mobile dev push}"
echo "OK: pushed to dev"
