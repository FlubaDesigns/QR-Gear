#!/usr/bin/env bash
set -Eeuo pipefail
source ./pushlib.sh
require_token; setup_git
ensure_branch "dev"
pull_rebase "dev"
echo "OK: pulled & rebased dev"
