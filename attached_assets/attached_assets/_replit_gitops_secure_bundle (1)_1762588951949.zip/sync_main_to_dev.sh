#!/usr/bin/env bash
set -Eeuo pipefail
source ./pushlib.sh
require_token; setup_git
ensure_branch "main"
pull_rebase "main"
ensure_branch "dev"
pull_rebase "dev"
ff_merge "main" "dev" || { echo "Not fast-forward; manual merge required."; exit 1; }
echo "OK: main → dev fast-forward sync complete"
