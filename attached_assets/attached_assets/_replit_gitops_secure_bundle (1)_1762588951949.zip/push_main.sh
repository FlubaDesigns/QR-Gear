#!/usr/bin/env bash
set -Eeuo pipefail
source ./pushlib.sh
require_token; setup_git
ensure_branch "main"
pull_rebase "main"
commit_and_push "main" "${1:-feat: mobile main push}"
echo "OK: pushed to main"
