#!/usr/bin/env bash
set -Eeuo pipefail
source ./pushlib.sh
require_token; setup_git
ensure_branch "dev"
pull_rebase "dev"
commit_and_push "dev" "chore: pre-sync dev"
ensure_branch "main"
pull_rebase "main"
ff_merge "dev" "main" || { echo "Not fast-forward; manual merge required."; exit 1; }
echo "OK: dev → main fast-forward sync complete"
