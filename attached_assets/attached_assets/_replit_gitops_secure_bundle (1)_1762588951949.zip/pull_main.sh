#!/usr/bin/env bash
set -Eeuo pipefail
source ./pushlib.sh
require_token; setup_git
ensure_branch "main"
pull_rebase "main"
echo "OK: pulled & rebased main"
