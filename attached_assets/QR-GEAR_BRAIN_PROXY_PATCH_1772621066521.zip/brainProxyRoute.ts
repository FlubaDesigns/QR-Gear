
import crypto from "crypto";
import fetch from "node-fetch";

function sign(secret:string,body:string){
  return crypto.createHmac("sha256",secret).update(body).digest("hex");
}

export async function submitToBrain(req,res){

  const body={
    action:req.body.action,
    payload:req.body.payload
  };

  const raw=JSON.stringify(body);

  const sig=sign(process.env.FLUBA_SITE_SECRET,raw);

  const r=await fetch(process.env.FLUBA_BRAIN_URL,{
    method:"POST",
    headers:{
      "content-type":"application/json",
      "x-site-id":"qr-gear",
      "x-signature":sig
    },
    body:raw
  });

  const data=await r.json();

  res.json(data);
}
