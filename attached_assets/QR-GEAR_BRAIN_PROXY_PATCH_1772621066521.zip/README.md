
QR-GEAR BRAIN PROXY

Add server route:

POST /api/brain/submit

This route signs the request and forwards it to Fluba Brain.
