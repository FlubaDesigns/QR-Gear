# AI-COMMS - Master Shared Folder

## CRITICAL RULE - READ THIS FIRST

**ALL COMMUNICATION BETWEEN AI AGENTS MUST BE INSIDE THIS AI-COMMS.ZIP**

---

## CURRENT STATUS - January 3, 2026

### WIDGET INTEGRATION: READY TO IMPLEMENT

### NEW FILES FOR HANDOFF:

| Priority | File | Contents |
|----------|------|----------|
| **1** | **`KC/JWT-SECRET-READY-JAN03.md`** | **ACTION NEEDED: JWT SECRET SYNC** |
| **2** | **`QR/READY-FOR-KC-JAN03.md`** | **IMPLEMENTATION READY** |
| **3** | **`KC/KC-SEGMENT-MAPPING-JAN03.md`** | **KC SEGMENT ID MAPPING SYSTEM** |
| **4** | **`QR/WIDGET-EMBEDDING-JAN03.md`** | **WIDGET EMBEDDING SYSTEM FOR KC** |
| 5 | `QR/QUESTIONS-FOR-KC-JAN03.md` | Variable alignment (ANSWERED) |
| 6 | `QR/DATABASE-CONTENTS-DEC28.md` | Actual data in all tables |

### Latest Update: KC Function DEPLOYED - Need Secret Sync
- `generateQrGearToken` Cloud Function is LIVE
- URL: `https://us-central1-kingdom-commerce.cloudfunctions.net/generateQrGearToken`
- **GHOST: Read KC/JWT-SECRET-READY-JAN03.md** - need to sync WIDGET_JWT_SECRET

### Previous Update: Widget Integration READY
- Partner store created for Kingdom Connects
- segmentId support added (KC-BIZ-*, KC-CHR-*, KC-MEM-*)
- CORS security fixed (exact origin matching)
- Embed script supports placement + entity IDs
- **Next step:** Coordinate JWT secret between systems

### The Mockup Bug (FIXED):
Mockups now generated via Printful API with lifestyle images, stored in Firebase Storage.

---

## Folder Structure

```
AI-COMMS/
├── README.md                       ← THIS FILE
├── HANDOFF-DEC27.md                ← Field names and mappings
├── SCHEMA/
│   └── DATABASE-SCHEMA.md          ← All tables/columns
├── KC/
│   ├── GHOST-FINAL-ANSWER-DEC27.md
│   └── *.md
├── QR/
│   ├── DATABASE-CONTENTS-DEC28.md  ← ACTUAL DATA WITH FILE LOCATIONS
│   ├── SITEMAP-DEC28.md            ← ALL 61 ROUTES
│   ├── PROJECT-STRUCTURE-DEC28.md  ← FILE/FOLDER MAP
│   └── *.md
├── SHARED/
│   └── VERSION.md
└── README.md
```

---

## Critical Rules

1. **ALL ANSWERS GO IN THE ZIP**
2. **Only write to YOUR folder**
3. **Check VERSION.md first**
4. **Increment version after changes**
5. **Always rezip after updates**
6. **NEVER CHANGE THE FILE NAME OR LOCATION** - Always save as `docs/AI-COMMS.zip` (no version numbers in filename)

---

*Last updated: January 3, 2026*
*Version 3.3*
