/**
 * Member Authentication Guard
 * Points to centralized access control
 */
import { requireMember, requireAuth } from "../../js/auth/access-control.js";
export { requireMember, requireAuth };
