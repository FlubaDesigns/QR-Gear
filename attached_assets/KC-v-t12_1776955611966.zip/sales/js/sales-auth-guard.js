/**
 * Sales Agent Authentication Guard
 * Points to centralized access control
 */
import { requireSalesAgent, requireSalesDirector, requireAuth } from "../../js/auth/access-control.js";
export { requireSalesAgent, requireSalesDirector, requireAuth };
