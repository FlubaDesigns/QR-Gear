import { initGlobalErrorHandler } from './error-handler.js';

initGlobalErrorHandler();
