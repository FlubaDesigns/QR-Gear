export function renderBusinessProBenefits(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = `
    <article class="card">
      <h2 class="gold-metallic text-center m-block-lg">What You Get as a Business Pro</h2>
      
      <div class="benefits-grid">
        <div class="benefit-item">
          <svg class="benefit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
          </svg>
          <div class="benefit-text">
            <strong>Directory Listing</strong>
            <p>Your business appears in our searchable Christian business directory, connecting you with faith-minded customers.</p>
          </div>
        </div>

        <div class="benefit-item">
          <svg class="benefit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
          </svg>
          <div class="benefit-text">
            <strong>Community Connection</strong>
            <p>Join a growing network of Christian businesses supporting each other and their local churches.</p>
          </div>
        </div>

        <div class="benefit-item">
          <svg class="benefit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/>
          </svg>
          <div class="benefit-text">
            <strong>Customer Reviews</strong>
            <p>Build trust with verified reviews from members of the Kingdom Connects community.</p>
          </div>
        </div>

        <div class="benefit-item">
          <svg class="benefit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
          </svg>
          <div class="benefit-text">
            <strong>Church Affiliation</strong>
            <p>Show your church connection to build instant trust with fellow believers in your community.</p>
          </div>
        </div>

        <div class="benefit-item">
          <svg class="benefit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>
          </svg>
          <div class="benefit-text">
            <strong>Business Dashboard</strong>
            <p>Manage your listing, view analytics, and respond to reviews from your dedicated dashboard.</p>
          </div>
        </div>

        <div class="benefit-item">
          <svg class="benefit-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
          </svg>
          <div class="benefit-text">
            <strong>Email Notifications</strong>
            <p>Get notified when customers leave reviews or when your listing needs attention.</p>
          </div>
        </div>
      </div>
    </article>

    <article class="card pro-upsell-card">
      <div class="pro-badge">PRO</div>
      <h2 class="gold-metallic text-center">Your Pro Features</h2>
      <p class="text-center text-muted m-block-lg">Premium features included with your Business Pro membership</p>
      
      <div class="benefits-grid">
        <div class="benefit-item pro-benefit">
          <svg class="benefit-icon gold-metallic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/>
          </svg>
          <div class="benefit-text">
            <strong class="gold-metallic">Promotions & Deals</strong>
            <p>Create special offers that appear prominently in the directory and attract new customers.</p>
          </div>
        </div>

        <div class="benefit-item pro-benefit">
          <svg class="benefit-icon gold-metallic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
          </svg>
          <div class="benefit-text">
            <strong class="gold-metallic">Products & Services Showcase</strong>
            <p>Display your offerings with photos and descriptions to help customers understand what you do.</p>
          </div>
        </div>

        <div class="benefit-item pro-benefit">
          <svg class="benefit-icon gold-metallic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
          </svg>
          <div class="benefit-text">
            <strong class="gold-metallic">Customer Testimonials</strong>
            <p>Highlight your best customer stories and endorsements on your listing page.</p>
          </div>
        </div>

        <div class="benefit-item pro-benefit">
          <svg class="benefit-icon gold-metallic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
          <div class="benefit-text">
            <strong class="gold-metallic">Photo Gallery</strong>
            <p>Showcase your work with multiple photos that help customers see what you do best.</p>
          </div>
        </div>

        <div class="benefit-item pro-benefit">
          <svg class="benefit-icon gold-metallic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
          </svg>
          <div class="benefit-text">
            <strong class="gold-metallic">Church Tithing</strong>
            <p>10% of your Pro subscription goes directly to your affiliated church, supporting their ministry.</p>
          </div>
        </div>

        <div class="benefit-item pro-benefit">
          <svg class="benefit-icon gold-metallic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
          </svg>
          <div class="benefit-text">
            <strong class="gold-metallic">Verified Pro Badge</strong>
            <p>Stand out with a gold Pro badge that shows you're committed to excellence and community.</p>
          </div>
        </div>
      </div>
    </article>

    <article class="card">
      <h3 class="gold">Why Kingdom Connects?</h3>
      <p class="line-height-relaxed">
        You're now part of a growing community of faith-based businesses supporting each other and their local churches. 
        Through Kingdom Connects, your business can reach fellow believers while contributing 10% of Pro subscriptions back to your church.
        Together, we're building sustainable Christian commerce that honors God and strengthens the Body of Christ.
      </p>
    </article>
  `;
}
