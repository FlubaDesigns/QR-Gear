import { renderMemberBenefits } from '/js/benefits/member-benefits.js';

document.addEventListener('DOMContentLoaded', () => {
  renderMemberBenefits('benefitsContainer');
});
