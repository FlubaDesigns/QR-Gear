import { generateSegmentId, getKcPageUrl } from './segment-mapper.js';

const QRGEAR_EMBED_URL = 'https://qrgear.web.app/embed/qrgear-embed.js';
const PARTNER_ID = 'kingdom-connects';

async function generateWidgetToken(entityType, entityData) {
  const segmentId = generateSegmentId(entityType, entityData.slug);
  const kcListingUrl = getKcPageUrl(entityType, entityData.slug);
  
  const tokenPayload = {
    partnerId: PARTNER_ID,
    placement: entityType,
    segmentId: segmentId,
    kcListingUrl: kcListingUrl,
    allowedSegments: ['Religious', 'Business', 'Custom']
  };
  
  if (entityType === 'business') {
    tokenPayload.businessId = entityData.id || entityData.slug;
    tokenPayload.businessName = entityData.name;
    tokenPayload.businessSlug = entityData.slug;
    tokenPayload.businessLogoUrl = entityData.logo || '';
    tokenPayload.ownerEmail = entityData.ownerEmail || '';
  } else if (entityType === 'church') {
    tokenPayload.churchId = entityData.id || entityData.slug;
    tokenPayload.churchName = entityData.name;
    tokenPayload.churchSlug = entityData.slug;
    tokenPayload.churchLogoUrl = entityData.logo || '';
  } else if (entityType === 'member') {
    tokenPayload.memberId = entityData.email;
    tokenPayload.memberEmail = entityData.email;
    tokenPayload.memberName = entityData.name || '';
  }
  
  try {
    const response = await fetch('/api/qr-widget-token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tokenPayload)
    });
    
    if (!response.ok) {
      throw new Error('Failed to generate widget token');
    }
    
    const data = await response.json();
    return data.token;
  } catch (error) {
    console.error('Error generating QR Gear token:', error);
    return null;
  }
}

function createWidgetEmbed(token, entityType, entityId, options = {}) {
  const container = document.createElement('div');
  container.id = 'qrgear-widget';
  container.setAttribute('data-token', token);
  container.setAttribute('data-placement', entityType);
  
  if (entityType === 'business') {
    container.setAttribute('data-business-id', entityId);
  } else if (entityType === 'church') {
    container.setAttribute('data-church-id', entityId);
  } else if (entityType === 'member') {
    container.setAttribute('data-member-id', entityId);
  }
  
  if (options.segment) {
    container.setAttribute('data-segment', options.segment);
  }
  
  return container;
}

function loadWidgetScript() {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${QRGEAR_EMBED_URL}"]`)) {
      resolve();
      return;
    }
    
    const script = document.createElement('script');
    script.src = QRGEAR_EMBED_URL;
    script.async = true;
    script.onload = resolve;
    script.onerror = reject;
    document.body.appendChild(script);
  });
}

async function embedQrGearWidget(targetElement, entityType, entityData, options = {}) {
  const token = await generateWidgetToken(entityType, entityData);
  
  if (!token) {
    console.error('Could not generate QR Gear token');
    return false;
  }
  
  const entityId = entityData.slug || entityData.id || entityData.email;
  const widgetContainer = createWidgetEmbed(token, entityType, entityId, options);
  
  if (typeof targetElement === 'string') {
    targetElement = document.querySelector(targetElement);
  }
  
  if (!targetElement) {
    console.error('Target element not found');
    return false;
  }
  
  targetElement.appendChild(widgetContainer);
  
  await loadWidgetScript();
  
  return true;
}

export {
  generateWidgetToken,
  createWidgetEmbed,
  loadWidgetScript,
  embedQrGearWidget,
  PARTNER_ID,
  QRGEAR_EMBED_URL
};
