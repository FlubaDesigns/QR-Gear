const SEGMENT_TYPES = {
  BUSINESS: 'business',
  CHURCH: 'church',
  MEMBER: 'member'
};

const SEGMENT_PREFIXES = {
  business: 'KC-BIZ',
  church: 'KC-CHR',
  member: 'KC-MEM'
};

function generateSegmentId(entityType, slug) {
  const prefix = SEGMENT_PREFIXES[entityType] || 'KC-UNK';
  const cleanSlug = (slug || '').toLowerCase().replace(/[^a-z0-9-]/g, '');
  return `${prefix}-${cleanSlug}`;
}

function parseSegmentId(segmentId) {
  if (!segmentId || typeof segmentId !== 'string') {
    return null;
  }
  
  const parts = segmentId.split('-');
  if (parts.length < 3 || parts[0] !== 'KC') {
    return null;
  }
  
  const typeCode = parts[1];
  const slug = parts.slice(2).join('-');
  
  let entityType = null;
  if (typeCode === 'BIZ') entityType = 'business';
  else if (typeCode === 'CHR') entityType = 'church';
  else if (typeCode === 'MEM') entityType = 'member';
  
  return entityType ? { entityType, slug } : null;
}

function getKcPageUrl(entityType, slug) {
  const baseUrl = 'https://kingdomconnects.org';
  
  switch (entityType) {
    case 'business':
      return `${baseUrl}/business/${slug}.htm`;
    case 'church':
      return `${baseUrl}/church/${slug}.htm`;
    case 'member':
      return `${baseUrl}/member/profile/${slug}`;
    default:
      return baseUrl;
  }
}

export { 
  SEGMENT_TYPES, 
  SEGMENT_PREFIXES,
  generateSegmentId, 
  parseSegmentId, 
  getKcPageUrl 
};
