import { renderBusinessBenefits } from '/js/benefits/business-benefits.js';
document.addEventListener('DOMContentLoaded', () => {
  renderBusinessBenefits('benefitsContainer');
});
