import { renderChurchBenefits } from '/js/benefits/church-benefits.js';
document.addEventListener('DOMContentLoaded', () => {
  renderChurchBenefits('benefitsContainer');
});
