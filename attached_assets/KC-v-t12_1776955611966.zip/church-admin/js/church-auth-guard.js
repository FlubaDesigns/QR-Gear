/**
 * Church Admin Authentication Guard
 * Points to centralized access control
 */
import { requireChurchAdmin, requireAuth } from "../../js/auth/access-control.js";
export { requireChurchAdmin, requireAuth };
