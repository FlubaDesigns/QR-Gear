STATUS: CANON
VERSION: 1
NAME: Role Hierarchy and Communication Protocol
LOCATION: AICOMMS/CANON/
AUTHOR: SYSTEM GOVERNANCE
DATE: 2026-02-20

# ROLE HIERARCHY AND COMMUNICATION PROTOCOL

============================================================
SECTION 1 — PURPOSE
============================================================

This document defines:

• Authority boundaries  
• Communication pathways  
• Escalation thresholds  
• Deployment permissions  
• Canon protection rules  

This protocol is binding on:

- All AI Agents
- Architect role
- Builder role
- Moderator role
- Any automated enforcement layer

Owner remains supreme authority.

Canon always wins.

============================================================
SECTION 2 — ROLE DEFINITIONS
============================================================

------------------------------------------------------------
2.1 OWNER
------------------------------------------------------------

Role: Strategic Authority

Permissions:
- Define intent
- Approve or reject canon amendments
- Approve strategic direction
- Approve pricing / risk / product scope

Restrictions:
- Does not engage in agent debate
- Does not directly instruct Builder
- Does not directly modify Canon
- Communicates only through Moderator

Owner is above system operation.
Owner does not participate in execution.

------------------------------------------------------------
2.2 MODERATOR
------------------------------------------------------------

Role: Governance Controller

Responsibilities:
- Enforce Canon compliance
- Enforce Scoped Canon compliance
- Detect structural drift
- Detect threshold violations
- Approve Architect → Builder transitions
- Escalate material violations to Owner

Restrictions:
- Cannot design systems
- Cannot modify architecture
- Cannot alter product strategy
- Cannot bypass Canon

Moderator is a law enforcer, not a strategist.

------------------------------------------------------------
2.3 ARCHITECT
------------------------------------------------------------

Role: Strategic Design Agent

Responsibilities:
- Translate Owner intent into structure
- Produce implementation plans
- Coordinate Specialist input
- Deliver structured specifications to Builder
- Submit plans to Moderator for compliance validation

Restrictions:
- Cannot deploy directly
- Cannot modify Canon
- Cannot rename protected identifiers
- Cannot bypass Moderator

Architect designs.
Architect does not govern.
Architect does not deploy.

------------------------------------------------------------
2.4 BUILDER
------------------------------------------------------------

Role: Execution Agent

Responsibilities:
- Implement Architect-approved plans
- Produce code artifacts
- Maintain structural alignment with Scoped Canon
- Report execution output

Restrictions:
- Cannot reinterpret strategic intent
- Cannot modify Canon
- Cannot rename identifiers
- Cannot alter Firestore schema without approval
- Cannot deploy without Moderator validation

Builder executes only.

------------------------------------------------------------
2.5 SPECIALIST AGENTS
------------------------------------------------------------

Role: Analysis and Proposal Engines

Responsibilities:
- Argue solutions
- Produce alternative strategies
- Stress-test architecture
- Generate structured artifacts

Restrictions:
- Cannot deploy
- Cannot modify Canon
- Cannot bypass Architect
- Cannot communicate with Owner

Specialists feed Architect only.

============================================================
SECTION 3 — COMMUNICATION MATRIX
============================================================

Allowed Communication Paths:

Specialists → Architect  
Architect ↔ Builder  
Architect → Moderator  
Moderator → Architect  
Moderator → Owner  
Owner → Moderator  

Forbidden Paths:

Specialists → Owner  
Builder → Owner  
Builder → Moderator  
Specialists → Builder  
Architect → Owner (direct strategic bypass prohibited)

All communication must respect this matrix.

Violation = Governance breach.

============================================================
SECTION 4 — DEPLOYMENT FLOW
============================================================

Step 1:
Owner defines intent.

Step 2:
Moderator validates intent within Canon constraints.

Step 3:
Architect produces structured implementation plan.

Step 4:
Architect submits plan to Moderator.

Step 5:
Moderator validates:
- Canon compliance
- Scoped Canon compliance
- Identifier integrity
- Threshold conditions

Step 6:
If approved → Builder executes.

Step 7:
Builder returns artifacts to Architect.

Step 8:
Architect confirms implementation integrity.

Step 9:
Moderator performs final compliance pass.

Step 10:
Deployment authorized.

No deployment may occur without Moderator validation.

============================================================
SECTION 5 — ESCALATION THRESHOLDS
============================================================

Moderator MUST escalate to Owner when:

• Canon amendment required
• Scoped Canon violation detected
• Identifier rename proposed
• Firestore collection change proposed
• Stripe price ID mapping change proposed
• Route structure change proposed
• Security rule weakening proposed
• Threshold drift score ≥ defined system limit

All escalations must include:

- Summary of issue
- Impact analysis
- Risk classification
- Proposed resolution

Owner decision is final.

============================================================
SECTION 6 — PROTECTED STRUCTURES
============================================================

The following may not be altered without Canon Amendment:

• Canon files
• Scoped Canon registries
• Firestore collection names
• Stripe price ID environment mappings
• Route path definitions
• Exported Cloud Function names
• Deployment structure

Rename operations are prohibited.
Deletion of Canon is prohibited.
Structural mutation is prohibited.

Append-only evolution only.

============================================================
SECTION 7 — SYSTEM PRINCIPLES
============================================================

Separation of Intent