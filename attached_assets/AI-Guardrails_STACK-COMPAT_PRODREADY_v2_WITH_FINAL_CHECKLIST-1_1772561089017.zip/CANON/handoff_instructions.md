# AI-COMMS CANON
## Handoff & Delivery Instructions (v1)

### PURPOSE
This document defines the required packaging and delivery procedure for AI-generated work.

It ensures predictable handoff between systems and prevents incomplete, fragmented, or improperly structured outputs.

---

## CORE PRINCIPLE

All deliverables must be:

• complete  
• structured  
• self-contained  
• portable  
• auditable  

Loose outputs are not permitted.

---

## DELIVERY FORMAT

Each implementation or iteration must return:

### EXACTLY ONE ZIP FILE

Naming format:

AICOMS_PACKET_v##.zip

Rules:

• no multiple zip files  
• no loose attachments  
• no partial responses  
• no alternate naming  

---

## REQUIRED ZIP STRUCTURE

The zip must contain:

AICOMS_PACKET/
│
├── PATCH/
│   └── proposed.patch
│
├── LOGS/
│   ├── FILES_CHANGED.md
│   ├── CHANGE_SUMMARY.md
│   └── IMPLEMENTATION_NOTES.md
│
├── TEST_REPORT/
│   └── test_results.md
│
└── RESPONSE.md

---

## PATCH REQUIREMENTS

proposed.patch must:

• include only necessary changes  
• avoid unrelated modifications  
• preserve structure and naming  
• not reformat entire files  

---

## RESPONSE.md REQUIREMENTS

RESPONSE.md must include:

### SUMMARY
What was done.

### ROOT CAUSE
Why the issue occurred.

### CHANGES
Files modified or added.

### RISKS
Possible side effects.

### TEST STEPS
How to verify manually.

### ROLLBACK
How to undo the changes.

### NEXT STEP
Recommended follow-up action.

---

## TEST REPORT REQUIREMENTS

test_results.md must include:

• build results  
• test results (if available)  
• errors or warnings  
• explanation if tests could not run  

---

## STRUCTURE PRESERVATION RULE

The packet structure must not be altered.

New files may be added only when necessary.

---

## COMPLETION MESSAGE

Upon completion, the AI must state:

"Send this packet back to Ghost for review."

---

## INVALID DELIVERY CONDITIONS

A delivery is invalid if:

• multiple zip files are returned  
• required folders are missing  
• RESPONSE.md is missing  
• patch file missing  
• structure altered  

Invalid deliveries must be corrected.

---

## WHY THIS EXISTS

This ensures:

• reliable handoff between AI systems  
• portable deliverables  
• audit-ready change history  
• safe iterative development  

---

## PRINCIPLE

Package completely.  
Deliver predictably.  
Preserve structure.

---

END CANON