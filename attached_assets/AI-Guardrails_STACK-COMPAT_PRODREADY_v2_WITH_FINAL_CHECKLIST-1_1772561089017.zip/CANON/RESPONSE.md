Must include:

- What was added
- Why it was added
- What changed
- Next recommended step

---

## ZIP DELIVERY RULE

Each iteration must return:

### EXACTLY ONE ZIP FILE

Naming format: