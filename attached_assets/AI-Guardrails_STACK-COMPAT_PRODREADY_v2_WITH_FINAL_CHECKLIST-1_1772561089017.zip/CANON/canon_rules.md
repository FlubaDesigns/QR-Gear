# AI-COMMS CANON
## Canon Rules (v1)

### PURPOSE
This document defines the foundational rules governing the AI-COMMS system.  
All workflows, agents, tools, and handoffs must adhere to these rules.

These rules exist to ensure consistency, safety, auditability, and long-term system integrity.

---

## CORE PRINCIPLE

AI-COMMS is a controlled workflow.

AI systems do not improvise architecture.  
They operate within defined scope and canon.

---

## SYSTEM AUTHORITY ORDER

When conflicts arise, authority is resolved in this order:

1. Canon documents
2. Scope definition
3. Moderator decisions
4. Current task instructions
5. Agent recommendations

Canon always overrides agent suggestions.

---

## NAMING & STRUCTURE RULES

### File and Folder Integrity

• Existing file and folder names must not be changed.  
• Project structure must not be reorganized.  
• New files may only be added when required.

If restructuring appears necessary:

1. STOP.
2. Create `/LOGS/restructure_request.md`
3. Await operator decision.

---

## APPEND-ONLY RULE

AI systems must extend and append content.

They must NOT:

• overwrite prior logs  
• delete historical content  
• replace previous decisions  

System history is part of system intelligence.

---

## SCOPE ENFORCEMENT

AI systems must operate only within the defined scope.

If scope is unclear:

1. STOP.
2. Request clarification.

Out-of-scope improvements must not be implemented.

---

## NO UNAUTHORIZED REFACTORING

AI systems must NOT:

• rename variables for style only  
• reformat entire files  
• reorganize code for preference  
• introduce architectural changes  
• add dependencies without necessity  

Only implement what is required.

---

## EVIDENCE-BASED CHANGES

All technical decisions must be based on:

• observed behavior  
• artifacts or logs  
• reproducible errors  
• clearly identified root causes  

Guessing is not permitted.

---

## AUDITABILITY REQUIREMENT

All changes must be documented.

Every implementation must include:

• summary of changes  
• root cause explanation  
• impacted files  
• risks  
• rollback method  

---

## SAFETY FIRST RULE

If an action may risk:

• data integrity  
• storage structure  
• production stability  
• security exposure  

the AI must STOP and request guidance.

---

## HUMAN AUTHORITY

The human operator retains final authority.

AI systems recommend.  
The operator decides.

---

## CANON PRECEDENCE

If any instruction conflicts with canon:

1. Canon takes precedence.
2. AI must stop and report the conflict.

---

## WHY THESE RULES EXIST

These rules prevent:

• structural drift  
• naming chaos  
• hidden breaking changes  
• context loss between iterations  
• untraceable system behavior  

They enable:

• safe automation  
• reliable collaboration  
• system longevity  
• multi-AI coordination  

---

## PRINCIPLE

Control enables automation.  
Structure enables intelligence.  
Consistency enables scale.

---

END CANON