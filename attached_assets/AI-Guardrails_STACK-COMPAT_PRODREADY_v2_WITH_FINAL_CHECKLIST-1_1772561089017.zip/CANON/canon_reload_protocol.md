# AI-COMMS CANON
## Canon Reload Protocol (v1)

### PURPOSE
This protocol ensures that all AI systems operate from the same canonical rules and project context at the beginning of every interaction and packet iteration.

Without enforced canon reload, context drift occurs and system integrity degrades.

---

## CORE PRINCIPLE

Canon is not assumed.

Canon must be loaded, acknowledged, and followed for every iteration.

---

## WHEN CANON MUST BE RELOADED

Canon must be reloaded at the start of:

• every new run  
• every packet iteration  
• every handoff between AI systems  
• every loopback after failure  
• every scope change  
• every implementation phase  

Canon reload is mandatory.

---

## REQUIRED CANON ACKNOWLEDGMENT

Before performing any work, the AI must output:

CANON_VERSION:  
CANON_FILES_READ:  
RENAMES_ALLOWED: NO  
SCOPE_ENFORCED: YES  

Example:

CANON_VERSION: v1  
CANON_FILES_READ:
- canon_rules.md
- canon_names.md
- packet_relay_protocol.md
- canon_reload_protocol.md

RENAMES_ALLOWED: NO  
SCOPE_ENFORCED: YES  

If this acknowledgment is missing, the response is invalid.

---

## CANON DIGEST REQUIREMENT

The AI must provide a brief digest of canon rules relevant to the task.

Example:

CANON DIGEST:
• File and folder names must not be changed  
• Packet structure must be preserved  
• Content must be appended, never replaced  

If the digest is missing or incorrect, the response must be rejected.

---

## SCOPE ALIGNMENT CHECK

After loading canon, the AI must confirm scope alignment.

If scope is unclear:

1. STOP.
2. Request clarification.
3. Do not proceed.

---

## DRIFT PREVENTION RULE

If instructions conflict with canon:

1. Canon takes precedence.
2. The AI must stop.
3. The conflict must be reported.

---

## LOOPBACK REQUIREMENT

Canon must be reloaded again after:

• failed tests  
• loopback iterations  
• major scope revisions  

This prevents drift across iterations.

---

## FAILURE CONDITIONS

A response is invalid if:

• canon acknowledgment is missing  
• canon digest is missing  
• digest misrepresents canon rules  
• work begins before acknowledgment  

Invalid responses must be corrected before proceeding.

---

## WHY THIS PROTOCOL EXISTS

This protocol prevents:

• structural drift  
• unauthorized renaming  
• architecture deviation  
• context loss between iterations  
• misalignment between AI systems  

It ensures all systems operate from the same rule set.

---

## PRINCIPLE

Load → Acknowledge → Align → Execute

Never assume.

---

END CANON