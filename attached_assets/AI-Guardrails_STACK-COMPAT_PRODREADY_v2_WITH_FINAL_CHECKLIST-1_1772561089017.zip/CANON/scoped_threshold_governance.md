# SCOPED THRESHOLD GOVERNANCE
STATUS: CANON
VERSION: 1
TIER: 1
PRINCIPLE: Scoped canon is enforced by Moderator. Operator is involved only when defined thresholds are triggered.

============================================================
PURPOSE
============================================================

This document defines:

• Who controls Scoped Canon
• When Operator involvement is required
• What actions Moderator may perform autonomously
• What triggers escalation

This prevents naming drift while protecting Operator attention.

============================================================
ROLE DEFINITIONS
============================================================

OPERATOR
- Final authority.
- May approve new identifiers.
- May amend canon via formal amendment protocol.
- May override Moderator decisions.

MODERATOR
- May activate Scoped Canon.
- Enforces registry discipline.
- Blocks drift attempts.
- Logs violations.
- Escalates only when threshold conditions are met.

ARCHITECT / INTEGRATOR AGENTS
- May propose changes.
- May not enact new identifiers without approval.
- Must operate within active scope registry.

============================================================
SCOPED CANON CONTROL
============================================================

When Operator declares:

SCOPE ACTIVE: {scope_id}

Moderator must:

1) Load associated Sub-Canon pack.
2) Enforce exact identifier registry.
3) Reject new identifiers not present in registry.
4) Log all violations.
5) Operate silently unless threshold conditions are met.

Scoped canon applies only during declared scope.
Scoped canon does not modify global canon.
Scoped canon does not override Tier 1.

============================================================
DRIFT RULE
============================================================

During active scope:

The following may NOT be created without approval:

• New environment variable names
• New endpoint/function names
• New route paths
• New Firestore collection names
• New Stripe price mappings
• New security rule identifiers

If a new identifier is proposed:

Moderator must:
- Block implementation
- Suggest existing equivalent if possible
- Log attempt

============================================================
THRESHOLD ESCALATION RULE
============================================================

Moderator must escalate to Operator only if:

1) A new identifier is required AND no equivalent exists.
2) A Stripe mapping or billing tier changes.
3) A pricing model or monetization rule changes.
4) A route path change impacts external URLs.
5) A security rule change alters access control.
6) A Tier 1 canon rule may be affected.
7) Drift attempts exceed threshold.

DEFAULT DRIFT THRESHOLD:
3 blocked identifier attempts per task.

When escalation occurs:

Moderator must declare:

THRESHOLD ESCALATION:
- Scope ID
- Proposed change
- Reason existing registry insufficient
- Risk summary
- Recommended action

Work pauses until Operator decision.

============================================================
AUTONOMOUS MODERATOR ACTIONS
============================================================

Moderator may act without escalation when:

• Referencing existing identifiers
• Refactoring without renaming
• Reorganizing internal code
• Formatting or structural cleanup
• Non-breaking implementation
• Logging violations

These actions require no Operator notification.

============================================================
SCOPE CLOSURE
============================================================

When Operator declares:

SCOPE CLOSE: {scope_id}

Moderator must respond:

• SCOPE CLOSED: {scope_id}
• Registry version used
• Drift attempts logged
• Escalations (if any)

============================================================
GOVERNING PRINCIPLE
============================================================

Enforce silently.
Escalate rarely.
Protect stability.
Preserve Operator focus.

END DOCUMENT