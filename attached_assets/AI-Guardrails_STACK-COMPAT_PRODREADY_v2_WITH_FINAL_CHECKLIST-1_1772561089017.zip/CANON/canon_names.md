# AI-COMMS CANON
## Naming Conventions (v1)

### PURPOSE
This document defines the official naming conventions for AI-COMMS.

Consistent naming ensures clarity, automation compatibility, and long-term maintainability.

Naming drift is a primary source of system instability.  
This canon prevents it.

---

## CORE PRINCIPLE

Names must be:

• consistent  
• predictable  
• machine-readable  
• human-readable  
• stable over time  

Once established, names are not changed without a controlled migration.

---

## GENERAL NAMING RULES

### Formatting

• Use lowercase for storage paths and database collections  
• Use underscores (_) for separators in database and storage names  
• Use lowerCamelCase for function names  
• Use PascalCase only for class/component names  
• Avoid spaces and special characters  
• Avoid abbreviations unless universally understood  

---

## PROJECT PREFIX

All AI-COMMS resources must use the prefix:

aicoms_

This prevents conflicts and clearly identifies system ownership.

---

## FIRESTORE COLLECTIONS

### Format
lowercase_with_underscores

### Canon Collections

aicoms_runs  
aicoms_artifacts  
aicoms_canon  
aicoms_config  
aicoms_library  

### Subcollections

aicoms_runs/{run_id}/turns  
aicoms_runs/{run_id}/events  

---

## DOCUMENT ID FORMATS

### Run ID

aicoms_run_YYYYMMDD_HHMMSS_random

Example:
aicoms_run_20260216_193045_x7k2m

---

### Artifact ID

aicoms_art_YYYYMMDD_HHMMSS_random

Example:
aicoms_art_20260216_193112_q9d4r

---

### Turn ID

aicoms_turn_role_timestamp

Example:
aicoms_turn_integrator_193245

---

## CLOUD FUNCTIONS

### Format
lowerCamelCase

### Required Prefix
aicoms

### Examples

aicomsRunDebate  
aicomsRunTool  
aicomsDispatchAgent  
aicomsUpdateScope  
aicomsFinalizeRun  

---

## CLOUD STORAGE PATHS

### Root Folder

aicoms/

### Artifact Paths

aicoms/artifacts/  
aicoms/artifacts/screenshot_reports/  
aicoms/artifacts/zip_index_reports/  
aicoms/artifacts/test_reports/  

### Export Paths

aicoms/exports/packets/

---

## FILE NAMING FOR ARTIFACTS

### Format

artifact_type__artifact_id__v#.ext

### Examples

screenshot_report__aicoms_art_20260216_193112_q9d4r__v1.json  
test_report__aicoms_art_20260216_194001_b7k2p__v2.txt  

---

## ROLE NAMES (CANON)

proposer  
challenger  
architect  
moderator  
integrator  
tester  

These names must not be altered.

---

## RUN PHASE NAMES (CANON)

scope_lock  
think_tank  
architect_review  
moderator_gate  
integration  
test_run  
validation  
loopback  
done  
blocked  

---

## ROUTES (IF USED)

### Format
kebab-case

Example:
/aicoms/runs  
/aicoms/artifacts  

---

## VARIABLES & FIELD NAMES

### Format
lower_snake_case

### Examples

run_id  
artifact_type  
created_at  
input_hash  
scope_status  

---

## PROHIBITED NAMING PRACTICES

AI systems must NOT:

• introduce inconsistent casing  
• invent alternate naming patterns  
• rename existing collections or paths  
• use ambiguous abbreviations  
• mix naming styles  

---

## RENAMING POLICY

Renaming is NOT permitted during normal operation.

If renaming appears necessary:

1. STOP.
2. Document request in `/LOGS/rename_request.md`
3. Await operator decision.
4. Migration planning required.

---

## WHY THIS MATTERS

Consistent naming enables:

• automation
• reliable querying
• predictable integrations
• safe refactoring
• multi-AI coordination

Inconsistent naming creates long-term technical debt.

---

## PRINCIPLE

Clear names reduce errors.  
Consistent names enable automation.  
Stable names preserve system integrity.

---

END CANON