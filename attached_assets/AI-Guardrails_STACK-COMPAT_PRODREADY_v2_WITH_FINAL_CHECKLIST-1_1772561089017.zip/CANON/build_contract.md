# AI-COMMS CANON
## Build Contract (v1)

### PURPOSE
This contract defines the mandatory rules governing implementation work performed by AI systems.

Its purpose is to ensure safe, predictable builds and prevent unauthorized changes, structural drift, or architectural deviation.

This contract is binding for all implementation tasks.

---

## OPERATING PRINCIPLE

AI systems implement requested changes.

They do NOT redesign systems.

They do NOT improve unrelated code.

They do NOT refactor architecture.

---

## CANON COMPLIANCE (MANDATORY)

Before any implementation begins, the AI must:

1. Load all canon documents.
2. Acknowledge canon compliance.
3. Confirm no renames will occur.
4. Confirm scope adherence.

If canon acknowledgment is missing, work must not proceed.

---

## SCOPE ENFORCEMENT

AI systems must operate strictly within the defined task scope.

If scope is unclear:

1. STOP.
2. Request clarification.

Out-of-scope improvements are prohibited.

---

## STRUCTURAL INTEGRITY RULE

AI systems must NOT:

• rename files  
• rename folders  
• move files  
• reorganize directories  
• restructure project layout  

If restructuring appears necessary:

1. STOP.
2. Create `/LOGS/restructure_request.md`
3. Await operator decision.

---

## NAMING PROTECTION RULE

AI systems must NOT:

• rename Firestore collections  
• rename storage paths  
• rename cloud functions  
• rename routes  
• rename environment variables  
• rename components for style  

If renaming appears necessary:

1. STOP.
2. Create `/LOGS/rename_request.md`
3. Await operator decision.

---

## APPEND-ONLY IMPLEMENTATION RULE

AI systems must:

• add new files when required  
• modify only necessary code sections  
• preserve existing logic outside the change area  

AI systems must NOT:

• overwrite unrelated code  
• delete existing logic  
• reformat entire files  

---

## NO UNAUTHORIZED REFACTORING

AI systems must NOT:

• reformat files for style preference  
• reorganize imports unless required  
• rewrite working logic  
• introduce new patterns or frameworks  
• change architecture conventions  

Only implement what is necessary.

---

## DEPENDENCY CONTROL

AI systems must NOT add new dependencies unless:

• required for functionality  
• explicitly approved  
• documented in RESPONSE.md  

---

## PATCH REQUIREMENTS

All implementation responses must include:

• list of files changed  
• exact changes made  
• root cause explanation  
• risks introduced  
• rollback instructions  

---

## TEST REQUIREMENTS

AI systems must:

• run available build/test processes  
• report results accurately  
• include errors and warnings  

If tests cannot run, the reason must be documented.

---

## SAFETY STOP CONDITIONS

The AI must STOP and request guidance if a change may impact:

• data integrity  
• storage structure  
• authentication or security  
• production stability  
• billing or external services  

---

## FAILURE CONDITIONS

An implementation is invalid if:

• files are renamed  
• structure is altered  
• unrelated code is modified  
• dependencies added without justification  
• scope exceeded  
• changes undocumented  

Invalid implementations must be corrected.

---

## WHY THIS CONTRACT EXISTS

This contract prevents:

• hidden breaking changes  
• naming drift  
• structural instability  
• uncontrolled refactoring  
• unpredictable system behavior  

It enables:

• safe automation  
• reliable collaboration  
• repeatable builds  
• long-term maintainability  

---

## PRINCIPLE

Implement precisely.  
Change only what is necessary.  
Preserve system integrity.

---

END CONTRACT