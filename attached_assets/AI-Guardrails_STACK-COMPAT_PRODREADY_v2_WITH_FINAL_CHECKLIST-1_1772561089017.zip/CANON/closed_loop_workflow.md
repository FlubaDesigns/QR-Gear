# AI-COMMS CANON
## Closed Loop Workflow (v1)

### PURPOSE
This document defines the end-to-end lifecycle for AI-assisted development using the AI-COMMS system.

It ensures every task follows a complete cycle of analysis, implementation, verification, and review between systems.

---

## CORE PRINCIPLE

Every task must complete the loop:

Define → Implement → Test → Review → Loopback (if needed)

No step may be skipped.

---

## SYSTEM ROLES

### Operator (Human)
• defines objectives  
• relays packet between systems  
• approves major decisions  

### Claude (Builder)
• reads packet and canon  
• implements requested changes  
• updates packet contents  
• runs tests when possible  
• returns updated packet  

### Ghost (Reviewer / Architect)
• verifies canon compliance  
• reviews implementation quality  
• detects drift or risk  
• refines next iteration  
• maintains architectural integrity  

---

## WORKFLOW PHASES

### 1. SCOPE LOCK (Operator + Ghost)

The objective is defined.

Requirements:
• clear goal  
• defined boundaries  
• success criteria  

If scope is unclear, implementation must not begin.

---

### 2. PACKET DELIVERY (Operator)

Operator delivers the current AI-COMMS packet to Claude.

Packet contents represent the current project state.

---

### 3. IMPLEMENTATION (Claude)

Claude must:

• reload canon documents  
• acknowledge canon compliance  
• preserve packet structure  
• implement only scoped changes  
• update packet logs and RESPONSE.md  
• run build/tests when possible  
• increment packet version  

Claude returns:

AICOMS_PACKET_v##.zip

---

### 4. TEST & VERIFICATION (Claude)

Claude must include:

• build results  
• test results (if available)  
• errors or warnings  
• explanation if tests cannot run  

---

### 5. REVIEW (Operator → Ghost)

Operator sends updated packet to Ghost.

Ghost performs:

• canon compliance check  
• structural integrity verification  
• implementation review  
• risk detection  
• improvement recommendations  

---

### 6. LOOPBACK DECISION (Ghost + Operator)

Possible outcomes:

PASS → proceed to next task  
PASS WITH NOTES → continue with improvements noted  
REVISION REQUIRED → new packet iteration required  
BLOCK → operator decision required  

---

### 7. ITERATION LOOP

If revision is required:

1. Ghost updates guidance.
2. Operator relays packet to Claude.
3. Claude updates packet.
4. Operator returns packet to Ghost.
5. Repeat until PASS.

---

## LOOPBACK TRIGGERS

Loopback is required when:

• tests fail  
• canon violations occur  
• structure is altered  
• risks are introduced  
• scope is exceeded  
• implementation incomplete  

---

## CANON ENFORCEMENT

At every iteration:

• canon must be reloaded  
• naming rules must be followed  
• structure must be preserved  

Canon overrides implementation decisions.

---

## FAILURE CONDITIONS

The workflow is invalid if:

• packet structure is altered  
• multiple zip files are returned  
• canon acknowledgment missing  
• scope exceeded  
• required documentation missing  

Invalid iterations must be corrected.

---

## WHY THIS WORKFLOW EXISTS

This loop ensures:

• safe multi-AI collaboration  
• architectural integrity  
• predictable iteration  
• audit-ready development  
• continuous improvement  

---

## PRINCIPLE

Build → Verify → Review → Refine

Repeat until correct.

---

END CANON