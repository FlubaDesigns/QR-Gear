# SCOPED REGISTRY MACHINE FORMAT
STATUS: CANON
VERSION: 1
TIER: 1
PRINCIPLE: Scoped Canon registries must have a deterministic machine-readable form to enable automated enforcement.

============================================================
PURPOSE
============================================================

This document defines the required JSON format for all Scoped Canon packs.

The machine format:

• Enables objective drift detection
• Prevents naming ambiguity
• Allows deterministic set comparison
• Removes subjective interpretation
• Ensures enforcement automation readiness

This file governs ALL Scoped Canon JSON registry files.

============================================================
REQUIRED STRUCTURE
============================================================

Each Scoped Canon pack MUST contain:

1) Human-readable file:
   example: aicomms_names_scope_v1.md

2) Machine-readable file:
   example: aicomms_names_scope_v1.json

Both files are immutable.
Changes require supersession via new version.

============================================================
JSON FILE LOCATION RULE
============================================================

Machine registry file must be located in:

/SCOPED_CANON/

Filename format:

{scope_name}_names_scope_v{number}.json

Example:

/SCOPED_CANON/aicomms_names_scope_v1.json

============================================================
MANDATORY JSON SCHEMA
============================================================

The JSON file must follow this exact structure:

{
  "meta": {
    "status": "SCOPED_CANON",
    "version": 1,
    "scope_name": "STRING",
    "pack_name": "STRING",
    "generated_at": "YYYY-MM-DD",
    "notes": "STRING"
  },
  "env": {
    "global": [],
    "stripe": [],
    "resend": [],
    "openai": [],
    "other": []
  },
  "functions": {
    "exports": []
  },
  "routes": {
    "paths": []
  },
  "firestore": {
    "collections": [],
    "doc_patterns": []
  },
  "stripe": {
    "price_id_env_keys": [],
    "price_to_tier": {}
  }
}

No additional top-level keys are permitted.

============================================================
IDENTIFIER MATCHING RULE
============================================================

All identifiers are:

• Case-sensitive
• Character-for-character exact
• Whitespace-sensitive
• No normalization permitted

Exact string equality required.

============================================================
REGISTRY SET CONSTRUCTION
============================================================

Registry set R is defined as:

R = union(
  env.global,
  env.stripe,
  env.resend,
  env.openai,
  env.other,
  functions.exports,
  routes.paths,
  firestore.collections,
  stripe.price_id_env_keys,
  keys(stripe.price_to_tier)
)

============================================================
DRIFT CALCULATION FORMULA
============================================================

Let:

P = identifiers proposed in current task
R = registry set from active JSON scope pack

DRIFT_SET = P − R

If DRIFT_SET ≠ ∅
→ Drift detected.

Drift count incremented by number of unique identifiers in DRIFT_SET.

============================================================
SCOPE VALIDATION RULE
============================================================

If:

• JSON registry file missing
• JSON malformed
• Required keys missing

Then:

Scope is INVALID.
Work must halt.
Operator intervention required.

============================================================
SUPERSESSION RULE
============================================================

Registry changes require:

1) New version file
2) Supersession log entry
3) Version increment

Old versions remain immutable.

============================================================
PRINCIPLE
============================================================

Human-readable for clarity.
Machine-readable for enforcement.
Immutable for stability.
Deterministic for scale.

END DOCUMENT