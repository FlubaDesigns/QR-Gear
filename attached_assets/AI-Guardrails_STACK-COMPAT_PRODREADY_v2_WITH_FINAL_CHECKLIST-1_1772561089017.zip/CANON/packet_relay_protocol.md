# AI-COMMS CANON
## Packet Relay Protocol (v1)

### PURPOSE
This protocol defines the required workflow for iterative packet-based collaboration between AI systems and the human operator.

It ensures continuity, structural integrity, and reliable handoff between systems.

Without this protocol, context drift and structural corruption occur.

---

## CORE PRINCIPLE

The AI-COMMS packet is the **single evolving source of project state**.

Each iteration must:

Preserve → Extend → Return

Never replace.

---

## OPERATOR ROLE

The human operator acts as the courier between systems.

Workflow:

1. Deliver packet to AI.
2. AI updates packet.
3. AI returns updated packet.
4. Operator delivers packet to next system.
5. Repeat.

This relay enables multi-AI collaboration.

---

## PACKET AUTHORITY

The packet contents are authoritative.

AI systems must treat packet contents as the current truth unless canon documents specify otherwise.

---

## PACKET ITERATION REQUIREMENTS

Each AI receiving the packet MUST:

### 1. READ
• Read all packet contents.  
• Review canon documents before acting.

### 2. PRESERVE
• Do NOT remove files.  
• Do NOT rename files.  
• Do NOT restructure folders.  
• Do NOT overwrite prior content.

### 3. APPEND
• Add new information.  
• Add artifacts as needed.  
• Extend logs rather than replacing them.

### 4. MAINTAIN HISTORY
System history must remain intact.

Previous decisions and logs must never be removed.

### 5. UPDATE VERSION
Increment packet version number.

Example:

AICOMS_PACKET_v01.zip  
AICOMS_PACKET_v02.zip  
AICOMS_PACKET_v03.zip  

---

## RESPONSE DOCUMENTATION

Each iteration must include:

RESPONSE.md

This file must contain:

• summary of additions  
• reason for changes  
• files modified or added  
• risks or cautions  
• recommended next step  

---

## ZIP DELIVERY RULE

Each iteration must return:

### EXACTLY ONE ZIP FILE

Naming format:

AICOMS_PACKET_v##.zip

Rules:

• no additional attachments  
• no multiple zip files  
• no loose files  

---

## STRUCTURE PRESERVATION RULE

The packet structure must remain intact.

New files may be added only when necessary.

Existing structure must not be altered.

---

## PROHIBITED ACTIONS

AI systems must NOT:

✖ rename files or folders  
✖ reorganize structure  
✖ delete content  
✖ overwrite logs  
✖ refactor unrelated code  
✖ redesign architecture  
✖ introduce structural changes  

If restructuring appears necessary:

1. STOP.
2. Create `/LOGS/restructure_request.md`
3. Await operator decision.

---

## CANON PRIORITY

Canon documents override packet contents.

If packet contents conflict with canon:

1. Canon takes precedence.
2. Report the conflict.
3. Await guidance.

---

## COMPLETION MESSAGE

Upon finishing an iteration, the AI must state:

"Send this packet back to Ghost for review."

---

## FAILURE CONDITIONS

A packet iteration is invalid if:

• multiple zip files are returned  
• packet structure is altered  
• previous contents removed  
• version not incremented  
• RESPONSE.md missing  

Invalid packets must be corrected before proceeding.

---

## WHY THIS PROTOCOL EXISTS

This protocol ensures:

• continuity between AI systems  
• protection against structural drift  
• reliable multi-AI collaboration  
• auditability of decisions  
• predictable evolution of system intelligence  

---

## PRINCIPLE

Preserve → Extend → Return

The packet evolves.  
It is never replaced.

---

END CANON