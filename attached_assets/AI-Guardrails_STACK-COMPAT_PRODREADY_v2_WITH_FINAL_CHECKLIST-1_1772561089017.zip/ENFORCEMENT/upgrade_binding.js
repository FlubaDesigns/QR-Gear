/**
 * Binding Upgrade Helper
 * STATUS: ENFORCEMENT
 * VERSION: 1
 *
 * Upgrades app scope_binding.json to newest allowed registry version
 * based on the latest supersession log where:
 *   OPERATOR_APPROVAL_REQUIRED: NO
 *
 * Usage:
 *   node AICOMMS/ENFORCEMENT/upgrade_binding.js --scope=AICOMMS
 *   node AICOMMS/ENFORCEMENT/upgrade_binding.js --scope=POLLSIT --app=pollsit-app
 *
 * Notes:
 * - Refuses upgrade if approval required
 * - Writes binding upgrade log
 */

const fs = require("fs");
const path = require("path");

function parseArgs(argv) {
  const out = {};
  argv.slice(2).forEach((a) => {
    const m = a.match(/^--([^=]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
  });
  return out;
}

function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2) + "\n");
}

function timestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function readText(p) {
  return fs.readFileSync(p, "utf8");
}

function parseSupersessionLog(txt) {
  // Very strict parsing (exact keys)
  const get = (key) => {
    const m = txt.match(new RegExp(`^${key}:\\s*(.+)$`, "m"));
    return m ? m[1].trim() : null;
  };

  return {
    scope: get("SCOPE"),
    from: get("FROM"),
    to: get("TO"),
    approval: get("OPERATOR_APPROVAL_REQUIRED"),
    createdAt: get("CREATED_AT"),
  };
}

function findLatestAllowedSupersession(logsDir, scopeLower) {
  const files = fs.readdirSync(logsDir)
    .filter((f) => f.toLowerCase().includes("artifact_supersession_") && f.toLowerCase().includes(scopeLower))
    .sort(); // timestamps in filename make lex sort work

  for (let i = files.length - 1; i >= 0; i--) {
    const p = path.join(logsDir, files[i]);
    const parsed = parseSupersessionLog(readText(p));

    if (!parsed.scope) continue;
    if (parsed.scope.toLowerCase() !== scopeLower) continue;

    if (parsed.approval === "NO" && parsed.to) {
      return { file: files[i], path: p, parsed };
    }
  }

  return null;
}

// Paths
const args = parseArgs(process.argv);
const scope = (args.scope || "").trim();
if (!scope) {
  console.error("❌ Missing --scope=NAME");
  process.exit(2);
}

const scopeLower = scope.toLowerCase();

const AICOMMS_ROOT = path.resolve(__dirname, ".."); // AICOMMS/
const REPO_ROOT = path.resolve(AICOMMS_ROOT, "..");
const APPS_DIR = path.join(AICOMMS_ROOT, "APPS");
const LOGS_DIR = path.join(AICOMMS_ROOT, "LOGS");

if (!exists(APPS_DIR) || !exists(LOGS_DIR)) {
  console.error("❌ Missing required folders: AICOMMS/APPS or AICOMMS/LOGS");
  process.exit(2);
}

// Find latest allowed supersession for this scope
const latest = findLatestAllowedSupersession(LOGS_DIR, scopeLower);

if (!latest) {
  console.error("❌ No allowed supersession found.");
  console.error("Either no supersession logs exist, or latest requires Operator approval.");
  process.exit(2);
}

const targetJsonRel = `AICOMMS/SCOPED_CANON/${latest.parsed.to}`;
const targetJsonAbs = path.join(REPO_ROOT, targetJsonRel);

if (!exists(targetJsonAbs)) {
  console.error("❌ Target registry json missing:", targetJsonAbs);
  process.exit(2);
}

// Determine which apps to upgrade
let apps = fs.readdirSync(APPS_DIR).filter((n) => {
  const p = path.join(APPS_DIR, n);
  return fs.statSync(p).isDirectory();
});

if (args.app) {
  apps = apps.filter((n) => n === args.app);
  if (apps.length === 0) {
    console.error("❌ App not found under AICOMMS/APPS:", args.app);
    process.exit(2);
  }
}

// Upgrade bindings
const upgraded = [];

for (const appName of apps) {
  const bindingPath = path.join(APPS_DIR, appName, "scope_binding.json");
  if (!exists(bindingPath)) continue;

  const binding = readJson(bindingPath);
  if (!binding.scope_name || String(binding.scope_name).toLowerCase() !== scopeLower) continue;

  const old = binding.registry_json;
  binding.registry_json = targetJsonRel;

  writeJson(bindingPath, binding);
  upgraded.push({ appName, old, now: binding.registry_json });
}

// Write upgrade log
const ts = timestamp();
const logName = `binding_upgrade_${ts}_${scopeLower}.md`;
const logPath = path.join(LOGS_DIR, logName);

const log = `# BINDING UPGRADE LOG
STATUS: LOG
TYPE: BINDING_UPGRADE
SCOPE: ${scope}
SUPERSESSION_LOG: ${latest.file}
TARGET_REGISTRY: ${targetJsonRel}
CREATED_AT: ${ts}

============================================================
UPGRADED APPS
============================================================
${upgraded.length ? upgraded.map(u => `- ${u.appName}: ${u.old} -> ${u.now}`).join("\n") : "- (none matched scope or no bindings found)"}

END LOG
`;

fs.writeFileSync(logPath, log);

console.log("✅ BINDING UPGRADE COMPLETE");
console.log("Scope:", scope);
console.log("Target registry:", targetJsonRel);
console.log("Apps upgraded:", upgraded.length);
console.log("Log:", logPath);
process.exit(0);