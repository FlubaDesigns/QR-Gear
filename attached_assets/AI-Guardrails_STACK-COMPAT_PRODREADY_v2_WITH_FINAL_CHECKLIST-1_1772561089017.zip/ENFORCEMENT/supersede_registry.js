/**
 * Registry Supersession Generator
 * STATUS: ENFORCEMENT
 * VERSION: 1
 *
 * Generates:
 * - new scoped registry JSON + MD (version bump)
 * - supersession log in /LOGS/
 *
 * Usage examples:
 *   node AICOMMS/ENFORCEMENT/supersede_registry.js --scope=AICOMMS --add=ENV:NEW_KEY
 *   node AICOMMS/ENFORCEMENT/supersede_registry.js --scope=POLLSIT --add=FUNCTION:newExport --add=ROUTE:/new
 *
 * Supported add/remove formats:
 *   ENV:<NAME>
 *   FUNCTION:<name>
 *   ROUTE:</path>
 *   COLLECTION:<name>
 *   STRIPE_KEY:<ENV_KEY>
 *   STRIPE_MAP:<ENV_KEY>=<tier>
 *
 * Notes:
 * - Exact match identifiers
 * - No mutation of existing packs
 */

const fs = require("fs");
const path = require("path");

function parseArgs(argv) {
  const out = { add: [], remove: [] };
  argv.slice(2).forEach((a) => {
    const m = a.match(/^--([^=]+)=(.*)$/);
    if (!m) return;
    const k = m[1];
    const v = m[2];
    if (k === "add") out.add.push(v);
    else if (k === "remove") out.remove.push(v);
    else out[k] = v;
  });
  return out;
}

function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function writeFile(p, content) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, content);
}

function timestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function findLatestPack(scopeName, scopedCanonDir) {
  const files = fs.readdirSync(scopedCanonDir);
  const rx = new RegExp(`^${scopeName.toLowerCase()}_names_scope_v(\\d+)\\.json$`);
  let best = null;
  for (const f of files) {
    const m = f.match(rx);
    if (!m) continue;
    const v = parseInt(m[1], 10);
    if (!best || v > best.v) best = { v, file: f };
  }
  return best;
}

function ensureArray(obj, pathArr) {
  let cur = obj;
  for (const key of pathArr) {
    if (!(key in cur)) cur[key] = [];
    cur = cur[key];
  }
  if (!Array.isArray(cur)) throw new Error(`Expected array at ${pathArr.join(".")}`);
  return cur;
}

function addUnique(arr, item) {
  if (!arr.includes(item)) arr.push(item);
}

function removeItem(arr, item) {
  const i = arr.indexOf(item);
  if (i >= 0) arr.splice(i, 1);
}

function parseChange(s) {
  // TYPE:VALUE or STRIPE_MAP:KEY=tier
  const idx = s.indexOf(":");
  if (idx === -1) throw new Error(`Bad change format: ${s}`);
  const type = s.slice(0, idx).trim().toUpperCase();
  const value = s.slice(idx + 1).trim();
  return { type, value };
}

function requiresApproval(changes) {
  const hardTypes = new Set(["STRIPE_KEY", "STRIPE_MAP", "ROUTE"]);
  return changes.some(c => hardTypes.has(c.type));
}

// Paths
const args = parseArgs(process.argv);
const scope = (args.scope || "").trim();
if (!scope) {
  console.error("❌ Missing --scope=NAME");
  process.exit(2);
}

const AICOMMS_ROOT = path.resolve(__dirname, "..");   // AICOMMS/
const REPO_ROOT = path.resolve(AICOMMS_ROOT, "..");   // repo root
const SCOPED_CANON_DIR = path.join(AICOMMS_ROOT, "SCOPED_CANON");
const LOGS_DIR = path.join(AICOMMS_ROOT, "LOGS");

if (!exists(SCOPED_CANON_DIR)) {
  console.error("❌ Missing AICOMMS/SCOPED_CANON/");
  process.exit(2);
}

const latest = findLatestPack(scope, SCOPED_CANON_DIR);
if (!latest) {
  console.error(`❌ No base registry found for scope "${scope}". Expected: ${scope.toLowerCase()}_names_scope_v1.json`);
  process.exit(2);
}

const baseJsonPath = path.join(SCOPED_CANON_DIR, latest.file);
const base = readJson(baseJsonPath);

const nextVersion = latest.v + 1;
const scopeLower = scope.toLowerCase();

const newJsonName = `${scopeLower}_names_scope_v${nextVersion}.json`;
const newMdName  = `${scopeLower}_names_scope_v${nextVersion}.md`;

const newJsonPath = path.join(SCOPED_CANON_DIR, newJsonName);
const newMdPath   = path.join(SCOPED_CANON_DIR, newMdName);

if (exists(newJsonPath) || exists(newMdPath)) {
  console.error("❌ Target version files already exist. Aborting.");
  process.exit(2);
}

// Apply changes
const addChanges = (args.add || []).map(parseChange);
const remChanges = (args.remove || []).map(parseChange);
const allChanges = [...addChanges, ...remChanges];

const updated = JSON.parse(JSON.stringify(base));
updated.meta = updated.meta || {};
updated.meta.version = nextVersion;
updated.meta.pack_name = `${scopeLower}_names_scope_v${nextVersion}`;
updated.meta.generated_at = new Date().toISOString().slice(0, 10);
updated.meta.notes = (updated.meta.notes || "") + ` (superseded from v${latest.v})`;

function apply(ch, mode) {
  const { type, value } = ch;

  if (type === "ENV") {
    // default bucket: env.other
    const arr = ensureArray(updated, ["env", "other"]);
    mode === "add" ? addUnique(arr, value) : removeItem(arr, value);
    return;
  }

  if (type === "FUNCTION") {
    const arr = ensureArray(updated, ["functions", "exports"]);
    mode === "add" ? addUnique(arr, value) : removeItem(arr, value);
    return;
  }

  if (type === "ROUTE") {
    const arr = ensureArray(updated, ["routes", "paths"]);
    mode === "add" ? addUnique(arr, value) : removeItem(arr, value);
    return;
  }

  if (type === "COLLECTION") {
    const arr = ensureArray(updated, ["firestore", "collections"]);
    mode === "add" ? addUnique(arr, value) : removeItem(arr, value);
    return;
  }

  if (type === "STRIPE_KEY") {
    const arr = ensureArray(updated, ["stripe", "price_id_env_keys"]);
    mode === "add" ? addUnique(arr, value) : removeItem(arr, value);
    return;
  }

  if (type === "STRIPE_MAP") {
    const [k, tier] = value.split("=");
    if (!k || !tier) throw new Error(`Bad STRIPE_MAP format: ${value} (expected KEY=tier)`);
    updated.stripe = updated.stripe || {};
    updated.stripe.price_to_tier = updated.stripe.price_to_tier || {};
    if (mode === "add") updated.stripe.price_to_tier[k] = tier;
    else delete updated.stripe.price_to_tier[k];
    return;
  }

  throw new Error(`Unsupported change type: ${type}`);
}

for (const ch of addChanges) apply(ch, "add");
for (const ch of remChanges) apply(ch, "remove");

// Write JSON
writeFile(newJsonPath, JSON.stringify(updated, null, 2) + "\n");

// Write MD (simple deterministic mirror)
const md = `# ${scope} NAMES SCOPE PACK
STATUS: SCOPED_CANON
VERSION: ${nextVersion}
SCOPE_NAME: ${scope}
PACK_NAME: ${scopeLower}_names_scope_v${nextVersion}
MACHINE_REGISTRY: ${newJsonName}
GENERATED_AT: ${updated.meta.generated_at}

============================================================
NOTE
============================================================

This is the human-readable mirror of the machine registry:
AICOMMS/SCOPED_CANON/${newJsonName}

Identifiers are exact-match only.

============================================================
END PACK
============================================================
`;
writeFile(newMdPath, md);

// Write supersession log
const ts = timestamp();
const logName = `artifact_supersession_${ts}_${scopeLower}_v${nextVersion}.md`;
const logPath = path.join(LOGS_DIR, logName);

const approval = requiresApproval(allChanges) ? "YES" : "NO";
const log = `# ARTIFACT SUPERSESSION
STATUS: LOG
TYPE: SUPERSESSION
SCOPE: ${scope}
FROM: ${latest.file}
TO: ${newJsonName}
OPERATOR_APPROVAL_REQUIRED: ${approval}
CREATED_AT: ${ts}

============================================================
CHANGES ADDED
============================================================
${addChanges.length ? addChanges.map(c => `- ${c.type}: ${c.value}`).join("\n") : "- (none)"}

============================================================
CHANGES REMOVED
============================================================
${remChanges.length ? remChanges.map(c => `- ${c.type}: ${c.value}`).join("\n") : "- (none)"}

============================================================
NOTES
============================================================
If OPERATOR_APPROVAL_REQUIRED is YES, do not update any bindings until Operator approves.

END LOG
`;
writeFile(logPath, log);

console.log("✅ SUPERSESSION GENERATED");
console.log(`Base: ${baseJsonPath}`);
console.log(`New:  ${newJsonPath}`);
console.log(`MD:   ${newMdPath}`);
console.log(`Log:  ${logPath}`);