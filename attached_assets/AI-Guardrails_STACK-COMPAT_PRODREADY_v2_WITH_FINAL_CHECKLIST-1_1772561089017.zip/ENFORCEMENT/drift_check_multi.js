/**
 * AI-COMMS Drift Check (Multi-scope)
 * Minimal v1: validates scope_binding + registry existence and emits a report.
 * (We can expand to deep parsing later; this gets you a working gate.)
 */

const fs = require("fs");
const path = require("path");

const AICOMMS_ROOT = path.resolve(__dirname, "..");
const REPO_ROOT = path.resolve(AICOMMS_ROOT, "..");
const APPS_DIR = path.join(AICOMMS_ROOT, "APPS");

function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }
function readJson(p) { return JSON.parse(fs.readFileSync(p, "utf8")); }
function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch { return false; } }

function listApps() {
  return fs.readdirSync(APPS_DIR)
    .map(n => path.join(APPS_DIR, n))
    .filter(isDir);
}

function main() {
  if (!exists(APPS_DIR)) {
    console.error("❌ Missing AICOMMS/APPS");
    process.exit(2);
  }

  const apps = listApps();
  const report = [];

  for (const appPath of apps) {
    const bindingPath = path.join(appPath, "scope_binding.json");
    const appName = path.basename(appPath);

    if (!exists(bindingPath)) {
      report.push({ app: appName, ok: false, error: "MISSING_BINDING" });
      continue;
    }

    let binding;
    try {
      binding = readJson(bindingPath);
    } catch {
      report.push({ app: appName, ok: false, error: "BINDING_INVALID_JSON" });
      continue;
    }

    const registryAbs = path.join(REPO_ROOT, binding.registry_json || "");
    if (!binding.registry_json || !exists(registryAbs)) {
      report.push({ app: appName, ok: false, error: "MISSING_REGISTRY", registry_json: binding.registry_json || null });
      continue;
    }

    report.push({
      app: appName,
      ok: true,
      scope: binding.scope_name,
      registry_json: binding.registry_json,
      scan_roots: binding.scan_roots || []
    });
  }

  const failures = report.filter(r => !r.ok);
  console.log(JSON.stringify({ ok: failures.length === 0, report }, null, 2));

  process.exit(failures.length === 0 ? 0 : 1);
}

main();