# AI-COMMS Enforcement Engine

This directory contains mechanical drift enforcement.

It compares code identifiers against:

SCOPED_CANON/aicomms_names_scope_v1.json

If an identifier appears in code but not in the registry:

→ Build fails
→ Exit code 1
→ Drift must be resolved via scoped canon supersession

Run manually:

node ENFORCEMENT/drift_check.js

Integrate into build:

"scripts": {
  "drift-check": "node ENFORCEMENT/drift_check.js"
}

Then run before deploy:

npm run drift-check