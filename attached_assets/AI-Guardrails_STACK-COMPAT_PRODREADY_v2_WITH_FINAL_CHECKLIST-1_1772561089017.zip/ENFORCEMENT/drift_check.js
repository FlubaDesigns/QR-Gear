/**
 * AI-COMMS Drift Enforcement Engine
 * VERSION: 1
 * PURPOSE: Deterministically block identifier drift
 *
 * Usage:
 * node drift_check.js
 *
 * Exits with code 1 if drift detected.
 */

const fs = require("fs");
const path = require("path");

// ----------------------------
// CONFIG
// ----------------------------

const ROOT = path.join(__dirname, "..");
const SCOPE_JSON_PATH = path.join(
  ROOT,
  "SCOPED_CANON",
  "aicomms_names_scope_v1.json"
);

const SEARCH_DIRECTORIES = [
  path.join(ROOT, "APPS"),
  path.join(ROOT, "functions"),
  path.join(ROOT, "public"),
];

// ----------------------------
// LOAD REGISTRY
// ----------------------------

if (!fs.existsSync(SCOPE_JSON_PATH)) {
  console.error("❌ Scoped Canon JSON not found.");
  process.exit(1);
}

const registry = JSON.parse(fs.readFileSync(SCOPE_JSON_PATH, "utf8"));

// Flatten allowed identifiers
const allowed = new Set();

// ENV
Object.values(registry.env).forEach(arr => {
  arr.forEach(v => allowed.add(v));
});

// FUNCTIONS
registry.functions.exports.forEach(v => allowed.add(v));

// ROUTES
registry.routes.paths.forEach(v => allowed.add(v));

// FIRESTORE COLLECTIONS
registry.firestore.collections.forEach(v => allowed.add(v));

// STRIPE ENV KEYS
registry.stripe.price_id_env_keys.forEach(v => allowed.add(v));

// ----------------------------
// FILE SCAN
// ----------------------------

function walk(dir, fileList = []) {
  if (!fs.existsSync(dir)) return fileList;

  const files = fs.readdirSync(dir);
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      walk(filePath, fileList);
    } else if (
      file.endsWith(".js") ||
      file.endsWith(".ts") ||
      file.endsWith(".tsx") ||
      file.endsWith(".json")
    ) {
      fileList.push(filePath);
    }
  });

  return fileList;
}

const filesToScan = SEARCH_DIRECTORIES.flatMap(dir => walk(dir));

const discovered = new Set();

filesToScan.forEach(file => {
  const content = fs.readFileSync(file, "utf8");

  // crude but effective token scan
  const matches = content.match(/[A-Z_]{4,}/g);
  if (matches) {
    matches.forEach(token => discovered.add(token));
  }
});

// ----------------------------
// DRIFT CALCULATION
// ----------------------------

const drift = [];

discovered.forEach(token => {
  if (!allowed.has(token)) {
    drift.push(token);
  }
});

if (drift.length > 0) {
  console.error("🚨 DRIFT DETECTED:");
  drift.forEach(d => console.error(" -", d));
  process.exit(1);
}

console.log("✅ No identifier drift detected.");
process.exit(0);