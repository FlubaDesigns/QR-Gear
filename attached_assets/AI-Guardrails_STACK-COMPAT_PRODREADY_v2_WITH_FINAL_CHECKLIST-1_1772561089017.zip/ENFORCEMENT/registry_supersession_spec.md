# REGISTRY SUPERSESSION SPEC
STATUS: ENFORCEMENT
VERSION: 1
PURPOSE: Deterministic, logged upgrades to SCOPED_CANON registries (v1 → v2 → v3...) without mutation.

============================================================
WHAT THIS DOES
============================================================

When a new identifier is legitimately required, we do NOT edit existing registry files.

Instead we:
1) Generate a new versioned registry pack (JSON + MD)
2) Create a supersession log entry in /LOGS/
3) Update scope_binding.json to point at the new JSON (optional, Operator-controlled)

This preserves history and prevents drift-based corruption.

============================================================
IMMUTABILITY RULE
============================================================

Existing files are never edited:

AICOMMS/SCOPED_CANON/*_v1.json
AICOMMS/SCOPED_CANON/*_v1.md

All changes create new version files:
*_v2.json / *_v2.md

============================================================
REQUIRED OUTPUTS
============================================================

Given:
- scope_name (e.g., AICOMMS, POLLSIT)
- base pack (e.g., aicomms_names_scope_v1.json)
- changes (add/remove identifiers)

We must output:

1) New JSON registry:
   AICOMMS/SCOPED_CANON/<scope>_names_scope_v{n}.json

2) New MD registry:
   AICOMMS/SCOPED_CANON/<scope>_names_scope_v{n}.md

3) Supersession log:
   AICOMMS/LOGS/artifact_supersession_<timestamp>_<scope>_v{n}.md

============================================================
APPROVAL RULE
============================================================

If the change includes any of:
- Stripe keys / billing tier mapping
- Security rules
- Public route changes

Then the change MUST be marked:
OPERATOR_APPROVAL_REQUIRED: YES

Otherwise:
OPERATOR_APPROVAL_REQUIRED: NO

============================================================
END SPEC
============================================================