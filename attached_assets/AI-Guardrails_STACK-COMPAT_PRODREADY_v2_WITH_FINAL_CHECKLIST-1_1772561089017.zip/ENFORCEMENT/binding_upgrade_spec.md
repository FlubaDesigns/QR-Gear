# BINDING UPGRADE SPEC
STATUS: ENFORCEMENT
VERSION: 1
PURPOSE: Safely upgrade app scope bindings to a newer scoped registry pack.

============================================================
GOAL
============================================================

Automate scope binding upgrades ONLY when permitted.

This prevents:
- accidental binding changes
- skipping Operator approval
- scope confusion across apps

============================================================
INPUTS
============================================================

- scope_name (e.g., AICOMMS, POLLSIT)
- app path(s) under AICOMMS/APPS/*
- supersession log file in AICOMMS/LOGS/

============================================================
RULES
============================================================

A binding upgrade is allowed ONLY if:

1) A supersession log exists that declares:
   - SCOPE matches requested scope_name
   - TO points to a newer registry json
   - OPERATOR_APPROVAL_REQUIRED: NO

2) The target registry json exists.

If OPERATOR_APPROVAL_REQUIRED is YES:
- tool must refuse
- human/Operator must approve first

============================================================
OUTPUT
============================================================

- Updates AICOMMS/APPS/<app>/scope_binding.json:
  registry_json → new registry json path

- Writes a log entry:
  AICOMMS/LOGS/binding_upgrade_<timestamp>_<scope>.md

============================================================
END SPEC
============================================================