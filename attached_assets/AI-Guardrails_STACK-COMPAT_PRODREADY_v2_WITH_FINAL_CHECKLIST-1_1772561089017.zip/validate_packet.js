#!/usr/bin/env node
/**
 * AI-Guardrails — validate_packet
 *
 * Usage:
 *   node validate_packet.js <packetDir> [--out <path>] [--no-secret-scan]
 *
 * Produces a VERDICT.json containing:
 *   - pass/fail
 *   - reasons
 *   - canon_hash_verified
 *   - tier (best-effort)
 *
 * Notes:
 *   - Does NOT modify any packet files.
 *   - Refuses obvious secrets/credentials by default.
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const args = process.argv.slice(2);
if (args.length < 1) {
  console.error("Usage: node validate_packet.js <packetDir> [--out <path>] [--no-secret-scan]");
  process.exit(2);
}

function sha256(buf) {
  return crypto.createHash("sha256").update(buf).digest();
}
function sha256hex(buf) {
  return crypto.createHash("sha256").update(buf).digest("hex");
}

function listFiles(root, relBase="") {
  const abs = path.join(root, relBase);
  const entries = fs.readdirSync(abs, { withFileTypes: true });
  let out = [];
  for (const e of entries) {
    const rel = path.join(relBase, e.name);
    const absChild = path.join(root, rel);
    if (e.isDirectory()) {
      out = out.concat(listFiles(root, rel));
    } else if (e.isFile()) {
      out.push(rel.replace(/\\/g, "/"));
    }
  }
  return out.sort();
}

function computeCanonHash(conscienceRoot) {
  const keptDirs = ["CANON", "SCOPED_CANON", "ENFORCEMENT", "TOOLS", "SYSTEM_STATE"];
  const keptFiles = ["CANON_INDEX.md", "OWNER_SETTINGS.json", "README.md"]; // NOTE: manifest is excluded from hash
  const requiredFiles = ["CONSCIENCE_MANIFEST.json"];
  let files = [];
  for (const d of keptDirs) {
    const p = path.join(conscienceRoot, d);
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) {
      for (const rel of listFiles(conscienceRoot, d)) {
        files.push(rel);
      }
    }
  }
  for (const f of keptFiles) {
    const p = path.join(conscienceRoot, f);
    if (fs.existsSync(p) && fs.statSync(p).isFile()) {
      files.push(f);
    }
  }
  // Required files (existence only; excluded from hash)
  for (const f of (requiredFiles || [])) {
    const p = path.join(conscienceRoot, f);
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) {
      throw new Error("Missing required file: " + f);
    }
  }
  files = Array.from(new Set(files)).sort();
  const h = crypto.createHash("sha256");
  for (const rel of files) {
    const abs = path.join(conscienceRoot, rel);
    h.update(Buffer.from(rel, "utf8"));
    h.update(Buffer.from([0]));
    const data = fs.readFileSync(abs);
    h.update(sha256(data));
  }
  return {
    hash: h.digest("hex"),
    fileCount: files.length
  };
}

function findFileCaseInsensitive(root, filename) {
  // shallow: check root only
  const entries = fs.readdirSync(root);
  const hit = entries.find(x => x.toLowerCase() === filename.toLowerCase());
  return hit ? path.join(root, hit) : null;
}

const packetDir = path.resolve(args[0]);
let outPath = null;
let secretScan = true;

for (let i=1;i<args.length;i++) {
  const a = args[i];
  if (a === "--out" && i+1 < args.length) {
    outPath = path.resolve(args[i+1]);
    i++;
  } else if (a === "--no-secret-scan") {
    secretScan = false;
  }
}

const conscienceRoot = path.resolve(__dirname);

const verdict = {
  ok: true,
  reasons: [],
  canon_hash_verified: false,
  canon_hash: null,
  canon_expected_hash: null,
  packet_dir: packetDir,
  timestamp_utc: new Date().toISOString(),
  tier: null,
};

// 1) Canon hash verify
try {
  const manifestPath = path.join(conscienceRoot, "CONSCIENCE_MANIFEST.json");
  const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  const expected = manifest.canon_hash || null;
  verdict.canon_expected_hash = expected;
  const computed = computeCanonHash(conscienceRoot);
  verdict.canon_hash = computed.hash;

  if (expected && expected === computed.hash) {
    verdict.canon_hash_verified = true;
  } else {
    verdict.ok = false;
    verdict.reasons.push("CANON_HASH_MISMATCH: expected " + expected + " got " + computed.hash);
  }
} catch (e) {
  verdict.ok = false;
  verdict.reasons.push("CANON_HASH_VERIFY_FAILED: " + String(e && e.message ? e.message : e));
}

// 2) Packet basic checks
if (!fs.existsSync(packetDir) || !fs.statSync(packetDir).isDirectory()) {
  verdict.ok = false;
  verdict.reasons.push("PACKET_DIR_MISSING");
} else {
  const responsePath = findFileCaseInsensitive(packetDir, "RESPONSE.md");
  if (!responsePath) {
    verdict.ok = false;
    verdict.reasons.push("MISSING_RESPONSE_MD_AT_PACKET_ROOT");
  }
}

// 3) Secret scan (best-effort)
if (verdict.ok && secretScan) {
  const patterns = [
    /-----BEGIN (?:RSA|EC|OPENSSH|PRIVATE) KEY-----/i,
    /\bapi[_-]?key\b\s*[:=]/i,
    /\b(secret|password|passwd|token|bearer)\b\s*[:=]/i,
    /AKIA[0-9A-Z]{16}/g, // AWS access key id
    /AIza[0-9A-Za-z\-_]{35}/g, // Google API key
    /xox[baprs]-[0-9A-Za-z-]{10,}/g, // Slack token-ish
  ];

  const maxBytes = 2 * 1024 * 1024; // 2MB per file cap
  const relFiles = listFiles(packetDir, "");
  for (const rel of relFiles) {
    const abs = path.join(packetDir, rel);
    try {
      const st = fs.statSync(abs);
      if (!st.isFile()) continue;
      if (st.size > maxBytes) continue;
      const buf = fs.readFileSync(abs);
      const text = buf.toString("utf8");
      for (const rx of patterns) {
        if (rx.test(text)) {
          verdict.ok = false;
          verdict.reasons.push("SECRET_PATTERN_DETECTED in " + rel);
          break;
        }
      }
      if (!verdict.ok) break;
    } catch (e) {
      // ignore read errors but record
      verdict.reasons.push("WARN_READ_FAIL " + rel + ": " + String(e && e.message ? e.message : e));
    }
  }
}

// 4) Tier (best-effort): if packet contains a tier hint file in root
if (fs.existsSync(packetDir)) {
  const hints = ["tier.txt", "TIER.txt", "TIER.md", "tier.md"];
  for (const h of hints) {
    const p = path.join(packetDir, h);
    if (fs.existsSync(p)) {
      try {
        const t = fs.readFileSync(p, "utf8").trim().split(/\s+/)[0];
        verdict.tier = t;
      } catch {}
      break;
    }
  }
}

const finalOut = JSON.stringify(verdict, null, 2);
const defaultOut = path.join(packetDir, "VERDICT.json");
const target = outPath || defaultOut;

try {
  fs.writeFileSync(target, finalOut, "utf8");
} catch (e) {
  // if can't write, still print
  console.error("WARN: failed to write verdict to", target, e.message);
}
console.log(finalOut);
process.exit(verdict.ok ? 0 : 1);
