# AI-COMMS NAMES SCOPE PACK
STATUS: SCOPED_CANON
VERSION: 1
SCOPE_NAME: AICOMMS
PACK_NAME: aicomms_names_scope_v1
MACHINE_REGISTRY: aicomms_names_scope_v1.json
GENERATED_AT: 2026-02-20
RULE: Identifiers are exact-match only. No aliases. No substitutions. No new names without supersession + log.

============================================================
PURPOSE
============================================================

This pack is the authoritative identifier registry for AI-COMMS tasks.
While AICOMMS scope is active, agents must ONLY use the identifiers listed here.

If an identifier is not listed, it is drift.
Drift is blocked, counted, and escalated per canon.

============================================================
A) ENV / SECRETS (EXACT NAMES)
============================================================

GLOBAL
- PUBLIC_SITE_BASE_URL

STRIPE
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_AUDIT_PRICE_ID
- STRIPE_PRO_PRICE_ID
- STRIPE_ENTERPRISE_PRICE_ID
- GRACE_PERIOD_DAYS

RESEND
- RESEND_API_KEY
- AICOMMS_FROM_EMAIL
- AICOMMS_ADMIN_EMAIL

OPENAI
- OPENAI_API_KEY

============================================================
B) CLOUD FUNCTIONS (EXACT EXPORT NAMES)
============================================================

- createCheckoutSession
- stripeWebhook
- onLeadCreated
- generateAuditDraft
- generateProposalDraft
- sendProposalOnApproval
- generateContractDraft
- sendContractOnApproval
- lifecycleReminder
- clientStatus

============================================================
C) WEB ROUTES (EXACT PATHS)
============================================================

- /
- /pricing
- /intake
- /checkout
- /checkout/success
- /checkout/cancel
- /login
- /admin
- /client
- /services
- /implementation
- /guardrail-packs
- /legal

============================================================
D) FIRESTORE (EXACT COLLECTIONS + PATTERNS)
============================================================

COLLECTIONS
- leads
- clients
- billing_events
- email_outbox

DOC PATTERNS
- leads/{leadId}
- clients/{clientId}
- billing_events/{stripe_event_id}
- email_outbox/{messageId}

============================================================
E) STRIPE MAPPING (PRICE ENV KEY → TIER)
============================================================

- STRIPE_AUDIT_PRICE_ID      → tier = "audit"
- STRIPE_PRO_PRICE_ID        → tier = "pro"
- STRIPE_ENTERPRISE_PRICE_ID → tier = "enterprise"

============================================================
END SCOPE PACK
============================================================