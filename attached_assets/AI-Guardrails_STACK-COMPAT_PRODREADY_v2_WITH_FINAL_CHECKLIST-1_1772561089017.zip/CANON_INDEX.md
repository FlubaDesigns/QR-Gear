# CANON INDEX

This index lists only canon files that exist in this repository.

Read in this order:

1. CANON/canon_rules.md
2. CANON/canon_reload_protocol.md
3. CANON/closed_loop_workflow.md
4. CANON/packet_relay_protocol.md
5. CANON/build_contract.md
6. CANON/tier1_impact_assessment_protocol.md
7. CANON/handoff_instructions.md
8. CANON/RESPONSE.md

Notes:
- All canon files are located in the CANON/ directory.
- No external canon files are referenced.
- If additional protocols are required, they must be created inside CANON/ before being listed here.
- CANON/conscience_kernel_v1.md
