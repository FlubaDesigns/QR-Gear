/**
 * Firestore Seed Apply Script (AICOMMS)
 *
 * Usage:
 *   node AICOMMS/TOOLS/firestore_seed_apply.js AICOMMS/BUILD/01_FIRESTORE_SEED
 *
 * Requires:
 *   FIREBASE_SERVICE_ACCOUNT_JSON = JSON string
 *
 * Seed file naming:
 *   collection__docId.json -> writes doc at collection/docId
 *
 * Seed payload format:
 * - If file contains { "json": {...}, ... } we write the full object.
 * - If file contains raw object, we write it as-is.
 */

const fs = require("fs");
const path = require("path");
const admin = require("firebase-admin");

function must(v, name) {
  if (!v) throw new Error(`Missing ${name}`);
  return v;
}

function safeJsonParse(raw) {
  try { return JSON.parse(raw); } catch { return null; }
}

function initFirebase() {
  if (admin.apps.length) return;

  const raw = must(process.env.FIREBASE_SERVICE_ACCOUNT_JSON, "FIREBASE_SERVICE_ACCOUNT_JSON");
  const svc = safeJsonParse(raw);
  if (!svc) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON is not valid JSON");

  admin.initializeApp({
    credential: admin.credential.cert(svc),
  });
}

function isJsonFile(name) {
  return name.toLowerCase().endsWith(".json");
}

function parseDocPathFromFilename(filename) {
  // collection__docId.json -> collection/docId
  const base = filename.replace(/\.json$/i, "");
  const parts = base.split("__");
  if (parts.length !== 2) return null;

  const [collection, docId] = parts.map((s) => String(s || "").trim()).filter(Boolean);
  if (!collection || !docId) return null;

  // basic safety: no slashes
  if (collection.includes("/") || docId.includes("/")) return null;

  return `${collection}/${docId}`;
}

async function applySeedDir(seedDir) {
  const db = admin.firestore();

  const entries = fs.readdirSync(seedDir, { withFileTypes: true })
    .filter((d) => d.isFile() && isJsonFile(d.name))
    .map((d) => d.name);

  if (!entries.length) {
    console.log(`[seed] No .json files found in: ${seedDir}`);
    return { ok: true, applied: 0, results: [] };
  }

  const results = [];
  for (const file of entries) {
    const docPath = parseDocPathFromFilename(file);
    if (!docPath) {
      results.push({ file, ok: false, error: "Bad filename. Use collection__docId.json" });
      continue;
    }

    const fullPath = path.join(seedDir, file);
    const raw = fs.readFileSync(fullPath, "utf8");
    const data = safeJsonParse(raw);

    if (!data || typeof data !== "object") {
      results.push({ file, ok: false, error: "Invalid JSON content" });
      continue;
    }

    try {
      await db.doc(docPath).set(data, { merge: true });
      results.push({ file, ok: true, docPath });
      console.log(`[seed] upserted ${docPath} <- ${file}`);
    } catch (e) {
      results.push({ file, ok: false, docPath, error: e?.message || String(e) });
      console.log(`[seed] FAILED ${docPath} <- ${file}: ${e?.message || e}`);
    }
  }

  const applied = results.filter((r) => r.ok).length;
  const failed = results.filter((r) => !r.ok).length;

  console.log(`\n[seed] Done. Applied: ${applied}  Failed: ${failed}\n`);
  if (failed) process.exitCode = 2;

  return { ok: failed === 0, applied, results };
}

async function main() {
  const seedDirArg = process.argv[2];
  if (!seedDirArg) {
    console.log("Usage: node AICOMMS/TOOLS/firestore_seed_apply.js <seed_dir>");
    process.exit(1);
  }

  const seedDir = path.resolve(seedDirArg);
  if (!fs.existsSync(seedDir)) throw new Error(`Seed dir not found: ${seedDir}`);

  initFirebase();
  await applySeedDir(seedDir);
}

main().catch((e) => {
  console.error("[seed] FATAL:", e?.message || e);
  process.exit(1);
});