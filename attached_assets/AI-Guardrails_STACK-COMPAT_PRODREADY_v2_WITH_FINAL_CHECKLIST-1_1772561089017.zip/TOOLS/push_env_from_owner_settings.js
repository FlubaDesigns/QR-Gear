/**
 * AICOMMS Push Env From OWNER_SETTINGS (v1)
 *
 * Purpose:
 * - Read AICOMMS/OWNER_SETTINGS.json
 * - Push env/secrets into Firebase Functions config (or .env file fallback)
 *
 * Modes:
 * 1) FIREBASE_CONFIG (recommended): uses Firebase CLI `firebase functions:config:set`
 * 2) DOTENV_FALLBACK: writes AICOMMS/APPS/aicomms-site/functions/.env (local only)
 *
 * Usage (Claude/Replit):
 *   node AICOMMS/TOOLS/push_env_from_owner_settings.js --mode firebase
 *   node AICOMMS/TOOLS/push_env_from_owner_settings.js --mode dotenv
 *
 * Notes:
 * - Firebase CLI must be installed and logged in to the correct project.
 * - This script never prints secret values to stdout (only which keys were set).
 */

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function flattenEnv(settings) {
  // Map OWNER_SETTINGS.json -> env keys expected by functions
  const env = {};

  // Public
  env.PUBLIC_SITE_BASE_URL = settings.public?.PUBLIC_SITE_BASE_URL || "";

  // Email / Resend
  env.RESEND_API_KEY = settings.resend?.RESEND_API_KEY || "";
  env.AICOMMS_FROM_EMAIL = settings.email?.AICOMMS_FROM_EMAIL || "";
  env.AICOMMS_ADMIN_EMAIL = settings.email?.AICOMMS_ADMIN_EMAIL || "";

  // Stripe
  env.STRIPE_SECRET_KEY = settings.stripe?.STRIPE_SECRET_KEY || "";
  env.STRIPE_WEBHOOK_SECRET = settings.stripe?.STRIPE_WEBHOOK_SECRET || "";
  env.STRIPE_AUDIT_PRICE_ID = settings.stripe?.STRIPE_AUDIT_PRICE_ID || "";
  env.STRIPE_PRO_PRICE_ID = settings.stripe?.STRIPE_PRO_PRICE_ID || "";
  env.STRIPE_ENTERPRISE_PRICE_ID = settings.stripe?.STRIPE_ENTERPRISE_PRICE_ID || "";
  env.GRACE_PERIOD_DAYS = String(settings.stripe?.GRACE_PERIOD_DAYS || "7");

  // Providers
  env.EXECUTION_MODE = settings.providers?.EXECUTION_MODE || "SIMULATED";
  env.OPENAI_API_KEY = settings.providers?.OPENAI_API_KEY || "";
  env.ANTHROPIC_API_KEY = settings.providers?.ANTHROPIC_API_KEY || "";
  env.XAI_API_KEY = settings.providers?.XAI_API_KEY || "";

  // Firebase basics (optional; may be unused in runtime but helpful)
  env.FIREBASE_PROJECT_ID = settings.firebase?.projectId || "";
  env.FUNCTIONS_REGION = settings.firebase?.region || "us-central1";

  return env;
}

function sanitizeForFirebaseConfig(envObj) {
  // Firebase functions:config:set expects lower-case namespaces like aicomms.key=value
  // We'll store under `aicomms.*` to avoid collisions.
  const cfg = {};
  for (const [k, v] of Object.entries(envObj)) {
    cfg[`aicomms.${k.toLowerCase()}`] = String(v ?? "");
  }
  return cfg;
}

function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { stdio: "pipe", encoding: "utf8", ...opts });
  return r;
}

function requireFirebaseCli() {
  const r = run("firebase", ["--version"]);
  if (r.status !== 0) {
    throw new Error(
      "Firebase CLI not found. Install it in Replit (npm i -g firebase-tools) and login (firebase login)."
    );
  }
}

function selectProject(projectId) {
  if (!projectId) return;
  // Best effort: set active project
  run("firebase", ["use", projectId], { stdio: "inherit" });
}

function pushFirebaseConfig(cfg) {
  requireFirebaseCli();

  // Build args: firebase functions:config:set key=value key=value ...
  const pairs = [];
  for (const [k, v] of Object.entries(cfg)) {
    // NOTE: we do NOT print values, but we must pass them to CLI.
    pairs.push(`${k}=${v}`);
  }

  if (pairs.length === 0) throw new Error("No config keys to set.");

  const r = run("firebase", ["functions:config:set", ...pairs], { stdio: "inherit" });
  if (r.status !== 0) throw new Error("firebase functions:config:set failed.");

  // Optional: show keys set (not values)
  return Object.keys(cfg);
}

function writeDotenv(envObj, dotenvPath) {
  const lines = [];
  for (const [k, v] of Object.entries(envObj)) {
    // Keep it safe for dotenv; wrap in quotes if needed
    const safe =
      String(v ?? "")
        .replace(/\n/g, "\\n")
        .replace(/"/g, '\\"');
    lines.push(`${k}="${safe}"`);
  }
  fs.writeFileSync(dotenvPath, lines.join("\n") + "\n", "utf8");
  return Object.keys(envObj);
}

function main() {
  const modeIdx = process.argv.indexOf("--mode");
  const mode = modeIdx >= 0 ? (process.argv[modeIdx + 1] || "").toLowerCase() : "firebase";

  const repoRoot = path.resolve(__dirname, "..", "..");
  const settingsPath = path.join(repoRoot, "AICOMMS", "OWNER_SETTINGS.json");
  if (!exists(settingsPath)) throw new Error(`Missing OWNER_SETTINGS.json at ${settingsPath}`);

  const settings = readJson(settingsPath);
  const projectId = settings.firebase?.projectId || "";

  const envObj = flattenEnv(settings);

  // Basic sanity (do not fail hard; validateConfig will report missing)
  if (projectId) {
    // Ensure CLI points to correct project for firebase mode
    if (mode === "firebase") {
      selectProject(projectId);
    }
  }

  if (mode === "firebase") {
    const cfg = sanitizeForFirebaseConfig(envObj);
    const keysSet = pushFirebaseConfig(cfg);

    console.log(
      JSON.stringify(
        {
          ok: true,
          mode: "firebase",
          projectId: projectId || null,
          keysSetCount: keysSet.length,
          keysSet: keysSet, // keys only; values not printed
          next: "Deploy functions: firebase deploy --only functions"
        },
        null,
        2
      )
    );
    return;
  }

  if (mode === "dotenv") {
    const dotenvPath = path.join(repoRoot, "AICOMMS", "APPS", "aicomms-site", "functions", ".env");
    const keysSet = writeDotenv(envObj, dotenvPath);

    console.log(
      JSON.stringify(
        {
          ok: true,
          mode: "dotenv",
          dotenvPath,
          keysWrittenCount: keysSet.length,
          keysWritten: keysSet,
          note:
            "This writes a local .env only. Firebase deployed functions will NOT see it unless your deploy process injects env. Prefer --mode firebase."
        },
        null,
        2
      )
    );
    return;
  }

  throw new Error(`Unknown mode: ${mode}. Use --mode firebase or --mode dotenv`);
}

main();