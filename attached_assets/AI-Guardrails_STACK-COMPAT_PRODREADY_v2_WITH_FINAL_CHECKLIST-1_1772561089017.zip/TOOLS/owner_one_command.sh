#!/usr/bin/env bash
# AICOMMS One-Command Owner Workflow (v3)
# Runs: push env -> autoconfig -> deploy -> auto-capture validate URL -> validate
#
# Owner edits ONLY: AICOMMS/OWNER_SETTINGS.json
# Claude runs this script from repo root.
#
# Usage:
#   bash AICOMMS/TOOLS/owner_one_command.sh --zip ./AICOMMS_SOURCE.zip
#
# Notes:
# - Requires: firebase CLI installed + logged in + correct project selected
# - If you omit --zip, it will skip uploading source zip and only update Firestore pointer.
# - If validateConfigUrl is missing, it will auto-capture it from deploy output and save it.

set -euo pipefail

ZIP_PATH=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --zip)
      ZIP_PATH="${2:-}"
      shift 2
      ;;
    *)
      echo "Unknown arg: $1"
      echo "Usage: bash AICOMMS/TOOLS/owner_one_command.sh --zip ./AICOMMS_SOURCE.zip"
      exit 1
      ;;
  esac
done

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
AICOMMS_DIR="${ROOT_DIR}/AICOMMS"
FUNCTIONS_DIR="${AICOMMS_DIR}/APPS/aicomms-site/functions"
SETTINGS_JSON="${AICOMMS_DIR}/OWNER_SETTINGS.json"
DEPLOY_LOG="/tmp/aicomms_firebase_deploy.log"

if [[ ! -f "${SETTINGS_JSON}" ]]; then
  echo "❌ Missing ${SETTINGS_JSON}"
  exit 1
fi

VALIDATE_URL="$(node -e "const s=require('${SETTINGS_JSON}'); console.log((s.endpoints&&s.endpoints.validateConfigUrl)||'');")"

echo "============================================================"
echo "AICOMMS: OWNER ONE-COMMAND WORKFLOW (v3)"
echo "Root: ${ROOT_DIR}"
echo "Settings: ${SETTINGS_JSON}"
echo "Functions: ${FUNCTIONS_DIR}"
echo "Zip: ${ZIP_PATH:-<none>}"
echo "validateConfigUrl (before): ${VALIDATE_URL:-<not set>}"
echo "============================================================"

echo ""
echo "STEP 1) Push env from OWNER_SETTINGS.json -> Firebase Functions config"
node "${AICOMMS_DIR}/TOOLS/push_env_from_owner_settings.js" --mode firebase

echo ""
echo "STEP 2) AutoConfig (Firestore pointer + optional Storage upload)"
if [[ -n "${ZIP_PATH}" ]]; then
  node "${AICOMMS_DIR}/TOOLS/autoconfig.js" --zip "${ZIP_PATH}"
else
  node "${AICOMMS_DIR}/TOOLS/autoconfig.js"
fi

echo ""
echo "STEP 3) Deploy Functions (capture output to log)"
cd "${FUNCTIONS_DIR}"
npm install

if npm run | grep -q " build"; then
  npm run build
fi

# Capture deploy output so we can parse URLs
set +e
firebase deploy --only functions 2>&1 | tee "${DEPLOY_LOG}"
DEPLOY_EXIT="${PIPESTATUS[0]}"
set -e

if [[ "${DEPLOY_EXIT}" -ne 0 ]]; then
  echo "❌ firebase deploy failed. See log: ${DEPLOY_LOG}"
  exit "${DEPLOY_EXIT}"
fi

echo ""
echo "STEP 4) If validateConfigUrl is missing, auto-capture it from deploy log"
VALIDATE_URL="$(node -e "const s=require('${SETTINGS_JSON}'); console.log((s.endpoints&&s.endpoints.validateConfigUrl)||'');")"

if [[ -z "${VALIDATE_URL}" ]]; then
  node "${AICOMMS_DIR}/TOOLS/capture_validate_url.js" --log "${DEPLOY_LOG}"
  VALIDATE_URL="$(node -e "const s=require('${SETTINGS_JSON}'); console.log((s.endpoints&&s.endpoints.validateConfigUrl)||'');")"
fi

if [[ -z "${VALIDATE_URL}" ]]; then
  echo "❌ validateConfigUrl still not set. Manual fallback:"
  echo "1) Open ${DEPLOY_LOG}"
  echo "2) Find the validateConfig function URL"
  echo "3) Paste into AICOMMS/OWNER_SETTINGS.json -> endpoints.validateConfigUrl"
  exit 2
fi

echo "validateConfigUrl (after): ${VALIDATE_URL}"

echo ""
echo "STEP 5) Validate Config (AUTO)"
if command -v curl >/dev/null 2>&1; then
  HTTP_BODY="$(curl -s "${VALIDATE_URL}")"
  echo "${HTTP_BODY}"

  node -e "const r=${HTTP_BODY:-null}; if(!r || r.ok!==true){ process.exit(2);} console.log('✅ validateConfig ok:true');" \
    || { echo "❌ validateConfig failed (ok:false). Fix missing items and rerun."; exit 2; }
else
  echo "❌ curl not found. Install curl or run validation manually by opening the URL."
  exit 1
fi

echo ""
echo "✅ DONE. Env pushed, source pointer set, functions deployed, validate URL captured, config validated."