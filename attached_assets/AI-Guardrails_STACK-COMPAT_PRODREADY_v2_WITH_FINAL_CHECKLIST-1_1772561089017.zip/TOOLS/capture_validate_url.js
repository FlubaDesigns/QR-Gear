/**
 * AICOMMS capture_validate_url (v1)
 *
 * Purpose:
 * - Read Firebase deploy output text (passed in via stdin or file)
 * - Extract the validateConfig HTTPS function URL
 * - Write it into AICOMMS/OWNER_SETTINGS.json at endpoints.validateConfigUrl
 *
 * Usage:
 *   firebase deploy --only functions 2>&1 | tee /tmp/deploy.log
 *   node AICOMMS/TOOLS/capture_validate_url.js --log /tmp/deploy.log
 *
 * Or pipe directly:
 *   firebase deploy --only functions 2>&1 | node AICOMMS/TOOLS/capture_validate_url.js
 */

const fs = require("fs");
const path = require("path");

function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function writeJson(p, obj) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2) + "\n", "utf8");
}

function readStdin() {
  return new Promise((resolve) => {
    let data = "";
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", (chunk) => (data += chunk));
    process.stdin.on("end", () => resolve(data));
    // If nothing is piped, end may never fire in some shells; handle TTY case:
    if (process.stdin.isTTY) resolve("");
  });
}

function extractValidateUrl(text) {
  // Firebase deploy output often contains lines like:
  // "Function URL (validateConfig(us-central1)): https://us-central1-<project>.cloudfunctions.net/validateConfig"
  // or:
  // "https://us-central1-<project>.cloudfunctions.net/validateConfig"
  const regex = /https:\/\/[a-z0-9-]+\.cloudfunctions\.net\/validateConfig\b/gi;
  const matches = text.match(regex);
  if (!matches || matches.length === 0) return null;

  // Prefer the last occurrence (deploy output may repeat)
  return matches[matches.length - 1];
}

async function main() {
  const repoRoot = path.resolve(__dirname, "..", "..");
  const settingsPath = path.join(repoRoot, "AICOMMS", "OWNER_SETTINGS.json");

  if (!exists(settingsPath)) {
    console.error(JSON.stringify({ ok: false, error: `Missing OWNER_SETTINGS.json at ${settingsPath}` }, null, 2));
    process.exit(1);
  }

  const logIdx = process.argv.indexOf("--log");
  const logPath = logIdx >= 0 ? process.argv[logIdx + 1] : null;

  let deployText = "";

  if (logPath) {
    const abs = path.resolve(process.cwd(), logPath);
    if (!exists(abs)) {
      console.error(JSON.stringify({ ok: false, error: `Log file not found: ${abs}` }, null, 2));
      process.exit(1);
    }
    deployText = fs.readFileSync(abs, "utf8");
  } else {
    deployText = await readStdin();
  }

  const url = extractValidateUrl(deployText || "");

  if (!url) {
    console.error(
      JSON.stringify(
        {
          ok: false,
          error: "Could not find validateConfig URL in deploy output.",
          hint: "Run: firebase deploy --only functions 2>&1 | tee /tmp/deploy.log ; node AICOMMS/TOOLS/capture_validate_url.js --log /tmp/deploy.log"
        },
        null,
        2
      )
    );
    process.exit(2);
  }

  const settings = readJson(settingsPath);
  settings.endpoints = settings.endpoints || {};
  settings.endpoints.validateConfigUrl = url;

  writeJson(settingsPath, settings);

  console.log(
    JSON.stringify(
      {
        ok: true,
        message: "validateConfigUrl saved into OWNER_SETTINGS.json",
        validateConfigUrl: url,
        settingsPath
      },
      null,
      2
    )
  );
}

main().catch((e) => {
  console.error(JSON.stringify({ ok: false, error: e?.message || String(e) }, null, 2));
  process.exit(1);
});