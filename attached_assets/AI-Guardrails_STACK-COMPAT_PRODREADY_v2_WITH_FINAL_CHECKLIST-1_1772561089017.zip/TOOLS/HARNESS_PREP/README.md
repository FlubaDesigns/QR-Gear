# Guardrails / Conscience Integration (Prep)

This project is the Conscience layer.
No UI. No Fluba direct calls.

Required endpoint:
POST /conscience/evaluate

Input:
{ "intent": { ... }, "planeKnobs": { ... } }

Output:
{
  "allow": true|false,
  "requireApproval": true|false,
  "decisionId": "string",
  "reason": "string",
  "riskScore": 0-100 (optional)
}

Brain is the only caller.
