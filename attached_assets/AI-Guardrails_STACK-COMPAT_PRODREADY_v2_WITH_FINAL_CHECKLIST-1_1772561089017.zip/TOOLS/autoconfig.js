/**
 * AICOMMS AutoConfig (v1)
 * Goal: Reduce Owner actions to editing OWNER_SETTINGS.json only.
 *
 * What it does:
 * - Reads AICOMMS/OWNER_SETTINGS.json
 * - Validates required fields
 * - Uses Firebase Admin (service account) OR Application Default Credentials
 * - Creates/updates Firestore pointer doc: system_state/current_source
 * - Uploads source zip to Firebase Storage (if local path is provided)
 * - Prints EXACT next steps for anything it cannot automate (DNS/Stripe/Resend)
 *
 * How Claude should run:
 *   node AICOMMS/TOOLS/autoconfig.js --zip ./AICOMMS_SOURCE.zip
 *
 * Notes:
 * - This script is designed to run in Replit where Firebase credentials are available.
 * - If Admin credentials aren’t available, script will stop and tell Claude exactly what to do.
 */

const fs = require("fs");
const path = require("path");

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function exists(p) {
  try { fs.accessSync(p); return true; } catch { return false; }
}

function requireNonEmpty(label, value) {
  if (!value || String(value).trim() === "") throw new Error(`Missing required setting: ${label}`);
}

function safeLog(obj) {
  console.log(JSON.stringify(obj, null, 2));
}

async function main() {
  const repoRoot = path.resolve(__dirname, "..", "..");
  const settingsPath = path.join(repoRoot, "AICOMMS", "OWNER_SETTINGS.json");

  if (!exists(settingsPath)) {
    throw new Error(`OWNER_SETTINGS.json not found at: ${settingsPath}`);
  }

  const settings = readJson(settingsPath);

  // CLI args
  const zipArgIndex = process.argv.indexOf("--zip");
  const localZipPath = zipArgIndex >= 0 ? process.argv[zipArgIndex + 1] : null;

  // Minimal required for automation
  requireNonEmpty("firebase.projectId", settings.firebase.projectId);

  // Lazy-import admin SDK so script can explain missing deps cleanly
  let admin;
  try {
    admin = require("firebase-admin");
  } catch (e) {
    throw new Error(
      "firebase-admin is not installed. Run from functions workspace or install in root: npm i firebase-admin"
    );
  }

  // Initialize Admin using default credentials (Replit often uses env/service account)
  try {
    if (admin.apps.length === 0) {
      admin.initializeApp({
        projectId: settings.firebase.projectId,
        storageBucket: settings.firebase.storageBucket || undefined
      });
    }
  } catch (e) {
    throw new Error(
      "Failed to initialize firebase-admin. Ensure service account / ADC credentials are available in Replit. " +
      "If using GOOGLE_APPLICATION_CREDENTIALS, point it to a service account json."
    );
  }

  const db = admin.firestore();
  const bucket = admin.storage().bucket();

  // 1) Create/update Firestore pointer doc
  const docPath = settings.sourceRegistry.currentSourceDocPath || "system_state/current_source";
  const [col, doc] = docPath.split("/");
  if (!col || !doc) throw new Error(`Invalid currentSourceDocPath: ${docPath}`);

  const pointerRef = db.collection(col).doc(doc);

  const pointerPayload = {
    active: true,
    source_version: Number(settings.sourceRegistry.sourceVersion || 1),
    storage_path: String(settings.sourceRegistry.storagePath || "source/aicomms_source_v0001.zip"),
    sha256: settings.sourceRegistry.sha256 ? String(settings.sourceRegistry.sha256) : null,
    updated_at: admin.firestore.FieldValue.serverTimestamp()
  };

  await pointerRef.set(pointerPayload, { merge: true });

  // 2) Upload source zip if provided
  let uploadResult = null;
  if (localZipPath) {
    const absZip = path.resolve(process.cwd(), localZipPath);
    if (!exists(absZip)) throw new Error(`Local zip not found: ${absZip}`);

    const destPath = pointerPayload.storage_path;
    await bucket.upload(absZip, {
      destination: destPath,
      metadata: { contentType: "application/zip" }
    });

    uploadResult = { uploaded: true, localZip: absZip, destination: destPath };
  } else {
    uploadResult = { uploaded: false, note: "No --zip provided, skipping upload." };
  }

  // 3) Print next steps (what cannot be automated)
  const nextSteps = [];

  // Provider keys (optional)
  if (settings.providers.EXECUTION_MODE === "REAL") {
    if (!settings.providers.OPENAI_API_KEY && !settings.providers.ANTHROPIC_API_KEY && !settings.providers.XAI_API_KEY) {
      nextSteps.push("EXECUTION_MODE=REAL but no provider API keys set. Add at least one provider key in functions env.");
    }
  }

  // Stripe checks
  if (settings.stripe.STRIPE_SECRET_KEY && !settings.stripe.STRIPE_WEBHOOK_SECRET) {
    nextSteps.push("Stripe Secret is set but STRIPE_WEBHOOK_SECRET is empty. Create webhook in Stripe Dashboard and paste secret.");
  }

  // Resend checks
  if (settings.resend.RESEND_API_KEY && (!settings.email.AICOMMS_FROM_EMAIL || !settings.email.AICOMMS_ADMIN_EMAIL)) {
    nextSteps.push("Resend key set but emails missing. Fill AICOMMS_FROM_EMAIL and AICOMMS_ADMIN_EMAIL.");
  }

  // Public base URL
  if (!settings.public.PUBLIC_SITE_BASE_URL) {
    nextSteps.push("PUBLIC_SITE_BASE_URL is empty. Set it for links in emails and receipts.");
  }

  safeLog({
    ok: true,
    message: "AutoConfig completed pointer doc update (and optional zip upload).",
    pointerDoc: { path: docPath, payload: pointerPayload },
    upload: uploadResult,
    nextSteps
  });

  console.log("\n--- RECOMMENDED NEXT COMMANDS (Claude/Replit) ---");
  console.log("1) Deploy functions (from functions folder): firebase deploy --only functions");
  console.log("2) Test validateConfig endpoint after deploy.");
}

main().catch((e) => {
  console.error(JSON.stringify({ ok: false, error: e.message || String(e) }, null, 2));
  process.exit(1);
});