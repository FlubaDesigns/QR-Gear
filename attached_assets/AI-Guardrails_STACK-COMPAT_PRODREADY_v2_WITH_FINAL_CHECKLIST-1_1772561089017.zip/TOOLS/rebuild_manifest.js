#!/usr/bin/env node
/**
 * AI-Guardrails — rebuild_manifest
 *
 * Recomputes CONSCIENCE_MANIFEST.json canon_hash to match the current on-disk contents.
 *
 * Usage:
 *   node TOOLS/rebuild_manifest.js
 *   node TOOLS/rebuild_manifest.js --root <path-to-AI-Guardrails>
 *
 * Notes:
 * - Intended to be run by the Owner (or CI) when the Guardrails package changes.
 * - This updates ONLY the manifest (no other files are modified).
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

function sha256(buf) {
  return crypto.createHash("sha256").update(buf).digest();
}

function listFiles(rootDir, subDir) {
  const out = [];
  const base = path.join(rootDir, subDir);
  const stack = [base];
  while (stack.length) {
    const cur = stack.pop();
    const relCur = path.relative(rootDir, cur);
    const st = fs.statSync(cur);
    if (st.isDirectory()) {
      for (const name of fs.readdirSync(cur)) {
        stack.push(path.join(cur, name));
      }
    } else if (st.isFile()) {
      out.push(relCur.replace(/\\/g, "/"));
    }
  }
  return out;
}

function computeCanonHash(conscienceRoot) {
  const keptDirs = ["CANON", "SCOPED_CANON", "ENFORCEMENT", "TOOLS", "SYSTEM_STATE"];
  const keptFiles = ["CANON_INDEX.md", "OWNER_SETTINGS.json", "README.md"]; // manifest excluded from hash
  const requiredFiles = ["CONSCIENCE_MANIFEST.json"];
  let files = [];
  for (const d of keptDirs) {
    const p = path.join(conscienceRoot, d);
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) {
      for (const rel of listFiles(conscienceRoot, d)) {
        files.push(rel);
      }
    }
  }
  for (const f of keptFiles) {
    const p = path.join(conscienceRoot, f);
    if (fs.existsSync(p) && fs.statSync(p).isFile()) {
      files.push(f);
    }
  }
  // Required files (existence only; excluded from hash)
  for (const f of (requiredFiles || [])) {
    const p = path.join(conscienceRoot, f);
    if (!fs.existsSync(p) || !fs.statSync(p).isFile()) {
      throw new Error("Missing required file: " + f);
    }
  }
  files = Array.from(new Set(files)).sort();

  const h = crypto.createHash("sha256");
  for (const rel of files) {
    const abs = path.join(conscienceRoot, rel);
    h.update(Buffer.from(rel, "utf8"));
    h.update(Buffer.from([0]));
    const data = fs.readFileSync(abs);
    h.update(sha256(data));
  }
  return { hash: h.digest("hex"), fileCount: files.length, files };
}

function parseArgs(argv) {
  const out = { root: null };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--root" && i + 1 < argv.length) {
      out.root = path.resolve(argv[i + 1]);
      i++;
    }
  }
  return out;
}

const args = parseArgs(process.argv);
const conscienceRoot = args.root || path.resolve(__dirname, "..");
const manifestPath = path.join(conscienceRoot, "CONSCIENCE_MANIFEST.json");

if (!fs.existsSync(conscienceRoot) || !fs.statSync(conscienceRoot).isDirectory()) {
  console.error("ERROR: Invalid --root directory:", conscienceRoot);
  process.exit(2);
}

const computed = computeCanonHash(conscienceRoot);

// Load or create manifest
let manifest = {
  name: "AI-Guardrails",
  generated_utc: new Date().toISOString(),
  source_zip: null,
  kept_dirs: ["CANON", "SCOPED_CANON", "ENFORCEMENT", "TOOLS", "SYSTEM_STATE"],
  kept_files: ["CANON_INDEX.md", "OWNER_SETTINGS.json", "CONSCIENCE_MANIFEST.json", "README.md"],
  hash_excludes: ["CONSCIENCE_MANIFEST.json"],
  excluded: [],
  canon_hash: computed.hash,
  canon_hash_algo: "sha256",
  canon_file_count: computed.fileCount
};

if (fs.existsSync(manifestPath)) {
  try {
    const prev = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
    manifest = { ...prev, ...manifest };
  } catch (e) {
    // keep defaults
  }
}

// Update manifest fields
manifest.generated_utc = new Date().toISOString();
manifest.canon_hash = computed.hash;
manifest.canon_hash_algo = "sha256";
manifest.canon_file_count = computed.fileCount;

// Write pretty JSON
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + "\n", "utf8");

console.log("Rebuilt CONSCIENCE_MANIFEST.json");
console.log("  root:", conscienceRoot);
console.log("  canon_hash:", computed.hash);
console.log("  files_hashed:", computed.fileCount);
process.exit(0);
