# AI-Guardrails — Conscience Only

This package is the **governance conscience** layer: Canon + enforcement + state + validators.
It intentionally excludes execution/adapters/runners. Those belong in **AI Socket**.

Included:
- AI-Guardrails/CANON/
- AI-Guardrails/SCOPED_CANON/
- AI-Guardrails/ENFORCEMENT/
- AI-Guardrails/TOOLS/
- AI-Guardrails/SYSTEM_STATE/
- AI-Guardrails/CANON_INDEX.md
- AI-Guardrails/OWNER_SETTINGS.json

Excluded:
- AI-Guardrails/CLAUDE_CONTROL/ (runner/execution toolbox)
- AI-Guardrails/BUILD/ (seeds/build notes)
- Any connectors/packs/logs/integration artifacts

Generated: 2026-02-26T09:12:22.371689 UTC


## Rebuild the manifest (Owner action)

If you change any files inside AI-Guardrails, you must rebuild `CONSCIENCE_MANIFEST.json` so `validate_packet.js` can verify Canon integrity.

```bash
node TOOLS/rebuild_manifest.js
```

This recomputes `canon_hash` over the kept directories/files (CANON, SCOPED_CANON, ENFORCEMENT, TOOLS, SYSTEM_STATE, plus key top-level files) using SHA-256.
