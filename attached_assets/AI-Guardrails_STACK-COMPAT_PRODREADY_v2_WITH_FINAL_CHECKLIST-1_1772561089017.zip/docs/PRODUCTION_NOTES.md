# Conscience (AI-Guardrails) Production Notes

- Removed duplicate `TOOLS/validate_packet.js` to eliminate drift/confusion.
- Keep canonical `validate_packet.js` at repository root.

