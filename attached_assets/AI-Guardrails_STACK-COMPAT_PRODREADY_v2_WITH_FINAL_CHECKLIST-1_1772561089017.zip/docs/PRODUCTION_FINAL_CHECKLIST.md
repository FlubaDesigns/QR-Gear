# FINAL PRODUCTION CHECKLIST — ALL FOUR LAYERS

This checklist governs Conscience → Brain → Fluba → Plane cutover.

------------------------------------------------------------
PHASE 0 – PRE-CHECKS
------------------------------------------------------------

[ ] All four packages build locally (no runtime errors)
[ ] HARNESS_MODE=local works end-to-end on AI-COMMS
[ ] Firestore rules locked (no public writes)
[ ] Stripe webhook signature verified
[ ] Stripe webhook idempotent (duplicate event safe)
[ ] Brain /brain/intents supports requestId dedupe
[ ] Brain Control API endpoints require admin auth (403 for non-admin)
[ ] Brain ingress rejects unauthenticated calls (401/403)
[ ] CORS restricted to approved domains

------------------------------------------------------------
PHASE 1 – CONTROL PLANE (Fluba Project)
------------------------------------------------------------

[ ] Deploy Conscience
[ ] Confirm /conscience/evaluate responds
[ ] Confirm Conscience denies a known-bad packet
[ ] Deploy Brain (API + Worker)
[ ] Set CONSCIENCE_EVAL_URL correctly
[ ] Configure Pub/Sub Dead Letter Queue
[ ] Deploy Fluba UI
[ ] Set BRAIN_BASE_URL in Fluba
[ ] Smoke test: deny → approve → execute

------------------------------------------------------------
PHASE 2 – PLANE (AI-COMMS Project)
------------------------------------------------------------

[ ] Deploy AI-COMMS with HARNESS_MODE=local first
[ ] Verify plane works standalone (orphan test)
[ ] Flip HARNESS_MODE=brain
[ ] Set BRAIN_BASE_URL
[ ] Confirm intent routes to Brain
[ ] Confirm Brain callback or polling returns result
[ ] Flip brain → local → brain (unplug test passes)

------------------------------------------------------------
PHASE 3 – GOVERNANCE ENABLEMENT
------------------------------------------------------------

[ ] Enable logging-only first
[ ] Turn on require_human_approval for high-risk intents
[ ] Enable fail-closed mode
[ ] Confirm seat scorecards appear in Fluba AI Seats tab
[ ] Run multi-seat (6+) job end-to-end test
[ ] Verify DLQ receives failed jobs
[ ] Verify incidents/alerts pipeline works

------------------------------------------------------------
PRODUCTION COMPLETE WHEN:
------------------------------------------------------------

• All must-pass gates checked
• Multi-seat team test job runs cleanly
• Fluba AI Seats shows live scorecards + timelines
• DLQ and incident pipeline verified
• Unplug/orphan mode confirmed functional
