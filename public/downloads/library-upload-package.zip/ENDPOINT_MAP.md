# Library Upload System - Endpoint & File Map

## Endpoint Flow

### Frontend calls → Backend endpoint → Firestore collection: library_assets

| Action | Frontend File | API Call | Cloud Function Route |
|--------|--------------|----------|---------------------|
| List source images | SourceImagesTab.tsx | GET /api/admin/background-assets?type=source | /admin/background-assets (GET) |
| List cropped images | CroppedImagesTab.tsx | GET /api/admin/background-assets?type=cropped | /admin/background-assets (GET) |
| List backgrounds | BackgroundsTab.tsx | GET /api/admin/background-assets?type=background | /admin/background-assets (GET) |
| Upload single image | ImageUploader.tsx → SourceImagesTab.tsx | POST /api/admin/background-assets | /admin/background-assets (POST) |
| Upload ZIP | ImageUploader.tsx → SourceImagesTab.tsx | POST /api/admin/background-assets | /admin/background-assets (POST) |
| Upload cropped image | SourceImagesTab.tsx (handleCropComplete) | POST /api/admin/background-assets | /admin/background-assets (POST) |
| Delete image | SourceImagesTab.tsx (handleDelete) | DELETE /api/admin/background-assets/:id | /admin/background-assets/:id (DELETE) |

### POST body format (upload):
```json
{
  "name": "filename-without-ext",
  "assetType": "source" | "cropped",
  "imageData": "<base64-encoded-image-data>",
  "mimeType": "image/jpeg",
  "sourceAssetId": "optional-parent-source-id",
  "cropData": "optional-crop-metadata"
}
```

### Firebase Storage paths:
- Source uploads: library/backgrounds/raw/{timestamp}-{name}.{ext}
- ZIP uploads: library/backgrounds/raw/zip/{timestamp}-{name}.{ext}
- Cropped uploads: library/backgrounds/cropped/{timestamp}-{name}.{ext}

### Firestore collection: library_assets
Key fields: ownerType, assetType, mediaType, name, fileName, storageUrl, publicUrl, isActive, createdAt

## File Dependency Tree

```
LibraryPage.tsx
├── AdminAuthContext.tsx (provides getAuthHeaders, apiBase="/api/admin")
├── LibraryContext.tsx (provides api object with fetch/upload/delete methods)
│   └── Uses fetchWithRetry() for upload resilience
├── tabs/
│   ├── SourceImagesTab.tsx (upload + crop workflow)
│   │   ├── ImageUploader.tsx (file picker + FileReader + base64 conversion)
│   │   ├── CropUtility.tsx (9:16 crop with accessible buttons)
│   │   └── CropDeleteSkin.tsx (grid item with crop/delete actions)
│   ├── CroppedImagesTab.tsx (view cropped results)
│   ├── BackgroundsTab.tsx (promoted backgrounds)
│   ├── TemplatesTab.tsx
│   └── GraphicsTab.tsx
└── shared/
    ├── types.ts (TypeScript interfaces)
    └── imageUtils.ts (image processing utilities)
```

## Upload Flow (step by step):
1. User picks file(s) via <input type="file"> in ImageUploader.tsx
2. ImageUploader reads file with FileReader.readAsDataURL() → extracts base64
3. Calls onUploadSingle() → SourceImagesTab.handleUploadSingle()
4. handleUploadSingle() calls api.uploadAsset() from LibraryContext
5. LibraryContext POSTs JSON with base64 to /api/admin/background-assets
6. Cloud Function saves to Firebase Storage + creates Firestore doc
7. Returns doc data, frontend invalidates query cache to refresh list

## Known Issue: "Could not read file"
The error comes from ImageUploader.tsx line 60/103 - FileReader.onerror fires.
This typically happens on mobile when:
- File reference becomes stale (input cleared before read completes)
- Browser restricts file access after a delay
- File is too large for the device's memory
