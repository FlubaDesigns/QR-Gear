# QR Gear Image Upload & Display System

This package contains all source files related to uploading and displaying images in the QR Gear admin library.

## Storage Path Structure
All background images are stored in Firebase Storage at:
- `library/backgrounds/raw/` - Original uploaded images
- `library/backgrounds/cropped/` - Cropped versions of images
- `library/backgrounds/zip/` - Original ZIP archives (when uploading multiple images)

---

## CLIENT FILES (React/TypeScript)

### client/LibraryPage.tsx
**Purpose:** Main admin library page component
**What it does:** Renders the tabbed interface for managing library assets (Templates, Backgrounds, Source Images, Cropped Images). Uses LibraryContext for shared state.

### client/LibraryContext.tsx
**Purpose:** React Context for library configuration
**What it does:** Provides shared configuration across all library components including:
- `storeId` - Multi-tenant store identifier
- `apiBase` - API endpoint base URL ("/api")
- `storageRoots` - Firebase Storage paths for different asset types
- `permissions` - User permissions (canUpload, canDelete, canEdit)

### client/types.ts
**Purpose:** TypeScript type definitions
**What it does:** Defines interfaces for library assets, upload responses, and component props.

---

### client/tabs/SourceImagesTab.tsx
**Purpose:** Tab for managing source/raw background images
**What it does:** 
- Displays grid of uploaded source images
- Handles image upload via drag-drop or file picker
- "Sync from Storage" button scans Firebase Storage and creates database records
- Calls `/api/library/backgrounds/sync` to sync files
- Calls `/api/library/backgrounds/upload` to upload new images

### client/tabs/LibraryBackgroundsTab.tsx
**Purpose:** Tab for viewing background images (read-only view)
**What it does:** Displays background images from the library in a gallery format.

### client/tabs/CroppedImagesTab.tsx
**Purpose:** Tab for managing cropped images
**What it does:** Shows images that have been cropped from source images. Uses same storage pattern but in `cropped/` subfolder.

### client/tabs/TemplatesTab.tsx
**Purpose:** Tab for managing design templates
**What it does:** Manages reusable design templates (separate from background images).

---

### client/services/useLibraryAssets.ts
**Purpose:** React Query hooks for library data fetching
**What it does:** Custom hooks that wrap TanStack Query for:
- Fetching library assets from API
- Uploading new assets
- Deleting assets
- Cache invalidation after mutations

### client/shared/constants.ts
**Purpose:** Shared constants
**What it does:** Defines constant values used across library components (e.g., allowed file types, max file sizes).

### client/shared/types.ts
**Purpose:** Shared type definitions
**What it does:** Additional TypeScript interfaces shared between library components.

---

## SERVER FILES (Node.js/Express)

### server/firebase-storage-service.ts
**Purpose:** Firebase Storage operations
**What it does:** Core storage service with functions for:
- `uploadToFirebaseStorage()` - Upload buffer to Firebase Storage
- `uploadImageFromBase64()` - Upload base64 encoded image
- `uploadImageFromBuffer()` - Upload image with auto-path detection
- `downloadFromFirebaseStorage()` - Download file from storage
- `getSignedUrl()` - Generate temporary signed URLs for private files
- `deleteFromFirebaseStorage()` - Delete file from storage
- `fileExistsInFirebaseStorage()` - Check if file exists
- `listFilesInFolder()` - List all files in a storage folder (used by sync)

**Key paths used:**
- Default folder: `library/backgrounds/raw`
- Also checks: `library/backgrounds/cropped`, `library/backgrounds/zip`

### server/routes.ts
**Purpose:** Express API route definitions
**What it does:** Defines all API endpoints. Image-related routes include:

**Upload routes:**
- `POST /api/library/backgrounds/upload` - Upload new background image
- `POST /api/library/backgrounds/upload-zip` - Upload ZIP of multiple images

**Sync routes:**
- `POST /api/library/backgrounds/sync` - Scan Firebase Storage and sync to database

**List/Get routes:**
- `GET /api/library/backgrounds` - Get all background images
- `GET /api/library/backgrounds/:id` - Get single image by ID

**Delete routes:**
- `DELETE /api/library/backgrounds/:id` - Delete image from storage and database

---

## FIREBASE FUNCTIONS (Cloud Functions)

### functions/index.ts
**Purpose:** Firebase Cloud Functions entry point
**What it does:** Deployed to Firebase Functions. Contains:
- All API endpoints (mirrors server/routes.ts for production)
- Image upload/sync handlers
- Storage path resolution for finding files
- Admin authentication checks

**Key endpoints:**
- `/api/library/backgrounds/sync` - Production sync endpoint
- `/api/library/backgrounds/upload` - Production upload endpoint

---

## HOW IMAGE UPLOAD WORKS

1. **User selects file(s)** in SourceImagesTab.tsx
2. **Frontend calls** `POST /api/library/backgrounds/upload`
3. **Server (routes.ts)** receives file and calls `uploadToFirebaseStorage()`
4. **firebase-storage-service.ts** uploads to `library/backgrounds/raw/{uniqueId}.{ext}`
5. **Server creates database record** with storage URL
6. **Frontend receives** upload result and refreshes image grid

## HOW SYNC WORKS

1. **User clicks "Sync from Storage"** button in SourceImagesTab.tsx
2. **Frontend calls** `POST /api/library/backgrounds/sync`
3. **Server (routes.ts)** calls `listFilesInFolder('library/backgrounds/raw')`
4. **For each file found**, creates database record if not exists
5. **Returns** list of synced images to frontend
6. **Frontend refreshes** to show all images

---

## TROUBLESHOOTING

**Images not showing after upload:**
- Check Firebase Storage console for files in `library/backgrounds/raw/`
- Verify signed URLs are being generated correctly

**Sync not finding images:**
- Confirm images are in `library/backgrounds/raw/` (not `libraries/`)
- Check Firebase Storage console directly

**Upload fails:**
- Check file size (max 10MB)
- Check file type (JPEG, PNG, GIF, WebP, HEIC supported)
- Check Firebase Storage permissions

