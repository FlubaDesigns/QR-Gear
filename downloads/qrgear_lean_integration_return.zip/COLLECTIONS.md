# QR Gear — Firestore Collections (Write Targets)

## Core Product Data
- `products` — Product catalog (isEnabled, isFeatured, basePrice, customerPrice, etc.)
- `productPackets` — Product packet configurations (single source of truth for product configs)
- `productTemplates` — Reusable product templates
- `customDesigns` — QR designs linked to products

## Member/Store Data
- `storeAllowedProducts/member-products` — Allowed products for member sandbox
- `partnerStores` — Partner store configurations
- `partnerStoreProducts` — Products per partner store

## Orders & Commerce
- `orders` — Customer orders
- `cart` — Shopping cart items
- `temp_packets` — Temporary packets for public wizard (24hr TTL)

## Printify/Printful
- `printifyBlueprints` — Synced Printify product catalog
- `printifyPrintProviders` — Print provider data with costs (doc ID: `{blueprintId}_{providerId}`)
- `printfulProducts` — Synced Printful product catalog
- `printful_products` — Legacy Printful products
- `printful_variants` — Printful variant data
- `printify_printful_mapping` — Cross-provider product mapping

## Mockups
- `mockup_jobs` — Mockup generation job queue
- `mockup_cache` — Cached mockup results

## Settings
- `settings/admin` — Global admin settings (markup, costs)
- `testSettings/pricing` — Member pricing settings (markupPercent, memberProfitShare, etc.)

## QR & Canvas
- `qrDesigns` — Public QR designs (gallery)
- `qr_dynamics_instances` — QR compose/rotation instances
- `canvasItems` — Canvas content items
- `playItems` — Video/play content items

## Catalog Sync
- `catalogSyncs` — Sync operation records
- `costSyncs` — Cost sync operation records

## Auth
- `users` — User profiles
- `adminUsers` — Admin user records

## Email
- `emailQueue` — NexusMail email queue
- `emailLogs` — Email delivery logs
