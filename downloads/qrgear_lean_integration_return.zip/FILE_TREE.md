# QR Gear — File Tree (Important Folders)

```
qr-gear/
├── client/
│   └── src/
│       ├── App.tsx                    # Main app router
│       ├── features/
│       │   ├── adminLibrary/          # Admin library module
│       │   ├── members/               # Member wizards (Simple, Advanced, Studio)
│       │   ├── owner/                 # Public owner wizard
│       │   ├── shared/                # Shared components, wizard steps
│       │   └── storeBuilder/          # Store builder harness
│       ├── lib/
│       │   ├── firebase.ts            # Firebase client config
│       │   └── queryClient.ts         # TanStack Query + API URL helper
│       ├── pages/                     # Route pages
│       └── components/ui/             # shadcn components
├── server/
│   ├── index.ts                       # Express server entry
│   ├── routes.ts                      # Route orchestrator
│   ├── routes/                        # 16 feature-based route modules
│   │   ├── auth.routes.ts
│   │   ├── products.routes.ts
│   │   ├── admin.routes.ts
│   │   ├── packets.routes.ts
│   │   ├── members.routes.ts
│   │   ├── designs.routes.ts
│   │   ├── pricing.routes.ts
│   │   └── ... (16 total)
│   ├── lib/
│   │   ├── firebase-admin.ts          # Firebase Admin SDK init
│   │   ├── firestore-adapter.ts       # Firestore CRUD adapter
│   │   ├── firestore-crud.ts          # Generic CRUD helper
│   │   ├── mockup-service.ts          # Printful mockup generation
│   │   └── printify.ts               # Printify API client
│   └── storage.ts                     # Storage interface
├── functions/
│   └── src/
│       └── index.ts                   # Cloud Function (SEPARATE Express app)
├── shared/
│   └── placements.ts                  # Placement normalization
├── firebase.json                      # Hosting + Functions config
├── .firebaserc                        # Firebase project binding
└── package.json
```
