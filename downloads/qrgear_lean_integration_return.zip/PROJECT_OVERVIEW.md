# QR Gear — Project Overview (for Brain Integration)

## Basic Info
- **Project Name**: QR Gear
- **Domain**: qrgear-c1ffd.web.app
- **siteId for Brain**: `qr-gear`
- **Firebase projectId**: `qrgear-c1ffd`
- **Region**: us-central1

## Firebase Services Used
- **Auth**: Yes — Firebase Authentication (email/password, custom tokens)
- **Firestore**: Yes — primary data store (firestore-only mode, no PostgreSQL)
- **Cloud Functions**: Yes — single Cloud Function `api` serving Express app
- **Firebase Hosting**: Yes — serves frontend + rewrites `/api/**` to Cloud Function
- **Firebase Storage**: Yes — product images, mockups, backgrounds, member assets

## External Services
- **Stripe**: Payment processing (webhooks, checkout)
- **Printify**: Print-on-demand fulfillment
- **Printful**: Product mockup generation
- **Resend**: Email services

## Existing Brain/AI Panels
- None currently. No Brain connector or Fluba bridge exists yet in QR Gear.

## Critical Answers
1. **Does QR Gear point to the SAME Firebase project as Fluba?**
   No. QR Gear uses `qrgear-c1ffd`. Fluba uses a separate project (`fluba-designs-app` or similar).

2. **Do you intend to keep it separate?**
   Yes — they are separate products. A proxy/bridge design is needed for Brain integration.
   The Brain connector would submit intents from QR Gear to the Fluba control plane's Brain
   via HTTP (POST to Brain ingress) or Pub/Sub cross-project messaging.
