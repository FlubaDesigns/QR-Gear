import { QrCode, Type, ExternalLink, Sparkles } from "lucide-react";
import { CollapsibleModule } from "@/features/shared/components/CollapsibleModule";
import { Card } from "@/components/ui/card";
import { useBuilderContext } from "../BuilderContext";
import { QR_PRODUCT_STATES } from "../types";
import type { QRProductState } from "../types";

const STATE_ICONS: Record<string, typeof QrCode> = {
  qr_basics: QrCode,
  qr_plus: Type,
  qr_canvas: ExternalLink,
  qr_play: Sparkles,
  qr_dynamics: Sparkles,
};

export function StateModule() {
  const { state, setQRProductState } = useBuilderContext();

  if (state.sourceType !== "custom" || !state.selectedProduct) {
    return null;
  }

  return (
    <CollapsibleModule
      title="QR Product Type"
      icon={<QrCode className="h-4 w-4" />}
      className="bg-muted/30"
      defaultOpen
    >
      <div className="space-y-3">
        <p className="text-sm text-muted-foreground">
          Choose how your QR code will work and look.
        </p>
        
        <div className="grid grid-cols-1 gap-3">
          {QR_PRODUCT_STATES.map((qrState) => {
            const Icon = STATE_ICONS[qrState.id] || QrCode;
            const isSelected = state.qrProductState === qrState.id;
            
            return (
              <Card
                key={qrState.id}
                className={`p-4 cursor-pointer hover-elevate transition-all ${
                  isSelected ? "ring-2 ring-primary bg-primary/5" : ""
                }`}
                onClick={() => setQRProductState(qrState.id as QRProductState)}
                data-testid={`state-${qrState.id}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-lg ${isSelected ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-base">{qrState.label}</p>
                    <p className="text-sm text-muted-foreground mt-0.5">{qrState.description}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {state.qrProductState && (
          <div className="p-3 bg-primary/5 rounded-md border">
            <p className="text-sm">
              <span className="font-medium">Selected: </span>
              {QR_PRODUCT_STATES.find(s => s.id === state.qrProductState)?.label}
            </p>
          </div>
        )}
      </div>
    </CollapsibleModule>
  );
}
