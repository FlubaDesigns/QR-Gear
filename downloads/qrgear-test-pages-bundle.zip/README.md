# QR Gear Test Pages Bundle - Complete Source

## Overview
This bundle contains the complete modular admin interface for QR Gear, including all test pages, feature modules, server routes, Firebase Cloud Functions, and shared schemas. Designed for accessibility (48px touch targets, voice input support) and multi-tenant store management.

---

## Directory Structure

```
/
├── README.md                    # This file
├── pages/                       # Test page components
├── features/adminProducts/      # Admin products feature modules
├── styles/                      # CSS theme and button styles
├── server/                      # Express backend (local dev)
├── functions/src/               # Firebase Cloud Functions
└── shared/                      # Shared TypeScript schemas
```

---

## Test Pages (pages/)

| File | Description |
|------|-------------|
| test-products.tsx | Main Products/Store Builder with role selector, store/channel management |
| test-stores.tsx | Store Library showing real store data |
| test-library.tsx | Asset Library page (placeholder) |
| test-images.tsx | Image testing page |

---

## Admin Products Feature (features/adminProducts/)

### Main Files
- **ProductsHarness.tsx** - Main harness combining all modules
- **ProductsContext.tsx** - Context provider for shared state (role, store, channel)

### Modules (modules/)
- **RolePickerModule.tsx** - Internal/External/Member role selector buttons (48px touch)
- **StoreChannelDropdownModule.tsx** - Store dropdown + channel chips with CRUD
- **StoreModule.tsx** - Store selection
- **ChannelModule.tsx** - Channel management
- **SyncModule.tsx** - Data sync
- **FulfillmentPickerModule.tsx** - Fulfillment provider selection

### Shared (shared/)
- **types.ts** - TypeScript types (Store, Channel, RoleType, etc.)
- **ProductSmartImage.tsx** - Image component with fallback

### Builder (builder/)
Product builder for creating/editing products
- BuilderHarness.tsx, BuilderContext.tsx, types.ts
- modules/: Category, Content, Products, Source, Fulfillment, Publish, State, SaveOptions, AddToCart
- components/: LibraryPickerDialog, ProductDetailModal, Viewers
- hooks/: useSaveProduct

### Store Builder (storeBuilder/)
For assigning products to stores/channels
- StoreBuilderHarness.tsx, StoreBuilderContext.tsx
- modules/: StorePicker, ChannelPicker, CatalogBrowser, ProductConfigure, Assignment

### Store Library (storeLibrary/)
Browse and manage stores
- StoreLibraryHarness.tsx, StoreLibraryContext.tsx
- modules/: StoreList, ChannelList, ProductGrid, StoreTypeFilter
- skins/: StoreLibrarySkin

---

## Server - Local Development (server/)

### Main Files
| File | Description |
|------|-------------|
| index.ts | Express server entry point |
| routes.ts | All API routes including test endpoints |
| storage.ts | Storage adapter with dual-write (Postgres + Firestore) |
| db.ts | Drizzle ORM database connection |
| firebaseAuth.ts | Firebase Authentication middleware |
| stripeClient.ts | Stripe client initialization |
| webhookHandlers.ts | Webhook handling |
| vite.ts | Vite dev server integration |

### Adapters (server/adapters/)
- base.ts - Base storage adapter interface
- index.ts - Adapter exports

### Key API Endpoints (from routes.ts)

**Test Endpoints:**
```
GET  /api/test/stores?roleType=internal|external|member
GET  /api/test/channels?storeId=xxx
POST /api/test/channels         # Create channel
DELETE /api/test/channels/:id   # Delete channel
GET  /api/test/products
GET  /api/test/product-configs
GET  /api/test/printify/catalog
```

**Channel CRUD in routes.ts:**
```typescript
// GET channels for a store
app.get("/api/test/channels", async (req, res) => {
  const { storeId } = req.query;
  const channelsRef = admin.firestore().collection("storeChannels");
  const snapshot = await channelsRef.where("storeId", "==", storeId).get();
  // ...
});

// POST create channel
app.post("/api/test/channels", async (req, res) => {
  const { name, storeId } = req.body;
  const channelsRef = admin.firestore().collection("storeChannels");
  const docRef = await channelsRef.add({
    name, storeId, isActive: true, productCount: 0, createdAt: new Date()
  });
  // ...
});

// DELETE channel
app.delete("/api/test/channels/:id", async (req, res) => {
  await admin.firestore().collection("storeChannels").doc(req.params.id).delete();
  // ...
});
```

---

## Firebase Cloud Functions (functions/src/)

### Main File: index.ts (165KB)
Contains all deployed Cloud Functions including:

**Channel Functions:**
```typescript
exports.getChannels = functions.https.onRequest(async (req, res) => {
  const { storeId } = req.query;
  const snapshot = await admin.firestore()
    .collection("storeChannels")
    .where("storeId", "==", storeId)
    .get();
  // ...
});

exports.createChannel = functions.https.onRequest(async (req, res) => {
  const { name, storeId } = req.body;
  const docRef = await admin.firestore().collection("storeChannels").add({
    name, storeId, isActive: true, productCount: 0, createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  // ...
});

exports.deleteChannel = functions.https.onRequest(async (req, res) => {
  const { id } = req.params;
  await admin.firestore().collection("storeChannels").doc(id).delete();
  // ...
});
```

**Other Functions:**
- Order processing
- Printify webhooks
- Email notifications (NexusMail)
- Stripe webhooks
- Mockup generation jobs

### NexusMail (functions/src/nexusmail/)
Email system with queue, templates, and provider abstraction

### Nexus (functions/src/nexus/)
Self-healing system modules

---

## Shared Schemas (shared/)

### schema.ts
Drizzle ORM schemas for all database tables:
- products, orders, users, stores, channels
- printify_products, printify_orders
- stripe tables, email tables
- And more...

---

## Styles (styles/)

| File | Description |
|------|-------------|
| theme.css | Blue glass theme (.glass-card, .glass-button, ice colors) |
| buttons.css | Button styles (.qr-btn, .qr-btn--touch for 48px targets) |
| forms.css | Form inputs with voice input support |
| layout.css | Layout utilities |
| auth.css | Authentication page styles |

### Key Button Classes:
```css
.qr-btn--touch {
  min-height: 48px;  /* Accessibility touch target */
  min-width: 48px;
}

.qr-btn--icon-touch {
  min-height: 48px;
  min-width: 48px;
  padding: 0.75rem;
}
```

---

## Firestore Collections

### storeChannels
```typescript
{
  id: string;           // Auto-generated
  name: string;         // Channel name
  storeId: string;      // Parent store ID
  isActive: boolean;    // Active status
  productCount: number; // Products in channel
  createdAt: Timestamp; // Creation date
}
```

---

## Environment Variables Required

```
# Firebase
FIREBASE_SERVICE_ACCOUNT_KEY={"type":"service_account",...}

# Database
DATABASE_URL=postgresql://...
STORAGE_MODE=dual-write

# Printify
PRINTIFY_API_KEY=...

# Stripe
STRIPE_SECRET_KEY=...
STRIPE_WEBHOOK_SECRET=...
```

---

## Deployment

### Local Development
```bash
npm run dev
```

### Firebase Production
```bash
npm run build
echo "$FIREBASE_SERVICE_ACCOUNT_KEY" > /tmp/firebase-key.json
GOOGLE_APPLICATION_CREDENTIALS=/tmp/firebase-key.json firebase deploy --only hosting,functions
```

### Production URL
https://qrgear-c1ffd.web.app/test-products

---

## Accessibility Features

1. **48px Touch Targets** - All buttons use qr-btn--touch class
2. **Voice Input** - All inputs have:
   - type="text"
   - inputMode="text"
   - autoCapitalize="words"
   - enterKeyHint="done"
3. **Full-Width Mobile** - Inputs stretch to full width on mobile
4. **Blue Glass Theme** - High contrast, readable UI

---

## Multi-Tenant Architecture

1. User selects **Role** (Internal/External/Member)
2. Store dropdown filters by role
3. User selects **Store**
4. Channel chips appear for that store
5. User can add/delete channels (persisted to Firestore)
