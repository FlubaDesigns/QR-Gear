-- QR Gear Database Schema Export
-- Generated: January 15, 2026

-- This file contains all table definitions from the PostgreSQL database
