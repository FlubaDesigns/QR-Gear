# QR Gear Database Tables and Fields

## PostgreSQL Tables (via Drizzle ORM)

See drizzle-schema.ts for complete definitions.

## Key Tables:
- users - User accounts
- products - Product catalog  
- orders - Customer orders
- order_items - Items in orders
- carts - Shopping carts
- cart_items - Items in carts
- sessions - User sessions
- stores - Multi-tenant stores
- channels - Store channels
- background_assets - Library assets
- printify_print_providers - Printify catalog cache
- mockup_jobs - Mockup generation queue
- email_outbox - Email queue
- email_logs - Email history

## Firestore Collections (production):
- users
- products  
- orders
- carts
- stores
- channels
- mockupJobs
- emailOutbox
