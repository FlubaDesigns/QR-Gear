# QR Gear Wizard System - Complete Architecture Reference

## Overview

The QR Gear Wizard System is a modular, multi-tier product creation engine that guides users (members and admins) through building personalized QR-enhanced merchandise. It supports five QR types (Basic, Plus, Canvas, Play, Compose) across four wizard tiers (Super Simple, Simple, Advanced, Studio), plus a separate admin builder with its own compose flow.

---

## Architecture Summary

```
┌─────────────────────────────────────────────────────────────┐
│                     MembersPage.tsx                          │
│  Pure routing shell: auth, nav tabs, view mode switching    │
│  Delegates rendering to wizard modules via WizardProvider   │
└─────────────────────┬───────────────────────────────────────┘
                      │
          ┌───────────┴───────────┐
          ▼                       ▼
  ┌───────────────┐     ┌─────────────────────┐
  │ WizardProvider │     │ MemberAuthProvider   │
  │ (WizardContext)│     │ MembersProvider      │
  └───────┬───────┘     └─────────────────────┘
          │
    ┌─────┼─────────┬──────────────┐
    ▼     ▼         ▼              ▼
  Super  Simple  Advanced      Studio
  Simple Wizard  Wizard         Mode
  Wizard
```

All wizard modules consume shared state via `useWizardContext()` hook — no state duplication.

---

## File Inventory

### Member Wizard Modules (`client/src/features/members/`)

| File | Lines | Purpose |
|------|-------|---------|
| `WizardContext.tsx` | ~1,815 | All shared wizard state (~100 useStates), pricing queries, API operations, navigation logic via React Context |
| `SuperSimpleWizard.tsx` | ~186 | 6-step card flow with blackboard explainers, progress dots, handoff to Simple |
| `SimpleWizard.tsx` | ~934 | Full guided wizard with all QR type branches (Basic/Plus/Canvas/Play/Compose), progress bar, next/back logic |
| `AdvancedWizard.tsx` | ~201 | Dense 8-step builder with PlacementPicker, HeaderFooterEditor, BackgroundLibraryPicker |
| `StudioMode.tsx` | ~128 | Quick publish interface for experienced users |
| `MembersPage.tsx` | ~817 | Pure routing shell: auth, nav tabs, view mode switching |
| `MembersContext.tsx` | - | Core member data context (AllowedProduct, Channel, TextStyleConfig, API helpers) |
| `MemberAuthContext.tsx` | - | Firebase authentication context for members (getAuthHeaders, apiBase) |

### Admin Builder Modules (`client/src/features/adminProducts/builder/`)

| File | Purpose |
|------|---------|
| `types.ts` | All admin builder TypeScript types (BuilderState, ContentData, QR types) |
| `BuilderContext.tsx` | Admin builder state management (similar pattern to WizardContext) |
| `BuilderHarness.tsx` | Step orchestrator that routes between builder modules |
| `modules/ComposeContentModule.tsx` | Inline 8-step compose flow for admins |
| `modules/StateModule.tsx` | State/region configuration module |
| `modules/CreateGraphicsModule.tsx` | Graphic generation and publish flow |
| `modules/ProductGraphicTextModule.tsx` | Text overlay configuration |
| `modules/BasicsContentModule.tsx` | Basic QR content setup |
| `modules/URLContentModule.tsx` | URL-based QR content |
| `modules/PlayContentModule.tsx` | Video/Play content setup |
| `modules/PlacementModule.tsx` | Graphic placement configuration |
| `modules/ProductsModule.tsx` | Product selection module |
| `hooks/useSaveProduct.ts` | Save product hook |
| `components/ProductViewerControls.tsx` | Product viewer controls |
| `components/ProductDetailModal.tsx` | Product detail modal |
| `__tests__/nullGuards.test.ts` | Null guard tests |

### Shared Wizard Steps (`client/src/features/shared/components/wizardSteps/`)

These are the reusable step components consumed by ALL wizard tiers and the admin builder:

| File | Purpose |
|------|---------|
| `wizardTypes.ts` | Core type definitions: WizardStep, SimpleWizardStep, QRType, step arrays, type guards |
| `index.ts` | Barrel export for all wizard step types and utilities |
| `WizardProgressBars.tsx` | Progress bar components for Simple and Advanced wizards |
| `BlackboardExplainer.tsx` | Educational "blackboard" panels for Super Simple wizard |
| `ChannelStep.tsx` | Channel selection/creation step |
| `ProductSteps.tsx` | Product picker, congrats, color picker, size picker steps |
| `TypeAndSurfaceSteps.tsx` | QR type picker, surface picker, graphic generation steps |
| `PlacementSteps.tsx` | Graphic size, placement count, placement config steps |
| `TextSteps.tsx` | Text layout, header edit, footer edit steps |
| `QRBasicSteps.tsx` | QR Basic specific steps (URL input, save options) |
| `QRPlusSteps.tsx` | QR Plus specific steps (enhanced QR options) |
| `CanvasSteps.tsx` | Canvas/image QR steps |
| `PlaySteps.tsx` | Video/Play QR steps |
| `ComposeSteps.tsx` | Compose playlist steps (pick items, mode, durations, order, hosting, preview, publish, confirm) |
| `PreviewAndPublishSteps.tsx` | Preview and publish workflow steps |

### Shared Components (`client/src/features/shared/components/`)

Utility components used by wizards:

| File | Purpose |
|------|---------|
| `PlacementPicker.tsx` | Placement type/size selection with visual preview |
| `HeaderFooterEditor.tsx` | Header/footer text style editor with live preview |
| `TextStyleEditor.tsx` | Font, size, color, spacing, warp text editor |
| `TextStyleViewer.tsx` | Read-only text style preview |
| `BackgroundPicker.tsx` | Simple background color/image picker |
| `BackgroundLibraryPicker.tsx` | Background picker with library integration |
| `LibraryBackgroundPicker.tsx` | Full library background picker with crop utility |
| `ColorSwatchPicker.tsx` | Color swatch selection component |
| `LandingPageEditor.tsx` | Landing page configuration editor |
| `LandingPageViewer.tsx` | Landing page preview |
| `VideoSourcePicker.tsx` | Video source selection (upload, URL, library) |
| `CanvasTextLayer.tsx` | Text overlay layer for canvas compositions |
| `GraphicViewer.tsx` | Graphic preview component |
| `ShareKitHandoff.tsx` | Post-publish share kit UI |
| `ProductCatalogPicker.tsx` | Product catalog browser |
| `CollapsibleModule.tsx` | Collapsible section wrapper |
| `CollapsibleTextInput.tsx` | Collapsible text input field |
| `ARPreviewModal.tsx` | AR preview modal |
| `SkinGridViewer.tsx` | Grid viewer with card/detail skin pattern |
| `SharedViewer.tsx` | Shared viewer orchestrator |
| `SharedLightbox.tsx` | Lightbox overlay component |
| `ProductLightbox.tsx` | Product-specific lightbox |
| `ProductConfigSkin.tsx` | Product configuration display skin |
| `ProductSkin.tsx` | Product display skin |

### Skins (`client/src/features/shared/components/skins/`)

Visual presentation components for the Viewer/View/Skin architecture:

| File | Purpose |
|------|---------|
| `types.ts` | Skin type definitions (SkinItem, SkinActions, etc.) |
| `index.ts` | Barrel export |
| `AllowedProductSkin.tsx` | Allowed product card/detail |
| `BackgroundSkin.tsx` | Background image card/detail |
| `ChannelContentSkin.tsx` | Channel content display |
| `ChannelItemSkin.tsx` | Channel item card |
| `CollectionItemSkin.tsx` | Collection item card (v1) |
| `CollectionItemSkinV2.tsx` | Collection item card (v2) |
| `CropDeleteSkin.tsx` | Cropped image with delete action |
| `CroppedImageSkin.tsx` | Cropped image display |
| `DeleteSkin.tsx` | Delete action skin |
| `DynamicsChannelSkin.tsx` | Dynamics channel card |
| `DynamicsCollectionSkin.tsx` | Dynamics collection card |
| `GraphicPreviewView.tsx` | Graphic preview with overlay |
| `GraphicsSkin.tsx` | Graphics card/detail |
| `LandingPageView.tsx` | Landing page preview skin |
| `MediaPreviewView.tsx` | Media (image/video) preview |
| `ProductCanvasSkin.tsx` | Product canvas skin |
| `QRDynamicsScanSkin.tsx` | QR scan interface skin |
| `SelectCropDeleteSkin.tsx` | Select/crop/delete actions |
| `SourceImageSkin.tsx` | Source image display |
| `StoreProductSkin.tsx` | Store product card |
| `TemplatePickerSkin.tsx` | Template selection card |
| `TemplateSkin.tsx` | Template display |
| `TextPreviewView.tsx` | Text style preview |
| `VideoPlaySkin.tsx` | Video play card |

### Views (`client/src/features/shared/components/views/`)

Layout/behavior components:

| File | Purpose |
|------|---------|
| `index.ts` | Barrel export |
| `ContentView.tsx` | Content display view |
| `GalleryView.tsx` | Gallery layout with navigation |
| `GridView.tsx` | Grid layout |
| `GridScrollView.tsx` | Scrollable grid |
| `ScrollView.tsx` | Horizontal scroll view |
| `SingleView.tsx` | Single item view |
| `ImageLightbox.tsx` | Image lightbox overlay |
| `QRDynamicsScanLightbox.tsx` | QR scan lightbox |

### Utilities (`client/src/features/shared/components/utilities/`)

| File | Purpose |
|------|---------|
| `index.ts` | Barrel export |
| `CropUtility.tsx` | Image crop tool |
| `ImageUploader.tsx` | Image upload with Firebase Storage |

### Other Shared Files

| File | Purpose |
|------|---------|
| `client/src/features/shared/AdminAuthContext.tsx` | Admin authentication context |
| `client/src/features/shared/placementTypes.ts` | Placement type/size constants |
| `client/src/features/shared/README.md` | Viewer/View/Skin architecture docs |
| `client/src/features/shared/SHARED_COMPONENTS.md` | Shared component system docs |
| `client/src/features/shared/PRODUCT_LIFECYCLE.md` | Product lifecycle docs |

---

## Wizard Tiers

### Super Simple Wizard (`wizardTier: 'super-simple'`)
A cards-based intro wizard presenting 6 steps as large tappable cards with progress dots. After type selection, hands off to the Simple Wizard for QR-specific flow.

**Steps**: Channel → Product → Congrats → Color → Size → Type → (handoff to Simple)

### Simple Wizard (`wizardTier: 'simple'`)
The full guided wizard supporting all QR type branches with a progress bar and next/back navigation.

**Core Steps**: Channel → Product → Congrats → Color → Size → Type → Surface → (branch by QR type)

**QR Type Branches**:
- **Basic**: URL input → Save options → Generate graphic → Preview → Publish
- **Plus**: Enhanced QR options → Generate → Preview → Publish
- **Canvas**: Image upload/select → Canvas config → Generate → Preview → Publish
- **Play**: Video source → Play config → Generate → Preview → Publish
- **Compose**: Pick items → Mode → Durations → Order → Hosting → Preview → Publish → Confirm

### Advanced Wizard (`wizardTier: 'advanced'`)
Dense 8-step builder with full control over placements, text styling, and backgrounds.

**Steps**: Channel → Product → Placement → Text → Background → Type/Surface → Generate → Publish

### Studio Mode (`wizardTier: 'studio'`)
Minimal quick-publish interface for experienced users who know what they want.

---

## QR Types

| Type | Surface | Description |
|------|---------|-------------|
| `qr_basic` | IMAGE | Simple URL-destination QR code |
| `qr_plus` | IMAGE | Enhanced QR with additional features |
| `qr_canvas` | IMAGE | Image-based QR experience |
| `qr_play` | VIDEO | Video-based QR experience |
| `qr_compose` | PLAYLIST | Rotating playlist of Canvas/Play items |

---

## State Management Pattern

All wizard state lives in `WizardContext.tsx` (~100 useState hooks) and is consumed via `useWizardContext()`. This pattern:

1. Eliminates prop drilling across wizard modules
2. Ensures state consistency across tier switches
3. Centralizes API operations (pricing queries, publish flow)
4. Enables any module to read/write any wizard state

The admin builder follows the same pattern with `BuilderContext.tsx`.

---

## Key Dependencies

- **React** + TypeScript
- **TanStack Query** (v5) - Data fetching, mutations, cache management
- **shadcn/ui** - UI component library (Button, Card, Badge, Dialog, etc.)
- **lucide-react** - Icon library
- **Firebase** - Authentication, Storage, Firestore
- **wouter** - Client-side routing

---

## Compose Flow (8 Steps)

The newest QR type, used by both Simple Wizard and admin ComposeContentModule:

1. **Pick Items** - Select from published Canvas/Play items
2. **Mode** - Choose auto-rotate or scan-to-reveal
3. **Durations** - Set display time per item
4. **Order** - Drag to reorder playlist items
5. **Hosting** - Select hosting term (1/3/5 years)
6. **Preview** - Summary with mockup preview
7. **Publish** - Sends to server API
8. **Confirm** - Shows instance ID and resolver URL

---

## Three-Layer Skin Architecture

```
┌─────────────────────────────────┐
│  VIEWER (SkinGridViewer)        │
│  Orchestrates layout and state  │
│  Decides which View to render   │
│                                 │
│  ┌───────────────────────────┐  │
│  │  VIEW (Behavior/Layout)   │  │
│  │  Grid, Gallery, Scroll    │  │
│  │  Handles interactions     │  │
│  │                           │  │
│  │  ┌─────────────────────┐  │  │
│  │  │  SKIN (Appearance)  │  │  │
│  │  │  Card + Detail      │  │  │
│  │  │  Pure presentation  │  │  │
│  │  └─────────────────────┘  │  │
│  └───────────────────────────┘  │
└─────────────────────────────────┘
```

---

## Pricing Architecture

- Admin configures retail price (`customer_price`)
- At publish time, server looks up real Printify manufacturing costs per variant
- Pricing snapshot stored on packet: retail, member earnings, admin margins, cost breakdown
- Members earn 25% of profit (retail minus Printify cost)
- At order time, actual costs recorded on order items

---

## Navigation & Routing

- Members access wizards at `/test-members`
- Admin builder at admin product management routes
- `MembersPage.tsx` handles tab switching between wizard tiers
- All wizard tiers always visible in nav tabs (unlock system bypassed for testing)
