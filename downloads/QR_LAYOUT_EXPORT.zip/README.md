# QR Layout Export — Unified Layout Authority

Both preview (UnifiedGraphic.tsx) and export (productGraphicRenderer.ts) now use
ONE shared layout function: `getGraphicLayout()` from `graphicLayout.ts`.

## Single Source of Truth
- `graphicLayout.ts` contains ALL layout math and defaults
- Zone sizes, QR positioning, background padding, border radius — all in one file
- Future tuning happens ONLY in graphicLayout.ts

## Consistent Defaults
- qrPositionX = 50 (centered horizontally)
- qrPositionY = 0 (top of middle zone)
- qrSizePercent = 42
- All sourced from `GRAPHIC_LAYOUT_DEFAULTS`

## Deleted
- `graphicLayoutConstants.ts` — was dead code with different values, removed
