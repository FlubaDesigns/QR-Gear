# QR Gear Wizard System — Complete Reference

## Overview

The wizard system is the core product creation flow for QR Gear. It guides members (and public visitors) through building customized QR-enhanced merchandise. There are 5 wizards total, plus a shared context and 15 shared step components.

---

## File Map

### Wizard Files (client/src/features/members/)

| File | Purpose |
|------|---------|
| `SuperSimpleWizard.tsx` | First-time member wizard. Includes chalkboard tutorial system, blackboard cards, QR type exploration cards. Meant to be the most guided, hand-holding experience. |
| `SimpleWizard.tsx` | Second-tier wizard. Same steps as Super Simple but without tutorial blackboards. Unlocked after completing Super Simple. |
| `AdvancedWizard.tsx` | Third-tier wizard. Same flow as Simple but with additional options. Unlocked after first publish. |
| `StudioMode.tsx` | Quick-publish mode. Minimal UI, jumps straight to key steps. For experienced users. |
| `WizardContext.tsx` | **THE SHARED BRAIN.** Contains all state, API calls, step navigation logic, `handleSimpleNext`, `handleSimpleBack`, `canSimpleProceed`, pricing calculations, packet creation, publishing flow. Every member wizard consumes this via `useWizardContext()`. |
| `MembersPage.tsx` | Routing shell. Determines which wizard to show based on `wizardTier` state. Also handles the members dashboard/index view. |
| `MembersContext.tsx` | Provides member-level context (channels, products, etc.) |
| `MemberAuthContext.tsx` | Firebase Auth wrapper for member pages |
| `MemberOnboarding.tsx` | Onboarding flow for new members |

### Public Wizard (client/src/features/owner/)

| File | Purpose |
|------|---------|
| `OwnerWizard.tsx` | Public-facing conversion funnel. Self-contained (does NOT use WizardContext). For unauthenticated users to build custom QR products. Has its own state, step navigation, and pricing. Integrates with planned Stripe checkout. |

### Shared Wizard Step Components (client/src/features/shared/components/wizardSteps/)

| File | Components | Used By |
|------|-----------|---------|
| `wizardTypes.ts` | Type definitions: `AllowedProduct`, `QRType`, `SimpleWizardStep`, `WizardStep`, `SHIRT_COLORS`, `SHIRT_SIZES`, `PlacementOption`, etc. | All wizards |
| `index.ts` | Exports: `calculateSizeEarningsBonuses()`, `generateQRCodeUrl()` | All wizards |
| `ProductSteps.tsx` | `ProductPickerStep` (fetches from `/api/members/allowed-products`), `ProductCongratsStep` | All wizards |
| `ChannelStep.tsx` | `ChannelPickerStep` — channel selection/creation | Member wizards |
| `PlacementSteps.tsx` | `PlacementCountStep`, `GraphicSizeStep`, `PlacementConfigStep` — pick print areas, graphic sizes | All wizards |
| `TextSteps.tsx` | `TextChoiceStep`, `TextEditStep` — header/footer text customization | All wizards |
| `TypeAndSurfaceSteps.tsx` | `QRTypePickerStep`, `SurfacePickerStep`, `GenerateGraphicStep` — QR type selection, surface choice (Canvas/Play/Compose), graphic generation prompt | All wizards |
| `QRBasicSteps.tsx` | `QRBasicTypeStep`, `QRBasicInputStep`, `QRBasicMockupStep`, `QRBasicSaveChoiceStep`, `QRBasicConfirmStep` | All wizards |
| `QRPlusSteps.tsx` | `QRPlusMockupStep`, `QRPlusSaveChoiceStep`, `QRPlusConfirmStep` | All wizards |
| `CanvasSteps.tsx` | `QRCanvasExplainerStep`, `UrlSourceChoiceStep`, `SimpleBackgroundStep`, `QRCanvasSaveChoiceStep`, `QRCanvasConfirmStep`, `SimplePreviewStep`, `SimplePublishStep` | All wizards |
| `PlaySteps.tsx` | `PlayVideoSourceStep`, `PlayPreviewStep`, `PlayPublishStep`, `PlayPublishedStep` | All wizards |
| `ComposeSteps.tsx` | `ComposeModePicker`, `ComposePickItemsStep`, `ComposeDurationsStep`, `ComposeOrderStep`, `ComposeHostingStep`, `ComposePreviewStep`, `ComposePublishStep`, `ComposeConfirmStep`, `ComposeExplainerCard`, `PlatformAcknowledgementCard` | All wizards |
| `PreviewAndPublishSteps.tsx` | `ShirtPreviewStep`, `UrlTitleStep`, `UrlDescriptionStep` | All wizards |
| `WizardProgressBars.tsx` | Progress bar UI components | All wizards |
| `BlackboardExplainer.tsx` | Reusable explainer card component | SuperSimpleWizard |

### Infrastructure Files

| File | Purpose |
|------|---------|
| `index.ts` (functions/src/) | Firebase Cloud Function — the ONLY production API. Contains ALL backend routes including `/members/allowed-products`, packet CRUD, publishing, mockup generation, etc. |
| `queryClient.ts` (client/src/lib/) | TanStack Query config. Contains `getApiUrl()` (rewrites `/api/*` to CF URL on production), `getAuthHeader()` (Firebase Auth token), default query function with Nexus retry. |
| `useAuth.ts` (client/src/hooks/) | Auth hook. Returns current user from Firebase Auth + API user data. |
| `firebase.ts` (client/src/lib/) | Firebase app initialization, auth, firestore, storage exports. |

---

## Wizard Tier System

Members progress through wizard tiers based on experience:

1. **Super Simple** — First-time users. Full tutorial with chalkboard cards explaining each concept. Blackboard queue system shows educational cards before/after key steps.
2. **Simple** — Tutorial complete. Same steps, no blackboards.
3. **Advanced** — After first publish. More options available.
4. **Studio** — Quick publish mode for power users.

Tier is tracked in `wizardTier` state in WizardContext. The `MembersPage.tsx` routing shell renders the appropriate wizard component based on this.

---

## Step Flow (Super Simple / Simple / Advanced)

All three member wizards follow the same core step sequence. The step ID is stored in `simpleStep` state in WizardContext.

### Core Steps (in order):
1. `channel` — Pick or create a channel
2. `product` — Pick a product from allowed products list
3. `product-congrats` — Shows earnings for selected product
4. `color` — Pick shirt color
5. `size` — Pick shirt size (affects earnings)
6. `type` — Pick QR type (basic/plus/canvas/play/compose)
7. `placement-count` — Pick print placement areas (front, back, sleeves, etc.)
8. `graphic-size` — Pick graphic size for each placement
9. `generate` — "Do you want header/footer text?" (Yes/No fork)

### After "generate" step, flow forks by QR type:

**QR Basic path** (user said No to text, or chose basic):
- `qr-basic-type` → `qr-basic-input` → `qr-basic-mockup` → `qr-basic-save-choice` → `qr-basic-confirm`

**QR Plus path** (user said Yes to text):
- `text-choice` → `text-edit-header` → `text-edit-footer` → `placement-config` → `shirt-preview` → `qr-plus-mockup` → `qr-plus-save-choice` → `qr-plus-confirm`

**Canvas path** (from canvas-fork):
- `canvas-fork` (surface picker) → `url-explainer` → `url-source-choice` → `url-library-pick` → `url-title` → `url-description` → `url-preview` → `url-publish` → `canvas-mockup` → `canvas-save-choice` → `canvas-confirm`

**Play path** (from canvas-fork):
- `canvas-fork` → `play-video-source` → `play-preview` → `play-publish` → `play-mockup` → `play-save-choice`

**Compose path** (from canvas-fork):
- `canvas-fork` → `compose-pick-items` → `compose-mode` → `compose-durations` → `compose-order` → `compose-hosting` → `compose-mockup` → `compose-preview` → `compose-publish` → `compose-confirm`

---

## Super Simple Blackboard System

The Super Simple wizard has a tutorial overlay system using "blackboard cards" — styled chalkboard-like educational cards that appear before and after key steps.

### Blackboard Content (BLACKBOARD_CONTENT object):
- `bb-welcome` — "Hey, You Made It!" intro
- `bb-channels` — Explains what channels are
- `bb-pricing` — Explains earnings system
- `bb-zones` — Explains color selection
- `bb-earnings` — Explains size → earnings relationship
- `bb-qr-intro` — Introduces QR types
- `bb-whats-next` — "Almost There!" transition
- `bb-finish` — "You Did It!" completion (button says "Start")

### Congrats Blackboards (dynamic, generated by getCongratsBlackboard()):
- `bb-channel-congrats` — Celebrates channel selection
- `bb-product-congrats` — Celebrates product pick
- `bb-color-congrats` — Shows earnings so far
- `bb-size-congrats` — Shows size bonus math

### QR Type Exploration Cards (QR_TYPE_CARDS object):
- `bb-qr-basic` → `bb-qr-plus` → `bb-qr-canvas` → `bb-qr-play`
- Each has "Choose [Type]" and "Show Me More" buttons
- After viewing all or choosing one, shows QR congrats card

### Blackboard Queue System:
- `PRE_STEP_BLACKBOARDS` — blackboards shown BEFORE a step: channel→[bb-welcome, bb-channels], product→[bb-pricing], color→[bb-zones], size→[bb-earnings], type→[bb-qr-intro]
- `POST_STEP_BLACKBOARDS` — blackboards shown AFTER completing a step: channel→[bb-channel-congrats], product-congrats→[bb-product-congrats], color→[bb-color-congrats], size→[bb-size-congrats]
- Tutorial completion tracked in Firestore: `member_profiles/{userId}.tutorial_complete`
- If tutorial already done, all blackboards are skipped

---

## WizardContext — Key Functions

### State:
- `simpleStep` / `setSimpleStep` — Current wizard step ID
- `selectedChannel`, `selectedProductType`, `selectedColor`, `selectedShirtSize`, `qrType`, `graphicSize`, `selectedPlacements` — User selections
- `runningEarnings` — Accumulated earnings display
- `contentRightsConfirmed` — Content rights checkbox state
- `currentPacketId` — Active product packet being built
- All text styling state (header/footer text, fonts, colors, sizes, positions)
- All QR-specific state (qrBasicContent, playVideoUrl, composeItems, etc.)

### Navigation:
- `handleSimpleNext()` — Main "Next" handler. Contains step-specific logic for what happens on each forward navigation. ~500 lines of branching logic.
- `handleSimpleBack()` — "Back" handler. Maps each step to its previous step.
- `canSimpleProceed()` — Returns boolean for whether the "Next" button should be enabled. Switch statement over all step IDs.

### API/Data:
- `createPacketForProduct()` — Creates a product packet in Firestore
- `handleProductSelect()` — Handles product selection + packet creation
- `handleSimplePublish()` — Publishes the product (creates assets, links to catalog)
- `handleVideoFileUpload()` — Handles video upload for Play flow
- `handleCanvasDone()` — Handles canvas completion
- `fetchPublishedCanvasPlayItems()` — Fetches published items for Compose flow
- `api` object — Contains all API call functions

---

## Known Issues (as of March 2026)

### Fixed in latest deploy:
1. **Canvas path dead end** — `canvas-mockup` canProceed required `contentRightsConfirmed` which was never set in Super Simple. Fixed: gate removed, returns `true`.
2. **Play path dead end** — `play-video-source` canProceed required `contentRightsConfirmed`. Fixed: gate removed. Props now wired up in Super Simple.
3. **Earnings doubling** — Going back/forward through `product-congrats` added earnings each time. Fixed: guard added (only sets when prev===0). Affects Super Simple, Simple, Advanced (shared WizardContext).
4. **Finish loop** — Super Simple finish blackboard reset to `channel` step, restarting wizard. Fixed: now calls `setViewMode('index')` to exit to dashboard.
5. **QR Basic wrong path** — "No" on generate step sent QR Basic users to `canvas-fork` instead of `qr-basic-type`. Fixed in all 3 member wizards.
6. **Misleading finish text** — Said "graduating to Simple Wizard" but didn't switch tiers. Fixed: text updated to "You're all set!"

### Still open:
- **Product picker showing "No Products Available"** — Production API returns 8 products correctly. CORS headers are correct. Endpoint works without auth. Issue appears to be front-end only — possibly browser cache, auth race condition, or silent fetch failure. The `on401: "returnNull"` behavior in queryClient means any auth error silently returns null → empty product list. Needs browser-side debugging to confirm root cause.
- `handleSimplePublish` has empty code blocks for qr-basic/qr-plus paths (works only because callers set the next step, but fragile)

---

## Cloud Function Routes (Wizard-Related)

All routes are in `functions/src/index.ts`. The CF strips the `/api` prefix — frontend calls `/api/members/...`, CF handles `/members/...`.

| Route | Method | Auth | Purpose |
|-------|--------|------|---------|
| `/members/allowed-products` | GET | None | Returns products available for members to customize. Reads from Firestore `storeAllowedProducts/member-products`. Enriches with pricing from `testSettings/pricing`. |
| `/members/allowed-products` | POST | Admin | Add/update allowed products list |
| `/members/channels` | GET | Member | List member's channels |
| `/members/channels` | POST | Member | Create a new channel |
| `/members/packets` | POST | Member | Create a product packet |
| `/members/packets/:id` | PATCH | Member | Update a packet |
| `/members/packets/:id` | GET | Member | Get a single packet |
| `/members/publish` | POST | Member | Publish a product |
| `/members/generate-product-graphic` | POST | Member | Generate product graphic image |
| `/members/mockup/priority` | POST | Member | Generate product mockup |
| `/admin/stores/:storeId/allowed-products` | GET/POST | Admin | Manage allowed products per store |

---

## Data Flow

### Product Selection:
1. Frontend: `ProductPickerStep` queries `/api/members/allowed-products`
2. CF reads `storeAllowedProducts/member-products` from Firestore
3. CF enriches each product with: image URL (from `printifyBlueprints`), base cost (from `printifyPrintProviders`), retail price & member earnings (calculated from `testSettings/pricing`)
4. Returns array of `AllowedProduct` objects

### Packet Creation:
1. User selects product → `handleProductSelect()` called
2. Creates packet in Firestore via `/api/members/packets` POST
3. Packet stores: channel, product info, color, size, QR type, placements, text, graphics
4. Packet updated incrementally as user progresses through steps

### Publishing:
1. User completes all steps → hits publish
2. `handleSimplePublish()` calls `/api/members/publish`
3. Server creates product graphic, mockup, template entry, catalog link
4. Returns published product info

---

## QR Types

| Type | ID | Description | Platform Fee | Content Baked In |
|------|----|-------------|-------------|-----------------|
| Basic | `qr-basic` | Static QR code linking to URL/text/contact | None | Yes |
| Plus | `qr-plus` | Basic + printed header/footer text | None | Yes |
| Canvas | `qr-canvas` | QR links to full-screen image landing page | Yes | No (server-hosted) |
| Play | `qr-play` | QR links to video landing page | Yes | No (server-hosted) |
| Compose | `qr-compose` | QR links to rotating playlist of Canvas/Play items | Yes | No (server-hosted) |

---

## Key Dependencies

- React + TypeScript + Vite (frontend)
- TanStack Query v5 (data fetching)
- Firebase Auth (authentication)
- Firebase Firestore (all data storage)
- Firebase Storage (file assets)
- Firebase Cloud Functions (API)
- Printify API (product catalog, fulfillment)
- Printful API (mockup generation)
- shadcn/ui (UI components)
- Lucide React (icons)
