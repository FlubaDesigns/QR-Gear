
const PRINTIFY_API_BASE = 'https://api.printify.com/v1';

export interface PrintifyBlueprint {
  id: number;
  title: string;
  description: string;
  brand: string;
  model: string;
  images: string[];
}

export interface PrintifyPrintProvider {
  id: number;
  title: string;
  location?: {
    address1?: string;
    city?: string;
    country?: string;
    region?: string;
    zip?: string;
  };
}

export interface PrintifyVariant {
  id: number;
  title: string;
  options: {
    color?: string;
    size?: string;
  };
  placeholders: Array<{
    position: string;
    height: number;
    width: number;
  }>;
  price?: number; // Price in cents from Printify catalog
  is_available?: boolean; // Stock status
}

export interface PrintifyProduct {
  id: string;
  title: string;
  description: string;
  tags: string[];
  options: any[];
  variants: any[];
  images: any[];
  created_at: string;
  updated_at: string;
  visible: boolean;
  is_locked: boolean;
  blueprint_id: number;
  print_provider_id: number;
  print_areas: any[];
  print_details: any[];
  sales_channel_properties: any[];
}

export interface PrintifyOrderLineItem {
  product_id: string;
  variant_id: number;
  quantity: number;
  print_areas?: {
    front?: string;
    back?: string;
  };
}

export interface PrintifyOrderAddress {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  country: string;
  region: string;
  address1: string;
  address2?: string;
  city: string;
  zip: string;
}

export interface CreateOrderRequest {
  external_id: string;
  label?: string;
  line_items: PrintifyOrderLineItem[];
  shipping_method: number;
  is_printify_express?: boolean;
  send_shipping_notification: boolean;
  address_to: PrintifyOrderAddress;
}

class PrintifyClient {
  private getApiKey(): string {
    const key = (process.env.PRINTIFY_API_KEY || process.env.PRINTIFY_API_KEY_2 || '').trim().replace(/\s+/g, '');
    if (!key) {
      console.error('[PrintifyClient] No PRINTIFY_API_KEY found in environment');
    }
    return key;
  }
  
  private getShopId(): string {
    return (process.env.PRINTIFY_SHOP_ID || '').trim().replace(/\s+/g, '');
  }

  private get headers() {
    return {
      'Authorization': `Bearer ${this.getApiKey()}`,
      'Content-Type': 'application/json',
    };
  }

  get isConfigured(): boolean {
    return Boolean(this.getApiKey() && this.getShopId());
  }

  private async request<T>(endpoint: string, options: RequestInit = {}, retries = 3): Promise<T> {
    if (!this.isConfigured) {
      throw new Error('Printify API not configured. Missing API key or Shop ID.');
    }

    const url = endpoint.startsWith('http') 
      ? endpoint 
      : `${PRINTIFY_API_BASE}${endpoint}`;

    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        const response = await fetch(url, {
          ...options,
          headers: {
            ...this.headers,
            ...options.headers,
          },
        });

        // If 401/429, wait and retry (unless last attempt)
        if ((response.status === 401 || response.status === 429) && attempt < retries - 1) {
          const waitTime = 1000 * Math.pow(2, attempt); // 1s, 2s, 4s
          console.log(`Printify API ${response.status}, retrying in ${waitTime}ms (attempt ${attempt + 1}/${retries})`);
          await new Promise(r => setTimeout(r, waitTime));
          continue;
        }

        if (!response.ok) {
          const error = await response.text();
          throw new Error(`Printify API error: ${response.status} - ${error}`);
        }

        return response.json();
      } catch (error: any) {
        lastError = error;
        if (attempt < retries - 1) {
          const waitTime = 1000 * Math.pow(2, attempt);
          console.log(`Printify API error, retrying in ${waitTime}ms (attempt ${attempt + 1}/${retries}): ${error.message}`);
          await new Promise(r => setTimeout(r, waitTime));
        }
      }
    }
    
    throw lastError || new Error('Printify API request failed after retries');
  }

  async getShops(): Promise<any[]> {
    return this.request('/shops.json');
  }

  async getCatalogBlueprints(): Promise<PrintifyBlueprint[]> {
    return this.request('/catalog/blueprints.json');
  }

  async getBlueprintDetails(blueprintId: number): Promise<PrintifyBlueprint> {
    return this.request(`/catalog/blueprints/${blueprintId}.json`);
  }

  async getPrintProviders(blueprintId: number): Promise<PrintifyPrintProvider[]> {
    return this.request(`/catalog/blueprints/${blueprintId}/print_providers.json`);
  }

  async getAllPrintProviders(): Promise<PrintifyPrintProvider[]> {
    return this.request('/catalog/print_providers.json');
  }

  async getVariants(blueprintId: number, printProviderId: number): Promise<{ variants: PrintifyVariant[] }> {
    return this.request(`/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/variants.json`);
  }

  /**
   * Get print areas (placements) available for a blueprint/provider combo.
   * Returns position names like 'front', 'back', 'left', 'right', etc.
   */
  async getPrintAreas(blueprintId: number, printProviderId: number): Promise<{ placeholders: Array<{ position: string; width: number; height: number }> }> {
    return this.request<any>(`/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/shipping.json`)
      .catch(() => {
        // Fallback: try the print_areas endpoint format
        return this.request(`/catalog/print_providers/${printProviderId}/shipping.json`);
      });
  }

  /**
   * Get a placement that works for ALL variants (intersection).
   * Returns the placement name and the variant IDs that support it.
   * Throws if no common placement exists.
   */
  async getCommonPlacement(blueprintId: number, printProviderId: number): Promise<{ placement: string; variantIds: number[] }> {
    const variantsData = await this.request<{ variants: any[] }>(
      `/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/variants.json`
    );
    
    // Build a map: placement -> set of variant IDs that support it
    const placementToVariants = new Map<string, Set<number>>();
    const allVariantIds: number[] = [];
    
    for (const variant of variantsData.variants) {
      allVariantIds.push(variant.id);
      if (variant.placeholders && variant.placeholders.length > 0) {
        for (const placeholder of variant.placeholders) {
          if (placeholder.position) {
            if (!placementToVariants.has(placeholder.position)) {
              placementToVariants.set(placeholder.position, new Set());
            }
            placementToVariants.get(placeholder.position)!.add(variant.id);
          }
        }
      }
    }
    
    // Find a placement that covers ALL variants
    const totalVariants = allVariantIds.length;
    const MAX_VARIANTS = 100; // Printify limit: maximum 100 variants per product
    
    for (const [placement, variantSet] of Array.from(placementToVariants.entries())) {
      if (variantSet.size === totalVariants) {
        const limitedIds = allVariantIds.slice(0, MAX_VARIANTS);
        console.log(`[Printify] Found common placement '${placement}' for ${limitedIds.length}/${totalVariants} variants (capped at ${MAX_VARIANTS})`);
        return { placement, variantIds: limitedIds };
      }
    }
    
    let bestPlacement = '';
    let bestCoverage = 0;
    let bestVariantIds: number[] = [];
    
    for (const [placement, variantSet] of Array.from(placementToVariants.entries())) {
      if (variantSet.size > bestCoverage) {
        bestCoverage = variantSet.size;
        bestPlacement = placement;
        bestVariantIds = Array.from(variantSet).slice(0, MAX_VARIANTS) as number[];
      }
    }
    
    if (bestPlacement && bestCoverage > 0) {
      console.log(`[Printify] Best placement '${bestPlacement}' covers ${Math.min(bestCoverage, MAX_VARIANTS)}/${totalVariants} variants`);
      return { placement: bestPlacement, variantIds: bestVariantIds };
    }
    
    // No placements found at all
    throw new Error(`No valid print placements found for blueprint ${blueprintId}. Cannot extract real production costs.`);
  }

  async getShopProducts(): Promise<{ data: PrintifyProduct[] }> {
    return this.request(`/shops/${this.getShopId()}/products.json`);
  }

  async getProduct(productId: string): Promise<PrintifyProduct> {
    return this.request(`/shops/${this.getShopId()}/products/${productId}.json`);
  }

  async createProduct(productData: {
    title: string;
    description: string;
    blueprint_id: number;
    print_provider_id: number;
    variants: Array<{ id: number; price: number; is_enabled: boolean }>;
    print_areas: Array<{
      variant_ids: number[];
      placeholders: Array<{
        position: string;
        images: Array<{
          id: string;
          x: number;
          y: number;
          scale: number;
          angle: number;
        }>;
      }>;
    }>;
  }): Promise<PrintifyProduct> {
    return this.request(`/shops/${this.getShopId()}/products.json`, {
      method: 'POST',
      body: JSON.stringify(productData),
    });
  }

  async uploadImage(imageUrl: string, fileName: string): Promise<{ id: string; file_name: string; height: number; width: number }> {
    return this.request(`/uploads/images.json`, {
      method: 'POST',
      body: JSON.stringify({
        file_name: fileName,
        url: imageUrl,
      }),
    });
  }

  async createOrder(orderData: CreateOrderRequest): Promise<{ id: string }> {
    return this.request(`/shops/${this.getShopId()}/orders.json`, {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  }

  async submitOrderToProduction(orderId: string): Promise<{ id: string; status: string }> {
    return this.request(`/shops/${this.getShopId()}/orders/${orderId}/send_to_production.json`, {
      method: 'POST',
    });
  }

  async getOrder(orderId: string): Promise<any> {
    return this.request(`/shops/${this.getShopId()}/orders/${orderId}.json`);
  }

  async getOrders(): Promise<{ data: any[] }> {
    return this.request(`/shops/${this.getShopId()}/orders.json`);
  }

  async calculateShipping(orderData: {
    line_items: Array<{ product_id: string; variant_id: number; quantity: number }>;
    address_to: { country: string; region: string; zip: string };
  }): Promise<{ standard: number; express?: number }> {
    return this.request(`/shops/${this.getShopId()}/orders/shipping.json`, {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  }

  async deleteProduct(productId: string): Promise<void> {
    await this.request(`/shops/${this.getShopId()}/products/${productId}.json`, {
      method: 'DELETE',
    });
  }

  /**
   * Request a publishing preview for a product - this triggers mockup rendering.
   * CRITICAL: This is the ONLY way to get Printify to render artwork onto mockups.
   * Draft products never have is_rendered=true; we must use this endpoint.
   * 
   * Flow:
   * 1. POST /shops/{shop_id}/products/{product_id}/publishing/preview.json - starts render task
   * 2. Poll GET /shops/{shop_id}/publishing/requests/{request_id}.json until status === "completed"
   * 3. Extract mockups[].images[] from completed response
   */
  async requestPublishingPreview(productId: string): Promise<{ 
    id?: string;
    status?: string;
    mockups?: Array<{ 
      variant_ids: number[]; 
      images: Array<{ src: string; position?: string; is_default?: boolean }>; 
    }>;
  }> {
    console.log(`[Printify] Requesting publishing preview for product ${productId}...`);
    
    // Step 1: Start the publishing preview task
    const previewRequest = await this.request<{ id: string }>(`/shops/${this.getShopId()}/products/${productId}/publishing/preview.json`, {
      method: 'POST',
      body: JSON.stringify({}),
    });
    
    console.log(`[Printify] Publishing preview request started, ID: ${previewRequest.id}`);
    return { id: previewRequest.id, status: 'pending' };
  }

  /**
   * Poll publishing preview status until completed
   * Returns the mockup URLs when ready
   */
  async getPublishingPreviewStatus(requestId: string): Promise<{
    status: string;
    mockups?: Array<{ 
      variant_ids: number[]; 
      images: Array<{ src: string; position?: string; is_default?: boolean }>; 
    }>;
  }> {
    return this.request(`/shops/${this.getShopId()}/publishing/requests/${requestId}.json`);
  }

  /**
   * Full publishing preview flow - start task, poll until complete, return mockups
   * Timeout after specified milliseconds
   */
  async getRenderedMockups(productId: string, timeoutMs: number = 60000): Promise<Array<{ src: string; position?: string; is_default?: boolean }> | null> {
    try {
      // Start the preview task
      const previewResult = await this.requestPublishingPreview(productId);
      if (!previewResult.id) {
        console.error(`[Printify] No preview request ID returned`);
        return null;
      }

      const requestId = previewResult.id;
      const startTime = Date.now();
      let attempts = 0;

      // Poll until completed or timeout
      while (Date.now() - startTime < timeoutMs) {
        attempts++;
        const delay = Math.min(3000 * Math.pow(1.2, attempts - 1), 10000);
        await new Promise(resolve => setTimeout(resolve, delay));

        const elapsedSec = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`[Printify] Preview poll attempt ${attempts} (${elapsedSec}s)...`);

        try {
          const status = await this.getPublishingPreviewStatus(requestId);
          console.log(`[Printify] Preview status: ${status.status}`);

          if (status.status === 'completed' && status.mockups && status.mockups.length > 0) {
            // Extract all images from mockups
            const allImages: Array<{ src: string; position?: string; is_default?: boolean }> = [];
            for (const mockup of status.mockups) {
              if (mockup.images) {
                allImages.push(...mockup.images);
              }
            }
            console.log(`[Printify] Got ${allImages.length} rendered mockup images!`);
            return allImages;
          } else if (status.status === 'failed') {
            console.error(`[Printify] Preview rendering failed`);
            return null;
          }
        } catch (pollErr: any) {
          console.log(`[Printify] Preview poll error: ${pollErr.message}`);
        }
      }

      console.warn(`[Printify] Preview rendering timed out after ${timeoutMs/1000}s`);
      return null;
    } catch (err: any) {
      console.error(`[Printify] Publishing preview error: ${err.message}`);
      return null;
    }
  }

  /**
   * Create a placeholder product WITH ONE PRINT to get the true minimum cost.
   * REQUIRES an image ID - will NOT fall back to blank garment cost.
   * 
   * @param blueprintId - The blueprint ID
   * @param printProviderId - The print provider ID  
   * @param variantIds - Array of variant IDs to enable
   * @param imageId - Printify image ID (REQUIRED)
   * @param placement - The print position to use (from getFirstAvailablePlacement)
   */
  async createPlaceholderProduct(
    blueprintId: number,
    printProviderId: number,
    variantIds: number[],
    imageId: string,
    placement: string
  ): Promise<PrintifyProduct> {
    if (!imageId) {
      throw new Error('Image ID is required to get real production costs');
    }
    
    const print_areas = [
      {
        variant_ids: variantIds,
        placeholders: [
          {
            position: placement,
            images: [{ id: imageId, x: 0.5, y: 0.5, scale: 1, angle: 0 }]
          }
        ]
      }
    ];
    
    const productData = {
      title: `[COST_SYNC] Blueprint ${blueprintId}`,
      description: 'Temporary product for cost extraction - will be deleted',
      blueprint_id: blueprintId,
      print_provider_id: printProviderId,
      variants: variantIds.map(id => ({
        id,
        price: 100, // Printify requires price > 0 (100 cents = $1.00 placeholder)
        is_enabled: true,
      })),
      print_areas,
    };

    console.log(`[Printify] Creating placeholder product with '${placement}' placement for real cost...`);
    
    const result = await this.request<PrintifyProduct>(
      `/shops/${this.getShopId()}/products.json`,
      { method: 'POST', body: JSON.stringify(productData) }
    );
    
    console.log(`[Printify] Created placeholder product ${result.id} with '${placement}' placement`);
    return result;
  }

  // Static placeholder image ID - cached after first upload
  private static placeholderImageId: string | null = null;

  /**
   * Get or create a placeholder image for cost extraction.
   * Uses a simple 100x100 QR placeholder image.
   */
  async getOrCreatePlaceholderImage(): Promise<string> {
    if (PrintifyClient.placeholderImageId) {
      return PrintifyClient.placeholderImageId;
    }

    // Upload a programmatically generated QR code PNG
    const base64Png = await this.createSimplePng();
    
    const result = await this.request<{ id: string; file_name: string; height: number; width: number }>(
      `/uploads/images.json`,
      {
        method: 'POST',
        body: JSON.stringify({
          file_name: 'qr-placeholder.png',
          contents: base64Png,
        }),
      }
    );
    
    PrintifyClient.placeholderImageId = result.id;
    console.log(`[Printify] Uploaded placeholder image: ${result.id}`);
    return result.id;
  }

  /**
   * Create a placeholder QR code image as base64 PNG
   */
  private async createSimplePng(): Promise<string> {
    const QRCode = await import('qrcode');
    // Generate a simple QR code as PNG buffer
    const buffer = await QRCode.toBuffer('PLACEHOLDER', {
      width: 200,
      margin: 1,
      color: { dark: '#000000', light: '#ffffff' }
    });
    return buffer.toString('base64');
  }

  /**
   * Extract production costs from a product's variants.
   * Returns min/max costs in cents.
   */
  extractCostsFromProduct(product: PrintifyProduct): { minCost: number; maxCost: number } {
    const costs: number[] = [];
    
    for (const variant of product.variants || []) {
      if (typeof variant.cost === 'number' && variant.cost > 0) {
        costs.push(variant.cost);
      }
    }

    if (costs.length === 0) {
      return { minCost: 0, maxCost: 0 };
    }

    return {
      minCost: Math.min(...costs),
      maxCost: Math.max(...costs),
    };
  }

  /**
   * Extract unique colors and sizes from a product's variants.
   * Returns arrays of color objects and size strings.
   */
  extractColorsAndSizes(product: PrintifyProduct): { 
    colors: Array<{ name: string; hex?: string }>; 
    sizes: string[] 
  } {
    const colorMap = new Map<string, { name: string; hex?: string }>();
    const sizeSet = new Set<string>();
    
    // Known size patterns to filter out from colors
    const sizePatterns = new Set(['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL', '4XL', '5XL', 'XXL', 'XXXL', 'ONE SIZE', 'OS']);
    
    const isSize = (value: string): boolean => {
      return sizePatterns.has(value.toUpperCase().trim());
    };
    
    for (const variant of product.variants || []) {
      // Extract from variant options array
      if (variant.options) {
        for (const opt of variant.options) {
          const value = opt.value || opt.title || '';
          if (!value) continue;
          
          // Check if explicitly typed
          if (opt.type === 'size' || opt.name?.toLowerCase().includes('size')) {
            sizeSet.add(value);
          } else if (opt.type === 'color' || opt.name?.toLowerCase().includes('color')) {
            // Only add if not a size pattern
            if (!isSize(value) && !colorMap.has(value.toLowerCase())) {
              colorMap.set(value.toLowerCase(), { 
                name: value,
                hex: opt.hex || undefined
              });
            }
          }
        }
      }
      
      // Parse from variant title (e.g., "S / White" or "White / S")
      if (variant.title) {
        const parts = variant.title.split('/').map((p: string) => p.trim());
        for (const part of parts) {
          if (!part) continue;
          if (isSize(part)) {
            sizeSet.add(part);
          } else if (!colorMap.has(part.toLowerCase())) {
            colorMap.set(part.toLowerCase(), { name: part });
          }
        }
      }
    }

    // Final filter: remove any size-like values that snuck into colors
    const colors = Array.from(colorMap.values()).filter(c => !isSize(c.name));

    return {
      colors,
      sizes: Array.from(sizeSet),
    };
  }
}

export const printify = new PrintifyClient();

export { getUSAPrintProviders, syncProductPlacements, syncProductVariants, detectCategory, getProviderColorsWithFallback } from "./printify-helpers";
