import { createCanvas, registerFont, loadImage } from "canvas";
import QRCode from "qrcode";

export interface TextStyle {
  text: string;
  fontFamily: string;
  fontSize: string;
  color?: string;
  letterSpacing?: number;
  warpPreset?: string;
  strokeColor?: string;
  strokeWidth?: number;
  verticalOffset?: number;
  horizontalOffset?: number;
  mode?: "text" | "image";
  imageUrl?: string;
  imageScale?: number;
}

export interface CompositeImageOptions {
  width?: number;
  height?: number;
  backgroundColor?: string;
  qrSize?: number;
  topText?: TextStyle | null;
  bottomText?: TextStyle | null;
  qrUrl: string;
  qrColor?: 'black' | 'white';
  placement?: string;
  graphicLayoutMode?: 'zone' | 'freeform';
}

const PLACEMENT_DIMENSIONS: Record<string, { width: number; height: number }> = {
  "front": { width: 3600, height: 4800 },
  "front_large": { width: 3600, height: 4800 },
  "back": { width: 3600, height: 4200 },
  "front_small": { width: 2400, height: 1800 },
  "pocket": { width: 1200, height: 1200 },
  "left_sleeve": { width: 1200, height: 1500 },
  "right_sleeve": { width: 1200, height: 1500 },
};

const FONT_MAP: Record<string, string> = {
  "Arial": "Arial",
  "Helvetica": "Helvetica", 
  "Times New Roman": "Times New Roman",
  "Georgia": "Georgia",
  "Verdana": "Verdana",
  "Courier New": "Courier New",
  "Impact": "Impact",
  "Comic Sans MS": "Comic Sans MS",
  "Trebuchet MS": "Trebuchet MS",
  "Palatino Linotype": "Palatino Linotype",
};

/**
 * Convert fontSize setting to actual display size (matches frontend PhoneMockup).
 * This ensures print output matches what the user sees in preview.
 * 
 * Frontend getFontSize logic:
 * - '12px' or 'sm' → '10px'
 * - '24px' or 'lg' → '16px'  
 * - default → '12px'
 */
function getPreviewFontSize(fontSize: string): number {
  if (fontSize === '12px' || fontSize === 'sm') return 10;
  if (fontSize === '24px' || fontSize === 'lg') return 16;
  if (fontSize === '32px' || fontSize === 'xl') return 22;
  return 12;
}

// WYSIWYG scaling constants
const PREVIEW_CONTAINER_WIDTH = 160;  // PhoneMockup container width in pixels

export async function generateCompositeImage(options: CompositeImageOptions): Promise<string> {
  const {
    width = 1200,
    height = 1800,
    backgroundColor = "#FFFFFF",
    qrSize = 600,
    topText,
    bottomText,
    qrUrl,
    qrColor = 'black',
    graphicLayoutMode = 'zone',
  } = options;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  if (backgroundColor && backgroundColor !== "transparent") {
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, width, height);
  }

  const textColor = "#000000";
  const scaleFactor = width / PREVIEW_CONTAINER_WIDTH;

  const BLEED_SAFE_PX = 75;
  const safeX = BLEED_SAFE_PX;
  const safeY = BLEED_SAFE_PX;
  const safeW = Math.max(1, width - 2 * BLEED_SAFE_PX);
  const safeH = Math.max(1, height - 2 * BLEED_SAFE_PX);

  let headerZoneTop: number, headerZoneHeight: number;
  let qrZoneTop: number, qrZoneHeight: number;
  let footerZoneTop: number, footerZoneHeight: number;
  let zoneX: number;
  let zoneW: number;

  if (graphicLayoutMode === 'freeform') {
    zoneX = safeX;
    zoneW = safeW;
    headerZoneTop = safeY;
    headerZoneHeight = safeH;
    qrZoneTop = safeY;
    qrZoneHeight = safeH;
    footerZoneTop = safeY;
    footerZoneHeight = safeH;
  } else {
    zoneX = safeX;
    zoneW = safeW;
    headerZoneTop = safeY;
    headerZoneHeight = safeH * 0.30;
    qrZoneTop = headerZoneTop + headerZoneHeight;
    qrZoneHeight = safeH * 0.40;
    footerZoneTop = qrZoneTop + qrZoneHeight;
    footerZoneHeight = safeH * 0.30;
  }

  const drawImageInZone = async (
    imgUrl: string,
    zoneX: number,
    zoneY: number,
    zoneW: number,
    zoneH: number,
    _padding: number = 0,
    offsetX: number = 50,
    offsetY: number = 50,
    scale: number = 100
  ) => {
    try {
      if (!imgUrl.startsWith("data:") && !imgUrl.startsWith("https://firebasestorage.googleapis.com/") && !imgUrl.startsWith("https://storage.googleapis.com/")) {
        console.warn("[composite-image-generator] Rejected non-allowed image URL scheme");
        return;
      }
      const img = await loadImage(imgUrl);
      const imgAspect = img.width / img.height;
      const zoneAspect = zoneW / zoneH;
      let baseW: number, baseH: number;
      if (imgAspect > zoneAspect) {
        baseW = zoneW;
        baseH = zoneW / imgAspect;
      } else {
        baseH = zoneH;
        baseW = zoneH * imgAspect;
      }
      const sf = scale / 100;
      let drawW = baseW * sf;
      let drawH = baseH * sf;
      if (drawW > zoneW || drawH > zoneH) {
        const fitScale = Math.min(zoneW / drawW, zoneH / drawH);
        drawW *= fitScale;
        drawH *= fitScale;
      }
      const clampedX = Math.max(0, Math.min(100, offsetX));
      const clampedY = Math.max(0, Math.min(100, offsetY));
      const drawX = zoneX + (clampedX / 100) * Math.max(0, zoneW - drawW);
      const drawY = zoneY + (clampedY / 100) * Math.max(0, zoneH - drawH);
      ctx.drawImage(img, drawX, drawY, drawW, drawH);
    } catch (e: any) {
      console.warn("[composite-image-generator] Image load failed:", e?.message);
    }
  };

  const topIsImage = topText?.mode === "image" && topText?.imageUrl;
  if (topIsImage) {
    await drawImageInZone(topText!.imageUrl!, zoneX, headerZoneTop, zoneW, headerZoneHeight, 0,
      topText!.horizontalOffset ?? 50, topText!.verticalOffset ?? 50, topText!.imageScale ?? 100);
  } else if (topText && topText.text) {
    const previewFontSize = getPreviewFontSize(topText.fontSize);
    const fontSize = previewFontSize * scaleFactor;
    const fontFamily = FONT_MAP[topText.fontFamily] || "Arial";
    const fillColor = topText.color || textColor;
    
    ctx.font = `bold ${fontSize}px "${fontFamily}"`;
    ctx.fillStyle = fillColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    
    if (topText.strokeColor && topText.strokeWidth && topText.strokeWidth > 0) {
      ctx.strokeStyle = topText.strokeColor;
      ctx.lineWidth = topText.strokeWidth * scaleFactor;
    }
    
    const lines = wrapText(ctx, topText.text, zoneW - 20);
    const totalTextHeight = lines.length * fontSize * 1.3;
    const vOff = topText.verticalOffset ?? 50;
    const hOff = topText.horizontalOffset ?? 50;
    let currentY = headerZoneTop + (vOff / 100) * Math.max(0, headerZoneHeight - totalTextHeight);
    const textX = zoneX + (hOff / 100) * zoneW;

    for (const line of lines) {
      if (topText.strokeColor && topText.strokeWidth && topText.strokeWidth > 0) {
        ctx.strokeText(line, textX, currentY);
      }
      ctx.fillText(line, textX, currentY);
      currentY += fontSize * 1.3;
    }
  }

  const qrDark = qrColor === 'white' ? "#FFFFFF" : "#000000";
  const qrLight = qrColor === 'white' ? "#000000" : "#FFFFFF";
  
  const qrMarginY = qrZoneHeight * 0.10;
  const qrAreaHeight = qrZoneHeight * 0.80;
  const bgPadding = 20;
  const bgRadius = 16;
  const qrContentHeight = qrAreaHeight - bgPadding * 2;
  const qrContentWidth = qrContentHeight;
  const qrDataUrl = await QRCode.toDataURL(qrUrl, {
    width: qrContentWidth,
    margin: 2,
    color: { dark: qrDark, light: qrLight },
  });
  
  const qrImage = await loadImage(qrDataUrl);
  const qrBgWidth = qrContentWidth + bgPadding * 2;
  const qrBgX = zoneX + (zoneW - qrBgWidth) / 2;
  const qrBgY = qrZoneTop + qrMarginY;
  const qrX = zoneX + (zoneW - qrContentWidth) / 2;
  const qrY = qrBgY + bgPadding;
  
  ctx.fillStyle = qrLight;
  ctx.beginPath();
  ctx.roundRect(qrBgX, qrBgY, qrBgWidth, qrAreaHeight, bgRadius);
  ctx.fill();
  
  ctx.drawImage(qrImage, qrX, qrY, qrContentWidth, qrContentHeight);

  const bottomIsImage = bottomText?.mode === "image" && bottomText?.imageUrl;
  if (bottomIsImage) {
    await drawImageInZone(bottomText!.imageUrl!, zoneX, footerZoneTop, zoneW, footerZoneHeight, 0,
      bottomText!.horizontalOffset ?? 50, bottomText!.verticalOffset ?? 50, bottomText!.imageScale ?? 100);
  } else if (bottomText && bottomText.text) {
    const previewFontSize = getPreviewFontSize(bottomText.fontSize);
    const fontSize = previewFontSize * scaleFactor;
    const fontFamily = FONT_MAP[bottomText.fontFamily] || "Arial";
    const fillColor = bottomText.color || textColor;
    
    ctx.font = `bold ${fontSize}px "${fontFamily}"`;
    ctx.fillStyle = fillColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    
    if (bottomText.strokeColor && bottomText.strokeWidth && bottomText.strokeWidth > 0) {
      ctx.strokeStyle = bottomText.strokeColor;
      ctx.lineWidth = bottomText.strokeWidth * scaleFactor;
    }
    
    const lines = wrapText(ctx, bottomText.text, zoneW - 20);
    const totalTextHeight = lines.length * fontSize * 1.3;
    const vOff = bottomText.verticalOffset ?? 50;
    const hOff = bottomText.horizontalOffset ?? 50;
    let currentY = footerZoneTop + (vOff / 100) * Math.max(0, footerZoneHeight - totalTextHeight);
    const textX = zoneX + (hOff / 100) * zoneW;

    for (const line of lines) {
      if (bottomText.strokeColor && bottomText.strokeWidth && bottomText.strokeWidth > 0) {
        ctx.strokeText(line, textX, currentY);
      }
      ctx.fillText(line, textX, currentY);
      currentY += fontSize * 1.3;
    }
  }

  return canvas.toDataURL("image/png");
}

function wrapText(ctx: any, text: string, maxWidth: number): string[] {
  const words = text.split(" ");
  const lines: string[] = [];
  let currentLine = "";

  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const metrics = ctx.measureText(testLine);
    
    if (metrics.width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  
  if (currentLine) {
    lines.push(currentLine);
  }

  return lines;
}

/**
 * Generate print-ready composite that matches the phone preview.
 * 
 * Preview dimensions (PhoneMockup component):
 * - Container: 160px wide
 * - QR code: 36px (smaller to leave room for text)
 * - Font sizes: 10-16px (via getFontSize function)
 * 
 * Printful actual t-shirt print area: 4500x5400px
 * We generate at 1200x1800 (same 2:3 ratio) for efficiency, Printful scales up.
 * 
 * Scale factor: 1200 / 160 = 7.5x
 */
const PREVIEW_WIDTH = 160;  // PhoneMockup container width
const PREVIEW_QR_SIZE = 36; // Smaller QR to leave room for header/footer text

export async function generatePrintifyComposite(
  qrUrl: string,
  topText: TextStyle | null,
  bottomText: TextStyle | null,
  printWidth: number = 1200,
  printHeight: number = 1800,
  qrColor: 'black' | 'white' = 'black',
  placement?: string
): Promise<string> {
  let finalWidth = printWidth;
  let finalHeight = printHeight;
  if (placement && PLACEMENT_DIMENSIONS[placement]) {
    finalWidth = PLACEMENT_DIMENSIONS[placement].width;
    finalHeight = PLACEMENT_DIMENSIONS[placement].height;
  }
  const scaleFactor = finalWidth / PREVIEW_WIDTH; // 7.5x for 1200px
  const qrSize = PREVIEW_QR_SIZE * scaleFactor;

  return generateCompositeImage({
    width: finalWidth,
    height: finalHeight,
    backgroundColor: "transparent",
    qrSize: qrSize,
    topText,
    bottomText,
    qrUrl,
    qrColor,
    placement,
  });
}

// Generate both black and white versions of the composite
export async function generateDualColorComposites(
  qrUrl: string,
  topText: TextStyle | null,
  bottomText: TextStyle | null,
  printWidth: number = 1200,
  printHeight: number = 1800
): Promise<{ blackVersion: string; whiteVersion: string }> {
  const [blackVersion, whiteVersion] = await Promise.all([
    generatePrintifyComposite(qrUrl, topText, bottomText, printWidth, printHeight, 'black'),
    generatePrintifyComposite(qrUrl, topText, bottomText, printWidth, printHeight, 'white'),
  ]);
  
  return { blackVersion, whiteVersion };
}

// Calculate luminance of a hex color to determine if it's "dark" or "light"
// Returns true if the color is dark (needs white QR), false if light (needs black QR)
export function isColorDark(hexColor: string): boolean {
  // Remove # if present
  const hex = hexColor.replace('#', '');
  
  // Parse RGB values
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  
  // Calculate relative luminance using sRGB formula
  // Higher values = lighter color
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  
  // If luminance is below 0.5, color is "dark" and needs white QR
  return luminance < 0.5;
}

// Get the appropriate artwork URL based on shirt color
export function getArtworkForColor(
  hexColor: string, 
  blackArtworkUrl: string, 
  whiteArtworkUrl: string
): string {
  return isColorDark(hexColor) ? whiteArtworkUrl : blackArtworkUrl;
}

export interface OverlayOptions {
  baseImageUrl: string;
  graphicUrl: string;
  position?: 'chest' | 'center' | 'back';
  graphicScale?: number;
  productType?: 'shirt' | 'hat' | 'bag' | 'mug' | 'other';
}

export async function overlayGraphicOnProduct(options: OverlayOptions): Promise<Buffer> {
  const { 
    baseImageUrl, 
    graphicUrl, 
    position = 'chest',
    graphicScale = 0.25,
    productType = 'shirt'
  } = options;

  const baseImage = await loadImage(baseImageUrl);
  const graphicImage = await loadImage(graphicUrl);

  const canvas = createCanvas(baseImage.width, baseImage.height);
  const ctx = canvas.getContext("2d");

  ctx.drawImage(baseImage, 0, 0);

  const graphicWidth = baseImage.width * graphicScale;
  const graphicHeight = (graphicImage.height / graphicImage.width) * graphicWidth;

  let x: number, y: number;

  if (productType === 'shirt') {
    if (position === 'chest') {
      x = (baseImage.width - graphicWidth) / 2;
      y = baseImage.height * 0.28;
    } else if (position === 'center') {
      x = (baseImage.width - graphicWidth) / 2;
      y = (baseImage.height - graphicHeight) / 2;
    } else {
      x = (baseImage.width - graphicWidth) / 2;
      y = baseImage.height * 0.35;
    }
  } else if (productType === 'hat') {
    x = (baseImage.width - graphicWidth) / 2;
    y = baseImage.height * 0.35;
  } else if (productType === 'bag') {
    x = (baseImage.width - graphicWidth) / 2;
    y = (baseImage.height - graphicHeight) / 2;
  } else {
    x = (baseImage.width - graphicWidth) / 2;
    y = (baseImage.height - graphicHeight) / 2;
  }

  ctx.drawImage(graphicImage, x, y, graphicWidth, graphicHeight);

  return canvas.toBuffer("image/png");
}

export async function overlayGraphicOnProductToDataUrl(options: OverlayOptions): Promise<string> {
  const buffer = await overlayGraphicOnProduct(options);
  return `data:image/png;base64,${buffer.toString('base64')}`;
}
