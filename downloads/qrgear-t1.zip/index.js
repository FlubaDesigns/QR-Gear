var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  adminSettings: () => adminSettings,
  backgroundAssets: () => backgroundAssets,
  browsingHistory: () => browsingHistory,
  bundleItems: () => bundleItems,
  canonicalPlacements: () => canonicalPlacements,
  cartItems: () => cartItems,
  channelConfigs: () => channelConfigs,
  channelPublishStates: () => channelPublishStates,
  coupons: () => coupons,
  customDesigns: () => customDesigns,
  customGifts: () => customGifts,
  dynamicContentSets: () => dynamicContentSets,
  dynamicContentSlots: () => dynamicContentSlots,
  dynamicPageAssets: () => dynamicPageAssets,
  dynamicPages: () => dynamicPages,
  emailLogs: () => emailLogs,
  emailTemplates: () => emailTemplates,
  giftBackgrounds: () => giftBackgrounds,
  giftCodes: () => giftCodes,
  giftPackages: () => giftPackages,
  giftRedemptions: () => giftRedemptions,
  graphicSets: () => graphicSets,
  hostedImages: () => hostedImages,
  hostingReminders: () => hostingReminders,
  hostingTiers: () => hostingTiers,
  insertAdminSettingsSchema: () => insertAdminSettingsSchema,
  insertBackgroundAssetSchema: () => insertBackgroundAssetSchema,
  insertBrowsingHistorySchema: () => insertBrowsingHistorySchema,
  insertBundleItemSchema: () => insertBundleItemSchema,
  insertCanonicalPlacementSchema: () => insertCanonicalPlacementSchema,
  insertCartItemSchema: () => insertCartItemSchema,
  insertChannelConfigSchema: () => insertChannelConfigSchema,
  insertChannelPublishStateSchema: () => insertChannelPublishStateSchema,
  insertCouponSchema: () => insertCouponSchema,
  insertCustomDesignSchema: () => insertCustomDesignSchema,
  insertCustomGiftSchema: () => insertCustomGiftSchema,
  insertDynamicContentSetSchema: () => insertDynamicContentSetSchema,
  insertDynamicContentSlotSchema: () => insertDynamicContentSlotSchema,
  insertDynamicPageAssetSchema: () => insertDynamicPageAssetSchema,
  insertDynamicPageSchema: () => insertDynamicPageSchema,
  insertEmailTemplateSchema: () => insertEmailTemplateSchema,
  insertGiftBackgroundSchema: () => insertGiftBackgroundSchema,
  insertGiftCodeSchema: () => insertGiftCodeSchema,
  insertGiftPackageSchema: () => insertGiftPackageSchema,
  insertGiftRedemptionSchema: () => insertGiftRedemptionSchema,
  insertGraphicSetSchema: () => insertGraphicSetSchema,
  insertHostedImageSchema: () => insertHostedImageSchema,
  insertHostingReminderSchema: () => insertHostingReminderSchema,
  insertHostingTierSchema: () => insertHostingTierSchema,
  insertLibraryAssetSchema: () => insertLibraryAssetSchema,
  insertMasterProductSchema: () => insertMasterProductSchema,
  insertMockupCacheSchema: () => insertMockupCacheSchema,
  insertMockupJobSchema: () => insertMockupJobSchema,
  insertOrderItemSchema: () => insertOrderItemSchema,
  insertOrderSchema: () => insertOrderSchema,
  insertOrderUnifiedSchema: () => insertOrderUnifiedSchema,
  insertPartnerStoreProductSchema: () => insertPartnerStoreProductSchema,
  insertPartnerStoreSchema: () => insertPartnerStoreSchema,
  insertPodProviderSchema: () => insertPodProviderSchema,
  insertPricingProfileSchema: () => insertPricingProfileSchema,
  insertPricingRuleSchema: () => insertPricingRuleSchema,
  insertPrintfulProductSchema: () => insertPrintfulProductSchema,
  insertPrintfulVariantSchema: () => insertPrintfulVariantSchema,
  insertPrintifyBlueprintSchema: () => insertPrintifyBlueprintSchema,
  insertPrintifyCatalogSyncSchema: () => insertPrintifyCatalogSyncSchema,
  insertPrintifyCostSyncSchema: () => insertPrintifyCostSyncSchema,
  insertPrintifyPrintProviderSchema: () => insertPrintifyPrintProviderSchema,
  insertPrintifyPrintfulMappingSchema: () => insertPrintifyPrintfulMappingSchema,
  insertProductBundleSchema: () => insertProductBundleSchema,
  insertProductCategoryAssignmentSchema: () => insertProductCategoryAssignmentSchema,
  insertProductCategorySchema: () => insertProductCategorySchema,
  insertProductDesignVersionSchema: () => insertProductDesignVersionSchema,
  insertProductPlacementAvailabilitySchema: () => insertProductPlacementAvailabilitySchema,
  insertProductSchema: () => insertProductSchema,
  insertProductVariantSchema: () => insertProductVariantSchema,
  insertProviderHealthLogSchema: () => insertProviderHealthLogSchema,
  insertProviderPlacementMappingSchema: () => insertProviderPlacementMappingSchema,
  insertProviderQuoteSchema: () => insertProviderQuoteSchema,
  insertQrDesignSchema: () => insertQrDesignSchema,
  insertQrScanEventSchema: () => insertQrScanEventSchema,
  insertQrTemplateSchema: () => insertQrTemplateSchema,
  insertRepricingHistorySchema: () => insertRepricingHistorySchema,
  insertRepricingRuleSchema: () => insertRepricingRuleSchema,
  insertTemplateCategorySchema: () => insertTemplateCategorySchema,
  insertUserSchema: () => insertUserSchema,
  libraryAssets: () => libraryAssets,
  masterProducts: () => masterProducts,
  mockupCache: () => mockupCache,
  mockupJobs: () => mockupJobs,
  orderItems: () => orderItems,
  orders: () => orders,
  ordersUnified: () => ordersUnified,
  partnerStoreProducts: () => partnerStoreProducts,
  partnerStores: () => partnerStores,
  podProviders: () => podProviders,
  pricingProfiles: () => pricingProfiles,
  pricingRules: () => pricingRules,
  printfulProducts: () => printfulProducts,
  printfulVariants: () => printfulVariants,
  printifyBlueprints: () => printifyBlueprints,
  printifyCatalogSync: () => printifyCatalogSync,
  printifyCostSync: () => printifyCostSync,
  printifyPrintProviders: () => printifyPrintProviders,
  printifyPrintfulMapping: () => printifyPrintfulMapping,
  productBundles: () => productBundles,
  productCategories: () => productCategories,
  productCategoryAssignments: () => productCategoryAssignments,
  productDesignVersions: () => productDesignVersions,
  productPlacementAvailability: () => productPlacementAvailability,
  productVariantMedia: () => productVariantMedia,
  productVariants: () => productVariants,
  products: () => products,
  providerHealthLog: () => providerHealthLog,
  providerPlacementMappings: () => providerPlacementMappings,
  providerQuotes: () => providerQuotes,
  qrDesigns: () => qrDesigns,
  qrScanEvents: () => qrScanEvents,
  qrTemplates: () => qrTemplates,
  repricingHistory: () => repricingHistory,
  repricingRules: () => repricingRules,
  sessions: () => sessions,
  templateCategories: () => templateCategories,
  users: () => users
});
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, decimal, timestamp, integer, boolean, index, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var sessions, users, browsingHistory, qrDesigns, products, productCategories, productCategoryAssignments, productVariants, productVariantMedia, qrTemplates, customDesigns, insertCustomDesignSchema, templateCategories, insertTemplateCategorySchema, graphicSets, insertGraphicSetSchema, backgroundAssets, insertBackgroundAssetSchema, partnerStores, partnerStoreProducts, pricingRules, adminSettings, cartItems, orders, orderItems, hostedImages, giftBackgrounds, hostingTiers, emailTemplates, insertEmailTemplateSchema, emailLogs, coupons, customGifts, hostingReminders, dynamicPages, dynamicPageAssets, libraryAssets, insertUserSchema, insertBrowsingHistorySchema, insertQrDesignSchema, insertProductSchema, insertCartItemSchema, insertOrderSchema, insertOrderItemSchema, insertHostedImageSchema, insertPricingRuleSchema, insertAdminSettingsSchema, insertGiftBackgroundSchema, insertHostingTierSchema, insertCouponSchema, insertCustomGiftSchema, insertProductVariantSchema, insertQrTemplateSchema, insertPartnerStoreSchema, insertPartnerStoreProductSchema, insertHostingReminderSchema, insertDynamicPageSchema, insertDynamicPageAssetSchema, insertLibraryAssetSchema, insertProductCategorySchema, insertProductCategoryAssignmentSchema, printifyBlueprints, printifyPrintProviders, printifyCatalogSync, printifyCostSync, insertPrintifyBlueprintSchema, insertPrintifyPrintProviderSchema, insertPrintifyCatalogSyncSchema, insertPrintifyCostSyncSchema, dynamicContentSets, dynamicContentSlots, insertDynamicContentSetSchema, insertDynamicContentSlotSchema, masterProducts, productDesignVersions, channelConfigs, channelPublishStates, providerQuotes, pricingProfiles, ordersUnified, qrScanEvents, providerHealthLog, repricingRules, repricingHistory, productBundles, bundleItems, giftPackages, giftCodes, giftRedemptions, insertMasterProductSchema, insertProductDesignVersionSchema, insertChannelConfigSchema, insertChannelPublishStateSchema, insertProviderQuoteSchema, insertPricingProfileSchema, insertOrderUnifiedSchema, insertQrScanEventSchema, insertProviderHealthLogSchema, insertRepricingRuleSchema, insertRepricingHistorySchema, insertProductBundleSchema, insertBundleItemSchema, insertGiftPackageSchema, insertGiftCodeSchema, insertGiftRedemptionSchema, canonicalPlacements, podProviders, providerPlacementMappings, productPlacementAvailability, insertCanonicalPlacementSchema, insertPodProviderSchema, insertProviderPlacementMappingSchema, insertProductPlacementAvailabilitySchema, mockupCache, insertMockupCacheSchema, printifyPrintfulMapping, insertPrintifyPrintfulMappingSchema, printfulProducts, insertPrintfulProductSchema, printfulVariants, insertPrintfulVariantSchema, mockupJobs, insertMockupJobSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    sessions = pgTable(
      "sessions",
      {
        sid: varchar("sid").primaryKey(),
        sess: jsonb("sess").notNull(),
        expire: timestamp("expire").notNull()
      },
      (table) => [index("IDX_session_expire").on(table.expire)]
    );
    users = pgTable("users", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      email: varchar("email").unique(),
      passwordHash: varchar("password_hash"),
      firstName: varchar("first_name"),
      lastName: varchar("last_name"),
      profileImageUrl: varchar("profile_image_url"),
      // Social media URLs for sharing
      socialFacebook: varchar("social_facebook"),
      socialInstagram: varchar("social_instagram"),
      socialTwitter: varchar("social_twitter"),
      socialLinkedin: varchar("social_linkedin"),
      socialTiktok: varchar("social_tiktok"),
      socialYoutube: varchar("social_youtube"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    browsingHistory = pgTable("browsing_history", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id),
      productId: varchar("product_id").notNull().references(() => products.id),
      viewedAt: timestamp("viewed_at").defaultNow().notNull()
    });
    qrDesigns = pgTable("qr_designs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id),
      name: text("name").notNull(),
      qrType: text("qr_type").notNull(),
      // 'text' or 'image'
      qrContent: text("qr_content").notNull(),
      // text content or image URL
      qrStyle: jsonb("qr_style").notNull(),
      // {color, backgroundColor, logoUrl}
      productId: text("product_id"),
      // Printify product ID
      placement: text("placement").notNull(),
      // 'front-chest', 'front-pocket', etc.
      productColor: text("product_color"),
      manufacturer: text("manufacturer"),
      madeInUSA: boolean("made_in_usa").default(false),
      previewUrl: text("preview_url"),
      showInGallery: boolean("show_in_gallery").default(false),
      galleryTitle: text("gallery_title"),
      galleryDescription: text("gallery_description"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    products = pgTable("products", {
      id: varchar("id").primaryKey(),
      printifyId: text("printify_id").unique(),
      blueprintId: integer("blueprint_id"),
      printProviderId: integer("print_provider_id"),
      name: text("name").notNull(),
      description: text("description"),
      category: text("category").notNull(),
      productLine: text("product_line").default("all"),
      // 'text', 'template', 'custom', 'all'
      basePrice: decimal("base_price", { precision: 10, scale: 2 }).notNull(),
      imageUrl: text("image_url"),
      manufacturer: text("manufacturer"),
      madeInUSA: boolean("made_in_usa").default(false),
      defaultPlacement: text("default_placement").default("front-chest"),
      availablePlacements: text("available_placements").array(),
      availableColors: jsonb("available_colors"),
      availableSizes: text("available_sizes").array(),
      defaultColor: text("default_color"),
      metadata: jsonb("metadata"),
      isEnabled: boolean("is_enabled").default(false),
      markupPercent: decimal("markup_percent", { precision: 5, scale: 2 }).default("0"),
      markupFixed: decimal("markup_fixed", { precision: 10, scale: 2 }).default("0"),
      qrProductionCost: decimal("qr_production_cost", { precision: 10, scale: 2 }).default("0"),
      customerPrice: decimal("customer_price", { precision: 10, scale: 2 }),
      isFeatured: boolean("is_featured").default(false),
      sortOrder: integer("sort_order").default(0),
      mockupsByColor: jsonb("mockups_by_color"),
      // { 'White': { front: 'url' }, 'Black': {...} }
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    productCategories = pgTable("product_categories_lookup", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      slug: text("slug").notNull().unique(),
      description: text("description"),
      taxonomyType: text("taxonomy_type").notNull(),
      // 'season', 'holiday', 'occasion', 'other'
      icon: text("icon"),
      // lucide icon name
      parentId: varchar("parent_id"),
      sortOrder: integer("sort_order").default(0),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    productCategoryAssignments = pgTable("product_category_assignments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      productId: varchar("product_id").notNull().references(() => products.id),
      categoryId: varchar("category_id").notNull().references(() => productCategories.id),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    productVariants = pgTable("product_variants", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      productId: varchar("product_id").notNull().references(() => products.id),
      printifyVariantId: integer("printify_variant_id").notNull(),
      title: text("title").notNull(),
      // e.g., "S / White"
      size: text("size"),
      color: text("color"),
      colorHex: text("color_hex"),
      price: decimal("price", { precision: 10, scale: 2 }).notNull(),
      isEnabled: boolean("is_enabled").default(true),
      isInStock: boolean("is_in_stock").default(true)
    }, (table) => ({
      productVariantUnique: unique().on(table.productId, table.printifyVariantId)
    }));
    productVariantMedia = pgTable("product_variant_media", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      productId: varchar("product_id").notNull().references(() => products.id),
      color: text("color").notNull(),
      // Color name (e.g., "White", "Black")
      colorHex: text("color_hex"),
      // Color hex code
      mockupUrl: text("mockup_url").notNull(),
      // Base mockup image from Printify
      overlayUrl: text("overlay_url"),
      // Mockup with QR overlay (generated on-demand)
      isPrimary: boolean("is_primary").default(false),
      // If true, use this as main product image
      mediaStatus: text("media_status").default("pending"),
      // 'pending', 'success', 'failed', 'rate_limited'
      printifyMockupId: text("printify_mockup_id"),
      // Track Printify's mockup ID for deduplication
      lastCheckedAt: timestamp("last_checked_at"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    }, (table) => ({
      productColorUnique: unique().on(table.productId, table.color)
    }));
    qrTemplates = pgTable("qr_templates", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description"),
      category: text("category"),
      // 'religious', 'business', 'sports', etc.
      thumbnailUrl: text("thumbnail_url").notNull(),
      fullImageUrl: text("full_image_url").notNull(),
      storageUrl: text("storage_url").notNull(),
      qrPlacement: jsonb("qr_placement"),
      // {x, y, width, height} as percentages
      availableSizes: text("available_sizes").array(),
      // ['small', 'medium', 'large']
      defaultTextAbove: text("default_text_above"),
      defaultTextBelow: text("default_text_below"),
      textStyle: jsonb("text_style"),
      // {font, color, size}
      priceUpcharge: decimal("price_upcharge", { precision: 10, scale: 2 }).default("0"),
      isActive: boolean("is_active").default(true),
      isFeatured: boolean("is_featured").default(false),
      sortOrder: integer("sort_order").default(0),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    customDesigns = pgTable("custom_designs", {
      id: varchar("id").primaryKey(),
      // Slugified project name, no auto-generate
      projectName: text("project_name").notNull(),
      // User-defined display name (e.g., "Hello World QR")
      productId: integer("product_id").notNull(),
      productName: text("product_name").notNull(),
      productImage: text("product_image"),
      placements: text("placements").array().notNull(),
      placementConfigs: jsonb("placement_configs"),
      // {placementId: 'full' | 'qr-only'}
      placementImages: jsonb("placement_images"),
      // {placementId: 'imageUrl'}
      backgroundImageUrl: text("background_image_url"),
      backgroundAssetId: varchar("background_asset_id").references(() => libraryAssets.id),
      // link to library asset
      topText: jsonb("top_text"),
      // {text, fontFamily, fontSize} - for PHYSICAL PRINT
      bottomText: jsonb("bottom_text"),
      // {text, fontFamily, fontSize} - for PHYSICAL PRINT
      textUpcharge: decimal("text_upcharge", { precision: 10, scale: 2 }).default("2.00"),
      // Landing page overlay - displayed when QR is scanned (not printed)
      // Format: { enabled, title, description, position: 'top'|'bottom', fontFamily, color }
      landingOverlay: jsonb("landing_overlay"),
      // QR Type variants: determines what the QR code contains and how landing page behaves
      // 'plain-text' = QR contains actual text (offline readable, up to ~2000 chars)
      // 'url' = QR links to hosted landing page with static content (image/text)
      // 'dynamics' = QR links to landing page showing cycling content based on schedule
      // 'external-url' = QR links directly to any external URL (no landing page, keeps header/footer)
      templateVariant: text("template_variant").default("url"),
      // 'plain-text', 'url', 'dynamics', 'external-url'
      // For external-url variant: the custom URL the QR code points to
      externalUrl: text("external_url"),
      // For dynamics variant: links to content set for cycling content
      dynamicContentSetId: varchar("dynamic_content_set_id"),
      storeType: text("store_type"),
      // 'Internal' or 'External'
      storeName: text("store_name"),
      segment: text("segment"),
      isFeatured: boolean("is_featured").default(false),
      isSeasonalPromo: boolean("is_seasonal_promo").default(false),
      qrCodeUrl: text("qr_code_url"),
      printifyCompositeUrl: text("printify_composite_url"),
      savedToLibrary: boolean("saved_to_library").default(false),
      savedToStore: boolean("saved_to_store").default(false),
      // Template organization - for library templates
      templateName: text("template_name"),
      // Custom display name (e.g., "Beach Scene 01")
      templateCategory: text("template_category"),
      // Main category (e.g., "Seasonal", "Events", "Evergreen")
      templateSubcategory: text("template_subcategory"),
      // Subcategory (e.g., "Summer", "Valentine's Day")
      // For user/partner templates - their private sandbox
      ownerUserId: varchar("owner_user_id").references(() => users.id),
      campaignName: text("campaign_name"),
      // User's campaign/project folder (e.g., "12 Days of Deals")
      // Printify integration for realistic mockups
      blueprintId: integer("blueprint_id"),
      // Printify blueprint ID (e.g., 5 for t-shirt)
      printProviderId: integer("print_provider_id"),
      // Printify print provider ID
      printifyProductId: text("printify_product_id"),
      // Created Printify product ID for orders
      printReadyArtUrl: text("print_ready_art_url"),
      // URL to uploaded print-ready artwork (QR + text)
      selectedColors: text("selected_colors").array(),
      // Colors admin chose for mockups ['White', 'Black', 'Navy']
      defaultColor: text("default_color"),
      // Color to display first (e.g., 'Navy')
      mockupsByColor: jsonb("mockups_by_color"),
      // { 'White': { front: 'url', angles: ['url1','url2'] }, 'Black': {...} }
      // Multi-graphic configuration (up to 2 graphics with different placements/sizes)
      // Format: [{ id: 'graphic-1', imageUrl: '/api/files/...', placement: 'front-chest', qrSize: 'medium' }, ...]
      // qrSize: 'small' (25%), 'medium' (45%), 'large' (65%) of print area
      graphicsConfig: jsonb("graphics_config"),
      selectedVariantIds: jsonb("selected_variant_ids"),
      // { 'White-M': 12345, 'Black-L': 12346 } for order fulfillment
      publishStatus: text("publish_status").default("draft"),
      // 'draft', 'pending', 'processing', 'complete', 'failed'
      publishError: text("publish_error"),
      // Error message if publish failed
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    insertCustomDesignSchema = createInsertSchema(customDesigns).omit({ createdAt: true, updatedAt: true });
    templateCategories = pgTable("template_categories", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      // "Seasonal", "Summer", "Valentine's Day"
      parentId: varchar("parent_id"),
      // null = top-level category, otherwise = subcategory
      sortOrder: integer("sort_order").default(0),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    insertTemplateCategorySchema = createInsertSchema(templateCategories).omit({ id: true, createdAt: true });
    graphicSets = pgTable("graphic_sets", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      // project name
      description: text("description"),
      // Category organization (reuses templateCategories)
      categoryId: varchar("category_id").references(() => templateCategories.id),
      subcategoryId: varchar("subcategory_id").references(() => templateCategories.id),
      // Image 1: Full graphic (header + QR + footer) - saved large
      fullGraphicUrl: text("full_graphic_url"),
      // Image 2: QR code only - saved large (same QR as in full graphic)
      qrOnlyUrl: text("qr_only_url"),
      // The destination URL the QR points to
      destinationUrl: text("destination_url"),
      // Storage path for the project folder (e.g., "library/my-project")
      storagePath: text("storage_path"),
      // Metadata
      tags: text("tags").array(),
      isActive: boolean("is_active").default(true),
      isFeatured: boolean("is_featured").default(false),
      usageCount: integer("usage_count").default(0),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    insertGraphicSetSchema = createInsertSchema(graphicSets).omit({ id: true, usageCount: true, createdAt: true, updatedAt: true });
    backgroundAssets = pgTable("background_assets", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      assetType: text("asset_type").notNull(),
      // 'source' or 'cropped'
      imageUrl: text("image_url").notNull(),
      storagePath: text("storage_path").notNull(),
      // Firebase Storage path
      sourceAssetId: varchar("source_asset_id"),
      // For cropped: references the source asset
      width: integer("width"),
      height: integer("height"),
      fileSize: integer("file_size"),
      // bytes
      mimeType: text("mime_type"),
      cropData: jsonb("crop_data"),
      // For cropped: { x, y, width, height, aspect }
      tags: text("tags").array(),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    insertBackgroundAssetSchema = createInsertSchema(backgroundAssets).omit({ id: true, createdAt: true, updatedAt: true });
    partnerStores = pgTable("partner_stores", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      slug: text("slug").notNull().unique(),
      // 'kingdom-connects'
      name: text("name").notNull(),
      description: text("description"),
      logoUrl: text("logo_url"),
      websiteUrl: text("website_url"),
      businessPageUrlPattern: text("business_page_url_pattern"),
      // e.g. "https://kingdomconnects.org/business/{slug}.htm"
      apiKey: text("api_key").notNull(),
      // for JWT token generation
      allowedOrigins: text("allowed_origins").array(),
      // CORS origins
      primaryColor: text("primary_color"),
      accentColor: text("accent_color"),
      commissionPercent: decimal("commission_percent", { precision: 5, scale: 2 }).default("0"),
      // Store segments this partner can access
      availableSegments: text("available_segments").array(),
      // ['Religious', 'Business', etc.]
      // Whether this is an internal store (our site) vs external (partner sites)
      isInternal: boolean("is_internal").default(false),
      // Annual member perks - JSON config for free items
      // Format: { enabled: boolean, products: ['T-Shirt', 'Hat'], maxItems: 2 }
      annualMemberPerk: jsonb("annual_member_perk"),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    partnerStoreProducts = pgTable("partner_store_products", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      partnerStoreId: varchar("partner_store_id").notNull().references(() => partnerStores.id),
      productId: varchar("product_id").notNull().references(() => products.id),
      customPrice: decimal("custom_price", { precision: 10, scale: 2 }),
      customName: text("custom_name"),
      kcPlacements: text("kc_placements").array(),
      // ['homepage', 'dashboard', 'static_page'] - can be multiple
      kcBusinessSlug: text("kc_business_slug"),
      // Optional: Links to specific KC business page (usable with any placement)
      enabledSizes: text("enabled_sizes").array(),
      // Which sizes are enabled for this store's product
      enabledColors: text("enabled_colors").array(),
      // Which colors are enabled for this store's product
      defaultColor: text("default_color"),
      // Which color to display by default
      mockupsByColor: jsonb("mockups_by_color"),
      // { "Black": { front: "url", back: "url" }, ... }
      sortOrder: integer("sort_order").default(0),
      isEnabled: boolean("is_enabled").default(true)
    });
    pricingRules = pgTable("pricing_rules", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      scope: text("scope").notNull(),
      scopeValue: text("scope_value"),
      markupType: text("markup_type").notNull(),
      markupValue: decimal("markup_value", { precision: 10, scale: 2 }).notNull(),
      qrProductionCost: decimal("qr_production_cost", { precision: 10, scale: 2 }).default("0"),
      priority: integer("priority").default(0),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    adminSettings = pgTable("admin_settings", {
      id: varchar("id").primaryKey().default("default"),
      globalMarkupPercent: decimal("global_markup_percent", { precision: 5, scale: 2 }).default("25"),
      globalMarkupFixed: decimal("global_markup_fixed", { precision: 10, scale: 2 }).default("0"),
      globalQrProductionCost: decimal("global_qr_production_cost", { precision: 10, scale: 2 }).default("2"),
      additionalPlacementCost: decimal("additional_placement_cost", { precision: 10, scale: 2 }).default("4"),
      textAboveUpcharge: decimal("text_above_upcharge", { precision: 10, scale: 2 }).default("2"),
      textBelowUpcharge: decimal("text_below_upcharge", { precision: 10, scale: 2 }).default("2"),
      imageHostingUpcharge: decimal("image_hosting_upcharge", { precision: 10, scale: 2 }).default("5"),
      dynamicQrUpcharge: decimal("dynamic_qr_upcharge", { precision: 10, scale: 2 }).default("25"),
      showPricesBeforeCustomization: boolean("show_prices_before_customization").default(false),
      defaultFulfillmentProvider: text("default_fulfillment_provider").default("printify"),
      // 'printify' or 'printful'
      defaultMockupProvider: text("default_mockup_provider").default("printful"),
      // 'printify' or 'printful'
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    cartItems = pgTable("cart_items", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id),
      designId: varchar("design_id").references(() => qrDesigns.id),
      productId: varchar("product_id").notNull().references(() => products.id),
      quantity: integer("quantity").notNull().default(1),
      customization: jsonb("customization").notNull(),
      // full design config
      price: decimal("price", { precision: 10, scale: 2 }).notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    orders = pgTable("orders", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id),
      status: text("status").notNull(),
      // 'pending', 'paid', 'processing', 'shipped', 'delivered'
      totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
      stripePaymentId: text("stripe_payment_id"),
      stripeSessionId: text("stripe_session_id"),
      stripePaymentIntentId: text("stripe_payment_intent_id"),
      printifyOrderId: text("printify_order_id"),
      shippingAddress: jsonb("shipping_address"),
      trackingNumber: text("tracking_number"),
      carrier: text("carrier"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    orderItems = pgTable("order_items", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      orderId: varchar("order_id").notNull().references(() => orders.id),
      productId: varchar("product_id").notNull().references(() => products.id),
      quantity: integer("quantity").notNull(),
      customization: jsonb("customization").notNull(),
      price: decimal("price", { precision: 10, scale: 2 }).notNull(),
      printifyItemId: text("printify_item_id")
    });
    hostedImages = pgTable("hosted_images", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id),
      fileName: text("file_name").notNull(),
      originalName: text("original_name").notNull(),
      mimeType: text("mime_type").notNull(),
      sizeBytes: integer("size_bytes").notNull(),
      storageUrl: text("storage_url").notNull(),
      publicUrl: text("public_url").notNull(),
      title: text("title"),
      description: text("description"),
      businessName: text("business_name"),
      businessLogo: text("business_logo"),
      views: integer("views").default(0),
      isActive: boolean("is_active").default(true),
      expiresAt: timestamp("expires_at"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    giftBackgrounds = pgTable("gift_backgrounds", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description"),
      category: text("category"),
      thumbnailUrl: text("thumbnail_url").notNull(),
      fullImageUrl: text("full_image_url").notNull(),
      storageUrl: text("storage_url").notNull(),
      isActive: boolean("is_active").default(true),
      isFeatured: boolean("is_featured").default(false),
      sortOrder: integer("sort_order").default(0),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    hostingTiers = pgTable("hosting_tiers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      code: text("code").notNull().unique(),
      name: text("name").notNull(),
      description: text("description"),
      durationDays: integer("duration_days").notNull(),
      isIncluded: boolean("is_included").default(false),
      priceUpcharge: decimal("price_upcharge", { precision: 10, scale: 2 }).default("0"),
      videoPriceUpcharge: decimal("video_price_upcharge", { precision: 10, scale: 2 }).default("0"),
      isActive: boolean("is_active").default(true),
      sortOrder: integer("sort_order").default(0)
    });
    emailTemplates = pgTable("email_templates", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      trigger: text("trigger").notNull().unique(),
      // 'order_confirmation', 'order_shipped', etc.
      name: text("name").notNull(),
      // Human-readable name
      subject: text("subject").notNull(),
      // Email subject line
      htmlContent: text("html_content").notNull(),
      // HTML email body
      textContent: text("text_content"),
      // Plain text fallback
      isEnabled: boolean("is_enabled").default(true),
      description: text("description"),
      // Admin description of when this sends
      variables: text("variables").array(),
      // Available merge tags like ['customerName', 'orderNumber']
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    insertEmailTemplateSchema = createInsertSchema(emailTemplates).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    emailLogs = pgTable("email_logs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      templateId: varchar("template_id").references(() => emailTemplates.id),
      trigger: text("trigger").notNull(),
      recipientEmail: text("recipient_email").notNull(),
      subject: text("subject").notNull(),
      status: text("status").notNull(),
      // 'sent', 'failed', 'bounced'
      resendId: text("resend_id"),
      // Resend message ID for tracking
      orderId: varchar("order_id"),
      // Related order if applicable
      userId: varchar("user_id").references(() => users.id),
      errorMessage: text("error_message"),
      sentAt: timestamp("sent_at").defaultNow().notNull()
    });
    coupons = pgTable("coupons", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      code: text("code").notNull().unique(),
      // Customer-facing code like "SUMMER20"
      name: text("name").notNull(),
      // Internal name for admin
      discountType: text("discount_type").notNull(),
      // 'percent' or 'fixed'
      discountValue: decimal("discount_value", { precision: 10, scale: 2 }).notNull(),
      // Percentage (e.g., 20) or dollar amount (e.g., 5.00)
      currency: text("currency").default("usd"),
      // For fixed amount discounts
      minOrderAmount: decimal("min_order_amount", { precision: 10, scale: 2 }),
      // Minimum order value required
      maxRedemptions: integer("max_redemptions"),
      // Total times this coupon can be used (null = unlimited)
      redemptionCount: integer("redemption_count").default(0),
      // How many times it's been used
      validFrom: timestamp("valid_from"),
      // Start date (null = immediately valid)
      validUntil: timestamp("valid_until"),
      // End date (null = no expiration)
      stripeCouponId: text("stripe_coupon_id"),
      // Stripe coupon ID
      stripePromotionCodeId: text("stripe_promotion_code_id"),
      // Stripe promotion code ID
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    customGifts = pgTable("custom_gifts", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id),
      slug: text("slug").notNull().unique(),
      backgroundSource: text("background_source").notNull(),
      backgroundId: varchar("background_id").references(() => giftBackgrounds.id),
      uploadedImageId: varchar("uploaded_image_id").references(() => hostedImages.id),
      compositeImageUrl: text("composite_image_url"),
      overlayConfig: jsonb("overlay_config"),
      textAboveQr: text("text_above_qr"),
      textBelowQr: text("text_below_qr"),
      qrTextContent: text("qr_text_content"),
      hostingTierId: varchar("hosting_tier_id").references(() => hostingTiers.id),
      disclaimerAccepted: boolean("disclaimer_accepted").default(false),
      disclaimerAcceptedAt: timestamp("disclaimer_accepted_at"),
      pricingSnapshot: jsonb("pricing_snapshot"),
      views: integer("views").default(0),
      status: text("status").default("active"),
      expiresAt: timestamp("expires_at"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    hostingReminders = pgTable("hosting_reminders", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      customGiftId: varchar("custom_gift_id").notNull().references(() => customGifts.id),
      userId: varchar("user_id").references(() => users.id),
      reminderType: text("reminder_type").notNull(),
      // '30_days', '7_days', 'expired'
      scheduledFor: timestamp("scheduled_for").notNull(),
      sentAt: timestamp("sent_at"),
      emailAddress: text("email_address"),
      status: text("status").default("pending"),
      // 'pending', 'sent', 'failed'
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    dynamicPages = pgTable("dynamic_pages", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id),
      slug: text("slug").notNull().unique(),
      // UUID-based for non-enumerable URLs
      title: text("title").notNull(),
      description: text("description"),
      activeAssetId: varchar("active_asset_id"),
      // references dynamicPageAssets.id (added after table creation)
      hostingTierId: varchar("hosting_tier_id").references(() => hostingTiers.id),
      views: integer("views").default(0),
      status: text("status").default("active"),
      // 'active', 'paused', 'expired'
      expiresAt: timestamp("expires_at"),
      renewalReminderSent: boolean("renewal_reminder_sent").default(false),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    dynamicPageAssets = pgTable("dynamic_page_assets", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      pageId: varchar("page_id").notNull().references(() => dynamicPages.id),
      hostedImageId: varchar("hosted_image_id").notNull().references(() => hostedImages.id),
      title: text("title"),
      isActive: boolean("is_active").default(false),
      // only one asset active at a time per page
      activatedAt: timestamp("activated_at"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    libraryAssets = pgTable("library_assets", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").references(() => users.id),
      // null = admin asset
      ownerType: text("owner_type").notNull(),
      // 'admin' or 'user'
      assetType: text("asset_type").notNull(),
      // 'background' or 'design'
      mediaType: text("media_type").notNull(),
      // 'image' or 'video'
      name: text("name").notNull(),
      description: text("description"),
      fileName: text("file_name").notNull(),
      originalName: text("original_name").notNull(),
      mimeType: text("mime_type").notNull(),
      sizeBytes: integer("size_bytes").notNull(),
      storageUrl: text("storage_url").notNull(),
      // path in object storage
      publicUrl: text("public_url").notNull(),
      // serving URL
      thumbnailUrl: text("thumbnail_url"),
      // for videos, generated thumbnail
      duration: integer("duration"),
      // for videos, duration in seconds
      // Hierarchical category organization (shares templateCategories table)
      libraryCategoryId: varchar("library_category_id").references(() => templateCategories.id),
      // top-level category
      librarySubcategoryId: varchar("library_subcategory_id").references(() => templateCategories.id),
      // subcategory
      // Legacy fields kept for migration - prefer category hierarchy
      category: text("category"),
      // 'general', 'seasonal', 'events', etc.
      season: text("season"),
      // 'christmas', 'easter', 'summer', etc.
      event: text("event"),
      // 'birthday', 'wedding', 'graduation', etc.
      tags: text("tags").array(),
      // additional searchable tags
      visibleStoreSlugs: text("visible_store_slugs").array(),
      // which stores can see this asset (null = all)
      visibleSegments: jsonb("visible_segments"),
      // segments per store, e.g., {"kingdom-connects": ["Religious", "Business"]}
      isActive: boolean("is_active").default(true),
      isFeatured: boolean("is_featured").default(false),
      sortOrder: integer("sort_order").default(0),
      usageCount: integer("usage_count").default(0),
      // track how often this is used
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    insertUserSchema = createInsertSchema(users).omit({
      createdAt: true,
      updatedAt: true
    });
    insertBrowsingHistorySchema = createInsertSchema(browsingHistory).omit({
      id: true,
      viewedAt: true
    });
    insertQrDesignSchema = createInsertSchema(qrDesigns).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertProductSchema = createInsertSchema(products).omit({
      createdAt: true,
      updatedAt: true
    });
    insertCartItemSchema = createInsertSchema(cartItems).omit({
      id: true,
      createdAt: true
    });
    insertOrderSchema = createInsertSchema(orders).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertOrderItemSchema = createInsertSchema(orderItems).omit({
      id: true
    });
    insertHostedImageSchema = createInsertSchema(hostedImages).omit({
      id: true,
      views: true,
      createdAt: true
    });
    insertPricingRuleSchema = createInsertSchema(pricingRules).omit({
      id: true,
      createdAt: true
    });
    insertAdminSettingsSchema = createInsertSchema(adminSettings).omit({
      updatedAt: true
    });
    insertGiftBackgroundSchema = createInsertSchema(giftBackgrounds).omit({
      id: true,
      createdAt: true
    });
    insertHostingTierSchema = createInsertSchema(hostingTiers).omit({
      id: true
    });
    insertCouponSchema = createInsertSchema(coupons).omit({
      id: true,
      redemptionCount: true,
      createdAt: true,
      updatedAt: true
    });
    insertCustomGiftSchema = createInsertSchema(customGifts).omit({
      id: true,
      views: true,
      createdAt: true,
      updatedAt: true
    });
    insertProductVariantSchema = createInsertSchema(productVariants).omit({
      id: true
    });
    insertQrTemplateSchema = createInsertSchema(qrTemplates).omit({
      id: true,
      createdAt: true
    });
    insertPartnerStoreSchema = createInsertSchema(partnerStores).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertPartnerStoreProductSchema = createInsertSchema(partnerStoreProducts).omit({
      id: true
    });
    insertHostingReminderSchema = createInsertSchema(hostingReminders).omit({
      id: true,
      createdAt: true
    });
    insertDynamicPageSchema = createInsertSchema(dynamicPages).omit({
      id: true,
      views: true,
      createdAt: true,
      updatedAt: true
    });
    insertDynamicPageAssetSchema = createInsertSchema(dynamicPageAssets).omit({
      id: true,
      createdAt: true
    });
    insertLibraryAssetSchema = createInsertSchema(libraryAssets).omit({
      id: true,
      usageCount: true,
      createdAt: true,
      updatedAt: true
    });
    insertProductCategorySchema = createInsertSchema(productCategories).omit({
      id: true,
      createdAt: true
    });
    insertProductCategoryAssignmentSchema = createInsertSchema(productCategoryAssignments).omit({
      id: true,
      createdAt: true
    });
    printifyBlueprints = pgTable("printify_blueprints", {
      id: integer("id").primaryKey(),
      // Printify blueprint ID
      title: text("title").notNull(),
      description: text("description"),
      brand: text("brand"),
      model: text("model"),
      images: text("images").array(),
      // Array of image URLs
      primaryImageUrl: text("primary_image_url"),
      category: text("category"),
      // Derived category (t-shirts, hats, mugs, etc.)
      lastSyncedAt: timestamp("last_synced_at").defaultNow().notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    printifyPrintProviders = pgTable("printify_print_providers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      blueprintId: integer("blueprint_id").notNull().references(() => printifyBlueprints.id),
      providerId: integer("provider_id").notNull(),
      title: text("title").notNull(),
      country: text("country"),
      isUSA: boolean("is_usa").default(false),
      minCost: integer("min_cost"),
      // Minimum production cost in cents across variants
      maxCost: integer("max_cost"),
      // Maximum production cost in cents across variants
      availableColors: jsonb("available_colors"),
      // Array of {name: string, hex?: string}
      availableSizes: text("available_sizes").array(),
      // Array of size strings
      placeholderProductId: text("placeholder_product_id"),
      // Printify product ID used to fetch costs
      costsFetchedAt: timestamp("costs_fetched_at"),
      // When costs were last retrieved
      lastSyncedAt: timestamp("last_synced_at").defaultNow().notNull()
    });
    printifyCatalogSync = pgTable("printify_catalog_sync", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      syncType: text("sync_type").notNull(),
      // 'full' or 'incremental'
      status: text("status").notNull(),
      // 'running', 'completed', 'failed'
      blueprintsCount: integer("blueprints_count").default(0),
      providersCount: integer("providers_count").default(0),
      errorMessage: text("error_message"),
      startedAt: timestamp("started_at").defaultNow().notNull(),
      completedAt: timestamp("completed_at")
    });
    printifyCostSync = pgTable("printify_cost_sync", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      status: text("status").notNull(),
      // 'running', 'completed', 'failed', 'paused'
      totalProviders: integer("total_providers").default(0),
      processedCount: integer("processed_count").default(0),
      successCount: integer("success_count").default(0),
      failedCount: integer("failed_count").default(0),
      skippedCount: integer("skipped_count").default(0),
      // Already had costs
      lastProcessedProviderId: text("last_processed_provider_id"),
      // For resume capability
      errorMessage: text("error_message"),
      startedAt: timestamp("started_at").defaultNow().notNull(),
      completedAt: timestamp("completed_at")
    });
    insertPrintifyBlueprintSchema = createInsertSchema(printifyBlueprints);
    insertPrintifyPrintProviderSchema = createInsertSchema(printifyPrintProviders).omit({
      id: true
    });
    insertPrintifyCatalogSyncSchema = createInsertSchema(printifyCatalogSync).omit({
      id: true
    });
    insertPrintifyCostSyncSchema = createInsertSchema(printifyCostSync).omit({
      id: true
    });
    dynamicContentSets = pgTable("dynamic_content_sets", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      // "12 Days of Christmas"
      description: text("description"),
      // Schedule type determines how content cycles
      // 'hourly' = new slot every hour, 'daily' = new slot every day
      // 'weekly' = new slot every week, 'monthly' = new slot every month
      scheduleType: text("schedule_type").notNull().default("daily"),
      // 'hourly', 'daily', 'weekly', 'monthly'
      // Start date/time for the first slot (slot 1 shows at this time)
      startDate: timestamp("start_date").notNull(),
      // Optional end date - after this, shows last slot or loops
      endDate: timestamp("end_date"),
      // Loop behavior: when all slots are exhausted
      // 'stop' = show last slot forever, 'loop' = restart from slot 1
      loopBehavior: text("loop_behavior").default("stop"),
      // 'stop', 'loop'
      // Total number of slots expected (for display purposes)
      totalSlots: integer("total_slots").default(0),
      // Owner info (for future user-created sets)
      userId: varchar("user_id").references(() => users.id),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    dynamicContentSlots = pgTable("dynamic_content_slots", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      contentSetId: varchar("content_set_id").notNull().references(() => dynamicContentSets.id, { onDelete: "cascade" }),
      // Position in the sequence (1-indexed: slot 1, slot 2, etc.)
      slotNumber: integer("slot_number").notNull(),
      // Content for this slot (similar to landing page overlay)
      title: text("title"),
      description: text("description"),
      // Background image for this slot
      imageUrl: text("image_url"),
      // Optional video URL
      videoUrl: text("video_url"),
      // Optional link (button or tap destination)
      linkUrl: text("link_url"),
      linkText: text("link_text"),
      // "Learn More", "Shop Now", etc.
      // Styling options
      textColor: text("text_color").default("#ffffff"),
      overlayPosition: text("overlay_position").default("bottom"),
      // 'top', 'center', 'bottom'
      fontFamily: text("font_family").default("Inter"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    insertDynamicContentSetSchema = createInsertSchema(dynamicContentSets).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertDynamicContentSlotSchema = createInsertSchema(dynamicContentSlots).omit({
      id: true,
      createdAt: true
    });
    masterProducts = pgTable("master_products", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Unified SKU: QRG-{type}-{designId}-{seq}
      sku: text("sku").notNull().unique(),
      title: text("title").notNull(),
      description: text("description"),
      // Product type for routing (apparel, drinkware, accessories, etc.)
      productType: text("product_type").notNull(),
      // Link to the current design version
      currentDesignVersionId: varchar("current_design_version_id"),
      // Link to pricing profile for markup rules
      pricingProfileId: varchar("pricing_profile_id"),
      // Base production cost (from cheapest provider)
      baseCost: decimal("base_cost", { precision: 10, scale: 2 }),
      // Retail price (calculated from pricing profile)
      retailPrice: decimal("retail_price", { precision: 10, scale: 2 }),
      // Product status
      status: text("status").default("draft"),
      // 'draft', 'active', 'paused', 'archived'
      // Channel toggles (which platforms to publish to)
      channels: jsonb("channels"),
      // { printify: true, printful: false, etsy: true, ... }
      // Tags for filtering
      tags: text("tags").array(),
      // Bundle info (for cross-sell)
      bundleParentId: varchar("bundle_parent_id"),
      bundleDiscount: decimal("bundle_discount", { precision: 5, scale: 2 }),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    productDesignVersions = pgTable("product_design_versions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      masterProductId: varchar("master_product_id").notNull().references(() => masterProducts.id, { onDelete: "cascade" }),
      versionNumber: integer("version_number").notNull().default(1),
      // Design inputs (what was used to generate the artwork)
      headerText: text("header_text"),
      headerStyle: jsonb("header_style"),
      // { fontFamily, fontSize, color, warpPreset, letterSpacing, stroke }
      footerText: text("footer_text"),
      footerStyle: jsonb("footer_style"),
      qrUrl: text("qr_url").notNull(),
      // Rendered assets (output files)
      renderedPngUrl: text("rendered_png_url"),
      // 4500x5400 transparent PNG
      renderedSvgUrl: text("rendered_svg_url"),
      // Source SVG
      qrCodeUrl: text("qr_code_url"),
      // QR code image
      // Placement-specific renders
      placementImages: jsonb("placement_images"),
      // { front: url, back: url, sleeve: url }
      // Metadata
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    channelConfigs = pgTable("channel_configs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Channel identifier: printify, printful, apliiq, etsy, ebay, amazon
      channelType: text("channel_type").notNull().unique(),
      displayName: text("display_name").notNull(),
      // Whether this channel is enabled globally
      isEnabled: boolean("is_enabled").default(false),
      // API credentials (stored encrypted via secrets, reference only here)
      apiKeySecretName: text("api_key_secret_name"),
      // e.g., "PRINTIFY_API_KEY"
      apiSecretSecretName: text("api_secret_secret_name"),
      shopId: text("shop_id"),
      // For Printify/Printful shop ID
      // Rate limiting
      rateLimit: integer("rate_limit").default(60),
      // requests per minute
      rateLimitWindow: integer("rate_limit_window").default(60),
      // seconds
      // Webhook config
      webhookSecret: text("webhook_secret"),
      webhookUrl: text("webhook_url"),
      // Health monitoring
      lastHealthCheck: timestamp("last_health_check"),
      // Channel-specific settings
      settings: jsonb("settings"),
      // { defaultShippingProfile, returnPolicy, etc. }
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    channelPublishStates = pgTable("channel_publish_states", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      masterProductId: varchar("master_product_id").notNull().references(() => masterProducts.id, { onDelete: "cascade" }),
      channelType: text("channel_type").notNull(),
      // printify, etsy, etc.
      // External IDs from the platform
      externalProductId: text("external_product_id"),
      externalListingId: text("external_listing_id"),
      externalVariantIds: jsonb("external_variant_ids"),
      // { "S/White": "ext123", ... }
      // Publishing status
      status: text("status").default("unpublished"),
      // 'unpublished', 'pending', 'published', 'failed', 'paused'
      lastPublishedAt: timestamp("last_published_at"),
      lastSyncedAt: timestamp("last_synced_at"),
      lastError: text("last_error"),
      // Version tracking (which design version is published)
      publishedDesignVersionId: varchar("published_design_version_id"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    }, (table) => ({
      productChannelUnique: unique().on(table.masterProductId, table.channelType)
    }));
    providerQuotes = pgTable("provider_quotes", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      masterProductId: varchar("master_product_id").notNull().references(() => masterProducts.id, { onDelete: "cascade" }),
      providerType: text("provider_type").notNull(),
      // printify, printful, apliiq
      // Cost breakdown
      productionCost: decimal("production_cost", { precision: 10, scale: 2 }).notNull(),
      shippingCost: decimal("shipping_cost", { precision: 10, scale: 2 }),
      // Estimated delivery
      estimatedDays: integer("estimated_days"),
      // Availability
      isAvailable: boolean("is_available").default(true),
      // When this quote was fetched
      quotedAt: timestamp("quoted_at").defaultNow().notNull(),
      // Expiry (quotes become stale)
      expiresAt: timestamp("expires_at")
    });
    pricingProfiles = pgTable("pricing_profiles", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description"),
      // Markup strategy
      markupType: text("markup_type").notNull().default("percentage"),
      // 'percentage', 'fixed', 'tiered'
      markupPercent: decimal("markup_percent", { precision: 5, scale: 2 }),
      markupFixed: decimal("markup_fixed", { precision: 10, scale: 2 }),
      // Minimum margin protection
      minMarginPercent: decimal("min_margin_percent", { precision: 5, scale: 2 }).default("40"),
      // Per-channel adjustments
      channelAdjustments: jsonb("channel_adjustments"),
      // { etsy: { addPercent: 5 }, ebay: { addFixed: 2 } }
      // Auto-repricing rules
      autoRepriceEnabled: boolean("auto_reprice_enabled").default(false),
      autoRepriceMinMargin: decimal("auto_reprice_min_margin", { precision: 5, scale: 2 }),
      isDefault: boolean("is_default").default(false),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    ordersUnified = pgTable("orders_unified", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Source channel
      sourceChannel: text("source_channel").notNull(),
      // 'direct', 'etsy', 'ebay', 'amazon'
      externalOrderId: text("external_order_id"),
      // Customer info
      customerEmail: text("customer_email"),
      customerName: text("customer_name"),
      shippingAddress: jsonb("shipping_address"),
      // Order details
      items: jsonb("items").notNull(),
      // [{ masterProductId, variantSku, quantity, price }]
      subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
      shippingTotal: decimal("shipping_total", { precision: 10, scale: 2 }),
      taxTotal: decimal("tax_total", { precision: 10, scale: 2 }),
      total: decimal("total", { precision: 10, scale: 2 }).notNull(),
      // Fulfillment routing
      routedProvider: text("routed_provider"),
      // printify, printful, apliiq
      providerOrderId: text("provider_order_id"),
      // Status timeline
      status: text("status").default("pending"),
      // 'pending', 'routed', 'in_production', 'shipped', 'delivered', 'cancelled'
      statusHistory: jsonb("status_history"),
      // [{ status, timestamp, note }]
      // Tracking
      trackingNumber: text("tracking_number"),
      trackingUrl: text("tracking_url"),
      shippedAt: timestamp("shipped_at"),
      deliveredAt: timestamp("delivered_at"),
      // Profit tracking
      productionCost: decimal("production_cost", { precision: 10, scale: 2 }),
      profit: decimal("profit", { precision: 10, scale: 2 }),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    qrScanEvents = pgTable("qr_scan_events", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // What was scanned
      masterProductId: varchar("master_product_id").references(() => masterProducts.id),
      customDesignId: varchar("custom_design_id"),
      qrUrl: text("qr_url"),
      // Scan metadata
      scanDate: timestamp("scan_date").defaultNow().notNull(),
      // Aggregation (daily rollup)
      scanCount: integer("scan_count").default(1),
      // Location (optional, from IP geolocation)
      country: text("country"),
      region: text("region"),
      // Device info
      deviceType: text("device_type"),
      // 'mobile', 'tablet', 'desktop'
      userAgent: text("user_agent")
    });
    providerHealthLog = pgTable("provider_health_log", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      providerType: text("provider_type").notNull(),
      // printify, printful, apliiq
      // Health check result
      checkTime: timestamp("check_time").defaultNow().notNull(),
      isHealthy: boolean("is_healthy").default(true),
      responseTimeMs: integer("response_time_ms"),
      // Error details
      errorMessage: text("error_message"),
      errorCode: text("error_code"),
      // Aggregated metrics (updated periodically)
      uptimePercent24h: decimal("uptime_percent_24h", { precision: 5, scale: 2 }),
      avgResponseTime24h: integer("avg_response_time_24h")
    });
    repricingRules = pgTable("repricing_rules", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description"),
      isActive: boolean("is_active").default(true),
      priority: integer("priority").default(0),
      // Higher = evaluated first
      // Conditions (JSON structure for flexibility)
      // e.g., { "marginBelow": 20, "channel": "amazon" }
      conditions: jsonb("conditions").default({}).$type(),
      // Action to take
      actionType: text("action_type").notNull(),
      // 'adjust_margin', 'match_target', 'increase_percent', 'decrease_percent'
      // Action parameters
      actionParams: jsonb("action_params").default({}).$type(),
      // Scope - which products/channels this applies to
      appliesTo: text("applies_to").default("all"),
      // 'all', 'category', 'product', 'channel'
      appliesToIds: text("applies_to_ids").array(),
      // Specific IDs if not 'all'
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    repricingHistory = pgTable("repricing_history", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      ruleId: varchar("rule_id").references(() => repricingRules.id),
      masterProductId: varchar("master_product_id").references(() => masterProducts.id),
      channel: text("channel"),
      // Price change details
      previousPrice: decimal("previous_price", { precision: 10, scale: 2 }).notNull(),
      newPrice: decimal("new_price", { precision: 10, scale: 2 }).notNull(),
      reason: text("reason").notNull(),
      // Human-readable explanation
      // Margin details
      previousMargin: decimal("previous_margin", { precision: 5, scale: 2 }),
      newMargin: decimal("new_margin", { precision: 5, scale: 2 }),
      // Metadata
      appliedAt: timestamp("applied_at").defaultNow().notNull(),
      wasAutomatic: boolean("was_automatic").default(true)
    });
    productBundles = pgTable("product_bundles", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description"),
      // Bundle type: 'fixed' (set items), 'pick' (choose N from list)
      bundleType: text("bundle_type").notNull().default("fixed"),
      // Display settings
      displayImage: text("display_image"),
      displayOrder: integer("display_order").default(0),
      // Pricing strategy
      pricingType: text("pricing_type").notNull().default("discount_percent"),
      // For 'discount_percent': percentage off sum of items
      // For 'fixed_price': exact bundle price
      // For 'discount_amount': flat discount off sum
      discountPercent: decimal("discount_percent", { precision: 5, scale: 2 }),
      fixedPrice: decimal("fixed_price", { precision: 10, scale: 2 }),
      discountAmount: decimal("discount_amount", { precision: 10, scale: 2 }),
      // For 'pick' bundles: min/max items customer must select
      minItems: integer("min_items"),
      maxItems: integer("max_items"),
      // Visibility and status
      isActive: boolean("is_active").default(true),
      // Where this bundle is shown: 'cart', 'product_page', 'checkout', 'all'
      displayLocations: text("display_locations").array().default(sql`ARRAY['cart']::text[]`),
      // Optional: only show for specific products (JSON array of product IDs)
      triggerProductIds: text("trigger_product_ids").array(),
      // Scheduling
      startDate: timestamp("start_date"),
      endDate: timestamp("end_date"),
      // Timestamps
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    bundleItems = pgTable("bundle_items", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      bundleId: varchar("bundle_id").notNull().references(() => productBundles.id, { onDelete: "cascade" }),
      // Can reference either a master product or a legacy product
      masterProductId: varchar("master_product_id").references(() => masterProducts.id),
      productId: integer("product_id"),
      // Display order within the bundle
      displayOrder: integer("display_order").default(0),
      // Quantity of this item in the bundle
      quantity: integer("quantity").default(1),
      // For 'pick' bundles: is this item required or optional?
      isRequired: boolean("is_required").default(false),
      // Item-specific discount override (optional)
      itemDiscountPercent: decimal("item_discount_percent", { precision: 5, scale: 2 }),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    giftPackages = pgTable("gift_packages", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      description: text("description"),
      // What type of gift: 'product' (physical item), 'dynamics' (QR Dynamics subscription)
      giftType: text("gift_type").notNull().default("product"),
      // For product gifts: which master product
      masterProductId: varchar("master_product_id").references(() => masterProducts.id),
      // For dynamics gifts: subscription tier level
      dynamicsTier: text("dynamics_tier"),
      dynamicsMonths: integer("dynamics_months"),
      // Pricing
      price: decimal("price", { precision: 10, scale: 2 }).notNull(),
      // Customization options available to recipient
      allowColorChoice: boolean("allow_color_choice").default(true),
      allowSizeChoice: boolean("allow_size_choice").default(true),
      allowQrCustomization: boolean("allow_qr_customization").default(true),
      // Optional personal message from buyer
      includePersonalMessage: boolean("include_personal_message").default(true),
      // Validity period for redemption (days after purchase)
      redemptionValidDays: integer("redemption_valid_days").default(365),
      // Display
      displayImage: text("display_image"),
      isActive: boolean("is_active").default(true),
      sortOrder: integer("sort_order").default(0),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    giftCodes = pgTable("gift_codes", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Unique redeemable code (e.g., "GIFT-A1B2-C3D4-E5F6")
      code: varchar("code", { length: 32 }).notNull().unique(),
      giftPackageId: varchar("gift_package_id").notNull().references(() => giftPackages.id),
      // Buyer info
      buyerUserId: varchar("buyer_user_id").references(() => users.id),
      buyerEmail: text("buyer_email"),
      buyerName: text("buyer_name"),
      // Personal message from buyer to recipient
      personalMessage: text("personal_message"),
      // Purchase tracking
      orderId: varchar("order_id"),
      stripePaymentId: text("stripe_payment_id"),
      purchasedAt: timestamp("purchased_at").defaultNow().notNull(),
      // Expiration
      expiresAt: timestamp("expires_at").notNull(),
      // Status: 'active', 'redeemed', 'expired', 'cancelled'
      status: text("status").notNull().default("active"),
      // When was this code last sent to recipient
      lastEmailedTo: text("last_emailed_to"),
      lastEmailedAt: timestamp("last_emailed_at"),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    giftRedemptions = pgTable("gift_redemptions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      giftCodeId: varchar("gift_code_id").notNull().references(() => giftCodes.id),
      // Recipient info
      recipientUserId: varchar("recipient_user_id").references(() => users.id),
      recipientEmail: text("recipient_email"),
      recipientName: text("recipient_name"),
      // Customizations selected by recipient
      selectedColor: text("selected_color"),
      selectedSize: text("selected_size"),
      qrContent: text("qr_content"),
      qrStyle: jsonb("qr_style"),
      shippingAddress: jsonb("shipping_address"),
      // For dynamics gifts: activated subscription
      dynamicsSubscriptionId: varchar("dynamics_subscription_id"),
      dynamicsContentSetId: varchar("dynamics_content_set_id").references(() => dynamicContentSets.id),
      // Fulfillment tracking
      fulfillmentOrderId: varchar("fulfillment_order_id"),
      fulfillmentProvider: text("fulfillment_provider"),
      fulfillmentStatus: text("fulfillment_status").default("pending"),
      trackingNumber: text("tracking_number"),
      trackingUrl: text("tracking_url"),
      // Timestamps
      redeemedAt: timestamp("redeemed_at").defaultNow().notNull(),
      fulfilledAt: timestamp("fulfilled_at"),
      shippedAt: timestamp("shipped_at"),
      deliveredAt: timestamp("delivered_at")
    });
    insertMasterProductSchema = createInsertSchema(masterProducts).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertProductDesignVersionSchema = createInsertSchema(productDesignVersions).omit({
      id: true,
      createdAt: true
    });
    insertChannelConfigSchema = createInsertSchema(channelConfigs).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertChannelPublishStateSchema = createInsertSchema(channelPublishStates).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertProviderQuoteSchema = createInsertSchema(providerQuotes).omit({
      id: true
    });
    insertPricingProfileSchema = createInsertSchema(pricingProfiles).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertOrderUnifiedSchema = createInsertSchema(ordersUnified).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertQrScanEventSchema = createInsertSchema(qrScanEvents).omit({
      id: true
    });
    insertProviderHealthLogSchema = createInsertSchema(providerHealthLog).omit({
      id: true
    });
    insertRepricingRuleSchema = createInsertSchema(repricingRules).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertRepricingHistorySchema = createInsertSchema(repricingHistory).omit({
      id: true,
      appliedAt: true
    });
    insertProductBundleSchema = createInsertSchema(productBundles).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertBundleItemSchema = createInsertSchema(bundleItems).omit({
      id: true,
      createdAt: true
    });
    insertGiftPackageSchema = createInsertSchema(giftPackages).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertGiftCodeSchema = createInsertSchema(giftCodes).omit({
      id: true,
      createdAt: true
    });
    insertGiftRedemptionSchema = createInsertSchema(giftRedemptions).omit({
      id: true
    });
    canonicalPlacements = pgTable("canonical_placements", {
      id: varchar("id").primaryKey(),
      // e.g., 'FRONT_PRIMARY', 'BACK_FULL', 'LEFT_SLEEVE'
      label: text("label").notNull(),
      // Human-readable: "Front Chest", "Full Back", "Left Sleeve"
      description: text("description"),
      category: text("category").notNull(),
      // 'apparel', 'headwear', 'drinkware', 'bags', 'accessories'
      // Preview positioning (for instant client-side mockups)
      previewX: decimal("preview_x", { precision: 5, scale: 3 }).default("0.5"),
      // 0-1 horizontal position
      previewY: decimal("preview_y", { precision: 5, scale: 3 }).default("0.4"),
      // 0-1 vertical position
      previewScale: decimal("preview_scale", { precision: 5, scale: 3 }).default("0.3"),
      // 0-1 scale factor
      sortOrder: integer("sort_order").default(0),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    podProviders = pgTable("pod_providers", {
      id: varchar("id").primaryKey(),
      // e.g., 'printify', 'printful', 'gooten', 'spod'
      name: text("name").notNull(),
      // "Printify", "Printful", etc.
      logoUrl: text("logo_url"),
      websiteUrl: text("website_url"),
      apiBaseUrl: text("api_base_url"),
      // Provider capabilities
      supportsWhiteLabel: boolean("supports_white_label").default(false),
      supportsRush: boolean("supports_rush").default(false),
      averageShipDays: integer("average_ship_days"),
      // Status
      isActive: boolean("is_active").default(true),
      healthStatus: text("health_status").default("unknown"),
      // 'healthy', 'degraded', 'down', 'unknown'
      lastHealthCheck: timestamp("last_health_check"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    });
    providerPlacementMappings = pgTable("provider_placement_mappings", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      podProviderId: varchar("pod_provider_id").notNull().references(() => podProviders.id),
      canonicalPlacementId: varchar("canonical_placement_id").notNull().references(() => canonicalPlacements.id),
      // Provider's native placement identifier
      providerPlacementKey: text("provider_placement_key").notNull(),
      // e.g., "front", "front-chest", "Front"
      // Optional: provider-specific positioning overrides (if different from canonical)
      overrideX: decimal("override_x", { precision: 5, scale: 3 }),
      overrideY: decimal("override_y", { precision: 5, scale: 3 }),
      overrideScale: decimal("override_scale", { precision: 5, scale: 3 }),
      // Additional provider-specific metadata
      metadata: jsonb("metadata"),
      // { maxDpi: 300, maxWidth: 4000, etc. }
      createdAt: timestamp("created_at").defaultNow().notNull()
    }, (table) => [
      unique("provider_placement_unique").on(table.podProviderId, table.providerPlacementKey)
    ]);
    productPlacementAvailability = pgTable("product_placement_availability", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      productId: varchar("product_id").notNull().references(() => products.id),
      canonicalPlacementId: varchar("canonical_placement_id").notNull().references(() => canonicalPlacements.id),
      // Artwork URLs for this placement (both black and white variants)
      artworkBlackUrl: text("artwork_black_url"),
      artworkWhiteUrl: text("artwork_white_url"),
      // Whether this is the default/primary placement for the product
      isPrimary: boolean("is_primary").default(false),
      isEnabled: boolean("is_enabled").default(true),
      createdAt: timestamp("created_at").defaultNow().notNull()
    }, (table) => [
      unique("product_placement_unique").on(table.productId, table.canonicalPlacementId)
    ]);
    insertCanonicalPlacementSchema = createInsertSchema(canonicalPlacements).omit({ createdAt: true });
    insertPodProviderSchema = createInsertSchema(podProviders).omit({ createdAt: true, updatedAt: true });
    insertProviderPlacementMappingSchema = createInsertSchema(providerPlacementMappings).omit({ id: true, createdAt: true });
    insertProductPlacementAvailabilitySchema = createInsertSchema(productPlacementAvailability).omit({ id: true, createdAt: true });
    mockupCache = pgTable("mockup_cache", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Product identification
      productId: varchar("product_id").references(() => products.id),
      blueprintId: integer("blueprint_id"),
      // Printify blueprint for products not yet in our DB
      printProviderId: integer("print_provider_id"),
      // Printify provider ID
      // Variant details
      colorName: text("color_name").notNull(),
      colorHex: text("color_hex"),
      // Placement
      canonicalPlacementId: varchar("canonical_placement_id").references(() => canonicalPlacements.id),
      // Artwork used (for matching)
      artworkUrl: text("artwork_url"),
      // The artwork that was applied
      artworkVariant: text("artwork_variant").default("black"),
      // 'black' or 'white' QR
      // Cached mockup URLs (what we serve to customers)
      mockupUrl: text("mockup_url").notNull(),
      // The generated mockup image (flat product shot)
      mockupUrlHq: text("mockup_url_hq"),
      // High-quality version if available
      lifestyleMockupUrl: text("lifestyle_mockup_url"),
      // Lifestyle mockup with model (if available)
      // Source info
      podProviderId: varchar("pod_provider_id").references(() => podProviders.id),
      providerMockupId: text("provider_mockup_id"),
      // Provider's internal ID for the mockup
      // Status and timing
      status: text("status").default("active"),
      // 'active', 'stale', 'error'
      generatedAt: timestamp("generated_at").defaultNow().notNull(),
      expiresAt: timestamp("expires_at"),
      // Optional expiry for refresh
      createdAt: timestamp("created_at").defaultNow().notNull()
    }, (table) => [
      unique("mockup_cache_unique").on(
        table.blueprintId,
        table.printProviderId,
        table.colorName,
        table.canonicalPlacementId,
        table.artworkVariant
      )
    ]);
    insertMockupCacheSchema = createInsertSchema(mockupCache).omit({ id: true, createdAt: true });
    printifyPrintfulMapping = pgTable("printify_printful_mapping", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Printify side (what we use for fulfillment)
      printifyBlueprintId: integer("printify_blueprint_id").notNull(),
      printifyPrintProviderId: integer("printify_print_provider_id"),
      printifyBrand: text("printify_brand"),
      printifyModel: text("printify_model"),
      // Printful side (what we use for mockups)
      printfulProductId: integer("printful_product_id").notNull(),
      printfulBrand: text("printful_brand"),
      printfulModel: text("printful_model"),
      // Placement mapping (Printify placement -> Printful placement)
      placementMapping: jsonb("placement_mapping"),
      // { 'front-chest': 'front', 'back': 'back' }
      // Color mapping (in case names differ)
      colorMapping: jsonb("color_mapping"),
      // { 'Solid Black': 'Black', 'Solid White': 'White' }
      // Status
      isActive: boolean("is_active").default(true),
      matchConfidence: text("match_confidence").default("auto"),
      // 'exact', 'auto', 'manual'
      notes: text("notes"),
      createdAt: timestamp("created_at").defaultNow().notNull(),
      updatedAt: timestamp("updated_at").defaultNow().notNull()
    }, (table) => [
      unique("printify_printful_unique").on(table.printifyBlueprintId, table.printifyPrintProviderId)
    ]);
    insertPrintifyPrintfulMappingSchema = createInsertSchema(printifyPrintfulMapping).omit({ id: true, createdAt: true, updatedAt: true });
    printfulProducts = pgTable("printful_products", {
      id: integer("id").primaryKey(),
      // Printful's product ID (e.g., 71 for Bella+Canvas 3001)
      type: text("type").notNull(),
      // e.g., "T-SHIRT", "POSTER", "MUG"
      typeName: text("type_name").notNull(),
      // e.g., "T-Shirt", "Poster", "Mug"
      brand: text("brand"),
      // e.g., "Bella+Canvas", "Gildan"
      model: text("model"),
      // e.g., "3001", "64000"
      title: text("title").notNull(),
      // Full product name
      image: text("image"),
      // Product image URL
      variantCount: integer("variant_count").default(0),
      currency: text("currency").default("USD"),
      // Pricing info
      minPrice: decimal("min_price", { precision: 10, scale: 2 }),
      maxPrice: decimal("max_price", { precision: 10, scale: 2 }),
      // Print area info
      printfileWidth: integer("printfile_width"),
      // Default printfile width
      printfileHeight: integer("printfile_height"),
      // Default printfile height
      printfileDpi: integer("printfile_dpi"),
      // Product details
      description: text("description"),
      avgFulfillmentTime: integer("avg_fulfillment_time"),
      // In days
      originCountry: text("origin_country"),
      isDiscontinued: boolean("is_discontinued").default(false),
      // Available placements (front, back, etc.)
      availablePlacements: text("available_placements").array(),
      // Sync tracking
      lastSyncedAt: timestamp("last_synced_at").defaultNow().notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    });
    insertPrintfulProductSchema = createInsertSchema(printfulProducts).omit({ createdAt: true });
    printfulVariants = pgTable("printful_variants", {
      id: integer("id").primaryKey(),
      // Printful's variant ID
      productId: integer("product_id").notNull().references(() => printfulProducts.id),
      name: text("name").notNull(),
      // e.g., "Black / M"
      size: text("size"),
      // e.g., "S", "M", "L", "XL"
      color: text("color"),
      // e.g., "Black", "White", "Navy"
      colorCode: text("color_code"),
      // Hex color, e.g., "#000000"
      colorCode2: text("color_code2"),
      // Secondary color for heathered/mixed colors
      image: text("image"),
      // Variant-specific image URL
      // Pricing
      price: decimal("price", { precision: 10, scale: 2 }).notNull(),
      // Availability
      inStock: boolean("in_stock").default(true),
      availabilityStatus: text("availability_status"),
      // e.g., "active", "discontinued"
      // Sync tracking
      lastSyncedAt: timestamp("last_synced_at").defaultNow().notNull(),
      createdAt: timestamp("created_at").defaultNow().notNull()
    }, (table) => [
      index("printful_variants_product_idx").on(table.productId),
      index("printful_variants_color_idx").on(table.color)
    ]);
    insertPrintfulVariantSchema = createInsertSchema(printfulVariants).omit({ createdAt: true });
    mockupJobs = pgTable("mockup_jobs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      // Job identification
      productId: varchar("product_id").notNull(),
      colorName: text("color_name").notNull(),
      qrSize: text("qr_size").notNull().default("medium"),
      // 'small', 'medium', 'large'
      placement: text("placement").notNull().default("front-chest"),
      // 'front-chest', 'back', 'left-shoulder', etc.
      // Job data (portable JSON blob)
      jobData: jsonb("job_data").notNull(),
      // { blueprintId, providerId, artworkUrl, etc }
      // Status tracking
      status: text("status").notNull().default("pending"),
      // pending, processing, completed, failed, delayed
      priority: integer("priority").default(10),
      // Lower = higher priority
      attempts: integer("attempts").default(0),
      maxAttempts: integer("max_attempts").default(5),
      // Priority boost tracking (for user-requested prioritization)
      priorityUpdatedAt: timestamp("priority_updated_at"),
      priorityOwner: varchar("priority_owner"),
      // viewerId for tracking who boosted
      priorityExpiresAt: timestamp("priority_expires_at"),
      // TTL for priority boost
      // Results
      resultData: jsonb("result_data"),
      // { mockupUrl, lifestyleUrl } on success
      errorMessage: text("error_message"),
      // Timing
      createdAt: timestamp("created_at").defaultNow().notNull(),
      startedAt: timestamp("started_at"),
      completedAt: timestamp("completed_at"),
      nextRetryAt: timestamp("next_retry_at")
      // For exponential backoff
    }, (table) => [
      index("mockup_jobs_status_idx").on(table.status),
      index("mockup_jobs_product_idx").on(table.productId),
      index("mockup_jobs_next_retry_idx").on(table.nextRetryAt),
      index("mockup_jobs_priority_idx").on(table.priority, table.priorityUpdatedAt),
      index("mockup_jobs_lookup_idx").on(table.productId, table.colorName, table.qrSize, table.placement)
    ]);
    insertMockupJobSchema = createInsertSchema(mockupJobs).omit({ id: true, createdAt: true });
  }
});

// server/lib/firebase-admin.ts
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";
import { getAuth } from "firebase-admin/auth";
function initializeFirebase() {
  if (initialized && db) {
    return db;
  }
  try {
    const projectId = process.env.VITE_FIREBASE_PROJECT_ID || process.env.FIREBASE_PROJECT_ID;
    if (!projectId) {
      throw new Error("Firebase project ID not configured. Set VITE_FIREBASE_PROJECT_ID or FIREBASE_PROJECT_ID environment variable.");
    }
    const serviceAccountKey = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
    const existingApps = getApps();
    if (existingApps.length === 0) {
      if (serviceAccountKey) {
        let serviceAccount;
        try {
          serviceAccount = JSON.parse(serviceAccountKey);
        } catch (parseError) {
          console.error("[Firebase] Failed to parse service account key:", parseError);
          throw new Error("Invalid FIREBASE_SERVICE_ACCOUNT_KEY format - must be valid JSON");
        }
        app = initializeApp({
          credential: cert(serviceAccount),
          projectId
        });
        console.log("[Firebase] Initialized with service account credentials for project:", projectId);
      } else {
        app = initializeApp({
          projectId
        });
        console.log("[Firebase] Initialized with default credentials (limited access)");
      }
    } else {
      app = existingApps[0];
      console.log("[Firebase] Using existing app instance");
    }
    db = getFirestore();
    storageInstance = getStorage();
    initialized = true;
    console.log("[Firebase] Storage bucket:", getStorageBucketName());
    return db;
  } catch (error) {
    console.error("[Firebase] Initialization error:", error);
    throw error;
  }
}
function getFirestoreDb() {
  if (!db) {
    return initializeFirebase();
  }
  return db;
}
function getFirebaseStorage() {
  if (!storageInstance) {
    initializeFirebase();
  }
  return storageInstance;
}
function getStorageBucket() {
  const storage2 = getFirebaseStorage();
  const bucketName = getStorageBucketName();
  return storage2.bucket(bucketName);
}
function getStorageBucketName() {
  return process.env.VITE_FIREBASE_STORAGE_BUCKET || process.env.FIREBASE_STORAGE_BUCKET || `${process.env.VITE_FIREBASE_PROJECT_ID || process.env.FIREBASE_PROJECT_ID}.firebasestorage.app`;
}
function isFirebaseInitialized() {
  return initialized && db !== null;
}
function getFirebaseAuth() {
  if (!initialized) {
    initializeFirebase();
  }
  return getAuth();
}
async function verifyFirebaseToken(idToken) {
  try {
    const auth = getFirebaseAuth();
    const decodedToken = await auth.verifyIdToken(idToken);
    return decodedToken;
  } catch (error) {
    console.error("[Firebase Auth] Token verification failed:", error);
    return null;
  }
}
var db, storageInstance, initialized, app;
var init_firebase_admin = __esm({
  "server/lib/firebase-admin.ts"() {
    "use strict";
    db = null;
    storageInstance = null;
    initialized = false;
    app = null;
  }
});

// server/lib/firestore-adapter.ts
var firestore_adapter_exports = {};
__export(firestore_adapter_exports, {
  FirestoreAdapter: () => FirestoreAdapter
});
function firestoreToDate(timestamp2) {
  if (!timestamp2) return /* @__PURE__ */ new Date();
  if (timestamp2.toDate) return timestamp2.toDate();
  if (timestamp2 instanceof Date) return timestamp2;
  return new Date(timestamp2);
}
function firestoreToDateNullable(timestamp2) {
  if (!timestamp2) return null;
  if (timestamp2.toDate) return timestamp2.toDate();
  if (timestamp2 instanceof Date) return timestamp2;
  return new Date(timestamp2);
}
var FirestoreAdapter;
var init_firestore_adapter = __esm({
  "server/lib/firestore-adapter.ts"() {
    "use strict";
    init_firebase_admin();
    FirestoreAdapter = class {
      db;
      constructor() {
        if (!isFirebaseInitialized()) {
          console.log("[FirestoreAdapter] Initializing Firebase...");
        }
        this.db = getFirestoreDb();
      }
      // ============================================
      // PRODUCT OPERATIONS (Core - Implemented)
      // ============================================
      async getProduct(id) {
        const doc = await this.db.collection("products").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToProduct(doc);
      }
      async getAllProducts() {
        const snapshot = await this.db.collection("products").get();
        return snapshot.docs.map((doc) => this.docToProduct(doc));
      }
      async getProducts() {
        return this.getAllProducts();
      }
      async getEnabledProducts() {
        const snapshot = await this.db.collection("products").where("isEnabled", "==", true).get();
        return snapshot.docs.map((doc) => this.docToProduct(doc));
      }
      async createProduct(product) {
        const productData = product;
        const docRef = this.db.collection("products").doc(productData.id);
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({
          ...productData,
          createdAt: productData.createdAt || now,
          updatedAt: productData.updatedAt || now
        });
        await docRef.set(data, { merge: true });
        const doc = await docRef.get();
        return this.docToProduct(doc);
      }
      async updateProduct(id, product) {
        const docRef = this.db.collection("products").doc(id);
        const data = this.prepareForFirestore({ ...product, id });
        if (!data.updatedAt) {
          data.updatedAt = /* @__PURE__ */ new Date();
        }
        await docRef.set(data, { merge: true });
        const updated = await docRef.get();
        return this.docToProduct(updated);
      }
      async deleteProduct(id) {
        await this.db.collection("products").doc(id).delete();
      }
      async toggleProductEnabled(id, enabled) {
        return this.updateProduct(id, { isEnabled: enabled });
      }
      docToProduct(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDate(data.createdAt),
          updatedAt: firestoreToDate(data.updatedAt)
        };
      }
      // ============================================
      // CUSTOM DESIGN OPERATIONS (Core - Implemented)
      // ============================================
      async getCustomDesign(id) {
        const doc = await this.db.collection("customDesigns").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToCustomDesign(doc);
      }
      async getCustomDesigns() {
        const snapshot = await this.db.collection("customDesigns").get();
        return snapshot.docs.map((doc) => this.docToCustomDesign(doc));
      }
      async getCustomDesignsForLibrary() {
        const snapshot = await this.db.collection("customDesigns").where("savedToLibrary", "==", true).get();
        return snapshot.docs.map((doc) => this.docToCustomDesign(doc));
      }
      async getCustomDesignsByStoreSegment(storeType, storeName, segment) {
        let query = this.db.collection("customDesigns").where("storeType", "==", storeType).where("storeName", "==", storeName);
        if (segment) {
          query = query.where("segment", "==", segment);
        }
        const snapshot = await query.get();
        return snapshot.docs.map((doc) => this.docToCustomDesign(doc));
      }
      async createCustomDesign(design) {
        const designData = design;
        const docRef = this.db.collection("customDesigns").doc(designData.id);
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({
          ...designData,
          createdAt: designData.createdAt || now,
          updatedAt: designData.updatedAt || now
        });
        await docRef.set(data, { merge: true });
        const doc = await docRef.get();
        return this.docToCustomDesign(doc);
      }
      async updateCustomDesign(id, design) {
        const docRef = this.db.collection("customDesigns").doc(id);
        const data = this.prepareForFirestore({ ...design, id });
        if (!data.updatedAt) {
          data.updatedAt = /* @__PURE__ */ new Date();
        }
        await docRef.set(data, { merge: true });
        const updated = await docRef.get();
        return this.docToCustomDesign(updated);
      }
      async deleteCustomDesign(id) {
        await this.db.collection("customDesigns").doc(id).delete();
      }
      docToCustomDesign(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDate(data.createdAt),
          updatedAt: firestoreToDate(data.updatedAt)
        };
      }
      // ============================================
      // ORDER OPERATIONS (Core - Implemented)
      // ============================================
      async getOrder(id) {
        const doc = await this.db.collection("orders").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToOrder(doc);
      }
      async getOrders() {
        const snapshot = await this.db.collection("ordersUnified").get();
        return snapshot.docs.map((doc) => this.docToOrderUnified(doc));
      }
      async getOrdersByUser(userId) {
        const snapshot = await this.db.collection("orders").where("userId", "==", userId).get();
        return snapshot.docs.map((doc) => this.docToOrder(doc));
      }
      async getOrdersByStatus(status) {
        const snapshot = await this.db.collection("orders").where("status", "==", status).get();
        return snapshot.docs.map((doc) => this.docToOrder(doc));
      }
      async getOrderByStripeSession(sessionId) {
        const snapshot = await this.db.collection("orders").where("stripeSessionId", "==", sessionId).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToOrder(snapshot.docs[0]);
      }
      async createOrder(order) {
        const orderData = order;
        const docId = orderData.id?.toString() || void 0;
        const docRef = docId ? this.db.collection("orders").doc(docId) : this.db.collection("orders").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({
          ...orderData,
          id: docRef.id,
          createdAt: orderData.createdAt || now,
          updatedAt: orderData.updatedAt || now
        });
        await docRef.set(data, { merge: true });
        const doc = await docRef.get();
        return this.docToOrder(doc);
      }
      async updateOrder(id, order) {
        const docRef = this.db.collection("orders").doc(id);
        const data = this.prepareForFirestore({ ...order, id });
        if (!data.updatedAt) {
          data.updatedAt = /* @__PURE__ */ new Date();
        }
        await docRef.set(data, { merge: true });
        const updated = await docRef.get();
        return this.docToOrder(updated);
      }
      docToOrder(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDate(data.createdAt),
          updatedAt: firestoreToDate(data.updatedAt)
        };
      }
      // ============================================
      // ORDER UNIFIED OPERATIONS
      // ============================================
      async getOrderUnified(id) {
        const doc = await this.db.collection("ordersUnified").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToOrderUnified(doc);
      }
      async createOrderUnified(order) {
        const orderData = order;
        const docId = orderData.id?.toString() || void 0;
        const docRef = docId ? this.db.collection("ordersUnified").doc(docId) : this.db.collection("ordersUnified").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({
          ...orderData,
          id: docRef.id,
          createdAt: orderData.createdAt || now,
          updatedAt: orderData.updatedAt || now
        });
        await docRef.set(data, { merge: true });
        const doc = await docRef.get();
        return this.docToOrderUnified(doc);
      }
      async updateOrderUnified(id, order) {
        const docRef = this.db.collection("ordersUnified").doc(id);
        const data = this.prepareForFirestore({ ...order, id });
        if (!data.updatedAt) {
          data.updatedAt = /* @__PURE__ */ new Date();
        }
        await docRef.set(data, { merge: true });
        const updated = await docRef.get();
        return this.docToOrderUnified(updated);
      }
      docToOrderUnified(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDate(data.createdAt),
          updatedAt: firestoreToDate(data.updatedAt)
        };
      }
      // ============================================
      // ORDER ITEM OPERATIONS
      // ============================================
      async getOrderItems(orderId) {
        const snapshot = await this.db.collection("orders").doc(orderId).collection("items").get();
        return snapshot.docs.map((doc) => this.docToOrderItem(doc, orderId));
      }
      async createOrderItem(item) {
        const itemData = item;
        const docId = itemData.id?.toString() || void 0;
        const docRef = docId ? this.db.collection("orders").doc(item.orderId).collection("items").doc(docId) : this.db.collection("orders").doc(item.orderId).collection("items").doc();
        const data = this.prepareForFirestore({ ...itemData, id: docId || docRef.id });
        await docRef.set(data, { merge: true });
        const doc = await docRef.get();
        return this.docToOrderItem(doc, item.orderId);
      }
      prepareForFirestore(data) {
        const result = {};
        for (const [key, value] of Object.entries(data)) {
          if (value === void 0) continue;
          if (value instanceof Date) {
            result[key] = value;
          } else if (typeof value === "string" && (key.endsWith("At") || key === "createdAt" || key === "updatedAt")) {
            result[key] = new Date(value);
          } else if (value !== null && typeof value === "object" && !Array.isArray(value) && value.constructor === Object) {
            result[key] = this.prepareForFirestore(value);
          } else {
            result[key] = value;
          }
        }
        return result;
      }
      docToOrderItem(doc, orderId) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          orderId
        };
      }
      // ============================================
      // USER OPERATIONS (Core - Implemented)
      // ============================================
      async getUser(id) {
        const doc = await this.db.collection("users").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToUser(doc);
      }
      async getUserByEmail(email) {
        const snapshot = await this.db.collection("users").where("email", "==", email).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToUser(snapshot.docs[0]);
      }
      async getUsers() {
        const snapshot = await this.db.collection("users").get();
        return snapshot.docs.map((doc) => this.docToUser(doc));
      }
      async createUser(user) {
        const userId = user.id || this.db.collection("users").doc().id;
        const docRef = this.db.collection("users").doc(userId);
        const data = {
          ...user,
          id: userId,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        await docRef.set(data);
        const doc = await docRef.get();
        return this.docToUser(doc);
      }
      async upsertUser(userData) {
        const userId = userData.id || this.db.collection("users").doc().id;
        const docRef = this.db.collection("users").doc(userId);
        const data = {
          ...userData,
          id: userId,
          updatedAt: /* @__PURE__ */ new Date()
        };
        await docRef.set(data, { merge: true });
        const doc = await docRef.get();
        return this.docToUser(doc);
      }
      docToUser(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDateNullable(data.createdAt),
          updatedAt: firestoreToDateNullable(data.updatedAt)
        };
      }
      // ============================================
      // ADMIN SETTINGS
      // ============================================
      async getAdminSettings() {
        const doc = await this.db.collection("settings").doc("admin").get();
        if (!doc.exists) return void 0;
        const data = doc.data();
        return {
          id: "admin",
          ...data
        };
      }
      async upsertAdminSettings(settings) {
        const docRef = this.db.collection("settings").doc("admin");
        await docRef.set(settings, { merge: true });
        const doc = await docRef.get();
        return {
          id: "admin",
          ...doc.data()
        };
      }
      // ============================================
      // BROWSING HISTORY
      // ============================================
      async getBrowsingHistory(userId) {
        const snapshot = await this.db.collection("browsingHistory").where("userId", "==", userId).orderBy("viewedAt", "desc").limit(50).get();
        return snapshot.docs.map((doc) => this.docToBrowsingHistory(doc));
      }
      async addBrowsingHistory(entry) {
        const docRef = this.db.collection("browsingHistory").doc();
        const data = this.prepareForFirestore({
          ...entry,
          id: docRef.id,
          viewedAt: /* @__PURE__ */ new Date()
        });
        await docRef.set(data);
        return this.docToBrowsingHistory(await docRef.get());
      }
      async clearBrowsingHistory(userId) {
        const snapshot = await this.db.collection("browsingHistory").where("userId", "==", userId).get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      }
      docToBrowsingHistory(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, viewedAt: firestoreToDate(data.viewedAt) };
      }
      // ============================================
      // QR DESIGNS
      // ============================================
      async getQrDesign(id) {
        const doc = await this.db.collection("qrDesigns").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToQrDesign(doc);
      }
      async getQrDesignsByUser(userId) {
        const snapshot = await this.db.collection("qrDesigns").where("userId", "==", userId).get();
        return snapshot.docs.map((doc) => this.docToQrDesign(doc));
      }
      async getPublicGalleryDesigns() {
        const snapshot = await this.db.collection("qrDesigns").where("isPublic", "==", true).get();
        return snapshot.docs.map((doc) => this.docToQrDesign(doc));
      }
      async createQrDesign(design) {
        const docRef = this.db.collection("qrDesigns").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...design, id: docRef.id, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToQrDesign(await docRef.get());
      }
      async updateQrDesign(id, design) {
        const docRef = this.db.collection("qrDesigns").doc(id);
        const existing = await docRef.get();
        if (!existing.exists) return void 0;
        const data = this.prepareForFirestore({ ...design, updatedAt: /* @__PURE__ */ new Date() });
        await docRef.update(data);
        return this.docToQrDesign(await docRef.get());
      }
      async deleteQrDesign(id) {
        await this.db.collection("qrDesigns").doc(id).delete();
      }
      docToQrDesign(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // Cart (Implemented for standalone operation)
      async getCartItemsByUser(userId) {
        const snapshot = await this.db.collection("cartItems").where("userId", "==", userId).get();
        return snapshot.docs.map((doc) => this.docToCartItem(doc));
      }
      async addCartItem(item) {
        const docRef = this.db.collection("cartItems").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({
          ...item,
          id: docRef.id,
          createdAt: now
        });
        await docRef.set(data);
        const doc = await docRef.get();
        return this.docToCartItem(doc);
      }
      async updateCartItem(id, quantity) {
        const docRef = this.db.collection("cartItems").doc(id);
        const existing = await docRef.get();
        if (!existing.exists) return void 0;
        await docRef.update({ quantity });
        const updated = await docRef.get();
        return this.docToCartItem(updated);
      }
      async deleteCartItem(id) {
        await this.db.collection("cartItems").doc(id).delete();
      }
      async clearCart(userId) {
        const snapshot = await this.db.collection("cartItems").where("userId", "==", userId).get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      }
      docToCartItem(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDate(data.createdAt)
        };
      }
      // ============================================
      // HOSTED IMAGES
      // ============================================
      async getHostedImage(id) {
        const doc = await this.db.collection("hostedImages").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToHostedImage(doc);
      }
      async getHostedImagesByUser(userId) {
        const snapshot = await this.db.collection("hostedImages").where("userId", "==", userId).get();
        return snapshot.docs.map((doc) => this.docToHostedImage(doc));
      }
      async getAllHostedImages() {
        const snapshot = await this.db.collection("hostedImages").get();
        return snapshot.docs.map((doc) => this.docToHostedImage(doc));
      }
      async createHostedImage(image) {
        const docRef = this.db.collection("hostedImages").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...image, id: docRef.id, createdAt: now, views: 0 });
        await docRef.set(data);
        return this.docToHostedImage(await docRef.get());
      }
      async updateHostedImage(id, image) {
        const docRef = this.db.collection("hostedImages").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(image));
        return this.docToHostedImage(await docRef.get());
      }
      async incrementImageViews(id) {
        const docRef = this.db.collection("hostedImages").doc(id);
        const { FieldValue } = await import("firebase-admin/firestore");
        await docRef.update({ views: FieldValue.increment(1) });
      }
      async deleteHostedImage(id) {
        await this.db.collection("hostedImages").doc(id).delete();
      }
      docToHostedImage(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), expiresAt: firestoreToDateNullable(data.expiresAt) };
      }
      // ============================================
      // HOSTING REMINDERS
      // ============================================
      async getHostingReminderByImageAndDays(imageId, daysRemaining) {
        const snapshot = await this.db.collection("hostingReminders").where("imageId", "==", imageId).where("daysRemaining", "==", daysRemaining).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToHostingReminder(snapshot.docs[0]);
      }
      async createHostingReminder(reminder) {
        const docRef = this.db.collection("hostingReminders").doc();
        const data = this.prepareForFirestore({ ...reminder, id: docRef.id, sentAt: /* @__PURE__ */ new Date() });
        await docRef.set(data);
        return this.docToHostingReminder(await docRef.get());
      }
      docToHostingReminder(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, sentAt: firestoreToDate(data.sentAt) };
      }
      // ============================================
      // PRICING RULES
      // ============================================
      async getPricingRules() {
        const snapshot = await this.db.collection("pricingRules").get();
        return snapshot.docs.map((doc) => this.docToPricingRule(doc));
      }
      async getPricingRule(id) {
        const doc = await this.db.collection("pricingRules").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToPricingRule(doc);
      }
      async createPricingRule(rule) {
        const docRef = this.db.collection("pricingRules").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...rule, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToPricingRule(await docRef.get());
      }
      async updatePricingRule(id, rule) {
        const docRef = this.db.collection("pricingRules").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(rule));
        return this.docToPricingRule(await docRef.get());
      }
      async deletePricingRule(id) {
        await this.db.collection("pricingRules").doc(id).delete();
      }
      docToPricingRule(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // HOSTING TIERS
      // ============================================
      async getHostingTiers() {
        const snapshot = await this.db.collection("hostingTiers").get();
        return snapshot.docs.map((doc) => this.docToHostingTier(doc));
      }
      async getHostingTier(id) {
        const doc = await this.db.collection("hostingTiers").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToHostingTier(doc);
      }
      async getHostingTierByCode(code) {
        const snapshot = await this.db.collection("hostingTiers").where("code", "==", code).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToHostingTier(snapshot.docs[0]);
      }
      async createHostingTier(tier) {
        const docRef = this.db.collection("hostingTiers").doc();
        const data = this.prepareForFirestore({ ...tier, id: docRef.id });
        await docRef.set(data);
        return this.docToHostingTier(await docRef.get());
      }
      async updateHostingTier(id, tier) {
        const docRef = this.db.collection("hostingTiers").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(tier));
        return this.docToHostingTier(await docRef.get());
      }
      async deleteHostingTier(id) {
        await this.db.collection("hostingTiers").doc(id).delete();
      }
      docToHostingTier(doc) {
        const data = doc.data();
        return { ...data, id: doc.id };
      }
      // ============================================
      // COUPONS
      // ============================================
      async getCoupons() {
        const snapshot = await this.db.collection("coupons").get();
        return snapshot.docs.map((doc) => this.docToCoupon(doc));
      }
      async getActiveCoupons() {
        const snapshot = await this.db.collection("coupons").where("isActive", "==", true).get();
        return snapshot.docs.map((doc) => this.docToCoupon(doc));
      }
      async getCoupon(id) {
        const doc = await this.db.collection("coupons").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToCoupon(doc);
      }
      async getCouponByCode(code) {
        const snapshot = await this.db.collection("coupons").where("code", "==", code).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToCoupon(snapshot.docs[0]);
      }
      async createCoupon(coupon) {
        const docRef = this.db.collection("coupons").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...coupon, id: docRef.id, createdAt: now, timesRedeemed: 0 });
        await docRef.set(data);
        return this.docToCoupon(await docRef.get());
      }
      async updateCoupon(id, coupon) {
        const docRef = this.db.collection("coupons").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(coupon));
        return this.docToCoupon(await docRef.get());
      }
      async deleteCoupon(id) {
        await this.db.collection("coupons").doc(id).delete();
      }
      async incrementCouponRedemption(id) {
        const docRef = this.db.collection("coupons").doc(id);
        const { FieldValue } = await import("firebase-admin/firestore");
        await docRef.update({ timesRedeemed: FieldValue.increment(1) });
      }
      docToCoupon(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), expiresAt: firestoreToDateNullable(data.expiresAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // QR TEMPLATES
      // ============================================
      async getQrTemplates() {
        const snapshot = await this.db.collection("qrTemplates").get();
        return snapshot.docs.map((doc) => this.docToQrTemplate(doc));
      }
      async getActiveQrTemplates() {
        const snapshot = await this.db.collection("qrTemplates").where("isActive", "==", true).get();
        return snapshot.docs.map((doc) => this.docToQrTemplate(doc));
      }
      async getQrTemplate(id) {
        const doc = await this.db.collection("qrTemplates").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToQrTemplate(doc);
      }
      async createQrTemplate(template) {
        const docRef = this.db.collection("qrTemplates").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...template, id: docRef.id, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToQrTemplate(await docRef.get());
      }
      async updateQrTemplate(id, template) {
        const docRef = this.db.collection("qrTemplates").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...template, updatedAt: /* @__PURE__ */ new Date() }));
        return this.docToQrTemplate(await docRef.get());
      }
      async deleteQrTemplate(id) {
        await this.db.collection("qrTemplates").doc(id).delete();
      }
      docToQrTemplate(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // DYNAMIC PAGES
      // ============================================
      async getDynamicPage(id) {
        const doc = await this.db.collection("dynamicPages").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToDynamicPage(doc);
      }
      async getDynamicPageBySlug(slug) {
        const snapshot = await this.db.collection("dynamicPages").where("slug", "==", slug).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToDynamicPage(snapshot.docs[0]);
      }
      async getDynamicPagesByUser(userId) {
        const snapshot = await this.db.collection("dynamicPages").where("userId", "==", userId).get();
        return snapshot.docs.map((doc) => this.docToDynamicPage(doc));
      }
      async createDynamicPage(page) {
        const docRef = this.db.collection("dynamicPages").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...page, id: docRef.id, createdAt: now, updatedAt: now, views: 0 });
        await docRef.set(data);
        return this.docToDynamicPage(await docRef.get());
      }
      async updateDynamicPage(id, page) {
        const docRef = this.db.collection("dynamicPages").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...page, updatedAt: /* @__PURE__ */ new Date() }));
        return this.docToDynamicPage(await docRef.get());
      }
      async deleteDynamicPage(id) {
        await this.db.collection("dynamicPages").doc(id).delete();
      }
      async incrementDynamicPageViews(id) {
        const docRef = this.db.collection("dynamicPages").doc(id);
        const { FieldValue } = await import("firebase-admin/firestore");
        await docRef.update({ views: FieldValue.increment(1) });
      }
      docToDynamicPage(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // DYNAMIC PAGE ASSETS
      // ============================================
      async getDynamicPageAsset(id) {
        const doc = await this.db.collection("dynamicPageAssets").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToDynamicPageAsset(doc);
      }
      async getDynamicPageAssets(pageId) {
        const snapshot = await this.db.collection("dynamicPageAssets").where("pageId", "==", pageId).get();
        return snapshot.docs.map((doc) => this.docToDynamicPageAsset(doc));
      }
      async createDynamicPageAsset(asset) {
        const docRef = this.db.collection("dynamicPageAssets").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...asset, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToDynamicPageAsset(await docRef.get());
      }
      async updateDynamicPageAsset(id, asset) {
        const docRef = this.db.collection("dynamicPageAssets").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(asset));
        return this.docToDynamicPageAsset(await docRef.get());
      }
      async deleteDynamicPageAsset(id) {
        await this.db.collection("dynamicPageAssets").doc(id).delete();
      }
      async setActiveAsset(pageId, assetId) {
        const snapshot = await this.db.collection("dynamicPageAssets").where("pageId", "==", pageId).get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.update(doc.ref, { isActive: doc.id === assetId }));
        await batch.commit();
      }
      docToDynamicPageAsset(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // PRODUCT CATEGORIES
      // ============================================
      async getProductCategories() {
        const snapshot = await this.db.collection("productCategories").get();
        return snapshot.docs.map((doc) => this.docToProductCategory(doc));
      }
      async getAllProductCategories() {
        return this.getProductCategories();
      }
      async getActiveProductCategories() {
        const snapshot = await this.db.collection("productCategories").where("isActive", "==", true).get();
        return snapshot.docs.map((doc) => this.docToProductCategory(doc));
      }
      async getProductCategoriesByTaxonomy(taxonomyType) {
        const snapshot = await this.db.collection("productCategories").where("taxonomyType", "==", taxonomyType).get();
        return snapshot.docs.map((doc) => this.docToProductCategory(doc));
      }
      async getProductCategory(id) {
        const doc = await this.db.collection("productCategories").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToProductCategory(doc);
      }
      async createProductCategory(category) {
        const docRef = this.db.collection("productCategories").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...category, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToProductCategory(await docRef.get());
      }
      async updateProductCategory(id, category) {
        const docRef = this.db.collection("productCategories").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(category));
        return this.docToProductCategory(await docRef.get());
      }
      async deleteProductCategory(id) {
        await this.db.collection("productCategories").doc(id).delete();
      }
      docToProductCategory(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // PRODUCT CATEGORY ASSIGNMENTS
      // ============================================
      async getProductCategoryAssignments(productId) {
        const snapshot = await this.db.collection("productCategoryAssignments").where("productId", "==", productId).get();
        return snapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
      }
      async getProductsByCategory(categoryId) {
        const assignments = await this.db.collection("productCategoryAssignments").where("categoryId", "==", categoryId).get();
        const productIds = assignments.docs.map((doc) => doc.data().productId);
        if (productIds.length === 0) return [];
        const products2 = [];
        for (const pid of productIds) {
          const p = await this.getProduct(pid);
          if (p) products2.push(p);
        }
        return products2;
      }
      async assignProductToCategory(assignment) {
        const docRef = this.db.collection("productCategoryAssignments").doc();
        const data = this.prepareForFirestore({ ...assignment, id: docRef.id });
        await docRef.set(data);
        return { ...data, id: docRef.id };
      }
      async removeProductFromCategory(productId, categoryId) {
        const snapshot = await this.db.collection("productCategoryAssignments").where("productId", "==", productId).where("categoryId", "==", categoryId).get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      }
      async syncProductCategories(productId, categoryIds) {
        const existing = await this.db.collection("productCategoryAssignments").where("productId", "==", productId).get();
        const batch = this.db.batch();
        existing.docs.forEach((doc) => batch.delete(doc.ref));
        for (const categoryId of categoryIds) {
          const docRef = this.db.collection("productCategoryAssignments").doc();
          batch.set(docRef, { id: docRef.id, productId, categoryId });
        }
        await batch.commit();
      }
      // ============================================
      // PARTNER STORES
      // ============================================
      async getPartnerStores() {
        const snapshot = await this.db.collection("partnerStores").get();
        return snapshot.docs.map((doc) => this.docToPartnerStore(doc));
      }
      async getPartnerStore(id) {
        const doc = await this.db.collection("partnerStores").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToPartnerStore(doc);
      }
      async getPartnerStoreBySlug(slug) {
        const snapshot = await this.db.collection("partnerStores").where("slug", "==", slug).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToPartnerStore(snapshot.docs[0]);
      }
      async createPartnerStore(store) {
        const docRef = this.db.collection("partnerStores").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...store, id: docRef.id, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToPartnerStore(await docRef.get());
      }
      async updatePartnerStore(id, store) {
        const docRef = this.db.collection("partnerStores").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...store, updatedAt: /* @__PURE__ */ new Date() }));
        return this.docToPartnerStore(await docRef.get());
      }
      async deletePartnerStore(id) {
        await this.db.collection("partnerStores").doc(id).delete();
      }
      docToPartnerStore(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // PARTNER STORE PRODUCTS
      // ============================================
      async getPartnerStoreProducts(partnerStoreId) {
        const snapshot = await this.db.collection("partnerStoreProducts").where("partnerStoreId", "==", partnerStoreId).get();
        return snapshot.docs.map((doc) => this.docToPartnerStoreProduct(doc));
      }
      async getPartnerStoreProduct(partnerStoreId, productId) {
        const snapshot = await this.db.collection("partnerStoreProducts").where("partnerStoreId", "==", partnerStoreId).where("productId", "==", productId).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToPartnerStoreProduct(snapshot.docs[0]);
      }
      async getProductsForStore(storeSlug, segment) {
        const store = await this.getPartnerStoreBySlug(storeSlug);
        if (!store) return [];
        let query = this.db.collection("partnerStoreProducts").where("partnerStoreId", "==", store.id);
        if (segment) query = query.where("segment", "==", segment);
        const snapshot = await query.get();
        const productIds = snapshot.docs.map((doc) => doc.data().productId);
        const products2 = [];
        for (const pid of productIds) {
          const p = await this.getProduct(pid);
          if (p) products2.push(p);
        }
        return products2;
      }
      async addPartnerStoreProduct(product) {
        const docRef = this.db.collection("partnerStoreProducts").doc();
        const data = this.prepareForFirestore({ ...product, id: docRef.id, addedAt: /* @__PURE__ */ new Date() });
        await docRef.set(data);
        return this.docToPartnerStoreProduct(await docRef.get());
      }
      async updatePartnerStoreProduct(id, product) {
        const docRef = this.db.collection("partnerStoreProducts").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(product));
        return this.docToPartnerStoreProduct(await docRef.get());
      }
      async updatePartnerStoreProductByIds(partnerStoreId, productId, product) {
        const existing = await this.getPartnerStoreProduct(partnerStoreId, productId);
        if (!existing) return void 0;
        return this.updatePartnerStoreProduct(existing.id, product);
      }
      async removePartnerStoreProduct(id) {
        await this.db.collection("partnerStoreProducts").doc(id).delete();
      }
      async syncPartnerStoreProducts(partnerStoreId, productIds) {
        const existing = await this.db.collection("partnerStoreProducts").where("partnerStoreId", "==", partnerStoreId).get();
        const batch = this.db.batch();
        existing.docs.forEach((doc) => batch.delete(doc.ref));
        for (const productId of productIds) {
          const docRef = this.db.collection("partnerStoreProducts").doc();
          batch.set(docRef, { id: docRef.id, partnerStoreId, productId, addedAt: /* @__PURE__ */ new Date() });
        }
        await batch.commit();
      }
      docToPartnerStoreProduct(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, addedAt: firestoreToDate(data.addedAt) };
      }
      // ============================================
      // PRODUCT VARIANTS
      // ============================================
      async getProductVariants(productId) {
        const snapshot = await this.db.collection("productVariants").where("productId", "==", productId).get();
        return snapshot.docs.map((doc) => this.docToProductVariant(doc));
      }
      async upsertProductVariant(variant) {
        const v = variant;
        const existingSnapshot = await this.db.collection("productVariants").where("productId", "==", v.productId).where("variantId", "==", v.variantId).limit(1).get();
        if (!existingSnapshot.empty) {
          const docRef2 = existingSnapshot.docs[0].ref;
          await docRef2.update(this.prepareForFirestore({ ...v, updatedAt: /* @__PURE__ */ new Date() }));
          return this.docToProductVariant(await docRef2.get());
        }
        const docRef = this.db.collection("productVariants").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...v, id: docRef.id, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToProductVariant(await docRef.get());
      }
      async toggleVariantEnabled(id, enabled) {
        const docRef = this.db.collection("productVariants").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update({ isEnabled: enabled, updatedAt: /* @__PURE__ */ new Date() });
        return this.docToProductVariant(await docRef.get());
      }
      docToProductVariant(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // PRINTIFY BLUEPRINTS
      // ============================================
      async getPrintifyBlueprints() {
        const snapshot = await this.db.collection("printifyBlueprints").get();
        return snapshot.docs.map((doc) => this.docToPrintifyBlueprint(doc));
      }
      async getPrintifyBlueprint(id) {
        const doc = await this.db.collection("printifyBlueprints").doc(String(id)).get();
        if (!doc.exists) return void 0;
        return this.docToPrintifyBlueprint(doc);
      }
      async upsertPrintifyBlueprint(blueprint) {
        const docRef = this.db.collection("printifyBlueprints").doc(String(blueprint.id));
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...blueprint, syncedAt: now });
        await docRef.set(data, { merge: true });
        return this.docToPrintifyBlueprint(await docRef.get());
      }
      async deletePrintifyBlueprint(id) {
        await this.db.collection("printifyBlueprints").doc(String(id)).delete();
      }
      async clearPrintifyBlueprints() {
        const snapshot = await this.db.collection("printifyBlueprints").get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      }
      docToPrintifyBlueprint(doc) {
        const data = doc.data();
        return { ...data, id: parseInt(doc.id), createdAt: firestoreToDate(data.createdAt), lastSyncedAt: firestoreToDate(data.syncedAt || data.lastSyncedAt) };
      }
      // ============================================
      // PRINTIFY PRINT PROVIDERS
      // ============================================
      async getAllPrintifyProviders() {
        const snapshot = await this.db.collection("printifyPrintProviders").get();
        return snapshot.docs.map((doc) => this.docToPrintifyPrintProvider(doc));
      }
      async getPrintifyPrintProviders(blueprintId) {
        const snapshot = await this.db.collection("printifyPrintProviders").where("blueprintId", "==", blueprintId).get();
        return snapshot.docs.map((doc) => this.docToPrintifyPrintProvider(doc));
      }
      async getPrintifyPrintProvider(blueprintId, providerId) {
        const docId = `${blueprintId}_${providerId}`;
        const doc = await this.db.collection("printifyPrintProviders").doc(docId).get();
        if (!doc.exists) return void 0;
        return this.docToPrintifyPrintProvider(doc);
      }
      async upsertPrintifyPrintProvider(provider) {
        const docId = `${provider.blueprintId}_${provider.providerId}`;
        const docRef = this.db.collection("printifyPrintProviders").doc(docId);
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...provider, syncedAt: now });
        await docRef.set(data, { merge: true });
        return this.docToPrintifyPrintProvider(await docRef.get());
      }
      async updatePrintifyProviderCosts(blueprintId, providerId, costs) {
        const docId = `${blueprintId}_${providerId}`;
        const docRef = this.db.collection("printifyPrintProviders").doc(docId);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...costs, costSyncedAt: /* @__PURE__ */ new Date() }));
        return this.docToPrintifyPrintProvider(await docRef.get());
      }
      async updateProductPricesByProvider(blueprintId, providerId, basePrice) {
        const snapshot = await this.db.collection("products").where("blueprintId", "==", blueprintId).where("printProviderId", "==", providerId).get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.update(doc.ref, { basePrice }));
        await batch.commit();
        return snapshot.size;
      }
      async deletePrintifyPrintProvidersByBlueprint(blueprintId) {
        const snapshot = await this.db.collection("printifyPrintProviders").where("blueprintId", "==", blueprintId).get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      }
      async clearPrintifyPrintProviders() {
        const snapshot = await this.db.collection("printifyPrintProviders").get();
        const batch = this.db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      }
      docToPrintifyPrintProvider(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, lastSyncedAt: firestoreToDate(data.syncedAt || data.lastSyncedAt), costsFetchedAt: firestoreToDateNullable(data.costSyncedAt || data.costsFetchedAt) };
      }
      // ============================================
      // CATALOG SYNC
      // ============================================
      async createCatalogSync(sync) {
        const docRef = this.db.collection("catalogSyncs").doc();
        const data = this.prepareForFirestore({ ...sync, id: docRef.id, startedAt: /* @__PURE__ */ new Date() });
        await docRef.set(data);
        return this.docToCatalogSync(await docRef.get());
      }
      async updateCatalogSync(id, sync) {
        const docRef = this.db.collection("catalogSyncs").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(sync));
        return this.docToCatalogSync(await docRef.get());
      }
      async getLatestCatalogSync() {
        const snapshot = await this.db.collection("catalogSyncs").orderBy("startedAt", "desc").limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToCatalogSync(snapshot.docs[0]);
      }
      async getCatalogSyncHistory() {
        const snapshot = await this.db.collection("catalogSyncs").orderBy("startedAt", "desc").limit(50).get();
        return snapshot.docs.map((doc) => this.docToCatalogSync(doc));
      }
      docToCatalogSync(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, startedAt: firestoreToDate(data.startedAt), completedAt: firestoreToDateNullable(data.completedAt) };
      }
      // ============================================
      // COST SYNC
      // ============================================
      async createCostSync(sync) {
        const docRef = this.db.collection("costSyncs").doc();
        const data = this.prepareForFirestore({ ...sync, id: docRef.id, startedAt: /* @__PURE__ */ new Date() });
        await docRef.set(data);
        return this.docToCostSync(await docRef.get());
      }
      async updateCostSync(id, sync) {
        const docRef = this.db.collection("costSyncs").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(sync));
        return this.docToCostSync(await docRef.get());
      }
      async getLatestCostSync() {
        const snapshot = await this.db.collection("costSyncs").orderBy("startedAt", "desc").limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToCostSync(snapshot.docs[0]);
      }
      async getActiveCostSync() {
        const snapshot = await this.db.collection("costSyncs").where("status", "==", "running").limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToCostSync(snapshot.docs[0]);
      }
      async getCostSyncHistory() {
        const snapshot = await this.db.collection("costSyncs").orderBy("startedAt", "desc").limit(50).get();
        return snapshot.docs.map((doc) => this.docToCostSync(doc));
      }
      async getProviderCostStats() {
        const providers = await this.getAllPrintifyProviders();
        const staleDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3);
        return {
          total: providers.length,
          withCosts: providers.filter((p) => p.minCost !== null).length,
          stale: providers.filter((p) => p.costsFetchedAt && new Date(p.costsFetchedAt) < staleDate).length
        };
      }
      docToCostSync(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, startedAt: firestoreToDate(data.startedAt), completedAt: firestoreToDateNullable(data.completedAt) };
      }
      // ============================================
      // TEMPLATE CATEGORIES
      // ============================================
      async getTemplateCategories() {
        const snapshot = await this.db.collection("templateCategories").get();
        return snapshot.docs.map((doc) => this.docToTemplateCategory(doc));
      }
      async getTemplateCategoriesByParent(parentId) {
        let query = this.db.collection("templateCategories");
        if (parentId === null) {
          query = query.where("parentId", "==", null);
        } else {
          query = query.where("parentId", "==", parentId);
        }
        const snapshot = await query.get();
        return snapshot.docs.map((doc) => this.docToTemplateCategory(doc));
      }
      async createTemplateCategory(category) {
        const docRef = this.db.collection("templateCategories").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...category, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToTemplateCategory(await docRef.get());
      }
      async updateTemplateCategory(id, category) {
        const docRef = this.db.collection("templateCategories").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(category));
        return this.docToTemplateCategory(await docRef.get());
      }
      async deleteTemplateCategory(id) {
        await this.db.collection("templateCategories").doc(id).delete();
      }
      docToTemplateCategory(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // GRAPHIC SETS
      // ============================================
      async getGraphicSets() {
        const snapshot = await this.db.collection("graphicSets").where("isActive", "==", true).orderBy("createdAt", "desc").get();
        return snapshot.docs.map((doc) => this.docToGraphicSet(doc));
      }
      async getGraphicSet(id) {
        const doc = await this.db.collection("graphicSets").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToGraphicSet(doc);
      }
      async getGraphicSetsByCategory(categoryId) {
        const snapshot = await this.db.collection("graphicSets").where("categoryId", "==", categoryId).where("isActive", "==", true).orderBy("createdAt", "desc").get();
        return snapshot.docs.map((doc) => this.docToGraphicSet(doc));
      }
      async createGraphicSet(graphicSet) {
        const id = graphicSet.id || this.db.collection("graphicSets").doc().id;
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({
          ...graphicSet,
          id,
          usageCount: 0,
          createdAt: now,
          updatedAt: now
        });
        await this.db.collection("graphicSets").doc(id).set(data);
        const doc = await this.db.collection("graphicSets").doc(id).get();
        return this.docToGraphicSet(doc);
      }
      async updateGraphicSet(id, graphicSet) {
        const docRef = this.db.collection("graphicSets").doc(id);
        const existing = await docRef.get();
        if (!existing.exists) return void 0;
        const data = this.prepareForFirestore({ ...graphicSet, updatedAt: /* @__PURE__ */ new Date() });
        await docRef.update(data);
        const updated = await docRef.get();
        return this.docToGraphicSet(updated);
      }
      async deleteGraphicSet(id) {
        await this.db.collection("graphicSets").doc(id).update({ isActive: false });
      }
      async incrementGraphicSetUsage(id) {
        const docRef = this.db.collection("graphicSets").doc(id);
        const doc = await docRef.get();
        if (doc.exists) {
          const currentCount = doc.data()?.usageCount || 0;
          await docRef.update({ usageCount: currentCount + 1 });
        }
      }
      docToGraphicSet(doc) {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          createdAt: firestoreToDate(data.createdAt),
          updatedAt: firestoreToDate(data.updatedAt)
        };
      }
      // ============================================
      // LIBRARY ASSETS
      // ============================================
      async getLibraryAsset(id) {
        const doc = await this.db.collection("libraryAssets").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToLibraryAsset(doc);
      }
      async getLibraryAssetByUrl(url) {
        const snapshot = await this.db.collection("libraryAssets").where("url", "==", url).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToLibraryAsset(snapshot.docs[0]);
      }
      async getLibraryAssets(filters) {
        let query = this.db.collection("libraryAssets");
        if (filters?.ownerType) query = query.where("ownerType", "==", filters.ownerType);
        if (filters?.assetType) query = query.where("assetType", "==", filters.assetType);
        if (filters?.mediaType) query = query.where("mediaType", "==", filters.mediaType);
        if (filters?.userId) query = query.where("userId", "==", filters.userId);
        if (filters?.category) query = query.where("category", "==", filters.category);
        const snapshot = await query.get();
        return snapshot.docs.map((doc) => this.docToLibraryAsset(doc));
      }
      async getAdminLibraryAssets(filters) {
        return this.getLibraryAssets({ ...filters, ownerType: "admin" });
      }
      async getUserLibraryAssets(userId, filters) {
        return this.getLibraryAssets({ ...filters, userId, ownerType: "user" });
      }
      async createLibraryAsset(asset) {
        const docRef = this.db.collection("libraryAssets").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...asset, id: docRef.id, createdAt: now, usageCount: 0 });
        await docRef.set(data);
        return this.docToLibraryAsset(await docRef.get());
      }
      async updateLibraryAsset(id, asset) {
        const docRef = this.db.collection("libraryAssets").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(asset));
        return this.docToLibraryAsset(await docRef.get());
      }
      async deleteLibraryAsset(id) {
        await this.db.collection("libraryAssets").doc(id).delete();
      }
      async incrementLibraryAssetUsage(id) {
        const docRef = this.db.collection("libraryAssets").doc(id);
        const { FieldValue } = await import("firebase-admin/firestore");
        await docRef.update({ usageCount: FieldValue.increment(1) });
      }
      docToLibraryAsset(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // MASTER PRODUCTS
      // ============================================
      async getAllMasterProducts() {
        const snapshot = await this.db.collection("masterProducts").get();
        return snapshot.docs.map((doc) => this.docToMasterProduct(doc));
      }
      async getMasterProduct(id) {
        const doc = await this.db.collection("masterProducts").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToMasterProduct(doc);
      }
      async createMasterProduct(product) {
        const docRef = this.db.collection("masterProducts").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...product, id: docRef.id, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToMasterProduct(await docRef.get());
      }
      async updateMasterProduct(id, product) {
        const docRef = this.db.collection("masterProducts").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...product, updatedAt: /* @__PURE__ */ new Date() }));
        return this.docToMasterProduct(await docRef.get());
      }
      async deleteMasterProduct(id) {
        await this.db.collection("masterProducts").doc(id).delete();
      }
      docToMasterProduct(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // DESIGN VERSIONS
      // ============================================
      async getDesignVersions(masterProductId) {
        const snapshot = await this.db.collection("designVersions").where("masterProductId", "==", masterProductId).get();
        return snapshot.docs.map((doc) => this.docToDesignVersion(doc));
      }
      async getActiveDesignVersion(masterProductId) {
        const snapshot = await this.db.collection("designVersions").where("masterProductId", "==", masterProductId).where("isActive", "==", true).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToDesignVersion(snapshot.docs[0]);
      }
      async createDesignVersion(version) {
        const docRef = this.db.collection("designVersions").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...version, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToDesignVersion(await docRef.get());
      }
      async updateDesignVersion(id, version) {
        const docRef = this.db.collection("designVersions").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(version));
        return this.docToDesignVersion(await docRef.get());
      }
      docToDesignVersion(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // CHANNEL CONFIGS
      // ============================================
      async getAllChannelConfigs() {
        const snapshot = await this.db.collection("channelConfigs").get();
        return snapshot.docs.map((doc) => this.docToChannelConfig(doc));
      }
      async getChannelConfig(channelType) {
        const doc = await this.db.collection("channelConfigs").doc(channelType).get();
        if (!doc.exists) return void 0;
        return this.docToChannelConfig(doc);
      }
      async createChannelConfig(config) {
        const docRef = this.db.collection("channelConfigs").doc(config.channelType);
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...config, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToChannelConfig(await docRef.get());
      }
      async updateChannelConfig(channelType, config) {
        const docRef = this.db.collection("channelConfigs").doc(channelType);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...config, updatedAt: /* @__PURE__ */ new Date() }));
        return this.docToChannelConfig(await docRef.get());
      }
      docToChannelConfig(doc) {
        const data = doc.data();
        return { ...data, channelType: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // PUBLISH STATES
      // ============================================
      async getPublishStates(masterProductId) {
        const snapshot = await this.db.collection("publishStates").where("masterProductId", "==", masterProductId).get();
        return snapshot.docs.map((doc) => this.docToPublishState(doc));
      }
      async getPublishState(masterProductId, channelType) {
        const docId = `${masterProductId}_${channelType}`;
        const doc = await this.db.collection("publishStates").doc(docId).get();
        if (!doc.exists) return void 0;
        return this.docToPublishState(doc);
      }
      async upsertPublishState(state) {
        const docId = `${state.masterProductId}_${state.channelType}`;
        const docRef = this.db.collection("publishStates").doc(docId);
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...state, updatedAt: now });
        await docRef.set(data, { merge: true });
        return this.docToPublishState(await docRef.get());
      }
      docToPublishState(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), publishedAt: firestoreToDateNullable(data.publishedAt), updatedAt: firestoreToDate(data.updatedAt), lastSyncedAt: firestoreToDateNullable(data.lastSyncedAt) };
      }
      // ============================================
      // PROVIDER HEALTH
      // ============================================
      async logProviderHealth(log2) {
        const docRef = this.db.collection("providerHealthLogs").doc();
        const data = this.prepareForFirestore({ ...log2, id: docRef.id, checkedAt: /* @__PURE__ */ new Date() });
        await docRef.set(data);
        return this.docToProviderHealthLog(await docRef.get());
      }
      async getProviderHealthLogs(limit = 100) {
        const snapshot = await this.db.collection("providerHealthLogs").orderBy("checkedAt", "desc").limit(limit).get();
        return snapshot.docs.map((doc) => this.docToProviderHealthLog(doc));
      }
      async getProviderHealthLogsByType(providerType, limit = 100) {
        const snapshot = await this.db.collection("providerHealthLogs").where("providerType", "==", providerType).orderBy("checkedAt", "desc").limit(limit).get();
        return snapshot.docs.map((doc) => this.docToProviderHealthLog(doc));
      }
      async getLatestProviderHealth(providerType) {
        const logs = await this.getProviderHealthLogsByType(providerType, 1);
        return logs[0];
      }
      async getAllLatestProviderHealth() {
        const allLogs = await this.getProviderHealthLogs(500);
        const latestByType = /* @__PURE__ */ new Map();
        for (const log2 of allLogs) {
          if (!latestByType.has(log2.providerType)) {
            latestByType.set(log2.providerType, log2);
          }
        }
        return Array.from(latestByType.values());
      }
      async getProviderHealthStats(providerType, hours = 24) {
        const cutoff = new Date(Date.now() - hours * 60 * 60 * 1e3);
        const snapshot = await this.db.collection("providerHealthLogs").where("providerType", "==", providerType).where("checkedAt", ">=", cutoff).get();
        const logs = snapshot.docs.map((doc) => this.docToProviderHealthLog(doc));
        if (logs.length === 0) return { uptimePercent: 0, avgResponseTime: 0, totalChecks: 0 };
        const upCount = logs.filter((l) => l.isHealthy).length;
        const avgTime = logs.reduce((sum, l) => sum + (l.responseTimeMs || 0), 0) / logs.length;
        return { uptimePercent: upCount / logs.length * 100, avgResponseTime: avgTime, totalChecks: logs.length };
      }
      docToProviderHealthLog(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, checkTime: firestoreToDate(data.checkedAt || data.checkTime) };
      }
      // ============================================
      // GIFT PACKAGES
      // ============================================
      async getAllGiftPackages() {
        const snapshot = await this.db.collection("giftPackages").get();
        return snapshot.docs.map((doc) => this.docToGiftPackage(doc));
      }
      async getActiveGiftPackages() {
        const snapshot = await this.db.collection("giftPackages").where("isActive", "==", true).get();
        return snapshot.docs.map((doc) => this.docToGiftPackage(doc));
      }
      async getGiftPackage(id) {
        const doc = await this.db.collection("giftPackages").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToGiftPackage(doc);
      }
      async createGiftPackage(pkg) {
        const docRef = this.db.collection("giftPackages").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...pkg, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToGiftPackage(await docRef.get());
      }
      async updateGiftPackage(id, pkg) {
        const docRef = this.db.collection("giftPackages").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(pkg));
        return this.docToGiftPackage(await docRef.get());
      }
      async deleteGiftPackage(id) {
        await this.db.collection("giftPackages").doc(id).delete();
      }
      docToGiftPackage(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt) };
      }
      // ============================================
      // GIFT CODES
      // ============================================
      async getGiftCode(id) {
        const doc = await this.db.collection("giftCodes").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToGiftCode(doc);
      }
      async getGiftCodeByCode(code) {
        const snapshot = await this.db.collection("giftCodes").where("code", "==", code).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToGiftCode(snapshot.docs[0]);
      }
      async getGiftCodesByBuyer(buyerUserId) {
        const snapshot = await this.db.collection("giftCodes").where("buyerUserId", "==", buyerUserId).get();
        return snapshot.docs.map((doc) => this.docToGiftCode(doc));
      }
      async createGiftCode(code) {
        const docRef = this.db.collection("giftCodes").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...code, id: docRef.id, createdAt: now });
        await docRef.set(data);
        return this.docToGiftCode(await docRef.get());
      }
      async updateGiftCode(id, code) {
        const docRef = this.db.collection("giftCodes").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(code));
        return this.docToGiftCode(await docRef.get());
      }
      docToGiftCode(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), expiresAt: firestoreToDateNullable(data.expiresAt) };
      }
      // ============================================
      // GIFT REDEMPTIONS
      // ============================================
      async getGiftRedemption(id) {
        const doc = await this.db.collection("giftRedemptions").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToGiftRedemption(doc);
      }
      async getGiftRedemptionByCode(giftCodeId) {
        const snapshot = await this.db.collection("giftRedemptions").where("giftCodeId", "==", giftCodeId).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToGiftRedemption(snapshot.docs[0]);
      }
      async getGiftRedemptionsByRecipient(recipientEmail) {
        const snapshot = await this.db.collection("giftRedemptions").where("recipientEmail", "==", recipientEmail).get();
        return snapshot.docs.map((doc) => this.docToGiftRedemption(doc));
      }
      async createGiftRedemption(redemption) {
        const docRef = this.db.collection("giftRedemptions").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...redemption, id: docRef.id, redeemedAt: now });
        await docRef.set(data);
        return this.docToGiftRedemption(await docRef.get());
      }
      async updateGiftRedemption(id, redemption) {
        const docRef = this.db.collection("giftRedemptions").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore(redemption));
        return this.docToGiftRedemption(await docRef.get());
      }
      docToGiftRedemption(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, redeemedAt: firestoreToDate(data.redeemedAt) };
      }
      // ============================================
      // EMAIL TEMPLATES
      // ============================================
      async getEmailTemplates() {
        const snapshot = await this.db.collection("emailTemplates").get();
        return snapshot.docs.map((doc) => this.docToEmailTemplate(doc));
      }
      async getEmailTemplate(id) {
        const doc = await this.db.collection("emailTemplates").doc(id).get();
        if (!doc.exists) return void 0;
        return this.docToEmailTemplate(doc);
      }
      async getEmailTemplateByTrigger(trigger) {
        const snapshot = await this.db.collection("emailTemplates").where("trigger", "==", trigger).limit(1).get();
        if (snapshot.empty) return void 0;
        return this.docToEmailTemplate(snapshot.docs[0]);
      }
      async createEmailTemplate(template) {
        const docRef = this.db.collection("emailTemplates").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...template, id: docRef.id, createdAt: now, updatedAt: now });
        await docRef.set(data);
        return this.docToEmailTemplate(await docRef.get());
      }
      async updateEmailTemplate(id, template) {
        const docRef = this.db.collection("emailTemplates").doc(id);
        if (!(await docRef.get()).exists) return void 0;
        await docRef.update(this.prepareForFirestore({ ...template, updatedAt: /* @__PURE__ */ new Date() }));
        return this.docToEmailTemplate(await docRef.get());
      }
      async deleteEmailTemplate(id) {
        await this.db.collection("emailTemplates").doc(id).delete();
      }
      docToEmailTemplate(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, createdAt: firestoreToDate(data.createdAt), updatedAt: firestoreToDate(data.updatedAt) };
      }
      // ============================================
      // EMAIL LOGS
      // ============================================
      async getEmailLogs(limit = 100) {
        const snapshot = await this.db.collection("emailLogs").orderBy("sentAt", "desc").limit(limit).get();
        return snapshot.docs.map((doc) => this.docToEmailLog(doc));
      }
      async logEmail(log2) {
        const docRef = this.db.collection("emailLogs").doc();
        const now = /* @__PURE__ */ new Date();
        const data = this.prepareForFirestore({ ...log2, id: docRef.id, sentAt: now });
        await docRef.set(data);
        return this.docToEmailLog(await docRef.get());
      }
      docToEmailLog(doc) {
        const data = doc.data();
        return { ...data, id: doc.id, sentAt: firestoreToDate(data.sentAt) };
      }
    };
  }
});

// server/lib/dual-write-adapter.ts
var dual_write_adapter_exports = {};
__export(dual_write_adapter_exports, {
  DualWriteAdapter: () => DualWriteAdapter
});
var DualWriteAdapter;
var init_dual_write_adapter = __esm({
  "server/lib/dual-write-adapter.ts"() {
    "use strict";
    DualWriteAdapter = class {
      constructor(primary, secondary) {
        this.primary = primary;
        this.secondary = secondary;
        console.log("[DualWriteAdapter] Initialized with Postgres (primary) and Firestore (secondary)");
      }
      failedWrites = [];
      logDualWriteError(operation, error) {
        const entry = { operation, error, timestamp: /* @__PURE__ */ new Date() };
        this.failedWrites.push(entry);
        if (this.failedWrites.length > 100) {
          this.failedWrites.shift();
        }
        console.error(`[DualWrite] ALERT: Secondary write failed for ${operation}:`, error);
      }
      getFailedWrites() {
        return [...this.failedWrites];
      }
      async mirrorWriteVoid(operation, secondaryFn) {
        try {
          await secondaryFn();
        } catch (error) {
          this.logDualWriteError(operation, error);
        }
      }
      // ============================================
      // USER OPERATIONS
      // ============================================
      async getUser(id) {
        return this.primary.getUser(id);
      }
      async getUserByEmail(email) {
        return this.primary.getUserByEmail(email);
      }
      async getUsers() {
        return this.primary.getUsers();
      }
      async createUser(user) {
        const result = await this.primary.createUser(user);
        try {
          await this.secondary.upsertUser({ ...result, id: result.id });
        } catch (error) {
          this.logDualWriteError("createUser", error);
        }
        return result;
      }
      async upsertUser(userData) {
        const result = await this.primary.upsertUser(userData);
        try {
          await this.secondary.upsertUser({ ...result, id: result.id });
        } catch (error) {
          this.logDualWriteError("upsertUser", error);
        }
        return result;
      }
      // ============================================
      // PRODUCT OPERATIONS
      // ============================================
      async getProduct(id) {
        return this.primary.getProduct(id);
      }
      async getAllProducts() {
        return this.primary.getAllProducts();
      }
      async getProducts() {
        return this.primary.getProducts();
      }
      async getEnabledProducts() {
        return this.primary.getEnabledProducts();
      }
      async createProduct(product) {
        const result = await this.primary.createProduct(product);
        try {
          await this.secondary.updateProduct(result.id, result);
        } catch (error) {
          this.logDualWriteError("createProduct", error);
        }
        return result;
      }
      async updateProduct(id, product) {
        const result = await this.primary.updateProduct(id, product);
        if (result) {
          try {
            await this.secondary.updateProduct(id, result);
          } catch (error) {
            this.logDualWriteError("updateProduct", error);
          }
        }
        return result;
      }
      async deleteProduct(id) {
        await this.primary.deleteProduct(id);
        await this.mirrorWriteVoid("deleteProduct", () => this.secondary.deleteProduct(id));
      }
      async toggleProductEnabled(id, enabled) {
        const result = await this.primary.toggleProductEnabled(id, enabled);
        if (result) {
          try {
            await this.secondary.updateProduct(id, result);
          } catch (error) {
            this.logDualWriteError("toggleProductEnabled", error);
          }
        }
        return result;
      }
      // ============================================
      // CUSTOM DESIGN OPERATIONS
      // ============================================
      async getCustomDesign(id) {
        return this.primary.getCustomDesign(id);
      }
      async getCustomDesigns() {
        return this.primary.getCustomDesigns();
      }
      async getCustomDesignsForLibrary() {
        return this.primary.getCustomDesignsForLibrary();
      }
      async getCustomDesignsByStoreSegment(storeType, storeName, segment) {
        return this.primary.getCustomDesignsByStoreSegment(storeType, storeName, segment);
      }
      async createCustomDesign(design) {
        const result = await this.primary.createCustomDesign(design);
        try {
          await this.secondary.updateCustomDesign(result.id, result);
        } catch (error) {
          this.logDualWriteError("createCustomDesign", error);
        }
        return result;
      }
      async updateCustomDesign(id, design) {
        const result = await this.primary.updateCustomDesign(id, design);
        if (result) {
          try {
            await this.secondary.updateCustomDesign(id, result);
          } catch (error) {
            this.logDualWriteError("updateCustomDesign", error);
          }
        }
        return result;
      }
      async deleteCustomDesign(id) {
        await this.primary.deleteCustomDesign(id);
        await this.mirrorWriteVoid("deleteCustomDesign", () => this.secondary.deleteCustomDesign(id));
      }
      // ============================================
      // ORDER OPERATIONS
      // ============================================
      async getOrder(id) {
        return this.primary.getOrder(id);
      }
      async getOrders() {
        return this.primary.getOrders();
      }
      async getOrdersByUser(userId) {
        return this.primary.getOrdersByUser(userId);
      }
      async getOrdersByStatus(status) {
        return this.primary.getOrdersByStatus(status);
      }
      async getOrderByStripeSession(sessionId) {
        return this.primary.getOrderByStripeSession(sessionId);
      }
      async createOrder(order) {
        const result = await this.primary.createOrder(order);
        try {
          await this.secondary.updateOrder(result.id, result);
        } catch (error) {
          this.logDualWriteError("createOrder", error);
        }
        return result;
      }
      async updateOrder(id, order) {
        const result = await this.primary.updateOrder(id, order);
        if (result) {
          try {
            await this.secondary.updateOrder(id, result);
          } catch (error) {
            this.logDualWriteError("updateOrder", error);
          }
        }
        return result;
      }
      // ============================================
      // ORDER UNIFIED OPERATIONS
      // ============================================
      async getOrderUnified(id) {
        return this.primary.getOrderUnified(id);
      }
      async createOrderUnified(order) {
        const result = await this.primary.createOrderUnified(order);
        try {
          await this.secondary.updateOrderUnified(result.id, result);
        } catch (error) {
          this.logDualWriteError("createOrderUnified", error);
        }
        return result;
      }
      async updateOrderUnified(id, order) {
        const result = await this.primary.updateOrderUnified(id, order);
        if (result) {
          try {
            await this.secondary.updateOrderUnified(id, result);
          } catch (error) {
            this.logDualWriteError("updateOrderUnified", error);
          }
        }
        return result;
      }
      // ============================================
      // ORDER ITEM OPERATIONS
      // ============================================
      async getOrderItems(orderId) {
        return this.primary.getOrderItems(orderId);
      }
      async createOrderItem(item) {
        const result = await this.primary.createOrderItem(item);
        try {
          await this.secondary.createOrderItem(result);
        } catch (error) {
          this.logDualWriteError("createOrderItem", error);
        }
        return result;
      }
      // ============================================
      // ADMIN SETTINGS
      // ============================================
      async getAdminSettings() {
        return this.primary.getAdminSettings();
      }
      async upsertAdminSettings(settings) {
        const result = await this.primary.upsertAdminSettings(settings);
        try {
          await this.secondary.upsertAdminSettings(result);
        } catch (error) {
          this.logDualWriteError("upsertAdminSettings", error);
        }
        return result;
      }
      // ============================================
      // DELEGATE ALL OTHER OPERATIONS TO PRIMARY
      // Secondary writes will be added as needed
      // ============================================
      // Browsing History
      async getBrowsingHistory(userId) {
        return this.primary.getBrowsingHistory(userId);
      }
      async addBrowsingHistory(entry) {
        return this.primary.addBrowsingHistory(entry);
      }
      async clearBrowsingHistory(userId) {
        return this.primary.clearBrowsingHistory(userId);
      }
      // QR Design
      async getQrDesign(id) {
        return this.primary.getQrDesign(id);
      }
      async getQrDesignsByUser(userId) {
        return this.primary.getQrDesignsByUser(userId);
      }
      async getPublicGalleryDesigns() {
        return this.primary.getPublicGalleryDesigns();
      }
      async createQrDesign(design) {
        return this.primary.createQrDesign(design);
      }
      async updateQrDesign(id, design) {
        return this.primary.updateQrDesign(id, design);
      }
      async deleteQrDesign(id) {
        return this.primary.deleteQrDesign(id);
      }
      // Cart
      async getCartItemsByUser(userId) {
        return this.primary.getCartItemsByUser(userId);
      }
      async addCartItem(item) {
        return this.primary.addCartItem(item);
      }
      async updateCartItem(id, quantity) {
        return this.primary.updateCartItem(id, quantity);
      }
      async deleteCartItem(id) {
        return this.primary.deleteCartItem(id);
      }
      async clearCart(userId) {
        return this.primary.clearCart(userId);
      }
      // Hosted Image
      async getHostedImage(id) {
        return this.primary.getHostedImage(id);
      }
      async getHostedImagesByUser(userId) {
        return this.primary.getHostedImagesByUser(userId);
      }
      async getAllHostedImages() {
        return this.primary.getAllHostedImages();
      }
      async createHostedImage(image) {
        return this.primary.createHostedImage(image);
      }
      async updateHostedImage(id, image) {
        return this.primary.updateHostedImage(id, image);
      }
      async incrementImageViews(id) {
        return this.primary.incrementImageViews(id);
      }
      async deleteHostedImage(id) {
        return this.primary.deleteHostedImage(id);
      }
      // Hosting Reminder
      async getHostingReminderByImageAndDays(imageId, daysRemaining) {
        return this.primary.getHostingReminderByImageAndDays(imageId, daysRemaining);
      }
      async createHostingReminder(reminder) {
        return this.primary.createHostingReminder(reminder);
      }
      // Pricing Rules
      async getPricingRules() {
        return this.primary.getPricingRules();
      }
      async getPricingRule(id) {
        return this.primary.getPricingRule(id);
      }
      async createPricingRule(rule) {
        return this.primary.createPricingRule(rule);
      }
      async updatePricingRule(id, rule) {
        return this.primary.updatePricingRule(id, rule);
      }
      async deletePricingRule(id) {
        return this.primary.deletePricingRule(id);
      }
      // Hosting Tiers
      async getHostingTiers() {
        return this.primary.getHostingTiers();
      }
      async getHostingTier(id) {
        return this.primary.getHostingTier(id);
      }
      async getHostingTierByCode(code) {
        return this.primary.getHostingTierByCode(code);
      }
      async createHostingTier(tier) {
        return this.primary.createHostingTier(tier);
      }
      async updateHostingTier(id, tier) {
        return this.primary.updateHostingTier(id, tier);
      }
      async deleteHostingTier(id) {
        return this.primary.deleteHostingTier(id);
      }
      // Coupons
      async getCoupons() {
        return this.primary.getCoupons();
      }
      async getActiveCoupons() {
        return this.primary.getActiveCoupons();
      }
      async getCoupon(id) {
        return this.primary.getCoupon(id);
      }
      async getCouponByCode(code) {
        return this.primary.getCouponByCode(code);
      }
      async createCoupon(coupon) {
        return this.primary.createCoupon(coupon);
      }
      async updateCoupon(id, coupon) {
        return this.primary.updateCoupon(id, coupon);
      }
      async deleteCoupon(id) {
        return this.primary.deleteCoupon(id);
      }
      async incrementCouponRedemption(id) {
        return this.primary.incrementCouponRedemption(id);
      }
      // QR Templates
      async getQrTemplates() {
        return this.primary.getQrTemplates();
      }
      async getActiveQrTemplates() {
        return this.primary.getActiveQrTemplates();
      }
      async getQrTemplate(id) {
        return this.primary.getQrTemplate(id);
      }
      async createQrTemplate(template) {
        return this.primary.createQrTemplate(template);
      }
      async updateQrTemplate(id, template) {
        return this.primary.updateQrTemplate(id, template);
      }
      async deleteQrTemplate(id) {
        return this.primary.deleteQrTemplate(id);
      }
      // Dynamic Pages
      async getDynamicPage(id) {
        return this.primary.getDynamicPage(id);
      }
      async getDynamicPageBySlug(slug) {
        return this.primary.getDynamicPageBySlug(slug);
      }
      async getDynamicPagesByUser(userId) {
        return this.primary.getDynamicPagesByUser(userId);
      }
      async createDynamicPage(page) {
        return this.primary.createDynamicPage(page);
      }
      async updateDynamicPage(id, page) {
        return this.primary.updateDynamicPage(id, page);
      }
      async deleteDynamicPage(id) {
        return this.primary.deleteDynamicPage(id);
      }
      async incrementDynamicPageViews(id) {
        return this.primary.incrementDynamicPageViews(id);
      }
      // Dynamic Page Assets
      async getDynamicPageAsset(id) {
        return this.primary.getDynamicPageAsset(id);
      }
      async getDynamicPageAssets(pageId) {
        return this.primary.getDynamicPageAssets(pageId);
      }
      async createDynamicPageAsset(asset) {
        return this.primary.createDynamicPageAsset(asset);
      }
      async updateDynamicPageAsset(id, asset) {
        return this.primary.updateDynamicPageAsset(id, asset);
      }
      async deleteDynamicPageAsset(id) {
        return this.primary.deleteDynamicPageAsset(id);
      }
      async setActiveAsset(pageId, assetId) {
        return this.primary.setActiveAsset(pageId, assetId);
      }
      // Product Categories
      async getProductCategories() {
        return this.primary.getProductCategories();
      }
      async getAllProductCategories() {
        return this.primary.getAllProductCategories();
      }
      async getActiveProductCategories() {
        return this.primary.getActiveProductCategories();
      }
      async getProductCategoriesByTaxonomy(taxonomyType) {
        return this.primary.getProductCategoriesByTaxonomy(taxonomyType);
      }
      async getProductCategory(id) {
        return this.primary.getProductCategory(id);
      }
      async createProductCategory(category) {
        return this.primary.createProductCategory(category);
      }
      async updateProductCategory(id, category) {
        return this.primary.updateProductCategory(id, category);
      }
      async deleteProductCategory(id) {
        return this.primary.deleteProductCategory(id);
      }
      // Product Category Assignments
      async getProductCategoryAssignments(productId) {
        return this.primary.getProductCategoryAssignments(productId);
      }
      async getProductsByCategory(categoryId) {
        return this.primary.getProductsByCategory(categoryId);
      }
      async assignProductToCategory(assignment) {
        return this.primary.assignProductToCategory(assignment);
      }
      async removeProductFromCategory(productId, categoryId) {
        return this.primary.removeProductFromCategory(productId, categoryId);
      }
      async syncProductCategories(productId, categoryIds) {
        return this.primary.syncProductCategories(productId, categoryIds);
      }
      // Partner Stores
      async getPartnerStores() {
        return this.primary.getPartnerStores();
      }
      async getPartnerStore(id) {
        return this.primary.getPartnerStore(id);
      }
      async getPartnerStoreBySlug(slug) {
        return this.primary.getPartnerStoreBySlug(slug);
      }
      async createPartnerStore(store) {
        return this.primary.createPartnerStore(store);
      }
      async updatePartnerStore(id, store) {
        return this.primary.updatePartnerStore(id, store);
      }
      async deletePartnerStore(id) {
        return this.primary.deletePartnerStore(id);
      }
      // Partner Store Products
      async getPartnerStoreProducts(partnerStoreId) {
        return this.primary.getPartnerStoreProducts(partnerStoreId);
      }
      async getPartnerStoreProduct(partnerStoreId, productId) {
        return this.primary.getPartnerStoreProduct(partnerStoreId, productId);
      }
      async getProductsForStore(storeSlug, segment) {
        return this.primary.getProductsForStore(storeSlug, segment);
      }
      async addPartnerStoreProduct(product) {
        return this.primary.addPartnerStoreProduct(product);
      }
      async updatePartnerStoreProduct(id, product) {
        return this.primary.updatePartnerStoreProduct(id, product);
      }
      async updatePartnerStoreProductByIds(partnerStoreId, productId, product) {
        return this.primary.updatePartnerStoreProductByIds(partnerStoreId, productId, product);
      }
      async removePartnerStoreProduct(id) {
        return this.primary.removePartnerStoreProduct(id);
      }
      async syncPartnerStoreProducts(partnerStoreId, productIds) {
        return this.primary.syncPartnerStoreProducts(partnerStoreId, productIds);
      }
      // Product Variants
      async getProductVariants(productId) {
        return this.primary.getProductVariants(productId);
      }
      async upsertProductVariant(variant) {
        return this.primary.upsertProductVariant(variant);
      }
      async toggleVariantEnabled(id, enabled) {
        return this.primary.toggleVariantEnabled(id, enabled);
      }
      // Printify Blueprints
      async getPrintifyBlueprints() {
        return this.primary.getPrintifyBlueprints();
      }
      async getPrintifyBlueprint(id) {
        return this.primary.getPrintifyBlueprint(id);
      }
      async upsertPrintifyBlueprint(blueprint) {
        return this.primary.upsertPrintifyBlueprint(blueprint);
      }
      async deletePrintifyBlueprint(id) {
        return this.primary.deletePrintifyBlueprint(id);
      }
      async clearPrintifyBlueprints() {
        return this.primary.clearPrintifyBlueprints();
      }
      // Printify Print Providers
      async getAllPrintifyProviders() {
        return this.primary.getAllPrintifyProviders();
      }
      async getPrintifyPrintProviders(blueprintId) {
        return this.primary.getPrintifyPrintProviders(blueprintId);
      }
      async getPrintifyPrintProvider(blueprintId, providerId) {
        return this.primary.getPrintifyPrintProvider(blueprintId, providerId);
      }
      async upsertPrintifyPrintProvider(provider) {
        return this.primary.upsertPrintifyPrintProvider(provider);
      }
      async updatePrintifyProviderCosts(blueprintId, providerId, costs) {
        return this.primary.updatePrintifyProviderCosts(blueprintId, providerId, costs);
      }
      async updateProductPricesByProvider(blueprintId, providerId, basePrice) {
        return this.primary.updateProductPricesByProvider(blueprintId, providerId, basePrice);
      }
      async deletePrintifyPrintProvidersByBlueprint(blueprintId) {
        return this.primary.deletePrintifyPrintProvidersByBlueprint(blueprintId);
      }
      async clearPrintifyPrintProviders() {
        return this.primary.clearPrintifyPrintProviders();
      }
      // Catalog Sync
      async createCatalogSync(sync) {
        return this.primary.createCatalogSync(sync);
      }
      async updateCatalogSync(id, sync) {
        return this.primary.updateCatalogSync(id, sync);
      }
      async getLatestCatalogSync() {
        return this.primary.getLatestCatalogSync();
      }
      async getCatalogSyncHistory() {
        return this.primary.getCatalogSyncHistory();
      }
      // Cost Sync
      async createCostSync(sync) {
        return this.primary.createCostSync(sync);
      }
      async updateCostSync(id, sync) {
        return this.primary.updateCostSync(id, sync);
      }
      async getLatestCostSync() {
        return this.primary.getLatestCostSync();
      }
      async getActiveCostSync() {
        return this.primary.getActiveCostSync();
      }
      async getCostSyncHistory() {
        return this.primary.getCostSyncHistory();
      }
      async getProviderCostStats() {
        return this.primary.getProviderCostStats();
      }
      // Template Categories
      async getTemplateCategories() {
        return this.primary.getTemplateCategories();
      }
      async getTemplateCategoriesByParent(parentId) {
        return this.primary.getTemplateCategoriesByParent(parentId);
      }
      async createTemplateCategory(category) {
        return this.primary.createTemplateCategory(category);
      }
      async updateTemplateCategory(id, category) {
        return this.primary.updateTemplateCategory(id, category);
      }
      async deleteTemplateCategory(id) {
        return this.primary.deleteTemplateCategory(id);
      }
      // Graphic Sets
      async getGraphicSets() {
        return this.primary.getGraphicSets();
      }
      async getGraphicSet(id) {
        return this.primary.getGraphicSet(id);
      }
      async getGraphicSetsByCategory(categoryId) {
        return this.primary.getGraphicSetsByCategory(categoryId);
      }
      async createGraphicSet(graphicSet) {
        const result = await this.primary.createGraphicSet(graphicSet);
        try {
          await this.secondary.createGraphicSet({ ...graphicSet, id: result.id });
        } catch (error) {
          this.logDualWriteError("createGraphicSet", error);
        }
        return result;
      }
      async updateGraphicSet(id, graphicSet) {
        const result = await this.primary.updateGraphicSet(id, graphicSet);
        try {
          await this.secondary.updateGraphicSet(id, graphicSet);
        } catch (error) {
          this.logDualWriteError("updateGraphicSet", error);
        }
        return result;
      }
      async deleteGraphicSet(id) {
        await this.primary.deleteGraphicSet(id);
        await this.mirrorWriteVoid("deleteGraphicSet", () => this.secondary.deleteGraphicSet(id));
      }
      async incrementGraphicSetUsage(id) {
        await this.primary.incrementGraphicSetUsage(id);
        await this.mirrorWriteVoid("incrementGraphicSetUsage", () => this.secondary.incrementGraphicSetUsage(id));
      }
      // Library Assets
      async getLibraryAsset(id) {
        return this.primary.getLibraryAsset(id);
      }
      async getLibraryAssetByUrl(url) {
        return this.primary.getLibraryAssetByUrl(url);
      }
      async getLibraryAssets(filters) {
        return this.primary.getLibraryAssets(filters);
      }
      async getAdminLibraryAssets(filters) {
        return this.primary.getAdminLibraryAssets(filters);
      }
      async getUserLibraryAssets(userId, filters) {
        return this.primary.getUserLibraryAssets(userId, filters);
      }
      async createLibraryAsset(asset) {
        return this.primary.createLibraryAsset(asset);
      }
      async updateLibraryAsset(id, asset) {
        return this.primary.updateLibraryAsset(id, asset);
      }
      async deleteLibraryAsset(id) {
        return this.primary.deleteLibraryAsset(id);
      }
      async incrementLibraryAssetUsage(id) {
        return this.primary.incrementLibraryAssetUsage(id);
      }
      // Master Products
      async getAllMasterProducts() {
        return this.primary.getAllMasterProducts();
      }
      async getMasterProduct(id) {
        return this.primary.getMasterProduct(id);
      }
      async createMasterProduct(product) {
        return this.primary.createMasterProduct(product);
      }
      async updateMasterProduct(id, product) {
        return this.primary.updateMasterProduct(id, product);
      }
      async deleteMasterProduct(id) {
        return this.primary.deleteMasterProduct(id);
      }
      // Design Versions
      async getDesignVersions(masterProductId) {
        return this.primary.getDesignVersions(masterProductId);
      }
      async getActiveDesignVersion(masterProductId) {
        return this.primary.getActiveDesignVersion(masterProductId);
      }
      async createDesignVersion(version) {
        return this.primary.createDesignVersion(version);
      }
      async updateDesignVersion(id, version) {
        return this.primary.updateDesignVersion(id, version);
      }
      // Channel Configs
      async getAllChannelConfigs() {
        return this.primary.getAllChannelConfigs();
      }
      async getChannelConfig(channelType) {
        return this.primary.getChannelConfig(channelType);
      }
      async createChannelConfig(config) {
        return this.primary.createChannelConfig(config);
      }
      async updateChannelConfig(channelType, config) {
        return this.primary.updateChannelConfig(channelType, config);
      }
      // Publish States
      async getPublishStates(masterProductId) {
        return this.primary.getPublishStates(masterProductId);
      }
      async getPublishState(masterProductId, channelType) {
        return this.primary.getPublishState(masterProductId, channelType);
      }
      async upsertPublishState(state) {
        return this.primary.upsertPublishState(state);
      }
      // Provider Health
      async logProviderHealth(log2) {
        return this.primary.logProviderHealth(log2);
      }
      async getProviderHealthLogs(limit) {
        return this.primary.getProviderHealthLogs(limit);
      }
      async getProviderHealthLogsByType(providerType, limit) {
        return this.primary.getProviderHealthLogsByType(providerType, limit);
      }
      async getLatestProviderHealth(providerType) {
        return this.primary.getLatestProviderHealth(providerType);
      }
      async getAllLatestProviderHealth() {
        return this.primary.getAllLatestProviderHealth();
      }
      async getProviderHealthStats(providerType, hours) {
        return this.primary.getProviderHealthStats(providerType, hours);
      }
      // Gift Packages
      async getAllGiftPackages() {
        return this.primary.getAllGiftPackages();
      }
      async getActiveGiftPackages() {
        return this.primary.getActiveGiftPackages();
      }
      async getGiftPackage(id) {
        return this.primary.getGiftPackage(id);
      }
      async createGiftPackage(pkg) {
        return this.primary.createGiftPackage(pkg);
      }
      async updateGiftPackage(id, pkg) {
        return this.primary.updateGiftPackage(id, pkg);
      }
      async deleteGiftPackage(id) {
        return this.primary.deleteGiftPackage(id);
      }
      // Gift Codes
      async getGiftCode(id) {
        return this.primary.getGiftCode(id);
      }
      async getGiftCodeByCode(code) {
        return this.primary.getGiftCodeByCode(code);
      }
      async getGiftCodesByBuyer(buyerUserId) {
        return this.primary.getGiftCodesByBuyer(buyerUserId);
      }
      async createGiftCode(code) {
        return this.primary.createGiftCode(code);
      }
      async updateGiftCode(id, code) {
        return this.primary.updateGiftCode(id, code);
      }
      // Gift Redemptions
      async getGiftRedemption(id) {
        return this.primary.getGiftRedemption(id);
      }
      async getGiftRedemptionByCode(giftCodeId) {
        return this.primary.getGiftRedemptionByCode(giftCodeId);
      }
      async getGiftRedemptionsByRecipient(recipientEmail) {
        return this.primary.getGiftRedemptionsByRecipient(recipientEmail);
      }
      async createGiftRedemption(redemption) {
        return this.primary.createGiftRedemption(redemption);
      }
      async updateGiftRedemption(id, redemption) {
        return this.primary.updateGiftRedemption(id, redemption);
      }
      // Email Templates
      async getEmailTemplates() {
        return this.primary.getEmailTemplates();
      }
      async getEmailTemplate(id) {
        return this.primary.getEmailTemplate(id);
      }
      async getEmailTemplateByTrigger(trigger) {
        return this.primary.getEmailTemplateByTrigger(trigger);
      }
      async createEmailTemplate(template) {
        return this.primary.createEmailTemplate(template);
      }
      async updateEmailTemplate(id, template) {
        return this.primary.updateEmailTemplate(id, template);
      }
      async deleteEmailTemplate(id) {
        return this.primary.deleteEmailTemplate(id);
      }
      // Email Logs
      async getEmailLogs(limit) {
        return this.primary.getEmailLogs(limit);
      }
      async logEmail(log2) {
        return this.primary.logEmail(log2);
      }
    };
  }
});

// server/storage.ts
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { eq, sql as sql2, and, or, ilike } from "drizzle-orm";
async function initializeWrappedStorage() {
  if (wrappedStorage && storageInitialized) {
    return wrappedStorage;
  }
  if (initPromise) {
    return initPromise;
  }
  initPromise = (async () => {
    const mode = process.env.STORAGE_MODE || "postgres-only";
    console.log(`[Storage] Initializing with mode: ${mode}`);
    if (mode === "dual-write") {
      try {
        const { FirestoreAdapter: FirestoreAdapter2 } = await Promise.resolve().then(() => (init_firestore_adapter(), firestore_adapter_exports));
        const { DualWriteAdapter: DualWriteAdapter2 } = await Promise.resolve().then(() => (init_dual_write_adapter(), dual_write_adapter_exports));
        const firestoreAdapter = new FirestoreAdapter2();
        wrappedStorage = new DualWriteAdapter2(baseStorage, firestoreAdapter);
        console.log("[Storage] Dual-write mode enabled - writes sync to Firestore");
      } catch (error) {
        console.error("[Storage] Failed to initialize dual-write mode, falling back to postgres-only:", error);
        wrappedStorage = baseStorage;
      }
    } else if (mode === "firestore-only") {
      try {
        const { FirestoreAdapter: FirestoreAdapter2 } = await Promise.resolve().then(() => (init_firestore_adapter(), firestore_adapter_exports));
        wrappedStorage = new FirestoreAdapter2();
        console.log("[Storage] Firestore-only mode enabled");
      } catch (error) {
        console.error("[Storage] Failed to initialize firestore-only mode, falling back to postgres-only:", error);
        wrappedStorage = baseStorage;
      }
    } else {
      wrappedStorage = baseStorage;
    }
    storageInitialized = true;
    return wrappedStorage;
  })();
  return initPromise;
}
function getStorageMode() {
  return process.env.STORAGE_MODE || "firestore-only";
}
var DATABASE_URL, neonSql, db2, DbStorage, MemStorage, baseStorage, wrappedStorage, storageInitialized, initPromise, storage;
var init_storage = __esm({
  "server/storage.ts"() {
    "use strict";
    init_schema();
    DATABASE_URL = process.env.DATABASE_URL;
    neonSql = DATABASE_URL ? neon(DATABASE_URL) : null;
    db2 = neonSql ? drizzle(neonSql, { schema: schema_exports }) : null;
    DbStorage = class {
      db = db2;
      // Safe because DbStorage is only used when db is non-null
      // User operations
      async getUser(id) {
        const [user] = await this.db.select().from(users).where(eq(users.id, id));
        return user;
      }
      async getUserByEmail(email) {
        const [user] = await this.db.select().from(users).where(eq(users.email, email));
        return user;
      }
      async createUser(user) {
        const [newUser] = await this.db.insert(users).values(user).returning();
        return newUser;
      }
      async upsertUser(userData) {
        const existingUser = await this.getUserByEmail(userData.email);
        if (existingUser) {
          const [updated] = await this.db.update(users).set({
            ...userData,
            updatedAt: /* @__PURE__ */ new Date()
          }).where(eq(users.id, existingUser.id)).returning();
          return updated;
        }
        const [user] = await this.db.insert(users).values(userData).returning();
        return user;
      }
      // Browsing history operations
      async getBrowsingHistory(userId) {
        return this.db.select().from(browsingHistory).where(eq(browsingHistory.userId, userId));
      }
      async addBrowsingHistory(entry) {
        const [newEntry] = await this.db.insert(browsingHistory).values(entry).returning();
        return newEntry;
      }
      async clearBrowsingHistory(userId) {
        await this.db.delete(browsingHistory).where(eq(browsingHistory.userId, userId));
      }
      // QR Design operations
      async getQrDesign(id) {
        const [design] = await this.db.select().from(qrDesigns).where(eq(qrDesigns.id, id));
        return design;
      }
      async getQrDesignsByUser(userId) {
        return this.db.select().from(qrDesigns).where(eq(qrDesigns.userId, userId));
      }
      async createQrDesign(design) {
        const [newDesign] = await this.db.insert(qrDesigns).values(design).returning();
        return newDesign;
      }
      async updateQrDesign(id, design) {
        const [updated] = await this.db.update(qrDesigns).set({ ...design, updatedAt: /* @__PURE__ */ new Date() }).where(eq(qrDesigns.id, id)).returning();
        return updated;
      }
      async deleteQrDesign(id) {
        await this.db.delete(qrDesigns).where(eq(qrDesigns.id, id));
      }
      async getPublicGalleryDesigns() {
        return this.db.select().from(qrDesigns).where(eq(qrDesigns.showInGallery, true)).orderBy(qrDesigns.createdAt);
      }
      // Product operations
      async getProduct(id) {
        const [product] = await this.db.select().from(products).where(eq(products.id, id));
        return product;
      }
      async getAllProducts() {
        return this.db.select().from(products);
      }
      async createProduct(product) {
        const [newProduct] = await this.db.insert(products).values(product).returning();
        return newProduct;
      }
      async updateProduct(id, product) {
        const [updated] = await this.db.update(products).set({ ...product, updatedAt: /* @__PURE__ */ new Date() }).where(eq(products.id, id)).returning();
        return updated;
      }
      async deleteProduct(id) {
        await this.db.delete(productCategoryAssignments).where(eq(productCategoryAssignments.productId, id));
        await this.db.delete(productVariants).where(eq(productVariants.productId, id));
        await this.db.delete(partnerStoreProducts).where(eq(partnerStoreProducts.productId, id));
        await this.db.delete(cartItems).where(eq(cartItems.productId, id));
        await this.db.delete(products).where(eq(products.id, id));
      }
      // Cart operations
      async getCartItemsByUser(userId) {
        return this.db.select().from(cartItems).where(eq(cartItems.userId, userId));
      }
      async addCartItem(item) {
        const [newItem] = await this.db.insert(cartItems).values(item).returning();
        return newItem;
      }
      async updateCartItem(id, quantity) {
        const [updated] = await this.db.update(cartItems).set({ quantity }).where(eq(cartItems.id, id)).returning();
        return updated;
      }
      async deleteCartItem(id) {
        await this.db.delete(cartItems).where(eq(cartItems.id, id));
      }
      async clearCart(userId) {
        await this.db.delete(cartItems).where(eq(cartItems.userId, userId));
      }
      // Order operations
      async getOrder(id) {
        const [order] = await this.db.select().from(orders).where(eq(orders.id, id));
        return order;
      }
      async getOrdersByUser(userId) {
        return this.db.select().from(orders).where(eq(orders.userId, userId));
      }
      async getOrdersByStatus(status) {
        return this.db.select().from(orders).where(eq(orders.status, status));
      }
      async getOrderByStripeSession(sessionId) {
        const [order] = await this.db.select().from(orders).where(eq(orders.stripeSessionId, sessionId));
        return order;
      }
      async createOrder(order) {
        const [newOrder] = await this.db.insert(orders).values(order).returning();
        return newOrder;
      }
      async updateOrder(id, order) {
        const [updated] = await this.db.update(orders).set({ ...order, updatedAt: /* @__PURE__ */ new Date() }).where(eq(orders.id, id)).returning();
        return updated;
      }
      // Order Item operations
      async getOrderItems(orderId) {
        return this.db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
      }
      async createOrderItem(item) {
        const [newItem] = await this.db.insert(orderItems).values(item).returning();
        return newItem;
      }
      // Hosted Image operations
      async getHostedImage(id) {
        const [image] = await this.db.select().from(hostedImages).where(eq(hostedImages.id, id));
        return image;
      }
      async getHostedImagesByUser(userId) {
        return this.db.select().from(hostedImages).where(eq(hostedImages.userId, userId));
      }
      async getAllHostedImages() {
        return this.db.select().from(hostedImages);
      }
      async createHostedImage(image) {
        const [newImage] = await this.db.insert(hostedImages).values(image).returning();
        return newImage;
      }
      async updateHostedImage(id, image) {
        const [updated] = await this.db.update(hostedImages).set(image).where(eq(hostedImages.id, id)).returning();
        return updated;
      }
      async incrementImageViews(id) {
        const image = await this.getHostedImage(id);
        if (image) {
          await this.db.update(hostedImages).set({ views: (image.views || 0) + 1 }).where(eq(hostedImages.id, id));
        }
      }
      async deleteHostedImage(id) {
        await this.db.delete(hostedImages).where(eq(hostedImages.id, id));
      }
      // Hosting Reminder operations
      async getHostingReminderByImageAndDays(imageId, daysRemaining) {
        const reminderType = `${daysRemaining}_day`;
        const results = await this.db.select().from(hostingReminders).where(eq(hostingReminders.customGiftId, imageId));
        return results.find((r) => r.reminderType === reminderType);
      }
      async createHostingReminder(reminder) {
        const [newReminder] = await this.db.insert(hostingReminders).values(reminder).returning();
        return newReminder;
      }
      // Admin Settings operations
      async getAdminSettings() {
        const [settings] = await this.db.select().from(adminSettings).where(eq(adminSettings.id, "default"));
        return settings;
      }
      async upsertAdminSettings(settings) {
        const [result] = await this.db.insert(adminSettings).values({ ...settings, id: "default" }).onConflictDoUpdate({
          target: adminSettings.id,
          set: { ...settings, updatedAt: /* @__PURE__ */ new Date() }
        }).returning();
        return result;
      }
      // Pricing Rules operations
      async getPricingRules() {
        return this.db.select().from(pricingRules);
      }
      async getPricingRule(id) {
        const [rule] = await this.db.select().from(pricingRules).where(eq(pricingRules.id, id));
        return rule;
      }
      async createPricingRule(rule) {
        const [newRule] = await this.db.insert(pricingRules).values(rule).returning();
        return newRule;
      }
      async updatePricingRule(id, rule) {
        const [updated] = await this.db.update(pricingRules).set(rule).where(eq(pricingRules.id, id)).returning();
        return updated;
      }
      async deletePricingRule(id) {
        await this.db.delete(pricingRules).where(eq(pricingRules.id, id));
      }
      // Admin Product operations
      async getEnabledProducts() {
        return this.db.select().from(products).where(eq(products.isEnabled, true));
      }
      async toggleProductEnabled(id, enabled) {
        const [updated] = await this.db.update(products).set({ isEnabled: enabled, updatedAt: /* @__PURE__ */ new Date() }).where(eq(products.id, id)).returning();
        return updated;
      }
      // Hosting Tier operations
      async getHostingTiers() {
        return this.db.select().from(hostingTiers);
      }
      async getHostingTier(id) {
        const [tier] = await this.db.select().from(hostingTiers).where(eq(hostingTiers.id, id));
        return tier;
      }
      async getHostingTierByCode(code) {
        const [tier] = await this.db.select().from(hostingTiers).where(eq(hostingTiers.code, code));
        return tier;
      }
      async createHostingTier(tier) {
        const [newTier] = await this.db.insert(hostingTiers).values(tier).returning();
        return newTier;
      }
      async updateHostingTier(id, tier) {
        const [updated] = await this.db.update(hostingTiers).set(tier).where(eq(hostingTiers.id, id)).returning();
        return updated;
      }
      async deleteHostingTier(id) {
        await this.db.delete(hostingTiers).where(eq(hostingTiers.id, id));
      }
      // Coupon operations
      async getCoupons() {
        return this.db.select().from(coupons);
      }
      async getActiveCoupons() {
        return this.db.select().from(coupons).where(eq(coupons.isActive, true));
      }
      async getCoupon(id) {
        const [coupon] = await this.db.select().from(coupons).where(eq(coupons.id, id));
        return coupon;
      }
      async getCouponByCode(code) {
        const [coupon] = await this.db.select().from(coupons).where(eq(coupons.code, code.toUpperCase()));
        return coupon;
      }
      async createCoupon(coupon) {
        const [newCoupon] = await this.db.insert(coupons).values({
          ...coupon,
          code: coupon.code.toUpperCase()
        }).returning();
        return newCoupon;
      }
      async updateCoupon(id, coupon) {
        const updateData = coupon.code ? { ...coupon, code: coupon.code.toUpperCase(), updatedAt: /* @__PURE__ */ new Date() } : { ...coupon, updatedAt: /* @__PURE__ */ new Date() };
        const [updated] = await this.db.update(coupons).set(updateData).where(eq(coupons.id, id)).returning();
        return updated;
      }
      async deleteCoupon(id) {
        await this.db.delete(coupons).where(eq(coupons.id, id));
      }
      async incrementCouponRedemption(id) {
        await this.db.update(coupons).set({ redemptionCount: sql2`${coupons.redemptionCount} + 1` }).where(eq(coupons.id, id));
      }
      // QR Template operations
      async getQrTemplates() {
        return this.db.select().from(qrTemplates);
      }
      async getActiveQrTemplates() {
        return this.db.select().from(qrTemplates).where(eq(qrTemplates.isActive, true));
      }
      async getQrTemplate(id) {
        const [template] = await this.db.select().from(qrTemplates).where(eq(qrTemplates.id, id));
        return template;
      }
      async createQrTemplate(template) {
        const [newTemplate] = await this.db.insert(qrTemplates).values(template).returning();
        return newTemplate;
      }
      async updateQrTemplate(id, template) {
        const [updated] = await this.db.update(qrTemplates).set(template).where(eq(qrTemplates.id, id)).returning();
        return updated;
      }
      async deleteQrTemplate(id) {
        await this.db.delete(qrTemplates).where(eq(qrTemplates.id, id));
      }
      // Dynamic Page operations
      async getDynamicPage(id) {
        const [page] = await this.db.select().from(dynamicPages).where(eq(dynamicPages.id, id));
        return page;
      }
      async getDynamicPageBySlug(slug) {
        const [page] = await this.db.select().from(dynamicPages).where(eq(dynamicPages.slug, slug));
        return page;
      }
      async getDynamicPagesByUser(userId) {
        return this.db.select().from(dynamicPages).where(eq(dynamicPages.userId, userId));
      }
      async createDynamicPage(page) {
        const [newPage] = await this.db.insert(dynamicPages).values(page).returning();
        return newPage;
      }
      async updateDynamicPage(id, page) {
        const [updated] = await this.db.update(dynamicPages).set({ ...page, updatedAt: /* @__PURE__ */ new Date() }).where(eq(dynamicPages.id, id)).returning();
        return updated;
      }
      async deleteDynamicPage(id) {
        await this.db.delete(dynamicPageAssets).where(eq(dynamicPageAssets.pageId, id));
        await this.db.delete(dynamicPages).where(eq(dynamicPages.id, id));
      }
      async incrementDynamicPageViews(id) {
        await this.db.update(dynamicPages).set({ views: sql2`${dynamicPages.views} + 1` }).where(eq(dynamicPages.id, id));
      }
      // Dynamic Page Asset operations
      async getDynamicPageAsset(id) {
        const [asset] = await this.db.select().from(dynamicPageAssets).where(eq(dynamicPageAssets.id, id));
        return asset;
      }
      async getDynamicPageAssets(pageId) {
        return this.db.select().from(dynamicPageAssets).where(eq(dynamicPageAssets.pageId, pageId));
      }
      async createDynamicPageAsset(asset) {
        const [newAsset] = await this.db.insert(dynamicPageAssets).values(asset).returning();
        return newAsset;
      }
      async updateDynamicPageAsset(id, asset) {
        const [updated] = await this.db.update(dynamicPageAssets).set(asset).where(eq(dynamicPageAssets.id, id)).returning();
        return updated;
      }
      async deleteDynamicPageAsset(id) {
        await this.db.delete(dynamicPageAssets).where(eq(dynamicPageAssets.id, id));
      }
      async setActiveAsset(pageId, assetId) {
        await this.db.update(dynamicPageAssets).set({ isActive: false, activatedAt: null }).where(eq(dynamicPageAssets.pageId, pageId));
        await this.db.update(dynamicPageAssets).set({ isActive: true, activatedAt: /* @__PURE__ */ new Date() }).where(eq(dynamicPageAssets.id, assetId));
        await this.db.update(dynamicPages).set({ activeAssetId: assetId, updatedAt: /* @__PURE__ */ new Date() }).where(eq(dynamicPages.id, pageId));
      }
      // Product Category operations
      async getProductCategories() {
        return await this.db.select().from(productCategories).orderBy(productCategories.sortOrder);
      }
      async getAllProductCategories() {
        return await this.db.select().from(productCategories).orderBy(productCategories.sortOrder);
      }
      async getActiveProductCategories() {
        return await this.db.select().from(productCategories).where(eq(productCategories.isActive, true)).orderBy(productCategories.sortOrder);
      }
      async getProductCategoriesByTaxonomy(taxonomyType) {
        return await this.db.select().from(productCategories).where(eq(productCategories.taxonomyType, taxonomyType)).orderBy(productCategories.sortOrder);
      }
      async getProductCategory(id) {
        const [category] = await this.db.select().from(productCategories).where(eq(productCategories.id, id));
        return category;
      }
      async createProductCategory(category) {
        const [newCategory] = await this.db.insert(productCategories).values(category).returning();
        return newCategory;
      }
      async updateProductCategory(id, category) {
        const [updated] = await this.db.update(productCategories).set(category).where(eq(productCategories.id, id)).returning();
        return updated;
      }
      async deleteProductCategory(id) {
        await this.db.delete(productCategoryAssignments).where(eq(productCategoryAssignments.categoryId, id));
        await this.db.delete(productCategories).where(eq(productCategories.id, id));
      }
      // Product Category Assignment operations
      async getProductCategoryAssignments(productId) {
        return await this.db.select().from(productCategoryAssignments).where(eq(productCategoryAssignments.productId, productId));
      }
      async getProductsByCategory(categoryId) {
        const assignments = await this.db.select().from(productCategoryAssignments).where(eq(productCategoryAssignments.categoryId, categoryId));
        const productIds = assignments.map((a) => a.productId);
        if (productIds.length === 0) return [];
        const products2 = await this.db.select().from(products);
        return products2.filter((p) => productIds.includes(p.id));
      }
      async assignProductToCategory(assignment) {
        const [newAssignment] = await this.db.insert(productCategoryAssignments).values(assignment).returning();
        return newAssignment;
      }
      async removeProductFromCategory(productId, categoryId) {
        const assignments = await this.db.select().from(productCategoryAssignments).where(eq(productCategoryAssignments.productId, productId));
        const toDelete = assignments.find((a) => a.categoryId === categoryId);
        if (toDelete) {
          await this.db.delete(productCategoryAssignments).where(eq(productCategoryAssignments.id, toDelete.id));
        }
      }
      async syncProductCategories(productId, categoryIds) {
        await this.db.delete(productCategoryAssignments).where(eq(productCategoryAssignments.productId, productId));
        if (categoryIds.length > 0) {
          const assignments = categoryIds.map((categoryId) => ({
            productId,
            categoryId
          }));
          await this.db.insert(productCategoryAssignments).values(assignments);
        }
      }
      // Partner Store operations
      async getPartnerStores() {
        return await this.db.select().from(partnerStores);
      }
      async getPartnerStore(id) {
        const [store] = await this.db.select().from(partnerStores).where(eq(partnerStores.id, id));
        return store;
      }
      async getPartnerStoreBySlug(slug) {
        const [store] = await this.db.select().from(partnerStores).where(eq(partnerStores.slug, slug));
        return store;
      }
      async createPartnerStore(store) {
        const [newStore] = await this.db.insert(partnerStores).values(store).returning();
        return newStore;
      }
      async updatePartnerStore(id, store) {
        const [updated] = await this.db.update(partnerStores).set({ ...store, updatedAt: /* @__PURE__ */ new Date() }).where(eq(partnerStores.id, id)).returning();
        return updated;
      }
      async deletePartnerStore(id) {
        await this.db.delete(partnerStoreProducts).where(eq(partnerStoreProducts.partnerStoreId, id));
        await this.db.delete(partnerStores).where(eq(partnerStores.id, id));
      }
      // Partner Store Product operations
      async getPartnerStoreProducts(partnerStoreId) {
        return await this.db.select().from(partnerStoreProducts).where(eq(partnerStoreProducts.partnerStoreId, partnerStoreId));
      }
      async getPartnerStoreProduct(partnerStoreId, productId) {
        const [result] = await this.db.select().from(partnerStoreProducts).where(and(
          eq(partnerStoreProducts.partnerStoreId, partnerStoreId),
          eq(partnerStoreProducts.productId, productId)
        ));
        return result;
      }
      async getProductsForStore(storeSlug, segment) {
        const [store] = await this.db.select().from(partnerStores).where(or(
          eq(partnerStores.slug, storeSlug),
          ilike(partnerStores.slug, `${storeSlug}%`),
          ilike(partnerStores.name, storeSlug),
          ilike(partnerStores.name, `%${storeSlug}%`)
        ));
        if (!store) {
          return [];
        }
        const storeProducts = await this.db.select({ product: products }).from(partnerStoreProducts).innerJoin(products, eq(partnerStoreProducts.productId, products.id)).where(and(
          eq(partnerStoreProducts.partnerStoreId, store.id),
          eq(partnerStoreProducts.isEnabled, true),
          eq(products.isEnabled, true)
        ));
        let products2 = storeProducts.map((sp) => sp.product);
        if (segment) {
          products2 = products2.filter((p) => {
            const category = p.category?.toLowerCase() || "";
            return category.includes(`/${segment.toLowerCase()}`);
          });
        }
        return products2;
      }
      async addPartnerStoreProduct(product) {
        const [newProduct] = await this.db.insert(partnerStoreProducts).values(product).returning();
        return newProduct;
      }
      async updatePartnerStoreProduct(id, product) {
        const [updated] = await this.db.update(partnerStoreProducts).set(product).where(eq(partnerStoreProducts.id, id)).returning();
        return updated;
      }
      async updatePartnerStoreProductByIds(partnerStoreId, productId, product) {
        const [updated] = await this.db.update(partnerStoreProducts).set(product).where(and(
          eq(partnerStoreProducts.partnerStoreId, partnerStoreId),
          eq(partnerStoreProducts.productId, productId)
        )).returning();
        return updated;
      }
      async removePartnerStoreProduct(id) {
        await this.db.delete(partnerStoreProducts).where(eq(partnerStoreProducts.id, id));
      }
      async syncPartnerStoreProducts(partnerStoreId, productIds) {
        const existingProducts = await this.db.select().from(partnerStoreProducts).where(eq(partnerStoreProducts.partnerStoreId, partnerStoreId));
        const existingConfigs = /* @__PURE__ */ new Map();
        existingProducts.forEach((p) => existingConfigs.set(p.productId, p));
        await this.db.delete(partnerStoreProducts).where(eq(partnerStoreProducts.partnerStoreId, partnerStoreId));
        if (productIds.length > 0) {
          const productsToInsert = await Promise.all(productIds.map(async (productId, index2) => {
            const existingConfig = existingConfigs.get(productId);
            if (existingConfig) {
              return {
                partnerStoreId,
                productId,
                sortOrder: index2,
                enabledSizes: existingConfig.enabledSizes,
                enabledColors: existingConfig.enabledColors,
                defaultColor: existingConfig.defaultColor,
                kcPlacements: existingConfig.kcPlacements,
                kcBusinessSlug: existingConfig.kcBusinessSlug,
                customPrice: existingConfig.customPrice,
                customName: existingConfig.customName,
                isEnabled: existingConfig.isEnabled
              };
            } else {
              const sourceProduct = await this.getProduct(productId);
              const availableSizes = Array.isArray(sourceProduct?.availableSizes) ? sourceProduct.availableSizes : null;
              const availableColors = Array.isArray(sourceProduct?.availableColors) ? sourceProduct.availableColors.map((c) => c.name) : null;
              return {
                partnerStoreId,
                productId,
                sortOrder: index2,
                enabledSizes: availableSizes,
                enabledColors: availableColors
              };
            }
          }));
          await this.db.insert(partnerStoreProducts).values(productsToInsert);
        }
      }
      // Product Variant operations
      async getProductVariants(productId) {
        return await this.db.select().from(productVariants).where(eq(productVariants.productId, productId));
      }
      async upsertProductVariant(variant) {
        const [result] = await this.db.insert(productVariants).values(variant).onConflictDoUpdate({
          target: [productVariants.productId, productVariants.printifyVariantId],
          set: {
            title: variant.title,
            size: variant.size,
            color: variant.color,
            colorHex: variant.colorHex,
            price: variant.price
          }
        }).returning();
        return result;
      }
      async toggleVariantEnabled(id, enabled) {
        const [updated] = await this.db.update(productVariants).set({ isEnabled: enabled }).where(eq(productVariants.id, id)).returning();
        return updated;
      }
      // Printify Catalog operations
      async getPrintifyBlueprints() {
        return await this.db.select().from(printifyBlueprints);
      }
      async getPrintifyBlueprint(id) {
        const [blueprint] = await this.db.select().from(printifyBlueprints).where(eq(printifyBlueprints.id, id));
        return blueprint;
      }
      async upsertPrintifyBlueprint(blueprint) {
        const [result] = await this.db.insert(printifyBlueprints).values(blueprint).onConflictDoUpdate({
          target: printifyBlueprints.id,
          set: {
            title: blueprint.title,
            description: blueprint.description,
            brand: blueprint.brand,
            model: blueprint.model,
            images: blueprint.images,
            primaryImageUrl: blueprint.primaryImageUrl,
            category: blueprint.category,
            lastSyncedAt: /* @__PURE__ */ new Date()
          }
        }).returning();
        return result;
      }
      async deletePrintifyBlueprint(id) {
        await this.db.delete(printifyBlueprints).where(eq(printifyBlueprints.id, id));
      }
      async clearPrintifyBlueprints() {
        await this.db.delete(printifyBlueprints);
      }
      // Printify Print Provider operations
      async getAllPrintifyProviders() {
        return await this.db.select().from(printifyPrintProviders);
      }
      async getPrintifyPrintProviders(blueprintId) {
        return await this.db.select().from(printifyPrintProviders).where(eq(printifyPrintProviders.blueprintId, blueprintId));
      }
      async getPrintifyPrintProvider(blueprintId, providerId) {
        const [provider] = await this.db.select().from(printifyPrintProviders).where(and(
          eq(printifyPrintProviders.blueprintId, blueprintId),
          eq(printifyPrintProviders.providerId, providerId)
        ));
        return provider;
      }
      async upsertPrintifyPrintProvider(provider) {
        const existingProviders = await this.db.select().from(printifyPrintProviders).where(and(
          eq(printifyPrintProviders.blueprintId, provider.blueprintId),
          eq(printifyPrintProviders.providerId, provider.providerId)
        ));
        if (existingProviders.length > 0) {
          const [updated] = await this.db.update(printifyPrintProviders).set({
            title: provider.title,
            country: provider.country,
            isUSA: provider.isUSA,
            lastSyncedAt: /* @__PURE__ */ new Date()
          }).where(eq(printifyPrintProviders.id, existingProviders[0].id)).returning();
          return updated;
        }
        const [result] = await this.db.insert(printifyPrintProviders).values(provider).returning();
        return result;
      }
      async updatePrintifyProviderCosts(blueprintId, providerId, costs) {
        const updateData = {
          minCost: costs.minCost,
          maxCost: costs.maxCost,
          placeholderProductId: costs.placeholderProductId ?? null,
          costsFetchedAt: /* @__PURE__ */ new Date()
        };
        if (costs.availableColors !== void 0) {
          updateData.availableColors = costs.availableColors;
        }
        if (costs.availableSizes !== void 0) {
          updateData.availableSizes = costs.availableSizes;
        }
        const [updated] = await this.db.update(printifyPrintProviders).set(updateData).where(and(
          eq(printifyPrintProviders.blueprintId, blueprintId),
          eq(printifyPrintProviders.providerId, providerId)
        )).returning();
        return updated;
      }
      async updateProductPricesByProvider(blueprintId, providerId, basePrice) {
        const result = await this.db.update(products).set({ basePrice, updatedAt: /* @__PURE__ */ new Date() }).where(and(
          eq(products.blueprintId, blueprintId),
          eq(products.printProviderId, providerId)
        ));
        return result.rowCount ?? 0;
      }
      async deletePrintifyPrintProvidersByBlueprint(blueprintId) {
        await this.db.delete(printifyPrintProviders).where(eq(printifyPrintProviders.blueprintId, blueprintId));
      }
      async clearPrintifyPrintProviders() {
        await this.db.delete(printifyPrintProviders);
      }
      // Printify Catalog Sync operations
      async createCatalogSync(sync) {
        const [result] = await this.db.insert(printifyCatalogSync).values(sync).returning();
        return result;
      }
      async updateCatalogSync(id, sync) {
        const [updated] = await this.db.update(printifyCatalogSync).set(sync).where(eq(printifyCatalogSync.id, id)).returning();
        return updated;
      }
      async getLatestCatalogSync() {
        const [sync] = await this.db.select().from(printifyCatalogSync).orderBy(sql2`${printifyCatalogSync.startedAt} DESC`).limit(1);
        return sync;
      }
      async getCatalogSyncHistory() {
        return await this.db.select().from(printifyCatalogSync).orderBy(sql2`${printifyCatalogSync.startedAt} DESC`).limit(20);
      }
      // Printify Cost Sync operations
      async createCostSync(sync) {
        const [result] = await this.db.insert(printifyCostSync).values(sync).returning();
        return result;
      }
      async updateCostSync(id, sync) {
        const [updated] = await this.db.update(printifyCostSync).set(sync).where(eq(printifyCostSync.id, id)).returning();
        return updated;
      }
      async getLatestCostSync() {
        const [sync] = await this.db.select().from(printifyCostSync).orderBy(sql2`${printifyCostSync.startedAt} DESC`).limit(1);
        return sync;
      }
      async getActiveCostSync() {
        const [sync] = await this.db.select().from(printifyCostSync).where(eq(printifyCostSync.status, "running")).orderBy(sql2`${printifyCostSync.startedAt} DESC`).limit(1);
        return sync;
      }
      async getCostSyncHistory() {
        return await this.db.select().from(printifyCostSync).orderBy(sql2`${printifyCostSync.startedAt} DESC`).limit(20);
      }
      async getProviderCostStats() {
        const providers = await this.db.select().from(printifyPrintProviders);
        const now = Date.now();
        const staleThreshold = 24 * 60 * 60 * 1e3;
        let withCosts = 0;
        let stale = 0;
        for (const p of providers) {
          if (p.minCost && p.minCost > 0) {
            withCosts++;
            if (p.costsFetchedAt && now - new Date(p.costsFetchedAt).getTime() > staleThreshold) {
              stale++;
            }
          }
        }
        return { total: providers.length, withCosts, stale };
      }
      // Custom Design operations
      async getCustomDesign(id) {
        const [design] = await this.db.select().from(customDesigns).where(eq(customDesigns.id, id));
        return design;
      }
      async getCustomDesigns() {
        return await this.db.select().from(customDesigns).orderBy(sql2`${customDesigns.createdAt} DESC`);
      }
      async getCustomDesignsForLibrary() {
        return await this.db.select().from(customDesigns).where(eq(customDesigns.savedToLibrary, true)).orderBy(sql2`${customDesigns.createdAt} DESC`);
      }
      async getCustomDesignsByStoreSegment(storeType, storeName, segment) {
        const conditions = [
          eq(customDesigns.savedToStore, true),
          sql2`LOWER(${customDesigns.storeType}) = LOWER(${storeType})`,
          sql2`LOWER(${customDesigns.storeName}) = LOWER(${storeName})`
        ];
        if (segment) {
          conditions.push(sql2`LOWER(${customDesigns.segment}) = LOWER(${segment})`);
        }
        return await this.db.select().from(customDesigns).where(and(...conditions)).orderBy(sql2`${customDesigns.createdAt} DESC`);
      }
      async createCustomDesign(design) {
        const [newDesign] = await this.db.insert(customDesigns).values(design).returning();
        return newDesign;
      }
      async updateCustomDesign(id, design) {
        const [updated] = await this.db.update(customDesigns).set({ ...design, updatedAt: /* @__PURE__ */ new Date() }).where(eq(customDesigns.id, id)).returning();
        return updated;
      }
      async deleteCustomDesign(id) {
        await this.db.delete(customDesigns).where(eq(customDesigns.id, id));
      }
      // Template Category operations
      async getTemplateCategories() {
        return await this.db.select().from(templateCategories).where(eq(templateCategories.isActive, true)).orderBy(templateCategories.sortOrder);
      }
      async getTemplateCategoriesByParent(parentId) {
        const condition = parentId === null ? sql2`${templateCategories.parentId} IS NULL` : eq(templateCategories.parentId, parentId);
        return await this.db.select().from(templateCategories).where(and(condition, eq(templateCategories.isActive, true))).orderBy(templateCategories.sortOrder);
      }
      async createTemplateCategory(category) {
        const [newCategory] = await this.db.insert(templateCategories).values(category).returning();
        return newCategory;
      }
      async updateTemplateCategory(id, category) {
        const [updated] = await this.db.update(templateCategories).set(category).where(eq(templateCategories.id, id)).returning();
        return updated;
      }
      async deleteTemplateCategory(id) {
        await this.db.update(templateCategories).set({ isActive: false }).where(eq(templateCategories.id, id));
      }
      // Graphic Set operations
      async getGraphicSets() {
        return await this.db.select().from(graphicSets).where(eq(graphicSets.isActive, true)).orderBy(sql2`${graphicSets.createdAt} DESC`);
      }
      async getGraphicSet(id) {
        const [graphicSet] = await this.db.select().from(graphicSets).where(eq(graphicSets.id, id));
        return graphicSet;
      }
      async getGraphicSetsByCategory(categoryId) {
        return await this.db.select().from(graphicSets).where(and(
          eq(graphicSets.categoryId, categoryId),
          eq(graphicSets.isActive, true)
        )).orderBy(sql2`${graphicSets.createdAt} DESC`);
      }
      async createGraphicSet(graphicSet) {
        const [newGraphicSet] = await this.db.insert(graphicSets).values(graphicSet).returning();
        return newGraphicSet;
      }
      async updateGraphicSet(id, graphicSet) {
        const [updated] = await this.db.update(graphicSets).set({ ...graphicSet, updatedAt: /* @__PURE__ */ new Date() }).where(eq(graphicSets.id, id)).returning();
        return updated;
      }
      async deleteGraphicSet(id) {
        await this.db.update(graphicSets).set({ isActive: false }).where(eq(graphicSets.id, id));
      }
      async incrementGraphicSetUsage(id) {
        await this.db.update(graphicSets).set({ usageCount: sql2`${graphicSets.usageCount} + 1` }).where(eq(graphicSets.id, id));
      }
      // Library Asset operations
      async getLibraryAsset(id) {
        const [asset] = await this.db.select().from(libraryAssets).where(eq(libraryAssets.id, id));
        return asset;
      }
      async getLibraryAssetByUrl(url) {
        const [asset] = await this.db.select().from(libraryAssets).where(or(
          eq(libraryAssets.publicUrl, url),
          eq(libraryAssets.storageUrl, url)
        ));
        return asset;
      }
      async getLibraryAssets(filters) {
        let query = this.db.select().from(libraryAssets).where(eq(libraryAssets.isActive, true));
        const conditions = [eq(libraryAssets.isActive, true)];
        if (filters?.ownerType) conditions.push(eq(libraryAssets.ownerType, filters.ownerType));
        if (filters?.assetType) conditions.push(eq(libraryAssets.assetType, filters.assetType));
        if (filters?.mediaType) conditions.push(eq(libraryAssets.mediaType, filters.mediaType));
        if (filters?.userId) conditions.push(eq(libraryAssets.userId, filters.userId));
        if (filters?.category) conditions.push(eq(libraryAssets.category, filters.category));
        if (filters?.season) conditions.push(eq(libraryAssets.season, filters.season));
        if (filters?.event) conditions.push(eq(libraryAssets.event, filters.event));
        return this.db.select().from(libraryAssets).where(and(...conditions)).orderBy(libraryAssets.sortOrder);
      }
      async getAdminLibraryAssets(filters) {
        const conditions = [eq(libraryAssets.ownerType, "admin"), eq(libraryAssets.isActive, true)];
        if (filters?.assetType) conditions.push(eq(libraryAssets.assetType, filters.assetType));
        if (filters?.mediaType) conditions.push(eq(libraryAssets.mediaType, filters.mediaType));
        if (filters?.category) conditions.push(eq(libraryAssets.category, filters.category));
        if (filters?.season) conditions.push(eq(libraryAssets.season, filters.season));
        if (filters?.event) conditions.push(eq(libraryAssets.event, filters.event));
        return this.db.select().from(libraryAssets).where(and(...conditions)).orderBy(libraryAssets.sortOrder);
      }
      async getUserLibraryAssets(userId, filters) {
        const conditions = [eq(libraryAssets.userId, userId), eq(libraryAssets.ownerType, "user"), eq(libraryAssets.isActive, true)];
        if (filters?.assetType) conditions.push(eq(libraryAssets.assetType, filters.assetType));
        if (filters?.mediaType) conditions.push(eq(libraryAssets.mediaType, filters.mediaType));
        return this.db.select().from(libraryAssets).where(and(...conditions)).orderBy(libraryAssets.createdAt);
      }
      async createLibraryAsset(asset) {
        const [newAsset] = await this.db.insert(libraryAssets).values(asset).returning();
        return newAsset;
      }
      async updateLibraryAsset(id, asset) {
        const [updated] = await this.db.update(libraryAssets).set({ ...asset, updatedAt: /* @__PURE__ */ new Date() }).where(eq(libraryAssets.id, id)).returning();
        return updated;
      }
      async deleteLibraryAsset(id) {
        await this.db.delete(libraryAssets).where(eq(libraryAssets.id, id));
      }
      async incrementLibraryAssetUsage(id) {
        await this.db.update(libraryAssets).set({ usageCount: sql2`${libraryAssets.usageCount} + 1` }).where(eq(libraryAssets.id, id));
      }
      // Orchestration: Master Product operations
      async getAllMasterProducts() {
        return this.db.select().from(masterProducts).orderBy(masterProducts.createdAt);
      }
      async getMasterProduct(id) {
        const [product] = await this.db.select().from(masterProducts).where(eq(masterProducts.id, id));
        return product;
      }
      async createMasterProduct(product) {
        const [newProduct] = await this.db.insert(masterProducts).values(product).returning();
        return newProduct;
      }
      async updateMasterProduct(id, product) {
        const [updated] = await this.db.update(masterProducts).set({ ...product, updatedAt: /* @__PURE__ */ new Date() }).where(eq(masterProducts.id, id)).returning();
        return updated;
      }
      async deleteMasterProduct(id) {
        await this.db.delete(masterProducts).where(eq(masterProducts.id, id));
      }
      // Orchestration: Design Version operations
      async getDesignVersions(masterProductId) {
        return this.db.select().from(productDesignVersions).where(eq(productDesignVersions.masterProductId, masterProductId)).orderBy(productDesignVersions.versionNumber);
      }
      async getActiveDesignVersion(masterProductId) {
        const [version] = await this.db.select().from(productDesignVersions).where(and(eq(productDesignVersions.masterProductId, masterProductId), eq(productDesignVersions.isActive, true)));
        return version;
      }
      async createDesignVersion(version) {
        const [newVersion] = await this.db.insert(productDesignVersions).values(version).returning();
        return newVersion;
      }
      async updateDesignVersion(id, version) {
        const [updated] = await this.db.update(productDesignVersions).set(version).where(eq(productDesignVersions.id, id)).returning();
        return updated;
      }
      // Orchestration: Channel Config operations
      async getAllChannelConfigs() {
        return this.db.select().from(channelConfigs);
      }
      async getChannelConfig(channelType) {
        const [config] = await this.db.select().from(channelConfigs).where(eq(channelConfigs.channelType, channelType));
        return config;
      }
      async createChannelConfig(config) {
        const [newConfig] = await this.db.insert(channelConfigs).values(config).returning();
        return newConfig;
      }
      async updateChannelConfig(channelType, config) {
        const [updated] = await this.db.update(channelConfigs).set(config).where(eq(channelConfigs.channelType, channelType)).returning();
        return updated;
      }
      // Orchestration: Publish State operations
      async getPublishStates(masterProductId) {
        return this.db.select().from(channelPublishStates).where(eq(channelPublishStates.masterProductId, masterProductId));
      }
      async getPublishState(masterProductId, channelType) {
        const [state] = await this.db.select().from(channelPublishStates).where(and(eq(channelPublishStates.masterProductId, masterProductId), eq(channelPublishStates.channelType, channelType)));
        return state;
      }
      async upsertPublishState(state) {
        const [result] = await this.db.insert(channelPublishStates).values(state).onConflictDoUpdate({
          target: [channelPublishStates.masterProductId, channelPublishStates.channelType],
          set: { ...state, lastSyncedAt: /* @__PURE__ */ new Date() }
        }).returning();
        return result;
      }
      // Batch retrieval operations for admin
      async getUsers() {
        return this.db.select().from(users).orderBy(sql2`${users.createdAt} DESC`);
      }
      async getOrders() {
        return this.db.select().from(ordersUnified).orderBy(sql2`${ordersUnified.createdAt} DESC`);
      }
      async getOrderUnified(id) {
        const [order] = await this.db.select().from(ordersUnified).where(eq(ordersUnified.id, id));
        return order;
      }
      async createOrderUnified(order) {
        const [result] = await this.db.insert(ordersUnified).values(order).returning();
        return result;
      }
      async updateOrderUnified(id, order) {
        const [updated] = await this.db.update(ordersUnified).set({
          ...order,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq(ordersUnified.id, id)).returning();
        return updated;
      }
      async getProducts() {
        return this.db.select().from(products);
      }
      // Provider Health operations
      async logProviderHealth(log2) {
        const [result] = await this.db.insert(providerHealthLog).values(log2).returning();
        return result;
      }
      async getProviderHealthLogs(limit = 100) {
        return this.db.select().from(providerHealthLog).orderBy(sql2`${providerHealthLog.checkTime} DESC`).limit(limit);
      }
      async getProviderHealthLogsByType(providerType, limit = 100) {
        return this.db.select().from(providerHealthLog).where(eq(providerHealthLog.providerType, providerType)).orderBy(sql2`${providerHealthLog.checkTime} DESC`).limit(limit);
      }
      async getLatestProviderHealth(providerType) {
        const [result] = await this.db.select().from(providerHealthLog).where(eq(providerHealthLog.providerType, providerType)).orderBy(sql2`${providerHealthLog.checkTime} DESC`).limit(1);
        return result;
      }
      async getAllLatestProviderHealth() {
        const providerTypes = ["printify", "printful", "apliiq"];
        const results = [];
        for (const type of providerTypes) {
          const latest = await this.getLatestProviderHealth(type);
          if (latest) results.push(latest);
        }
        return results;
      }
      async getProviderHealthStats(providerType, hours = 24) {
        const cutoff = new Date(Date.now() - hours * 60 * 60 * 1e3);
        const logs = await this.db.select().from(providerHealthLog).where(and(
          eq(providerHealthLog.providerType, providerType),
          sql2`${providerHealthLog.checkTime} > ${cutoff}`
        ));
        if (logs.length === 0) {
          return { uptimePercent: 0, avgResponseTime: 0, totalChecks: 0 };
        }
        const healthyCount = logs.filter((l) => l.isHealthy).length;
        const totalResponseTime = logs.reduce((sum, l) => sum + (l.responseTimeMs || 0), 0);
        return {
          uptimePercent: Math.round(healthyCount / logs.length * 100 * 100) / 100,
          avgResponseTime: Math.round(totalResponseTime / logs.length),
          totalChecks: logs.length
        };
      }
      // Gift Mode: Package operations
      async getAllGiftPackages() {
        return this.db.select().from(giftPackages).orderBy(giftPackages.sortOrder);
      }
      async getActiveGiftPackages() {
        return this.db.select().from(giftPackages).where(eq(giftPackages.isActive, true)).orderBy(giftPackages.sortOrder);
      }
      async getGiftPackage(id) {
        const [pkg] = await this.db.select().from(giftPackages).where(eq(giftPackages.id, id));
        return pkg;
      }
      async createGiftPackage(pkg) {
        const [result] = await this.db.insert(giftPackages).values(pkg).returning();
        return result;
      }
      async updateGiftPackage(id, pkg) {
        const [result] = await this.db.update(giftPackages).set({ ...pkg, updatedAt: /* @__PURE__ */ new Date() }).where(eq(giftPackages.id, id)).returning();
        return result;
      }
      async deleteGiftPackage(id) {
        await this.db.delete(giftPackages).where(eq(giftPackages.id, id));
      }
      // Gift Mode: Code operations
      async getGiftCode(id) {
        const [code] = await this.db.select().from(giftCodes).where(eq(giftCodes.id, id));
        return code;
      }
      async getGiftCodeByCode(code) {
        const [result] = await this.db.select().from(giftCodes).where(eq(giftCodes.code, code));
        return result;
      }
      async getGiftCodesByBuyer(buyerUserId) {
        return this.db.select().from(giftCodes).where(eq(giftCodes.buyerUserId, buyerUserId));
      }
      async createGiftCode(code) {
        const [result] = await this.db.insert(giftCodes).values(code).returning();
        return result;
      }
      async updateGiftCode(id, code) {
        const [result] = await this.db.update(giftCodes).set(code).where(eq(giftCodes.id, id)).returning();
        return result;
      }
      // Gift Mode: Redemption operations
      async getGiftRedemption(id) {
        const [redemption] = await this.db.select().from(giftRedemptions).where(eq(giftRedemptions.id, id));
        return redemption;
      }
      async getGiftRedemptionByCode(giftCodeId) {
        const [result] = await this.db.select().from(giftRedemptions).where(eq(giftRedemptions.giftCodeId, giftCodeId));
        return result;
      }
      async getGiftRedemptionsByRecipient(recipientEmail) {
        return this.db.select().from(giftRedemptions).where(eq(giftRedemptions.recipientEmail, recipientEmail));
      }
      async createGiftRedemption(redemption) {
        const [result] = await this.db.insert(giftRedemptions).values(redemption).returning();
        return result;
      }
      async updateGiftRedemption(id, redemption) {
        const [result] = await this.db.update(giftRedemptions).set(redemption).where(eq(giftRedemptions.id, id)).returning();
        return result;
      }
      // Email Template operations
      async getEmailTemplates() {
        return this.db.select().from(emailTemplates);
      }
      async getEmailTemplate(id) {
        const [template] = await this.db.select().from(emailTemplates).where(eq(emailTemplates.id, id));
        return template;
      }
      async getEmailTemplateByTrigger(trigger) {
        const [template] = await this.db.select().from(emailTemplates).where(eq(emailTemplates.trigger, trigger));
        return template;
      }
      async createEmailTemplate(template) {
        const [result] = await this.db.insert(emailTemplates).values(template).returning();
        return result;
      }
      async updateEmailTemplate(id, template) {
        const [result] = await this.db.update(emailTemplates).set({ ...template, updatedAt: /* @__PURE__ */ new Date() }).where(eq(emailTemplates.id, id)).returning();
        return result;
      }
      async deleteEmailTemplate(id) {
        await this.db.delete(emailTemplates).where(eq(emailTemplates.id, id));
      }
      // Email Log operations
      async getEmailLogs(limit = 100) {
        return this.db.select().from(emailLogs).orderBy(sql2`${emailLogs.sentAt} DESC`).limit(limit);
      }
      async logEmail(log2) {
        const [result] = await this.db.insert(emailLogs).values(log2).returning();
        return result;
      }
    };
    MemStorage = class {
      users = /* @__PURE__ */ new Map();
      qrDesigns = /* @__PURE__ */ new Map();
      products = /* @__PURE__ */ new Map();
      cartItems = /* @__PURE__ */ new Map();
      orders = /* @__PURE__ */ new Map();
      orderItems = /* @__PURE__ */ new Map();
      ordersUnified = /* @__PURE__ */ new Map();
      hostedImages = /* @__PURE__ */ new Map();
      browsingHistory = /* @__PURE__ */ new Map();
      adminSettings;
      pricingRules = /* @__PURE__ */ new Map();
      partnerStores = /* @__PURE__ */ new Map();
      partnerStoreProducts = /* @__PURE__ */ new Map();
      providerHealthLogs = [];
      async getUser(id) {
        return this.users.get(id);
      }
      async getUserByEmail(email) {
        return Array.from(this.users.values()).find((u) => u.email === email);
      }
      async createUser(user) {
        const newUser = {
          ...user,
          id: user.id || `user_${Date.now()}`,
          firstName: user.firstName ?? null,
          lastName: user.lastName ?? null,
          profileImageUrl: user.profileImageUrl ?? null,
          email: user.email ?? null,
          passwordHash: user.passwordHash ?? null,
          socialFacebook: user.socialFacebook ?? null,
          socialInstagram: user.socialInstagram ?? null,
          socialTwitter: user.socialTwitter ?? null,
          socialLinkedin: user.socialLinkedin ?? null,
          socialTiktok: user.socialTiktok ?? null,
          socialYoutube: user.socialYoutube ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.users.set(newUser.id, newUser);
        return newUser;
      }
      async upsertUser(userData) {
        const existing = userData.id ? this.users.get(userData.id) : void 0;
        const user = {
          id: userData.id || `user_${Date.now()}`,
          email: userData.email ?? null,
          passwordHash: userData.passwordHash ?? null,
          firstName: userData.firstName ?? null,
          lastName: userData.lastName ?? null,
          profileImageUrl: userData.profileImageUrl ?? null,
          socialFacebook: userData.socialFacebook ?? null,
          socialInstagram: userData.socialInstagram ?? null,
          socialTwitter: userData.socialTwitter ?? null,
          socialLinkedin: userData.socialLinkedin ?? null,
          socialTiktok: userData.socialTiktok ?? null,
          socialYoutube: userData.socialYoutube ?? null,
          createdAt: existing?.createdAt || /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.users.set(user.id, user);
        return user;
      }
      async getBrowsingHistory(userId) {
        return Array.from(this.browsingHistory.values()).filter((h) => h.userId === userId);
      }
      async addBrowsingHistory(entry) {
        const id = `bh_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newEntry = {
          id,
          userId: entry.userId,
          productId: entry.productId,
          viewedAt: /* @__PURE__ */ new Date()
        };
        this.browsingHistory.set(id, newEntry);
        return newEntry;
      }
      async clearBrowsingHistory(userId) {
        const toDelete = [];
        this.browsingHistory.forEach((entry, id) => {
          if (entry.userId === userId) {
            toDelete.push(id);
          }
        });
        toDelete.forEach((id) => this.browsingHistory.delete(id));
      }
      async getQrDesign(id) {
        return this.qrDesigns.get(id);
      }
      async getQrDesignsByUser(userId) {
        return Array.from(this.qrDesigns.values()).filter((d) => d.userId === userId);
      }
      async createQrDesign(design) {
        const id = `qr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newDesign = {
          ...design,
          id,
          productId: design.productId ?? null,
          productColor: design.productColor ?? null,
          manufacturer: design.manufacturer ?? null,
          madeInUSA: design.madeInUSA ?? null,
          previewUrl: design.previewUrl ?? null,
          showInGallery: design.showInGallery ?? false,
          galleryTitle: design.galleryTitle ?? null,
          galleryDescription: design.galleryDescription ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.qrDesigns.set(id, newDesign);
        return newDesign;
      }
      async getPublicGalleryDesigns() {
        return Array.from(this.qrDesigns.values()).filter((d) => d.showInGallery === true);
      }
      async updateQrDesign(id, design) {
        const existing = this.qrDesigns.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...design, updatedAt: /* @__PURE__ */ new Date() };
        this.qrDesigns.set(id, updated);
        return updated;
      }
      async deleteQrDesign(id) {
        this.qrDesigns.delete(id);
      }
      async getProduct(id) {
        return this.products.get(id);
      }
      async getAllProducts() {
        return Array.from(this.products.values());
      }
      async createProduct(product) {
        const id = product.id || `prod_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newProduct = {
          ...product,
          id,
          printifyId: product.printifyId ?? null,
          blueprintId: product.blueprintId ?? null,
          printProviderId: product.printProviderId ?? null,
          description: product.description ?? null,
          imageUrl: product.imageUrl ?? null,
          manufacturer: product.manufacturer ?? null,
          madeInUSA: product.madeInUSA ?? null,
          availablePlacements: product.availablePlacements ?? null,
          availableColors: product.availableColors ?? null,
          availableSizes: product.availableSizes ?? null,
          metadata: product.metadata ?? null,
          isEnabled: product.isEnabled ?? false,
          markupPercent: product.markupPercent ?? "0",
          markupFixed: product.markupFixed ?? "0",
          qrProductionCost: product.qrProductionCost ?? "0",
          sortOrder: product.sortOrder ?? 0,
          productLine: product.productLine ?? null,
          defaultPlacement: product.defaultPlacement ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.products.set(id, newProduct);
        return newProduct;
      }
      async updateProduct(id, product) {
        const existing = this.products.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...product, updatedAt: /* @__PURE__ */ new Date() };
        this.products.set(id, updated);
        return updated;
      }
      async deleteProduct(id) {
        Array.from(this.productCategoryAssignments.entries()).forEach(([assignmentId, assignment]) => {
          if (assignment.productId === id) this.productCategoryAssignments.delete(assignmentId);
        });
        this.products.delete(id);
      }
      async getCartItemsByUser(userId) {
        return Array.from(this.cartItems.values()).filter((item) => item.userId === userId);
      }
      async addCartItem(item) {
        const id = `cart_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newItem = {
          ...item,
          id,
          designId: item.designId ?? null,
          quantity: item.quantity ?? 1,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.cartItems.set(id, newItem);
        return newItem;
      }
      async updateCartItem(id, quantity) {
        const existing = this.cartItems.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, quantity };
        this.cartItems.set(id, updated);
        return updated;
      }
      async deleteCartItem(id) {
        this.cartItems.delete(id);
      }
      async clearCart(userId) {
        const entries = Array.from(this.cartItems.entries());
        for (const [id, item] of entries) {
          if (item.userId === userId) {
            this.cartItems.delete(id);
          }
        }
      }
      async getOrder(id) {
        return this.orders.get(id);
      }
      async getOrdersByUser(userId) {
        return Array.from(this.orders.values()).filter((order) => order.userId === userId);
      }
      async getOrdersByStatus(status) {
        return Array.from(this.orders.values()).filter((order) => order.status === status);
      }
      async getOrderByStripeSession(sessionId) {
        return Array.from(this.orders.values()).find((order) => order.stripeSessionId === sessionId);
      }
      async createOrder(order) {
        const id = `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newOrder = {
          ...order,
          id,
          stripePaymentId: order.stripePaymentId ?? null,
          stripeSessionId: order.stripeSessionId ?? null,
          stripePaymentIntentId: order.stripePaymentIntentId ?? null,
          printifyOrderId: order.printifyOrderId ?? null,
          trackingNumber: order.trackingNumber ?? null,
          shippingAddress: order.shippingAddress ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.orders.set(id, newOrder);
        return newOrder;
      }
      async updateOrder(id, order) {
        const existing = this.orders.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...order, updatedAt: /* @__PURE__ */ new Date() };
        this.orders.set(id, updated);
        return updated;
      }
      async getOrderItems(orderId) {
        return Array.from(this.orderItems.values()).filter((item) => item.orderId === orderId);
      }
      async createOrderItem(item) {
        const id = `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newItem = {
          ...item,
          id,
          printifyItemId: item.printifyItemId ?? null
        };
        this.orderItems.set(id, newItem);
        return newItem;
      }
      // Hosted Image operations
      async getHostedImage(id) {
        return this.hostedImages.get(id);
      }
      async getHostedImagesByUser(userId) {
        return Array.from(this.hostedImages.values()).filter((img) => img.userId === userId);
      }
      async getAllHostedImages() {
        return Array.from(this.hostedImages.values());
      }
      async createHostedImage(image) {
        const id = `img_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newImage = {
          ...image,
          id,
          userId: image.userId ?? null,
          title: image.title ?? null,
          description: image.description ?? null,
          businessName: image.businessName ?? null,
          businessLogo: image.businessLogo ?? null,
          views: 0,
          isActive: image.isActive ?? true,
          expiresAt: image.expiresAt ?? null,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.hostedImages.set(id, newImage);
        return newImage;
      }
      async updateHostedImage(id, image) {
        const existing = this.hostedImages.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...image };
        this.hostedImages.set(id, updated);
        return updated;
      }
      async incrementImageViews(id) {
        const image = this.hostedImages.get(id);
        if (image) {
          this.hostedImages.set(id, { ...image, views: (image.views || 0) + 1 });
        }
      }
      async deleteHostedImage(id) {
        this.hostedImages.delete(id);
      }
      // Hosting Reminder operations
      hostingReminders = /* @__PURE__ */ new Map();
      async getHostingReminderByImageAndDays(imageId, daysRemaining) {
        const reminderType = `${daysRemaining}_day`;
        return Array.from(this.hostingReminders.values()).find(
          (r) => r.customGiftId === imageId && r.reminderType === reminderType
        );
      }
      async createHostingReminder(reminder) {
        const id = `reminder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newReminder = {
          ...reminder,
          id,
          userId: reminder.userId ?? null,
          sentAt: reminder.sentAt ?? null,
          emailAddress: reminder.emailAddress ?? null,
          status: reminder.status ?? "pending",
          createdAt: /* @__PURE__ */ new Date()
        };
        this.hostingReminders.set(id, newReminder);
        return newReminder;
      }
      // Admin Settings operations
      async getAdminSettings() {
        return this.adminSettings;
      }
      async upsertAdminSettings(settings) {
        const newSettings = {
          id: "default",
          globalMarkupPercent: settings.globalMarkupPercent ?? "25",
          globalMarkupFixed: settings.globalMarkupFixed ?? "0",
          globalQrProductionCost: settings.globalQrProductionCost ?? "2",
          textAboveUpcharge: settings.textAboveUpcharge ?? "2",
          textBelowUpcharge: settings.textBelowUpcharge ?? "2",
          imageHostingUpcharge: settings.imageHostingUpcharge ?? "5",
          dynamicQrUpcharge: settings.dynamicQrUpcharge ?? "25",
          showPricesBeforeCustomization: settings.showPricesBeforeCustomization ?? false,
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.adminSettings = newSettings;
        return newSettings;
      }
      // Pricing Rules operations
      async getPricingRules() {
        return Array.from(this.pricingRules.values());
      }
      async getPricingRule(id) {
        return this.pricingRules.get(id);
      }
      async createPricingRule(rule) {
        const id = `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const newRule = {
          ...rule,
          id,
          scopeValue: rule.scopeValue ?? null,
          qrProductionCost: rule.qrProductionCost ?? "0",
          priority: rule.priority ?? 0,
          isActive: rule.isActive ?? true,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.pricingRules.set(id, newRule);
        return newRule;
      }
      async updatePricingRule(id, rule) {
        const existing = this.pricingRules.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...rule };
        this.pricingRules.set(id, updated);
        return updated;
      }
      async deletePricingRule(id) {
        this.pricingRules.delete(id);
      }
      // Admin Product operations
      async getEnabledProducts() {
        return Array.from(this.products.values()).filter((p) => p.isEnabled);
      }
      async toggleProductEnabled(id, enabled) {
        const existing = this.products.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, isEnabled: enabled, updatedAt: /* @__PURE__ */ new Date() };
        this.products.set(id, updated);
        return updated;
      }
      // Hosting Tier operations (stubs for MemStorage)
      hostingTiers = /* @__PURE__ */ new Map();
      qrTemplates = /* @__PURE__ */ new Map();
      async getHostingTiers() {
        return Array.from(this.hostingTiers.values());
      }
      async getHostingTier(id) {
        return this.hostingTiers.get(id);
      }
      async getHostingTierByCode(code) {
        return Array.from(this.hostingTiers.values()).find((t) => t.code === code);
      }
      async createHostingTier(tier) {
        const id = `tier_${Date.now()}`;
        const newTier = {
          ...tier,
          id,
          description: tier.description ?? null,
          isIncluded: tier.isIncluded ?? false,
          priceUpcharge: tier.priceUpcharge ?? "0",
          isActive: tier.isActive ?? true,
          sortOrder: tier.sortOrder ?? 0
        };
        this.hostingTiers.set(id, newTier);
        return newTier;
      }
      async updateHostingTier(id, tier) {
        const existing = this.hostingTiers.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...tier };
        this.hostingTiers.set(id, updated);
        return updated;
      }
      async deleteHostingTier(id) {
        this.hostingTiers.delete(id);
      }
      // Coupon operations
      couponsMap = /* @__PURE__ */ new Map();
      async getCoupons() {
        return Array.from(this.couponsMap.values());
      }
      async getActiveCoupons() {
        return Array.from(this.couponsMap.values()).filter((c) => c.isActive);
      }
      async getCoupon(id) {
        return this.couponsMap.get(id);
      }
      async getCouponByCode(code) {
        return Array.from(this.couponsMap.values()).find((c) => c.code === code.toUpperCase());
      }
      async createCoupon(coupon) {
        const id = `coupon_${Date.now()}`;
        const newCoupon = {
          ...coupon,
          id,
          code: coupon.code.toUpperCase(),
          currency: coupon.currency ?? "usd",
          minOrderAmount: coupon.minOrderAmount ?? null,
          maxRedemptions: coupon.maxRedemptions ?? null,
          redemptionCount: 0,
          validFrom: coupon.validFrom ?? null,
          validUntil: coupon.validUntil ?? null,
          stripeCouponId: coupon.stripeCouponId ?? null,
          stripePromotionCodeId: coupon.stripePromotionCodeId ?? null,
          isActive: coupon.isActive ?? true,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.couponsMap.set(id, newCoupon);
        return newCoupon;
      }
      async updateCoupon(id, coupon) {
        const existing = this.couponsMap.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...coupon, updatedAt: /* @__PURE__ */ new Date() };
        if (coupon.code) updated.code = coupon.code.toUpperCase();
        this.couponsMap.set(id, updated);
        return updated;
      }
      async deleteCoupon(id) {
        this.couponsMap.delete(id);
      }
      async incrementCouponRedemption(id) {
        const existing = this.couponsMap.get(id);
        if (existing) {
          existing.redemptionCount = (existing.redemptionCount || 0) + 1;
          this.couponsMap.set(id, existing);
        }
      }
      // QR Template operations
      async getQrTemplates() {
        return Array.from(this.qrTemplates.values());
      }
      async getActiveQrTemplates() {
        return Array.from(this.qrTemplates.values()).filter((t) => t.isActive);
      }
      async getQrTemplate(id) {
        return this.qrTemplates.get(id);
      }
      async createQrTemplate(template) {
        const id = `template_${Date.now()}`;
        const newTemplate = {
          ...template,
          id,
          description: template.description ?? null,
          category: template.category ?? null,
          qrPlacement: template.qrPlacement ?? null,
          availableSizes: template.availableSizes ?? null,
          defaultTextAbove: template.defaultTextAbove ?? null,
          defaultTextBelow: template.defaultTextBelow ?? null,
          textStyle: template.textStyle ?? null,
          priceUpcharge: template.priceUpcharge ?? "0",
          isActive: template.isActive ?? true,
          isFeatured: template.isFeatured ?? false,
          sortOrder: template.sortOrder ?? 0,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.qrTemplates.set(id, newTemplate);
        return newTemplate;
      }
      async updateQrTemplate(id, template) {
        const existing = this.qrTemplates.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...template };
        this.qrTemplates.set(id, updated);
        return updated;
      }
      async deleteQrTemplate(id) {
        this.qrTemplates.delete(id);
      }
      // Dynamic Page operations (MemStorage)
      dynamicPages = /* @__PURE__ */ new Map();
      dynamicPageAssets = /* @__PURE__ */ new Map();
      async getDynamicPage(id) {
        return this.dynamicPages.get(id);
      }
      async getDynamicPageBySlug(slug) {
        return Array.from(this.dynamicPages.values()).find((p) => p.slug === slug);
      }
      async getDynamicPagesByUser(userId) {
        return Array.from(this.dynamicPages.values()).filter((p) => p.userId === userId);
      }
      async createDynamicPage(page) {
        const id = `dp_${Date.now()}`;
        const newPage = {
          ...page,
          id,
          description: page.description ?? null,
          activeAssetId: page.activeAssetId ?? null,
          hostingTierId: page.hostingTierId ?? null,
          views: 0,
          status: page.status ?? "active",
          expiresAt: page.expiresAt ?? null,
          renewalReminderSent: page.renewalReminderSent ?? false,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.dynamicPages.set(id, newPage);
        return newPage;
      }
      async updateDynamicPage(id, page) {
        const existing = this.dynamicPages.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...page, updatedAt: /* @__PURE__ */ new Date() };
        this.dynamicPages.set(id, updated);
        return updated;
      }
      async deleteDynamicPage(id) {
        Array.from(this.dynamicPageAssets.entries()).forEach(([assetId, asset]) => {
          if (asset.pageId === id) this.dynamicPageAssets.delete(assetId);
        });
        this.dynamicPages.delete(id);
      }
      async incrementDynamicPageViews(id) {
        const page = this.dynamicPages.get(id);
        if (page) {
          page.views = (page.views || 0) + 1;
          this.dynamicPages.set(id, page);
        }
      }
      async getDynamicPageAsset(id) {
        return this.dynamicPageAssets.get(id);
      }
      async getDynamicPageAssets(pageId) {
        return Array.from(this.dynamicPageAssets.values()).filter((a) => a.pageId === pageId);
      }
      async createDynamicPageAsset(asset) {
        const id = `dpa_${Date.now()}`;
        const newAsset = {
          ...asset,
          id,
          title: asset.title ?? null,
          isActive: asset.isActive ?? false,
          activatedAt: asset.activatedAt ?? null,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.dynamicPageAssets.set(id, newAsset);
        return newAsset;
      }
      async updateDynamicPageAsset(id, asset) {
        const existing = this.dynamicPageAssets.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...asset };
        this.dynamicPageAssets.set(id, updated);
        return updated;
      }
      async deleteDynamicPageAsset(id) {
        this.dynamicPageAssets.delete(id);
      }
      async setActiveAsset(pageId, assetId) {
        Array.from(this.dynamicPageAssets.entries()).forEach(([id, asset2]) => {
          if (asset2.pageId === pageId) {
            this.dynamicPageAssets.set(id, { ...asset2, isActive: false, activatedAt: null });
          }
        });
        const asset = this.dynamicPageAssets.get(assetId);
        if (asset) {
          this.dynamicPageAssets.set(assetId, { ...asset, isActive: true, activatedAt: /* @__PURE__ */ new Date() });
        }
        const page = this.dynamicPages.get(pageId);
        if (page) {
          this.dynamicPages.set(pageId, { ...page, activeAssetId: assetId, updatedAt: /* @__PURE__ */ new Date() });
        }
      }
      // Product Category operations (MemStorage stubs)
      productCategories = /* @__PURE__ */ new Map();
      productCategoryAssignments = /* @__PURE__ */ new Map();
      async getProductCategories() {
        return Array.from(this.productCategories.values()).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async getAllProductCategories() {
        return Array.from(this.productCategories.values()).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async getActiveProductCategories() {
        return Array.from(this.productCategories.values()).filter((c) => c.isActive).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async getProductCategoriesByTaxonomy(taxonomyType) {
        return Array.from(this.productCategories.values()).filter((c) => c.taxonomyType === taxonomyType).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async getProductCategory(id) {
        return this.productCategories.get(id);
      }
      async createProductCategory(category) {
        const id = `cat_${Date.now()}`;
        const newCategory = {
          ...category,
          id,
          description: category.description ?? null,
          icon: category.icon ?? null,
          parentId: category.parentId ?? null,
          sortOrder: category.sortOrder ?? 0,
          isActive: category.isActive ?? true,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.productCategories.set(id, newCategory);
        return newCategory;
      }
      async updateProductCategory(id, category) {
        const existing = this.productCategories.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...category };
        this.productCategories.set(id, updated);
        return updated;
      }
      async deleteProductCategory(id) {
        Array.from(this.productCategoryAssignments.entries()).forEach(([assignmentId, assignment]) => {
          if (assignment.categoryId === id) this.productCategoryAssignments.delete(assignmentId);
        });
        this.productCategories.delete(id);
      }
      async getProductCategoryAssignments(productId) {
        return Array.from(this.productCategoryAssignments.values()).filter((a) => a.productId === productId);
      }
      async getProductsByCategory(categoryId) {
        const assignments = Array.from(this.productCategoryAssignments.values()).filter((a) => a.categoryId === categoryId);
        const productIds = assignments.map((a) => a.productId);
        return Array.from(this.products.values()).filter((p) => productIds.includes(p.id));
      }
      async assignProductToCategory(assignment) {
        const id = `pca_${Date.now()}`;
        const newAssignment = {
          ...assignment,
          id,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.productCategoryAssignments.set(id, newAssignment);
        return newAssignment;
      }
      async removeProductFromCategory(productId, categoryId) {
        for (const [id, assignment] of Array.from(this.productCategoryAssignments.entries())) {
          if (assignment.productId === productId && assignment.categoryId === categoryId) {
            this.productCategoryAssignments.delete(id);
            break;
          }
        }
      }
      async syncProductCategories(productId, categoryIds) {
        Array.from(this.productCategoryAssignments.entries()).forEach(([id, assignment]) => {
          if (assignment.productId === productId) {
            this.productCategoryAssignments.delete(id);
          }
        });
        for (const categoryId of categoryIds) {
          await this.assignProductToCategory({ productId, categoryId });
        }
      }
      // Partner Store operations
      async getPartnerStores() {
        return Array.from(this.partnerStores.values());
      }
      async getPartnerStore(id) {
        return this.partnerStores.get(id);
      }
      async getPartnerStoreBySlug(slug) {
        return Array.from(this.partnerStores.values()).find((s) => s.slug === slug);
      }
      async createPartnerStore(store) {
        const id = `ps_${Date.now()}`;
        const newStore = {
          ...store,
          id,
          description: store.description ?? null,
          logoUrl: store.logoUrl ?? null,
          websiteUrl: store.websiteUrl ?? null,
          businessPageUrlPattern: store.businessPageUrlPattern ?? null,
          allowedOrigins: store.allowedOrigins ?? null,
          primaryColor: store.primaryColor ?? null,
          accentColor: store.accentColor ?? null,
          availableSegments: store.availableSegments ?? null,
          annualMemberPerk: store.annualMemberPerk ?? null,
          commissionPercent: store.commissionPercent ?? "0",
          isActive: store.isActive ?? true,
          isInternal: store.isInternal ?? false,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.partnerStores.set(id, newStore);
        return newStore;
      }
      async updatePartnerStore(id, store) {
        const existing = this.partnerStores.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...store, updatedAt: /* @__PURE__ */ new Date() };
        this.partnerStores.set(id, updated);
        return updated;
      }
      async deletePartnerStore(id) {
        Array.from(this.partnerStoreProducts.entries()).forEach(([productId, product]) => {
          if (product.partnerStoreId === id) this.partnerStoreProducts.delete(productId);
        });
        this.partnerStores.delete(id);
      }
      // Partner Store Product operations
      async getPartnerStoreProducts(partnerStoreId) {
        return Array.from(this.partnerStoreProducts.values()).filter((p) => p.partnerStoreId === partnerStoreId);
      }
      async getPartnerStoreProduct(partnerStoreId, productId) {
        return Array.from(this.partnerStoreProducts.values()).find(
          (p) => p.partnerStoreId === partnerStoreId && p.productId === productId
        );
      }
      async getProductsForStore(storeSlug, segment) {
        const slugLower = storeSlug.toLowerCase();
        const store = Array.from(this.partnerStores.values()).find(
          (s) => s.slug === storeSlug || s.slug.toLowerCase().startsWith(slugLower) || s.name.toLowerCase() === slugLower || s.name.toLowerCase().includes(slugLower)
        );
        if (!store) return [];
        const storeProductLinks = Array.from(this.partnerStoreProducts.values()).filter((sp) => sp.partnerStoreId === store.id && sp.isEnabled);
        let products2 = storeProductLinks.map((sp) => this.products.get(sp.productId)).filter((p) => p !== void 0 && p.isEnabled);
        if (segment) {
          products2 = products2.filter((p) => {
            const category = p.category?.toLowerCase() || "";
            return category.includes(`/${segment.toLowerCase()}`);
          });
        }
        return products2;
      }
      async addPartnerStoreProduct(product) {
        const id = `psp_${Date.now()}`;
        const newProduct = {
          ...product,
          id,
          customPrice: product.customPrice ?? null,
          customName: product.customName ?? null,
          kcPlacements: product.kcPlacements ?? null,
          kcBusinessSlug: product.kcBusinessSlug ?? null,
          enabledSizes: product.enabledSizes ?? null,
          enabledColors: product.enabledColors ?? null,
          sortOrder: product.sortOrder ?? 0,
          isEnabled: product.isEnabled ?? true
        };
        this.partnerStoreProducts.set(id, newProduct);
        return newProduct;
      }
      async updatePartnerStoreProduct(id, product) {
        const existing = this.partnerStoreProducts.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...product };
        this.partnerStoreProducts.set(id, updated);
        return updated;
      }
      async updatePartnerStoreProductByIds(partnerStoreId, productId, product) {
        const existing = await this.getPartnerStoreProduct(partnerStoreId, productId);
        if (!existing) return void 0;
        const updated = { ...existing, ...product };
        this.partnerStoreProducts.set(existing.id, updated);
        return updated;
      }
      async removePartnerStoreProduct(id) {
        this.partnerStoreProducts.delete(id);
      }
      async syncPartnerStoreProducts(partnerStoreId, productIds) {
        const existingProducts = Array.from(this.partnerStoreProducts.values()).filter((p) => p.partnerStoreId === partnerStoreId);
        const existingConfigs = /* @__PURE__ */ new Map();
        existingProducts.forEach((p) => existingConfigs.set(p.productId, p));
        Array.from(this.partnerStoreProducts.entries()).forEach(([id, product]) => {
          if (product.partnerStoreId === partnerStoreId) this.partnerStoreProducts.delete(id);
        });
        for (let i = 0; i < productIds.length; i++) {
          const productId = productIds[i];
          const existingConfig = existingConfigs.get(productId);
          if (existingConfig) {
            await this.addPartnerStoreProduct({
              partnerStoreId,
              productId,
              sortOrder: i,
              enabledSizes: existingConfig.enabledSizes,
              enabledColors: existingConfig.enabledColors,
              kcPlacements: existingConfig.kcPlacements,
              kcBusinessSlug: existingConfig.kcBusinessSlug,
              customPrice: existingConfig.customPrice,
              customName: existingConfig.customName,
              isEnabled: existingConfig.isEnabled
            });
          } else {
            const sourceProduct = this.products.get(productId);
            const availableSizes = Array.isArray(sourceProduct?.availableSizes) ? sourceProduct.availableSizes : null;
            const availableColors = Array.isArray(sourceProduct?.availableColors) ? sourceProduct.availableColors.map((c) => c.name) : null;
            await this.addPartnerStoreProduct({
              partnerStoreId,
              productId,
              sortOrder: i,
              enabledSizes: availableSizes,
              enabledColors: availableColors
            });
          }
        }
      }
      // Product Variant operations (stub for MemStorage)
      productVariants = /* @__PURE__ */ new Map();
      async getProductVariants(productId) {
        return Array.from(this.productVariants.values()).filter((v) => v.productId === productId);
      }
      async upsertProductVariant(variant) {
        const id = `pv_${Date.now()}`;
        const newVariant = {
          ...variant,
          id,
          size: variant.size ?? null,
          color: variant.color ?? null,
          colorHex: variant.colorHex ?? null,
          isEnabled: variant.isEnabled ?? true,
          isInStock: variant.isInStock ?? true
        };
        this.productVariants.set(id, newVariant);
        return newVariant;
      }
      async toggleVariantEnabled(id, enabled) {
        const existing = this.productVariants.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, isEnabled: enabled };
        this.productVariants.set(id, updated);
        return updated;
      }
      // Printify Catalog operations (stubs for MemStorage)
      printifyBlueprints = /* @__PURE__ */ new Map();
      printifyPrintProviders = /* @__PURE__ */ new Map();
      catalogSyncs = [];
      async getPrintifyBlueprints() {
        return Array.from(this.printifyBlueprints.values());
      }
      async getPrintifyBlueprint(id) {
        return this.printifyBlueprints.get(id);
      }
      async upsertPrintifyBlueprint(blueprint) {
        const existing = this.printifyBlueprints.get(blueprint.id);
        const result = {
          ...blueprint,
          description: blueprint.description ?? null,
          brand: blueprint.brand ?? null,
          model: blueprint.model ?? null,
          images: blueprint.images ?? null,
          primaryImageUrl: blueprint.primaryImageUrl ?? null,
          category: blueprint.category ?? null,
          lastSyncedAt: /* @__PURE__ */ new Date(),
          createdAt: existing?.createdAt || /* @__PURE__ */ new Date()
        };
        this.printifyBlueprints.set(blueprint.id, result);
        return result;
      }
      async deletePrintifyBlueprint(id) {
        this.printifyBlueprints.delete(id);
      }
      async clearPrintifyBlueprints() {
        this.printifyBlueprints.clear();
      }
      async getAllPrintifyProviders() {
        return Array.from(this.printifyPrintProviders.values());
      }
      async getPrintifyPrintProviders(blueprintId) {
        return Array.from(this.printifyPrintProviders.values()).filter((p) => p.blueprintId === blueprintId);
      }
      async getPrintifyPrintProvider(blueprintId, providerId) {
        const id = `pp_${blueprintId}_${providerId}`;
        return this.printifyPrintProviders.get(id);
      }
      async upsertPrintifyPrintProvider(provider) {
        const id = `pp_${provider.blueprintId}_${provider.providerId}`;
        const result = {
          ...provider,
          id,
          country: provider.country ?? null,
          isUSA: provider.isUSA ?? false,
          minCost: null,
          maxCost: null,
          availableColors: null,
          availableSizes: null,
          placeholderProductId: null,
          costsFetchedAt: null,
          lastSyncedAt: /* @__PURE__ */ new Date()
        };
        this.printifyPrintProviders.set(id, result);
        return result;
      }
      async updatePrintifyProviderCosts(blueprintId, providerId, costs) {
        const id = `pp_${blueprintId}_${providerId}`;
        const existing = this.printifyPrintProviders.get(id);
        if (!existing) return void 0;
        const updated = {
          ...existing,
          minCost: costs.minCost,
          maxCost: costs.maxCost,
          placeholderProductId: costs.placeholderProductId ?? null,
          costsFetchedAt: /* @__PURE__ */ new Date()
        };
        if (costs.availableColors !== void 0) {
          updated.availableColors = costs.availableColors;
        }
        if (costs.availableSizes !== void 0) {
          updated.availableSizes = costs.availableSizes;
        }
        this.printifyPrintProviders.set(id, updated);
        return updated;
      }
      async updateProductPricesByProvider(blueprintId, providerId, basePrice) {
        let count = 0;
        this.products.forEach((product, id) => {
          if (product.blueprintId === blueprintId && product.printProviderId === providerId) {
            this.products.set(id, { ...product, basePrice, updatedAt: /* @__PURE__ */ new Date() });
            count++;
          }
        });
        return count;
      }
      async deletePrintifyPrintProvidersByBlueprint(blueprintId) {
        Array.from(this.printifyPrintProviders.entries()).forEach(([id, p]) => {
          if (p.blueprintId === blueprintId) this.printifyPrintProviders.delete(id);
        });
      }
      async clearPrintifyPrintProviders() {
        this.printifyPrintProviders.clear();
      }
      async createCatalogSync(sync) {
        const result = {
          ...sync,
          id: `sync_${Date.now()}`,
          blueprintsCount: sync.blueprintsCount ?? 0,
          providersCount: sync.providersCount ?? 0,
          errorMessage: sync.errorMessage ?? null,
          startedAt: sync.startedAt ?? /* @__PURE__ */ new Date(),
          completedAt: sync.completedAt ?? null
        };
        this.catalogSyncs.unshift(result);
        return result;
      }
      async updateCatalogSync(id, sync) {
        const index2 = this.catalogSyncs.findIndex((s) => s.id === id);
        if (index2 === -1) return void 0;
        this.catalogSyncs[index2] = { ...this.catalogSyncs[index2], ...sync };
        return this.catalogSyncs[index2];
      }
      async getLatestCatalogSync() {
        return this.catalogSyncs[0];
      }
      async getCatalogSyncHistory() {
        return this.catalogSyncs.slice(0, 20);
      }
      // Printify Cost Sync operations (MemStorage)
      costSyncs = [];
      async createCostSync(sync) {
        const result = {
          ...sync,
          id: `cost_sync_${Date.now()}`,
          totalProviders: sync.totalProviders ?? 0,
          processedCount: sync.processedCount ?? 0,
          successCount: sync.successCount ?? 0,
          failedCount: sync.failedCount ?? 0,
          skippedCount: sync.skippedCount ?? 0,
          lastProcessedProviderId: sync.lastProcessedProviderId ?? null,
          errorMessage: sync.errorMessage ?? null,
          startedAt: sync.startedAt ?? /* @__PURE__ */ new Date(),
          completedAt: sync.completedAt ?? null
        };
        this.costSyncs.unshift(result);
        return result;
      }
      async updateCostSync(id, sync) {
        const index2 = this.costSyncs.findIndex((s) => s.id === id);
        if (index2 === -1) return void 0;
        this.costSyncs[index2] = { ...this.costSyncs[index2], ...sync };
        return this.costSyncs[index2];
      }
      async getLatestCostSync() {
        return this.costSyncs[0];
      }
      async getActiveCostSync() {
        return this.costSyncs.find((s) => s.status === "running");
      }
      async getCostSyncHistory() {
        return this.costSyncs.slice(0, 20);
      }
      async getProviderCostStats() {
        const providers = Array.from(this.printifyPrintProviders.values());
        const now = Date.now();
        const staleThreshold = 24 * 60 * 60 * 1e3;
        let withCosts = 0;
        let stale = 0;
        for (const p of providers) {
          if (p.minCost && p.minCost > 0) {
            withCosts++;
            if (p.costsFetchedAt && now - new Date(p.costsFetchedAt).getTime() > staleThreshold) {
              stale++;
            }
          }
        }
        return { total: providers.length, withCosts, stale };
      }
      // Custom Design operations (MemStorage)
      customDesigns = /* @__PURE__ */ new Map();
      async getCustomDesign(id) {
        return this.customDesigns.get(id);
      }
      async getCustomDesigns() {
        return Array.from(this.customDesigns.values()).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      async getCustomDesignsForLibrary() {
        return Array.from(this.customDesigns.values()).filter((d) => d.savedToLibrary).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      async getCustomDesignsByStoreSegment(storeType, storeName, segment) {
        return Array.from(this.customDesigns.values()).filter((d) => {
          if (!d.savedToStore) return false;
          if (d.storeType?.toLowerCase() !== storeType.toLowerCase()) return false;
          if (d.storeName?.toLowerCase() !== storeName.toLowerCase()) return false;
          if (segment && d.segment?.toLowerCase() !== segment.toLowerCase()) return false;
          return true;
        }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      async createCustomDesign(design) {
        const id = design.id || `custom_${Date.now()}`;
        const newDesign = {
          ...design,
          id,
          productImage: design.productImage ?? null,
          backgroundImageUrl: design.backgroundImageUrl ?? null,
          backgroundAssetId: design.backgroundAssetId ?? null,
          topText: design.topText ?? null,
          bottomText: design.bottomText ?? null,
          textUpcharge: design.textUpcharge ?? "2.00",
          landingOverlay: design.landingOverlay ?? null,
          storeType: design.storeType ?? null,
          storeName: design.storeName ?? null,
          segment: design.segment ?? null,
          isFeatured: design.isFeatured ?? false,
          isSeasonalPromo: design.isSeasonalPromo ?? false,
          qrCodeUrl: design.qrCodeUrl ?? null,
          printifyCompositeUrl: design.printifyCompositeUrl ?? null,
          savedToLibrary: design.savedToLibrary ?? false,
          savedToStore: design.savedToStore ?? false,
          placementConfigs: design.placementConfigs ?? {},
          placementImages: design.placementImages ?? null,
          templateVariant: design.templateVariant ?? null,
          externalUrl: design.externalUrl ?? null,
          dynamicContentSetId: design.dynamicContentSetId ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.customDesigns.set(newDesign.id, newDesign);
        return newDesign;
      }
      async updateCustomDesign(id, design) {
        const existing = this.customDesigns.get(id);
        if (!existing) return void 0;
        const updated = {
          ...existing,
          ...design,
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.customDesigns.set(id, updated);
        return updated;
      }
      async deleteCustomDesign(id) {
        this.customDesigns.delete(id);
      }
      // Template Category operations (MemStorage)
      templateCategories = /* @__PURE__ */ new Map();
      async getTemplateCategories() {
        return Array.from(this.templateCategories.values()).filter((c) => c.isActive).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async getTemplateCategoriesByParent(parentId) {
        return Array.from(this.templateCategories.values()).filter((c) => c.isActive && c.parentId === parentId).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async createTemplateCategory(category) {
        const id = crypto.randomUUID();
        const newCategory = {
          id,
          name: category.name,
          parentId: category.parentId ?? null,
          sortOrder: category.sortOrder ?? 0,
          isActive: category.isActive ?? true,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.templateCategories.set(id, newCategory);
        return newCategory;
      }
      async updateTemplateCategory(id, category) {
        const existing = this.templateCategories.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...category };
        this.templateCategories.set(id, updated);
        return updated;
      }
      async deleteTemplateCategory(id) {
        const existing = this.templateCategories.get(id);
        if (existing) {
          this.templateCategories.set(id, { ...existing, isActive: false });
        }
      }
      // Graphic Set operations (MemStorage)
      graphicSets = /* @__PURE__ */ new Map();
      async getGraphicSets() {
        return Array.from(this.graphicSets.values()).filter((g) => g.isActive).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      async getGraphicSet(id) {
        return this.graphicSets.get(id);
      }
      async getGraphicSetsByCategory(categoryId) {
        return Array.from(this.graphicSets.values()).filter((g) => g.isActive && g.categoryId === categoryId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
      async createGraphicSet(graphicSet) {
        const id = crypto.randomUUID();
        const newGraphicSet = {
          id,
          name: graphicSet.name,
          description: graphicSet.description ?? null,
          categoryId: graphicSet.categoryId ?? null,
          subcategoryId: graphicSet.subcategoryId ?? null,
          fullGraphicUrl: graphicSet.fullGraphicUrl ?? null,
          qrOnlyUrl: graphicSet.qrOnlyUrl ?? null,
          destinationUrl: graphicSet.destinationUrl ?? null,
          storagePath: graphicSet.storagePath ?? null,
          tags: graphicSet.tags ?? null,
          isActive: graphicSet.isActive ?? true,
          isFeatured: graphicSet.isFeatured ?? false,
          usageCount: 0,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.graphicSets.set(id, newGraphicSet);
        return newGraphicSet;
      }
      async updateGraphicSet(id, graphicSet) {
        const existing = this.graphicSets.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...graphicSet, updatedAt: /* @__PURE__ */ new Date() };
        this.graphicSets.set(id, updated);
        return updated;
      }
      async deleteGraphicSet(id) {
        const existing = this.graphicSets.get(id);
        if (existing) {
          this.graphicSets.set(id, { ...existing, isActive: false });
        }
      }
      async incrementGraphicSetUsage(id) {
        const existing = this.graphicSets.get(id);
        if (existing) {
          this.graphicSets.set(id, { ...existing, usageCount: (existing.usageCount || 0) + 1 });
        }
      }
      // Library Asset operations (MemStorage)
      libraryAssets = /* @__PURE__ */ new Map();
      async getLibraryAsset(id) {
        return this.libraryAssets.get(id);
      }
      async getLibraryAssetByUrl(url) {
        return Array.from(this.libraryAssets.values()).find((a) => a.publicUrl === url || a.storageUrl === url);
      }
      async getLibraryAssets(filters) {
        let assets = Array.from(this.libraryAssets.values()).filter((a) => a.isActive);
        if (filters?.ownerType) assets = assets.filter((a) => a.ownerType === filters.ownerType);
        if (filters?.assetType) assets = assets.filter((a) => a.assetType === filters.assetType);
        if (filters?.mediaType) assets = assets.filter((a) => a.mediaType === filters.mediaType);
        if (filters?.userId) assets = assets.filter((a) => a.userId === filters.userId);
        if (filters?.category) assets = assets.filter((a) => a.category === filters.category);
        if (filters?.season) assets = assets.filter((a) => a.season === filters.season);
        if (filters?.event) assets = assets.filter((a) => a.event === filters.event);
        return assets.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
      }
      async getAdminLibraryAssets(filters) {
        return this.getLibraryAssets({ ...filters, ownerType: "admin" });
      }
      async getUserLibraryAssets(userId, filters) {
        return this.getLibraryAssets({ ...filters, ownerType: "user", userId });
      }
      async createLibraryAsset(asset) {
        const id = crypto.randomUUID();
        const newAsset = {
          ...asset,
          id,
          userId: asset.userId ?? null,
          description: asset.description ?? null,
          thumbnailUrl: asset.thumbnailUrl ?? null,
          duration: asset.duration ?? null,
          category: asset.category ?? null,
          season: asset.season ?? null,
          event: asset.event ?? null,
          tags: asset.tags ?? null,
          visibleStoreSlugs: asset.visibleStoreSlugs ?? null,
          visibleSegments: asset.visibleSegments ?? null,
          isActive: asset.isActive ?? true,
          isFeatured: asset.isFeatured ?? false,
          sortOrder: asset.sortOrder ?? 0,
          usageCount: 0,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.libraryAssets.set(id, newAsset);
        return newAsset;
      }
      async updateLibraryAsset(id, asset) {
        const existing = this.libraryAssets.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...asset, updatedAt: /* @__PURE__ */ new Date() };
        this.libraryAssets.set(id, updated);
        return updated;
      }
      async deleteLibraryAsset(id) {
        this.libraryAssets.delete(id);
      }
      async incrementLibraryAssetUsage(id) {
        const asset = this.libraryAssets.get(id);
        if (asset) {
          asset.usageCount = (asset.usageCount || 0) + 1;
          this.libraryAssets.set(id, asset);
        }
      }
      // Orchestration: Master Product operations (stub implementations for MemStorage)
      orchestrationMasterProducts = /* @__PURE__ */ new Map();
      orchestrationDesignVersions = /* @__PURE__ */ new Map();
      orchestrationChannelConfigs = /* @__PURE__ */ new Map();
      orchestrationPublishStates = /* @__PURE__ */ new Map();
      async getAllMasterProducts() {
        return Array.from(this.orchestrationMasterProducts.values());
      }
      async getMasterProduct(id) {
        return this.orchestrationMasterProducts.get(id);
      }
      async createMasterProduct(product) {
        const id = crypto.randomUUID();
        const newProduct = {
          id,
          sku: product.sku,
          title: product.title,
          description: product.description ?? null,
          productType: product.productType,
          currentDesignVersionId: null,
          pricingProfileId: null,
          baseCost: null,
          retailPrice: null,
          status: product.status ?? "draft",
          channels: null,
          tags: product.tags ?? [],
          bundleParentId: null,
          bundleDiscount: null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.orchestrationMasterProducts.set(id, newProduct);
        return newProduct;
      }
      async updateMasterProduct(id, product) {
        const existing = this.orchestrationMasterProducts.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...product, updatedAt: /* @__PURE__ */ new Date() };
        this.orchestrationMasterProducts.set(id, updated);
        return updated;
      }
      async deleteMasterProduct(id) {
        this.orchestrationMasterProducts.delete(id);
      }
      async getDesignVersions(masterProductId) {
        return Array.from(this.orchestrationDesignVersions.values()).filter((v) => v.masterProductId === masterProductId);
      }
      async getActiveDesignVersion(masterProductId) {
        return Array.from(this.orchestrationDesignVersions.values()).find((v) => v.masterProductId === masterProductId && v.isActive);
      }
      async createDesignVersion(version) {
        const id = crypto.randomUUID();
        const newVersion = {
          id,
          masterProductId: version.masterProductId,
          versionNumber: version.versionNumber ?? 1,
          headerText: version.headerText ?? null,
          headerStyle: version.headerStyle ?? null,
          footerText: version.footerText ?? null,
          footerStyle: version.footerStyle ?? null,
          qrUrl: version.qrUrl,
          renderedPngUrl: version.renderedPngUrl ?? null,
          renderedSvgUrl: version.renderedSvgUrl ?? null,
          qrCodeUrl: null,
          placementImages: null,
          isActive: version.isActive ?? true,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.orchestrationDesignVersions.set(id, newVersion);
        return newVersion;
      }
      async updateDesignVersion(id, version) {
        const existing = this.orchestrationDesignVersions.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...version };
        this.orchestrationDesignVersions.set(id, updated);
        return updated;
      }
      async getAllChannelConfigs() {
        return Array.from(this.orchestrationChannelConfigs.values());
      }
      async getChannelConfig(channelType) {
        return this.orchestrationChannelConfigs.get(channelType);
      }
      async createChannelConfig(config) {
        const id = crypto.randomUUID();
        const newConfig = {
          id,
          channelType: config.channelType,
          displayName: config.displayName,
          isEnabled: config.isEnabled ?? false,
          apiKeySecretName: config.apiKeySecretName ?? null,
          apiSecretSecretName: null,
          shopId: config.shopId ?? null,
          rateLimit: 60,
          rateLimitWindow: 60,
          webhookSecret: null,
          webhookUrl: null,
          lastHealthCheck: null,
          settings: config.settings ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.orchestrationChannelConfigs.set(config.channelType, newConfig);
        return newConfig;
      }
      async updateChannelConfig(channelType, config) {
        const existing = this.orchestrationChannelConfigs.get(channelType);
        if (!existing) return void 0;
        const updated = { ...existing, ...config };
        this.orchestrationChannelConfigs.set(channelType, updated);
        return updated;
      }
      async getPublishStates(masterProductId) {
        return Array.from(this.orchestrationPublishStates.values()).filter((s) => s.masterProductId === masterProductId);
      }
      async getPublishState(masterProductId, channelType) {
        return this.orchestrationPublishStates.get(`${masterProductId}-${channelType}`);
      }
      async upsertPublishState(state) {
        const key = `${state.masterProductId}-${state.channelType}`;
        const existing = this.orchestrationPublishStates.get(key);
        const newState = {
          id: existing?.id ?? crypto.randomUUID(),
          masterProductId: state.masterProductId,
          publishedDesignVersionId: state.publishedDesignVersionId ?? null,
          channelType: state.channelType,
          externalProductId: state.externalProductId ?? null,
          externalListingId: null,
          externalVariantIds: null,
          status: state.status ?? "pending",
          lastPublishedAt: null,
          lastSyncedAt: /* @__PURE__ */ new Date(),
          lastError: state.lastError ?? null,
          createdAt: existing?.createdAt ?? /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.orchestrationPublishStates.set(key, newState);
        return newState;
      }
      // Batch retrieval operations for admin
      async getUsers() {
        return Array.from(this.users.values()).sort(
          (a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
        );
      }
      async getOrders() {
        return Array.from(this.ordersUnified.values()).sort(
          (a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
        );
      }
      async getOrderUnified(id) {
        return this.ordersUnified.get(id);
      }
      async createOrderUnified(order) {
        const newOrder = {
          id: crypto.randomUUID(),
          sourceChannel: order.sourceChannel,
          externalOrderId: order.externalOrderId ?? null,
          customerEmail: order.customerEmail ?? null,
          customerName: order.customerName ?? null,
          shippingAddress: order.shippingAddress ?? null,
          items: order.items,
          subtotal: order.subtotal,
          shippingTotal: order.shippingTotal ?? null,
          taxTotal: order.taxTotal ?? null,
          total: order.total,
          routedProvider: order.routedProvider ?? null,
          providerOrderId: order.providerOrderId ?? null,
          status: order.status ?? "pending",
          statusHistory: order.statusHistory ?? null,
          trackingNumber: order.trackingNumber ?? null,
          trackingUrl: order.trackingUrl ?? null,
          shippedAt: null,
          deliveredAt: null,
          productionCost: order.productionCost ?? null,
          profit: order.profit ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.ordersUnified.set(newOrder.id, newOrder);
        return newOrder;
      }
      async updateOrderUnified(id, order) {
        const existing = this.ordersUnified.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...order, updatedAt: /* @__PURE__ */ new Date() };
        this.ordersUnified.set(id, updated);
        return updated;
      }
      async getProducts() {
        return Array.from(this.products.values());
      }
      // Provider Health operations
      async logProviderHealth(log2) {
        const newLog = {
          id: crypto.randomUUID(),
          providerType: log2.providerType,
          checkTime: /* @__PURE__ */ new Date(),
          isHealthy: log2.isHealthy ?? true,
          responseTimeMs: log2.responseTimeMs ?? null,
          errorMessage: log2.errorMessage ?? null,
          errorCode: log2.errorCode ?? null,
          uptimePercent24h: null,
          avgResponseTime24h: null
        };
        this.providerHealthLogs.push(newLog);
        if (this.providerHealthLogs.length > 1e3) {
          this.providerHealthLogs = this.providerHealthLogs.slice(-1e3);
        }
        return newLog;
      }
      async getProviderHealthLogs(limit = 100) {
        return this.providerHealthLogs.sort((a, b) => (b.checkTime?.getTime() || 0) - (a.checkTime?.getTime() || 0)).slice(0, limit);
      }
      async getProviderHealthLogsByType(providerType, limit = 100) {
        return this.providerHealthLogs.filter((l) => l.providerType === providerType).sort((a, b) => (b.checkTime?.getTime() || 0) - (a.checkTime?.getTime() || 0)).slice(0, limit);
      }
      async getLatestProviderHealth(providerType) {
        const logs = await this.getProviderHealthLogsByType(providerType, 1);
        return logs[0];
      }
      async getAllLatestProviderHealth() {
        const providerTypes = ["printify", "printful", "apliiq"];
        const results = [];
        for (const type of providerTypes) {
          const latest = await this.getLatestProviderHealth(type);
          if (latest) results.push(latest);
        }
        return results;
      }
      async getProviderHealthStats(providerType, hours = 24) {
        const cutoff = Date.now() - hours * 60 * 60 * 1e3;
        const logs = this.providerHealthLogs.filter(
          (l) => l.providerType === providerType && (l.checkTime?.getTime() || 0) > cutoff
        );
        if (logs.length === 0) {
          return { uptimePercent: 0, avgResponseTime: 0, totalChecks: 0 };
        }
        const healthyCount = logs.filter((l) => l.isHealthy).length;
        const totalResponseTime = logs.reduce((sum, l) => sum + (l.responseTimeMs || 0), 0);
        return {
          uptimePercent: Math.round(healthyCount / logs.length * 100 * 100) / 100,
          avgResponseTime: Math.round(totalResponseTime / logs.length),
          totalChecks: logs.length
        };
      }
      // Gift Mode: Package operations
      giftPackages = /* @__PURE__ */ new Map();
      giftCodes = /* @__PURE__ */ new Map();
      giftRedemptions = /* @__PURE__ */ new Map();
      async getAllGiftPackages() {
        return Array.from(this.giftPackages.values());
      }
      async getActiveGiftPackages() {
        return Array.from(this.giftPackages.values()).filter((p) => p.isActive);
      }
      async getGiftPackage(id) {
        return this.giftPackages.get(id);
      }
      async createGiftPackage(pkg) {
        const newPkg = {
          id: crypto.randomUUID(),
          name: pkg.name,
          description: pkg.description ?? null,
          giftType: pkg.giftType ?? "product",
          masterProductId: pkg.masterProductId ?? null,
          dynamicsTier: pkg.dynamicsTier ?? null,
          dynamicsMonths: pkg.dynamicsMonths ?? null,
          price: pkg.price,
          allowColorChoice: pkg.allowColorChoice ?? true,
          allowSizeChoice: pkg.allowSizeChoice ?? true,
          allowQrCustomization: pkg.allowQrCustomization ?? true,
          includePersonalMessage: pkg.includePersonalMessage ?? true,
          redemptionValidDays: pkg.redemptionValidDays ?? 365,
          displayImage: pkg.displayImage ?? null,
          isActive: pkg.isActive ?? true,
          sortOrder: pkg.sortOrder ?? 0,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.giftPackages.set(newPkg.id, newPkg);
        return newPkg;
      }
      async updateGiftPackage(id, pkg) {
        const existing = this.giftPackages.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...pkg, updatedAt: /* @__PURE__ */ new Date() };
        this.giftPackages.set(id, updated);
        return updated;
      }
      async deleteGiftPackage(id) {
        this.giftPackages.delete(id);
      }
      // Gift Mode: Code operations
      async getGiftCode(id) {
        return this.giftCodes.get(id);
      }
      async getGiftCodeByCode(code) {
        return Array.from(this.giftCodes.values()).find((c) => c.code === code);
      }
      async getGiftCodesByBuyer(buyerUserId) {
        return Array.from(this.giftCodes.values()).filter((c) => c.buyerUserId === buyerUserId);
      }
      async createGiftCode(code) {
        const newCode = {
          id: crypto.randomUUID(),
          code: code.code,
          giftPackageId: code.giftPackageId,
          buyerUserId: code.buyerUserId ?? null,
          buyerEmail: code.buyerEmail ?? null,
          buyerName: code.buyerName ?? null,
          personalMessage: code.personalMessage ?? null,
          orderId: code.orderId ?? null,
          stripePaymentId: code.stripePaymentId ?? null,
          purchasedAt: /* @__PURE__ */ new Date(),
          expiresAt: code.expiresAt,
          status: code.status ?? "active",
          lastEmailedTo: code.lastEmailedTo ?? null,
          lastEmailedAt: code.lastEmailedAt ?? null,
          createdAt: /* @__PURE__ */ new Date()
        };
        this.giftCodes.set(newCode.id, newCode);
        return newCode;
      }
      async updateGiftCode(id, code) {
        const existing = this.giftCodes.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...code };
        this.giftCodes.set(id, updated);
        return updated;
      }
      // Gift Mode: Redemption operations
      async getGiftRedemption(id) {
        return this.giftRedemptions.get(id);
      }
      async getGiftRedemptionByCode(giftCodeId) {
        return Array.from(this.giftRedemptions.values()).find((r) => r.giftCodeId === giftCodeId);
      }
      async getGiftRedemptionsByRecipient(recipientEmail) {
        return Array.from(this.giftRedemptions.values()).filter((r) => r.recipientEmail === recipientEmail);
      }
      async createGiftRedemption(redemption) {
        const newRedemption = {
          id: crypto.randomUUID(),
          giftCodeId: redemption.giftCodeId,
          recipientUserId: redemption.recipientUserId ?? null,
          recipientEmail: redemption.recipientEmail ?? null,
          recipientName: redemption.recipientName ?? null,
          selectedColor: redemption.selectedColor ?? null,
          selectedSize: redemption.selectedSize ?? null,
          qrContent: redemption.qrContent ?? null,
          qrStyle: redemption.qrStyle ?? null,
          shippingAddress: redemption.shippingAddress ?? null,
          dynamicsSubscriptionId: redemption.dynamicsSubscriptionId ?? null,
          dynamicsContentSetId: redemption.dynamicsContentSetId ?? null,
          fulfillmentOrderId: redemption.fulfillmentOrderId ?? null,
          fulfillmentProvider: redemption.fulfillmentProvider ?? null,
          fulfillmentStatus: redemption.fulfillmentStatus ?? "pending",
          trackingNumber: redemption.trackingNumber ?? null,
          trackingUrl: redemption.trackingUrl ?? null,
          redeemedAt: /* @__PURE__ */ new Date(),
          fulfilledAt: redemption.fulfilledAt ?? null,
          shippedAt: redemption.shippedAt ?? null,
          deliveredAt: redemption.deliveredAt ?? null
        };
        this.giftRedemptions.set(newRedemption.id, newRedemption);
        return newRedemption;
      }
      async updateGiftRedemption(id, redemption) {
        const existing = this.giftRedemptions.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...redemption };
        this.giftRedemptions.set(id, updated);
        return updated;
      }
      // Email Template operations (in-memory stubs)
      emailTemplates = /* @__PURE__ */ new Map();
      emailLogs = [];
      async getEmailTemplates() {
        return Array.from(this.emailTemplates.values());
      }
      async getEmailTemplate(id) {
        return this.emailTemplates.get(id);
      }
      async getEmailTemplateByTrigger(trigger) {
        return Array.from(this.emailTemplates.values()).find((t) => t.trigger === trigger);
      }
      async createEmailTemplate(template) {
        const newTemplate = {
          id: crypto.randomUUID(),
          trigger: template.trigger,
          name: template.name,
          subject: template.subject,
          htmlContent: template.htmlContent,
          textContent: template.textContent ?? null,
          isEnabled: template.isEnabled ?? true,
          description: template.description ?? null,
          variables: template.variables ?? null,
          createdAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        };
        this.emailTemplates.set(newTemplate.id, newTemplate);
        return newTemplate;
      }
      async updateEmailTemplate(id, template) {
        const existing = this.emailTemplates.get(id);
        if (!existing) return void 0;
        const updated = { ...existing, ...template, updatedAt: /* @__PURE__ */ new Date() };
        this.emailTemplates.set(id, updated);
        return updated;
      }
      async deleteEmailTemplate(id) {
        this.emailTemplates.delete(id);
      }
      async getEmailLogs(limit = 100) {
        return this.emailLogs.slice(0, limit);
      }
      async logEmail(log2) {
        const newLog = {
          ...log2,
          id: crypto.randomUUID(),
          sentAt: /* @__PURE__ */ new Date()
        };
        this.emailLogs.unshift(newLog);
        return newLog;
      }
    };
    baseStorage = db2 ? new DbStorage() : new MemStorage();
    wrappedStorage = null;
    storageInitialized = false;
    initPromise = null;
    storage = new Proxy(baseStorage, {
      get(target, prop, receiver) {
        const actualStorage = wrappedStorage || target;
        const value = Reflect.get(actualStorage, prop, actualStorage);
        if (typeof value === "function") {
          return value.bind(actualStorage);
        }
        return value;
      }
    });
  }
});

// server/db.ts
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle as drizzle2 } from "drizzle-orm/neon-serverless";
import ws from "ws";
var pool, db3;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    neonConfig.webSocketConstructor = ws;
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL must be set. Did you forget to provision a database?"
      );
    }
    pool = new Pool({ connectionString: process.env.DATABASE_URL });
    db3 = drizzle2({ client: pool, schema: schema_exports });
  }
});

// server/lib/qr-generator.ts
var qr_generator_exports = {};
__export(qr_generator_exports, {
  generateImageQRCode: () => generateImageQRCode,
  generateTextQRCode: () => generateTextQRCode,
  sanitizeQRContent: () => sanitizeQRContent,
  validateQRContent: () => validateQRContent
});
import QRCode from "qrcode";
async function generateTextQRCode(text2, style = {}) {
  const options = {
    errorCorrectionLevel: "H",
    type: "image/png",
    quality: 1,
    margin: 1,
    color: {
      dark: style.color || "#000000",
      light: style.backgroundColor || "#FFFFFF"
    }
  };
  try {
    const dataUrl = await QRCode.toDataURL(text2, options);
    return dataUrl;
  } catch (error) {
    throw new Error(`Failed to generate QR code: ${error}`);
  }
}
async function generateImageQRCode(imageUrl, style = {}) {
  const options = {
    errorCorrectionLevel: "H",
    type: "image/png",
    quality: 1,
    margin: 1,
    color: {
      dark: style.color || "#000000",
      light: style.backgroundColor || "#FFFFFF"
    }
  };
  try {
    const dataUrl = await QRCode.toDataURL(imageUrl, options);
    return dataUrl;
  } catch (error) {
    throw new Error(`Failed to generate QR code: ${error}`);
  }
}
function sanitizeQRContent(content) {
  if (!content) return "";
  let sanitized = content.trim();
  sanitized = sanitized.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
  return sanitized;
}
function validateQRContent(content, type) {
  if (!content || content.trim().length === 0) {
    return false;
  }
  const lowerContent = content.toLowerCase().trim();
  for (const protocol of DANGEROUS_PROTOCOLS) {
    if (lowerContent.startsWith(protocol)) {
      return false;
    }
  }
  for (const pattern of SUSPICIOUS_PATTERNS) {
    if (pattern.test(content)) {
      return false;
    }
  }
  if (type === "text") {
    return content.length <= 2953;
  }
  if (type === "image") {
    try {
      const url = new URL(content);
      const allowedProtocols = ["http:", "https:"];
      if (!allowedProtocols.includes(url.protocol)) {
        return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  return false;
}
var DANGEROUS_PROTOCOLS, SUSPICIOUS_PATTERNS;
var init_qr_generator = __esm({
  "server/lib/qr-generator.ts"() {
    "use strict";
    DANGEROUS_PROTOCOLS = ["javascript:", "data:", "vbscript:", "file:"];
    SUSPICIOUS_PATTERNS = [
      /<script\b/i,
      /javascript:/i,
      /on\w+\s*=/i,
      /\beval\s*\(/i,
      /\bdocument\./i,
      /\bwindow\./i
    ];
  }
});

// server/lib/printify.ts
var printify_exports = {};
__export(printify_exports, {
  detectCategory: () => detectCategory,
  getProviderColorsWithFallback: () => getProviderColorsWithFallback,
  getUSAPrintProviders: () => getUSAPrintProviders,
  printify: () => printify,
  syncProductPlacements: () => syncProductPlacements,
  syncProductVariants: () => syncProductVariants
});
import * as fs from "fs";
import * as path from "path";
async function getUSAPrintProviders(blueprintId) {
  const providers = await printify.getPrintProviders(blueprintId);
  return providers.filter((p) => p.location.country === "US" || p.location.country === "USA");
}
async function syncProductPlacements(blueprintId, printProviderId) {
  try {
    const result = await printify.getVariants(blueprintId, printProviderId);
    const variants = result.variants || [];
    const placementMap = /* @__PURE__ */ new Map();
    for (const variant of variants) {
      if (variant.placeholders) {
        for (const placeholder of variant.placeholders) {
          const position = placeholder.position;
          if (!placementMap.has(position)) {
            placementMap.set(position, {
              position,
              label: formatPlacementLabel(position),
              printArea: {
                position,
                width: placeholder.width,
                height: placeholder.height
              }
            });
          }
        }
      }
    }
    const placements = Array.from(placementMap.values());
    const blueprint = await printify.getBlueprintDetails(blueprintId);
    const mockupImageUrl = blueprint.images?.[0] || null;
    return { placements, mockupImageUrl };
  } catch (error) {
    console.error("Error syncing product placements:", error);
    return { placements: [], mockupImageUrl: null };
  }
}
function formatPlacementLabel(position) {
  const labelMap = {
    "front": "Front",
    "back": "Back",
    "left": "Left Side",
    "right": "Right Side",
    "front_large": "Front (Large)",
    "front_small": "Front (Small)",
    "sleeve_left": "Left Sleeve",
    "sleeve_right": "Right Sleeve",
    "pocket": "Pocket",
    "center": "Center",
    "front_center": "Front Center",
    "back_center": "Back Center",
    "side": "Side",
    "wraparound": "Wraparound"
  };
  if (labelMap[position]) return labelMap[position];
  return position.split(/[_-]/).map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
}
async function getProviderColorsWithFallback(blueprintId, printProviderId, storage2) {
  const localProvider = await storage2.getPrintifyPrintProvider(blueprintId, printProviderId);
  if (localProvider?.availableColors && Array.isArray(localProvider.availableColors)) {
    const colors = localProvider.availableColors;
    const hasHexValues = colors.some((c) => c.hex);
    if (colors.length > 0 && hasHexValues) {
      console.log(`[ColorFallback] Using local colors for ${blueprintId}/${printProviderId}: ${colors.length} colors`);
      return colors;
    }
  }
  console.log(`[ColorFallback] Local colors missing for ${blueprintId}/${printProviderId}, calling Printify API...`);
  try {
    const { colors, sizes } = await syncProductVariants(blueprintId, printProviderId);
    if (colors.length > 0) {
      await storage2.updatePrintifyProviderCosts(blueprintId, printProviderId, {
        availableColors: colors,
        availableSizes: sizes
      });
      console.log(`[ColorFallback] Saved ${colors.length} colors from Printify to local database`);
    }
    return colors;
  } catch (error) {
    console.error(`[ColorFallback] Printify API call failed: ${error.message}`);
    return [];
  }
}
async function syncProductVariants(blueprintId, printProviderId) {
  const result = await printify.getVariants(blueprintId, printProviderId);
  const variants = result.variants || [];
  const colorMap = /* @__PURE__ */ new Map();
  const sizeSet = /* @__PURE__ */ new Set();
  for (const variant of variants) {
    if (variant.options?.color) {
      const colorName = variant.options.color;
      if (!colorMap.has(colorName)) {
        const hex = getColorHex(colorName);
        colorMap.set(colorName, hex);
      }
    }
    if (variant.options?.size) {
      sizeSet.add(variant.options.size);
    }
  }
  const colors = Array.from(colorMap.entries()).map(([name, hex]) => ({ name, hex }));
  const sizeOrder = ["XXS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL", "11oz", "15oz"];
  const sizes = Array.from(sizeSet).sort((a, b) => {
    const aIdx = sizeOrder.indexOf(a);
    const bIdx = sizeOrder.indexOf(b);
    if (aIdx !== -1 && bIdx !== -1) return aIdx - bIdx;
    if (aIdx !== -1) return -1;
    if (bIdx !== -1) return 1;
    return a.localeCompare(b);
  });
  return { colors, sizes, variants };
}
function getColorHex(colorName) {
  const colorMap = {
    // Basic colors
    "White": "#FFFFFF",
    "Black": "#000000",
    "Red": "#DC2626",
    "Blue": "#2563EB",
    "Green": "#16A34A",
    "Yellow": "#FACC15",
    "Orange": "#F97316",
    "Purple": "#9333EA",
    "Pink": "#EC4899",
    "Brown": "#92400E",
    "Gray": "#6B7280",
    "Grey": "#6B7280",
    // Heather variants
    "Heather Gray": "#9CA3AF",
    "Heather Grey": "#9CA3AF",
    "Athletic Heather": "#9CA3AF",
    "Dark Heather": "#374151",
    "Dark Grey Heather": "#4B5563",
    "Heather Navy": "#1E3A5F",
    "Heather Peach": "#FBBF94",
    "Heather Mauve": "#C4A5A5",
    "Heather Olive": "#6B7355",
    "Heather Red": "#B91C1C",
    "Heather Blue": "#60A5FA",
    "Heather Green": "#22C55E",
    "Heather Purple": "#A855F7",
    "Heather Prism Dusty Blue": "#7DA7BC",
    "Heather Prism Ice Blue": "#B8D4E3",
    "Heather Prism Mint": "#98E4D2",
    "Heather Prism Peach": "#F5C8A3",
    "Heather Prism Lilac": "#D8B4E2",
    "Heather Raspberry": "#9B1B57",
    "Heather Midnight Navy": "#1E3A5F",
    "Heather True Royal": "#3B5DC9",
    "Heather Deep Teal": "#0D5C63",
    "Heather Forest": "#1D4D2B",
    // Sport/Athletic
    "Sport Gray": "#6B7280",
    "Sport Grey": "#6B7280",
    // Blues
    "Navy": "#1E3A5F",
    "Navy Blue": "#1E3A5F",
    "Midnight Navy": "#1A2744",
    "True Navy": "#1E3A5F",
    "Royal": "#4169E1",
    "Royal Blue": "#4169E1",
    "True Royal": "#4169E1",
    "Light Blue": "#93C5FD",
    "Sky Blue": "#87CEEB",
    "Carolina Blue": "#56A0D3",
    "Ocean": "#006994",
    "Ocean Blue": "#006994",
    "Teal": "#0D9488",
    "Deep Teal": "#0D5C63",
    "Sapphire": "#0F52BA",
    "Indigo": "#4B0082",
    "Aqua": "#06B6D4",
    "Turquoise": "#40E0D0",
    "Cobalt": "#0047AB",
    "Steel Blue": "#4682B4",
    "Slate": "#708090",
    "Denim": "#1560BD",
    // Greens
    "Forest Green": "#228B22",
    "Dark Green": "#006400",
    "Kelly Green": "#4CBB17",
    "Irish Green": "#009A44",
    "Turf Green": "#3C8D0D",
    "Military Green": "#4B5320",
    "Olive": "#6B8E23",
    "Olive Drab": "#6B8E23",
    "Sage": "#9CAF88",
    "Mint": "#98FB98",
    "Seafoam": "#71EEB8",
    "Lime": "#84CC16",
    "Leaf": "#568203",
    "Hunter Green": "#355E3B",
    // Reds & Pinks
    "Cardinal": "#C41E3A",
    "Cardinal Red": "#C41E3A",
    "Maroon": "#800000",
    "Burgundy": "#722F37",
    "Crimson": "#DC143C",
    "Cherry Red": "#DE3163",
    "Light Pink": "#FFB6C1",
    "Hot Pink": "#FF69B4",
    "Fuchsia": "#FF00FF",
    "Magenta": "#FF00FF",
    "Berry": "#8E4585",
    "Coral": "#FF7F50",
    "Salmon": "#FA8072",
    "Rose": "#FF007F",
    "Heliconia": "#E31557",
    "Azalea": "#FF3399",
    // Purples
    "Violet": "#8B5CF6",
    "Lavender": "#E6E6FA",
    "Plum": "#8E4585",
    "Lilac": "#C8A2C8",
    "Orchid": "#DA70D6",
    "Purple Rush": "#652DC1",
    "Team Purple": "#652DC1",
    // Browns & Neutrals
    "Charcoal": "#36454F",
    "Natural": "#F5F5DC",
    "Cream": "#FFFDD0",
    "Solid Cream": "#FFFDD0",
    "Beige": "#F5F5DC",
    "Sand": "#C2B280",
    "Tan": "#D2B48C",
    "Khaki": "#C3B091",
    "Chocolate": "#7B3F00",
    "Dark Chocolate": "#3D1C02",
    "Solid Dark Chocolate": "#3D1C02",
    "Coffee": "#6F4E37",
    "Espresso": "#3C2218",
    "Chestnut": "#954535",
    "Coyote Brown": "#81613C",
    "Russet": "#80461B",
    // Grays
    "Ice Grey": "#D3D3D3",
    "Ice Gray": "#D3D3D3",
    "Light Gray": "#D1D5DB",
    "Light Grey": "#D1D5DB",
    "Silver": "#C0C0C0",
    "Ash": "#B2BEB5",
    "Graphite": "#383838",
    "Charcoal Heather": "#4B5563",
    "Heavy Metal": "#2E3339",
    "Solid Heavy Metal": "#2E3339",
    "Smoke": "#738276",
    "Storm": "#4F5D75",
    // Golds & Yellows
    "Gold": "#FFD700",
    "Daisy": "#FFD93D",
    "Sunshine": "#FFD93D",
    "Lemon": "#FFF44F",
    "Banana": "#FFE135",
    "Mustard": "#FFDB58",
    "Honey": "#EB9605",
    // Oranges
    "Burnt Orange": "#CC5500",
    "Tangerine": "#FF9966",
    "Sunset": "#FAD6A5",
    "Peach": "#FFCBA4",
    "Apricot": "#FBCEB1",
    "Tennessee Orange": "#FF8200",
    "Texas Orange": "#BF5700",
    // Solid prefix variants (Printify uses these)
    "Solid Black": "#000000",
    "Solid White": "#FFFFFF",
    "Solid Red": "#DC2626",
    "Solid Navy": "#1E3A5F",
    "Solid Natural": "#F5F5DC",
    "Solid Kelly Green": "#4CBB17",
    "Solid Light Blue": "#93C5FD",
    "Solid Light Grey": "#D1D5DB",
    "Solid Light Gray": "#D1D5DB",
    "Solid Light Pink": "#FFB6C1",
    "Solid Midnight Navy": "#1A2744",
    "Solid Military Green": "#4B5320",
    "Solid Purple Rush": "#652DC1",
    "Solid Royal": "#4169E1",
    "Solid Turquoise": "#40E0D0",
    "Solid Cardinal Red": "#C41E3A"
  };
  if (colorMap[colorName]) return colorMap[colorName];
  const lowerName = colorName.toLowerCase();
  for (const [key, value] of Object.entries(colorMap)) {
    if (key.toLowerCase() === lowerName) return value;
  }
  for (const [key, value] of Object.entries(colorMap)) {
    if (lowerName.includes(key.toLowerCase()) || key.toLowerCase().includes(lowerName)) {
      return value;
    }
  }
  if (lowerName.includes("black")) return "#000000";
  if (lowerName.includes("white")) return "#FFFFFF";
  if (lowerName.includes("navy")) return "#1E3A5F";
  if (lowerName.includes("red")) return "#DC2626";
  if (lowerName.includes("blue")) return "#2563EB";
  if (lowerName.includes("green")) return "#16A34A";
  if (lowerName.includes("yellow")) return "#FACC15";
  if (lowerName.includes("orange")) return "#F97316";
  if (lowerName.includes("purple")) return "#9333EA";
  if (lowerName.includes("pink")) return "#EC4899";
  if (lowerName.includes("gray") || lowerName.includes("grey")) return "#6B7280";
  if (lowerName.includes("brown") || lowerName.includes("chocolate")) return "#92400E";
  if (lowerName.includes("heather")) return "#9CA3AF";
  return "#808080";
}
function detectCategory(title, brand) {
  const combined = `${title} ${brand}`.toLowerCase();
  if (combined.includes("hat") || combined.includes("cap") || combined.includes("beanie")) {
    return "hats";
  }
  if (combined.includes("mug") || combined.includes("cup") || combined.includes("tumbler")) {
    return "drinkware";
  }
  if (combined.includes("bag") || combined.includes("tote") || combined.includes("backpack")) {
    return "bags";
  }
  if (combined.includes("hoodie") || combined.includes("sweatshirt")) {
    return "hoodies";
  }
  if (combined.includes("tank")) {
    return "tanks";
  }
  if (combined.includes("polo")) {
    return "polos";
  }
  if (combined.includes("long sleeve")) {
    return "long-sleeves";
  }
  if (combined.includes("shirt") || combined.includes("tee") || combined.includes("t-shirt")) {
    return "t-shirts";
  }
  if (combined.includes("sticker") || combined.includes("decal")) {
    return "stickers";
  }
  if (combined.includes("poster") || combined.includes("print") || combined.includes("canvas")) {
    return "wall-art";
  }
  if (combined.includes("phone") || combined.includes("case")) {
    return "phone-cases";
  }
  return "other";
}
var PRINTIFY_API_BASE, PrintifyClient, printify;
var init_printify = __esm({
  "server/lib/printify.ts"() {
    "use strict";
    PRINTIFY_API_BASE = "https://api.printify.com/v1";
    PrintifyClient = class _PrintifyClient {
      getApiKey() {
        let key = (process.env.PRINTIFY_API_KEY || process.env.PRINTIFY_API_KEY_2 || "").trim().replace(/\s+/g, "");
        if (!key || !key.startsWith("eyJ")) {
          try {
            const tokenPath = path.join(process.cwd(), "server", "printify-token.txt");
            if (fs.existsSync(tokenPath)) {
              key = fs.readFileSync(tokenPath, "utf-8").trim().replace(/\s+/g, "");
            }
          } catch (e) {
          }
        }
        return key;
      }
      getShopId() {
        return (process.env.PRINTIFY_SHOP_ID || "").trim().replace(/\s+/g, "");
      }
      get headers() {
        return {
          "Authorization": `Bearer ${this.getApiKey()}`,
          "Content-Type": "application/json"
        };
      }
      get isConfigured() {
        return Boolean(this.getApiKey() && this.getShopId());
      }
      async request(endpoint, options = {}, retries = 3) {
        if (!this.isConfigured) {
          throw new Error("Printify API not configured. Missing API key or Shop ID.");
        }
        const url = endpoint.startsWith("http") ? endpoint : `${PRINTIFY_API_BASE}${endpoint}`;
        let lastError = null;
        for (let attempt = 0; attempt < retries; attempt++) {
          try {
            const response = await fetch(url, {
              ...options,
              headers: {
                ...this.headers,
                ...options.headers
              }
            });
            if ((response.status === 401 || response.status === 429) && attempt < retries - 1) {
              const waitTime = 1e3 * Math.pow(2, attempt);
              console.log(`Printify API ${response.status}, retrying in ${waitTime}ms (attempt ${attempt + 1}/${retries})`);
              await new Promise((r) => setTimeout(r, waitTime));
              continue;
            }
            if (!response.ok) {
              const error = await response.text();
              throw new Error(`Printify API error: ${response.status} - ${error}`);
            }
            return response.json();
          } catch (error) {
            lastError = error;
            if (attempt < retries - 1) {
              const waitTime = 1e3 * Math.pow(2, attempt);
              console.log(`Printify API error, retrying in ${waitTime}ms (attempt ${attempt + 1}/${retries}): ${error.message}`);
              await new Promise((r) => setTimeout(r, waitTime));
            }
          }
        }
        throw lastError || new Error("Printify API request failed after retries");
      }
      async getShops() {
        return this.request("/shops.json");
      }
      async getCatalogBlueprints() {
        return this.request("/catalog/blueprints.json");
      }
      async getBlueprintDetails(blueprintId) {
        return this.request(`/catalog/blueprints/${blueprintId}.json`);
      }
      async getPrintProviders(blueprintId) {
        return this.request(`/catalog/blueprints/${blueprintId}/print_providers.json`);
      }
      async getVariants(blueprintId, printProviderId) {
        return this.request(`/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/variants.json`);
      }
      /**
       * Get print areas (placements) available for a blueprint/provider combo.
       * Returns position names like 'front', 'back', 'left', 'right', etc.
       */
      async getPrintAreas(blueprintId, printProviderId) {
        return this.request(`/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/shipping.json`).catch(() => {
          return this.request(`/catalog/print_providers/${printProviderId}/shipping.json`);
        });
      }
      /**
       * Get a placement that works for ALL variants (intersection).
       * Returns the placement name and the variant IDs that support it.
       * Throws if no common placement exists.
       */
      async getCommonPlacement(blueprintId, printProviderId) {
        const variantsData = await this.request(
          `/catalog/blueprints/${blueprintId}/print_providers/${printProviderId}/variants.json`
        );
        const placementToVariants = /* @__PURE__ */ new Map();
        const allVariantIds = [];
        for (const variant of variantsData.variants) {
          allVariantIds.push(variant.id);
          if (variant.placeholders && variant.placeholders.length > 0) {
            for (const placeholder of variant.placeholders) {
              if (placeholder.position) {
                if (!placementToVariants.has(placeholder.position)) {
                  placementToVariants.set(placeholder.position, /* @__PURE__ */ new Set());
                }
                placementToVariants.get(placeholder.position).add(variant.id);
              }
            }
          }
        }
        const totalVariants = allVariantIds.length;
        const MAX_VARIANTS = 100;
        for (const [placement, variantSet] of placementToVariants) {
          if (variantSet.size === totalVariants) {
            const limitedIds = allVariantIds.slice(0, MAX_VARIANTS);
            console.log(`[Printify] Found common placement '${placement}' for ${limitedIds.length}/${totalVariants} variants (capped at ${MAX_VARIANTS})`);
            return { placement, variantIds: limitedIds };
          }
        }
        let bestPlacement = "";
        let bestCoverage = 0;
        let bestVariantIds = [];
        for (const [placement, variantSet] of placementToVariants) {
          if (variantSet.size > bestCoverage) {
            bestCoverage = variantSet.size;
            bestPlacement = placement;
            bestVariantIds = Array.from(variantSet).slice(0, MAX_VARIANTS);
          }
        }
        if (bestPlacement && bestCoverage > 0) {
          console.log(`[Printify] Best placement '${bestPlacement}' covers ${Math.min(bestCoverage, MAX_VARIANTS)}/${totalVariants} variants`);
          return { placement: bestPlacement, variantIds: bestVariantIds };
        }
        throw new Error(`No valid print placements found for blueprint ${blueprintId}. Cannot extract real production costs.`);
      }
      async getShopProducts() {
        return this.request(`/shops/${this.getShopId()}/products.json`);
      }
      async getProduct(productId) {
        return this.request(`/shops/${this.getShopId()}/products/${productId}.json`);
      }
      async createProduct(productData) {
        return this.request(`/shops/${this.getShopId()}/products.json`, {
          method: "POST",
          body: JSON.stringify(productData)
        });
      }
      async uploadImage(imageUrl, fileName) {
        return this.request(`/uploads/images.json`, {
          method: "POST",
          body: JSON.stringify({
            file_name: fileName,
            url: imageUrl
          })
        });
      }
      async createOrder(orderData) {
        return this.request(`/shops/${this.getShopId()}/orders.json`, {
          method: "POST",
          body: JSON.stringify(orderData)
        });
      }
      async submitOrderToProduction(orderId) {
        return this.request(`/shops/${this.getShopId()}/orders/${orderId}/send_to_production.json`, {
          method: "POST"
        });
      }
      async getOrder(orderId) {
        return this.request(`/shops/${this.getShopId()}/orders/${orderId}.json`);
      }
      async getOrders() {
        return this.request(`/shops/${this.getShopId()}/orders.json`);
      }
      async calculateShipping(orderData) {
        return this.request(`/shops/${this.getShopId()}/orders/shipping.json`, {
          method: "POST",
          body: JSON.stringify(orderData)
        });
      }
      async deleteProduct(productId) {
        await this.request(`/shops/${this.getShopId()}/products/${productId}.json`, {
          method: "DELETE"
        });
      }
      /**
       * Request a publishing preview for a product - this triggers mockup rendering.
       * CRITICAL: This is the ONLY way to get Printify to render artwork onto mockups.
       * Draft products never have is_rendered=true; we must use this endpoint.
       * 
       * Flow:
       * 1. POST /shops/{shop_id}/products/{product_id}/publishing/preview.json - starts render task
       * 2. Poll GET /shops/{shop_id}/publishing/requests/{request_id}.json until status === "completed"
       * 3. Extract mockups[].images[] from completed response
       */
      async requestPublishingPreview(productId) {
        console.log(`[Printify] Requesting publishing preview for product ${productId}...`);
        const previewRequest = await this.request(`/shops/${this.getShopId()}/products/${productId}/publishing/preview.json`, {
          method: "POST",
          body: JSON.stringify({})
        });
        console.log(`[Printify] Publishing preview request started, ID: ${previewRequest.id}`);
        return { id: previewRequest.id, status: "pending" };
      }
      /**
       * Poll publishing preview status until completed
       * Returns the mockup URLs when ready
       */
      async getPublishingPreviewStatus(requestId) {
        return this.request(`/shops/${this.getShopId()}/publishing/requests/${requestId}.json`);
      }
      /**
       * Full publishing preview flow - start task, poll until complete, return mockups
       * Timeout after specified milliseconds
       */
      async getRenderedMockups(productId, timeoutMs = 6e4) {
        try {
          const previewResult = await this.requestPublishingPreview(productId);
          if (!previewResult.id) {
            console.error(`[Printify] No preview request ID returned`);
            return null;
          }
          const requestId = previewResult.id;
          const startTime = Date.now();
          let attempts = 0;
          while (Date.now() - startTime < timeoutMs) {
            attempts++;
            const delay = Math.min(3e3 * Math.pow(1.2, attempts - 1), 1e4);
            await new Promise((resolve) => setTimeout(resolve, delay));
            const elapsedSec = ((Date.now() - startTime) / 1e3).toFixed(1);
            console.log(`[Printify] Preview poll attempt ${attempts} (${elapsedSec}s)...`);
            try {
              const status = await this.getPublishingPreviewStatus(requestId);
              console.log(`[Printify] Preview status: ${status.status}`);
              if (status.status === "completed" && status.mockups && status.mockups.length > 0) {
                const allImages = [];
                for (const mockup of status.mockups) {
                  if (mockup.images) {
                    allImages.push(...mockup.images);
                  }
                }
                console.log(`[Printify] Got ${allImages.length} rendered mockup images!`);
                return allImages;
              } else if (status.status === "failed") {
                console.error(`[Printify] Preview rendering failed`);
                return null;
              }
            } catch (pollErr) {
              console.log(`[Printify] Preview poll error: ${pollErr.message}`);
            }
          }
          console.warn(`[Printify] Preview rendering timed out after ${timeoutMs / 1e3}s`);
          return null;
        } catch (err) {
          console.error(`[Printify] Publishing preview error: ${err.message}`);
          return null;
        }
      }
      /**
       * Create a placeholder product WITH ONE PRINT to get the true minimum cost.
       * REQUIRES an image ID - will NOT fall back to blank garment cost.
       * 
       * @param blueprintId - The blueprint ID
       * @param printProviderId - The print provider ID  
       * @param variantIds - Array of variant IDs to enable
       * @param imageId - Printify image ID (REQUIRED)
       * @param placement - The print position to use (from getFirstAvailablePlacement)
       */
      async createPlaceholderProduct(blueprintId, printProviderId, variantIds, imageId, placement) {
        if (!imageId) {
          throw new Error("Image ID is required to get real production costs");
        }
        const print_areas = [
          {
            variant_ids: variantIds,
            placeholders: [
              {
                position: placement,
                images: [{ id: imageId, x: 0.5, y: 0.5, scale: 1, angle: 0 }]
              }
            ]
          }
        ];
        const productData = {
          title: `[COST_SYNC] Blueprint ${blueprintId}`,
          description: "Temporary product for cost extraction - will be deleted",
          blueprint_id: blueprintId,
          print_provider_id: printProviderId,
          variants: variantIds.map((id) => ({
            id,
            price: 100,
            // Printify requires price > 0 (100 cents = $1.00 placeholder)
            is_enabled: true
          })),
          print_areas
        };
        console.log(`[Printify] Creating placeholder product with '${placement}' placement for real cost...`);
        const result = await this.request(
          `/shops/${this.getShopId()}/products.json`,
          { method: "POST", body: JSON.stringify(productData) }
        );
        console.log(`[Printify] Created placeholder product ${result.id} with '${placement}' placement`);
        return result;
      }
      // Static placeholder image ID - cached after first upload
      static placeholderImageId = null;
      /**
       * Get or create a placeholder image for cost extraction.
       * Uses a simple 100x100 QR placeholder image.
       */
      async getOrCreatePlaceholderImage() {
        if (_PrintifyClient.placeholderImageId) {
          return _PrintifyClient.placeholderImageId;
        }
        const base64Png = await this.createSimplePng();
        const result = await this.request(
          `/uploads/images.json`,
          {
            method: "POST",
            body: JSON.stringify({
              file_name: "qr-placeholder.png",
              contents: base64Png
            })
          }
        );
        _PrintifyClient.placeholderImageId = result.id;
        console.log(`[Printify] Uploaded placeholder image: ${result.id}`);
        return result.id;
      }
      /**
       * Create a placeholder QR code image as base64 PNG
       */
      async createSimplePng() {
        const QRCode5 = await import("qrcode");
        const buffer = await QRCode5.toBuffer("PLACEHOLDER", {
          width: 200,
          margin: 1,
          color: { dark: "#000000", light: "#ffffff" }
        });
        return buffer.toString("base64");
      }
      /**
       * Extract production costs from a product's variants.
       * Returns min/max costs in cents.
       */
      extractCostsFromProduct(product) {
        const costs = [];
        for (const variant of product.variants || []) {
          if (typeof variant.cost === "number" && variant.cost > 0) {
            costs.push(variant.cost);
          }
        }
        if (costs.length === 0) {
          return { minCost: 0, maxCost: 0 };
        }
        return {
          minCost: Math.min(...costs),
          maxCost: Math.max(...costs)
        };
      }
      /**
       * Extract unique colors and sizes from a product's variants.
       * Returns arrays of color objects and size strings.
       */
      extractColorsAndSizes(product) {
        const colorMap = /* @__PURE__ */ new Map();
        const sizeSet = /* @__PURE__ */ new Set();
        const sizePatterns = /* @__PURE__ */ new Set(["XS", "S", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL", "XXL", "XXXL", "ONE SIZE", "OS"]);
        const isSize = (value) => {
          return sizePatterns.has(value.toUpperCase().trim());
        };
        for (const variant of product.variants || []) {
          if (variant.options) {
            for (const opt of variant.options) {
              const value = opt.value || opt.title || "";
              if (!value) continue;
              if (opt.type === "size" || opt.name?.toLowerCase().includes("size")) {
                sizeSet.add(value);
              } else if (opt.type === "color" || opt.name?.toLowerCase().includes("color")) {
                if (!isSize(value) && !colorMap.has(value.toLowerCase())) {
                  colorMap.set(value.toLowerCase(), {
                    name: value,
                    hex: opt.hex || void 0
                  });
                }
              }
            }
          }
          if (variant.title) {
            const parts = variant.title.split("/").map((p) => p.trim());
            for (const part of parts) {
              if (!part) continue;
              if (isSize(part)) {
                sizeSet.add(part);
              } else if (!colorMap.has(part.toLowerCase())) {
                colorMap.set(part.toLowerCase(), { name: part });
              }
            }
          }
        }
        const colors = Array.from(colorMap.values()).filter((c) => !isSize(c.name));
        return {
          colors,
          sizes: Array.from(sizeSet)
        };
      }
    };
    printify = new PrintifyClient();
  }
});

// server/lib/composite-image-generator.ts
var composite_image_generator_exports = {};
__export(composite_image_generator_exports, {
  generateCompositeImage: () => generateCompositeImage,
  generateDualColorComposites: () => generateDualColorComposites,
  generatePrintifyComposite: () => generatePrintifyComposite,
  getArtworkForColor: () => getArtworkForColor,
  isColorDark: () => isColorDark,
  overlayGraphicOnProduct: () => overlayGraphicOnProduct,
  overlayGraphicOnProductToDataUrl: () => overlayGraphicOnProductToDataUrl
});
import { createCanvas, loadImage } from "canvas";
import QRCode2 from "qrcode";
async function generateCompositeImage(options) {
  const {
    width = 1200,
    height = 1800,
    backgroundColor = "#FFFFFF",
    qrSize = 600,
    topText,
    bottomText,
    qrUrl,
    qrColor = "black"
  } = options;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, width, height);
  const padding = 60;
  const textColor = "#000000";
  let currentY = padding;
  if (topText && topText.text) {
    const fontSize = parseInt(topText.fontSize) * 3;
    const fontFamily = FONT_MAP[topText.fontFamily] || "Arial";
    const fillColor = topText.color || textColor;
    ctx.font = `bold ${fontSize}px "${fontFamily}"`;
    ctx.fillStyle = fillColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    if (topText.strokeColor && topText.strokeWidth && topText.strokeWidth > 0) {
      ctx.strokeStyle = topText.strokeColor;
      ctx.lineWidth = topText.strokeWidth * 3;
    }
    const lines = wrapText(ctx, topText.text, width - padding * 2);
    for (const line of lines) {
      if (topText.strokeColor && topText.strokeWidth && topText.strokeWidth > 0) {
        ctx.strokeText(line, width / 2, currentY);
      }
      ctx.fillText(line, width / 2, currentY);
      currentY += fontSize * 1.3;
    }
    currentY += padding;
  }
  const qrDark = qrColor === "white" ? "#FFFFFF" : "#000000";
  const qrLight = "transparent";
  const qrDataUrl = await QRCode2.toDataURL(qrUrl, {
    width: qrSize,
    margin: 2,
    color: { dark: qrDark, light: qrLight }
  });
  const qrImage = await loadImage(qrDataUrl);
  const qrX = (width - qrSize) / 2;
  const qrY = topText ? currentY : (height - qrSize) / 2 - (bottomText ? 100 : 0);
  ctx.drawImage(qrImage, qrX, qrY, qrSize, qrSize);
  currentY = qrY + qrSize + padding;
  if (bottomText && bottomText.text) {
    const fontSize = parseInt(bottomText.fontSize) * 3;
    const fontFamily = FONT_MAP[bottomText.fontFamily] || "Arial";
    const fillColor = bottomText.color || textColor;
    ctx.font = `bold ${fontSize}px "${fontFamily}"`;
    ctx.fillStyle = fillColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    if (bottomText.strokeColor && bottomText.strokeWidth && bottomText.strokeWidth > 0) {
      ctx.strokeStyle = bottomText.strokeColor;
      ctx.lineWidth = bottomText.strokeWidth * 3;
    }
    const lines = wrapText(ctx, bottomText.text, width - padding * 2);
    for (const line of lines) {
      if (bottomText.strokeColor && bottomText.strokeWidth && bottomText.strokeWidth > 0) {
        ctx.strokeText(line, width / 2, currentY);
      }
      ctx.fillText(line, width / 2, currentY);
      currentY += fontSize * 1.3;
    }
  }
  return canvas.toDataURL("image/png");
}
function wrapText(ctx, text2, maxWidth) {
  const words = text2.split(" ");
  const lines = [];
  let currentLine = "";
  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) {
    lines.push(currentLine);
  }
  return lines;
}
async function generatePrintifyComposite(qrUrl, topText, bottomText, printWidth = 1200, printHeight = 1800, qrColor = "black") {
  return generateCompositeImage({
    width: printWidth,
    height: printHeight,
    backgroundColor: "transparent",
    qrSize: Math.min(printWidth, printHeight) * 0.4,
    topText,
    bottomText,
    qrUrl,
    qrColor
  });
}
async function generateDualColorComposites(qrUrl, topText, bottomText, printWidth = 1200, printHeight = 1800) {
  const [blackVersion, whiteVersion] = await Promise.all([
    generatePrintifyComposite(qrUrl, topText, bottomText, printWidth, printHeight, "black"),
    generatePrintifyComposite(qrUrl, topText, bottomText, printWidth, printHeight, "white")
  ]);
  return { blackVersion, whiteVersion };
}
function isColorDark(hexColor) {
  const hex = hexColor.replace("#", "");
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance < 0.5;
}
function getArtworkForColor(hexColor, blackArtworkUrl, whiteArtworkUrl) {
  return isColorDark(hexColor) ? whiteArtworkUrl : blackArtworkUrl;
}
async function overlayGraphicOnProduct(options) {
  const {
    baseImageUrl,
    graphicUrl,
    position = "chest",
    graphicScale = 0.25,
    productType = "shirt"
  } = options;
  const baseImage = await loadImage(baseImageUrl);
  const graphicImage = await loadImage(graphicUrl);
  const canvas = createCanvas(baseImage.width, baseImage.height);
  const ctx = canvas.getContext("2d");
  ctx.drawImage(baseImage, 0, 0);
  const graphicWidth = baseImage.width * graphicScale;
  const graphicHeight = graphicImage.height / graphicImage.width * graphicWidth;
  let x, y;
  if (productType === "shirt") {
    if (position === "chest") {
      x = (baseImage.width - graphicWidth) / 2;
      y = baseImage.height * 0.28;
    } else if (position === "center") {
      x = (baseImage.width - graphicWidth) / 2;
      y = (baseImage.height - graphicHeight) / 2;
    } else {
      x = (baseImage.width - graphicWidth) / 2;
      y = baseImage.height * 0.35;
    }
  } else if (productType === "hat") {
    x = (baseImage.width - graphicWidth) / 2;
    y = baseImage.height * 0.35;
  } else if (productType === "bag") {
    x = (baseImage.width - graphicWidth) / 2;
    y = (baseImage.height - graphicHeight) / 2;
  } else {
    x = (baseImage.width - graphicWidth) / 2;
    y = (baseImage.height - graphicHeight) / 2;
  }
  ctx.drawImage(graphicImage, x, y, graphicWidth, graphicHeight);
  return canvas.toBuffer("image/png");
}
async function overlayGraphicOnProductToDataUrl(options) {
  const buffer = await overlayGraphicOnProduct(options);
  return `data:image/png;base64,${buffer.toString("base64")}`;
}
var FONT_MAP;
var init_composite_image_generator = __esm({
  "server/lib/composite-image-generator.ts"() {
    "use strict";
    FONT_MAP = {
      "Arial": "Arial",
      "Helvetica": "Helvetica",
      "Times New Roman": "Times New Roman",
      "Georgia": "Georgia",
      "Verdana": "Verdana",
      "Courier New": "Courier New",
      "Impact": "Impact",
      "Comic Sans MS": "Comic Sans MS",
      "Trebuchet MS": "Trebuchet MS",
      "Palatino Linotype": "Palatino Linotype"
    };
  }
});

// server/lib/firebase-storage-service.ts
import crypto2 from "crypto";
function useFirebaseStorage() {
  return true;
}
function ensureFirebaseInitialized() {
  if (!isFirebaseInitialized()) {
    initializeFirebase();
  }
}
function getMimeTypeFromUrl(url) {
  const ext = url.split(".").pop()?.toLowerCase() || "jpg";
  const mimeTypes = {
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "png": "image/png",
    "gif": "image/gif",
    "webp": "image/webp",
    "heic": "image/heic",
    "heif": "image/heif",
    "mp4": "video/mp4",
    "webm": "video/webm",
    "mov": "video/quicktime"
  };
  return mimeTypes[ext] || "application/octet-stream";
}
async function uploadToFirebaseStorage(buffer, fileName, mimeType, folder = "uploads") {
  ensureFirebaseInitialized();
  if (!ALLOWED_MIME_TYPES.includes(mimeType)) {
    throw new Error(`Invalid file type: ${mimeType}. Allowed: ${ALLOWED_MIME_TYPES.join(", ")}`);
  }
  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error(`File too large. Maximum size is ${MAX_FILE_SIZE / 1024 / 1024}MB`);
  }
  const extension = mimeType.split("/")[1] || "jpg";
  const uniqueId = crypto2.randomBytes(8).toString("hex");
  const objectName = `${folder}/${uniqueId}.${extension}`;
  const bucket = getStorageBucket();
  const file = bucket.file(objectName);
  await file.save(buffer, {
    metadata: {
      contentType: mimeType
    }
  });
  const publicUrl = `/api/files/${uniqueId}.${extension}`;
  console.log(`[FirebaseStorage] Uploaded ${objectName} (${buffer.length} bytes)`);
  return {
    fileName: objectName,
    storageUrl: objectName,
    publicUrl,
    sizeBytes: buffer.length,
    mimeType
  };
}
async function getFileFromFirebaseStorage(fileName, folder = "custom-designs") {
  if (!useFirebaseStorage()) {
    return null;
  }
  ensureFirebaseInitialized();
  try {
    const bucket = getStorageBucket();
    const possiblePaths = [
      `${folder}/${fileName}`,
      fileName,
      `custom-designs/${fileName}`,
      `hosted-images/${fileName}`,
      `mockups/${fileName}`,
      `library/${fileName}`
    ];
    for (const objectName of possiblePaths) {
      const file = bucket.file(objectName);
      const [exists] = await file.exists();
      if (exists) {
        const [contents] = await file.download();
        const [metadata] = await file.getMetadata();
        const mimeType = metadata.contentType || "application/octet-stream";
        console.log(`[FirebaseStorage] Downloaded ${objectName}`);
        return { buffer: contents, mimeType };
      }
    }
    console.log(`[FirebaseStorage] File not found: ${fileName}`);
    return null;
  } catch (error) {
    console.error("[FirebaseStorage] Error downloading file:", error);
    return null;
  }
}
async function downloadAndStreamFile(fileName, res, folder = "custom-designs", cacheTtlSec = 3600) {
  if (!useFirebaseStorage()) {
    return false;
  }
  ensureFirebaseInitialized();
  try {
    const bucket = getStorageBucket();
    const possiblePaths = [
      `${folder}/${fileName}`,
      fileName,
      `custom-designs/${fileName}`,
      `hosted-images/${fileName}`,
      `mockups/${fileName}`,
      `library/${fileName}`,
      `library/admin/backgrounds/${fileName}`,
      `library/admin/designs/${fileName}`,
      `library/admin/videos/${fileName}`,
      `library/user/${fileName}`,
      // Background assets paths
      `backgrounds/source/${fileName}`,
      `library/backgrounds/raw/${fileName}`,
      `library/backgrounds/raw/zip/${fileName}`,
      `library/backgrounds/cropped/${fileName}`
    ];
    for (const objectName of possiblePaths) {
      const file = bucket.file(objectName);
      const [exists] = await file.exists();
      if (exists) {
        const [metadata] = await file.getMetadata();
        res.set({
          "Content-Type": metadata.contentType || "application/octet-stream",
          "Content-Length": metadata.size,
          "Cache-Control": `public, max-age=${cacheTtlSec}`
        });
        const stream = file.createReadStream();
        stream.on("error", (err) => {
          console.error("[FirebaseStorage] Stream error:", err);
          if (!res.headersSent) {
            res.status(500).json({ error: "Error streaming file" });
          }
        });
        stream.pipe(res);
        return true;
      }
    }
    return false;
  } catch (error) {
    console.error("[FirebaseStorage] Error streaming file:", error);
    return false;
  }
}
async function deleteFromFirebaseStorage(fileName, folder = "custom-designs") {
  if (!useFirebaseStorage()) {
    return false;
  }
  ensureFirebaseInitialized();
  try {
    const bucket = getStorageBucket();
    const objectName = fileName.includes("/") ? fileName : `${folder}/${fileName}`;
    const file = bucket.file(objectName);
    await file.delete();
    console.log(`[FirebaseStorage] Deleted ${objectName}`);
    return true;
  } catch (error) {
    console.error("[FirebaseStorage] Error deleting file:", error);
    return false;
  }
}
async function downloadAndStoreFromUrl(imageUrl, storagePath) {
  try {
    console.log(`[Storage] Downloading image from ${imageUrl.substring(0, 80)}...`);
    const response = await fetch(imageUrl);
    if (!response.ok) {
      console.error(`[Storage] Failed to download image: ${response.status}`);
      return null;
    }
    const contentLength = response.headers.get("content-length");
    if (contentLength === "0") {
      console.error(`[Storage] Image has zero content length`);
      return null;
    }
    const buffer = Buffer.from(await response.arrayBuffer());
    if (buffer.length < 1e3) {
      console.error(`[Storage] Image too small (${buffer.length} bytes), likely invalid`);
      return null;
    }
    console.log(`[Storage] Downloaded ${buffer.length} bytes, uploading to storage...`);
    const filename = `mockup-${storagePath.replace(/\//g, "-")}`;
    let mimeType = response.headers.get("content-type") || getMimeTypeFromUrl(imageUrl);
    if (!ALLOWED_MIME_TYPES.includes(mimeType)) {
      mimeType = "image/jpeg";
    }
    ensureFirebaseInitialized();
    const bucket = getStorageBucket();
    const fullPath = `custom-designs/${filename}`;
    const file = bucket.file(fullPath);
    await file.save(buffer, {
      metadata: {
        contentType: mimeType
      }
    });
    const publicUrl = `/api/files/${filename}`;
    console.log(`[FirebaseStorage] Stored permanently at: ${publicUrl}`);
    return publicUrl;
  } catch (err) {
    console.error(`[Storage] Failed to download/store image:`, err);
    return null;
  }
}
var ALLOWED_MIME_TYPES, MAX_FILE_SIZE;
var init_firebase_storage_service = __esm({
  "server/lib/firebase-storage-service.ts"() {
    "use strict";
    init_firebase_admin();
    ALLOWED_MIME_TYPES = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
      "image/heic",
      "image/heif",
      "video/mp4",
      "video/webm",
      "video/quicktime"
    ];
    MAX_FILE_SIZE = 10 * 1024 * 1024;
  }
});

// server/stripeClient.ts
var stripeClient_exports = {};
__export(stripeClient_exports, {
  getStripePublishableKey: () => getStripePublishableKey,
  getStripeSecretKey: () => getStripeSecretKey,
  getStripeSync: () => getStripeSync,
  getUncachableStripeClient: () => getUncachableStripeClient
});
import Stripe from "stripe";
async function getCredentials2() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY ? "repl " + process.env.REPL_IDENTITY : process.env.WEB_REPL_RENEWAL ? "depl " + process.env.WEB_REPL_RENEWAL : null;
  if (!xReplitToken) {
    throw new Error("X_REPLIT_TOKEN not found for repl/depl");
  }
  const connectorName = "stripe";
  const isProduction = process.env.REPLIT_DEPLOYMENT === "1";
  const targetEnvironment = isProduction ? "production" : "development";
  const url = new URL(`https://${hostname}/api/v2/connection`);
  url.searchParams.set("include_secrets", "true");
  url.searchParams.set("connector_names", connectorName);
  url.searchParams.set("environment", targetEnvironment);
  const response = await fetch(url.toString(), {
    headers: {
      "Accept": "application/json",
      "X_REPLIT_TOKEN": xReplitToken
    }
  });
  const data = await response.json();
  connectionSettings2 = data.items?.[0];
  if (!connectionSettings2 || (!connectionSettings2.settings.publishable || !connectionSettings2.settings.secret)) {
    throw new Error(`Stripe ${targetEnvironment} connection not found`);
  }
  return {
    publishableKey: connectionSettings2.settings.publishable,
    secretKey: connectionSettings2.settings.secret
  };
}
async function getUncachableStripeClient() {
  const { secretKey } = await getCredentials2();
  return new Stripe(secretKey, {
    apiVersion: "2025-11-17.clover"
  });
}
async function getStripePublishableKey() {
  const { publishableKey } = await getCredentials2();
  return publishableKey;
}
async function getStripeSecretKey() {
  const { secretKey } = await getCredentials2();
  return secretKey;
}
async function getStripeSync() {
  if (!stripeSync) {
    const { StripeSync } = await import("stripe-replit-sync");
    const secretKey = await getStripeSecretKey();
    stripeSync = new StripeSync({
      poolConfig: {
        connectionString: process.env.DATABASE_URL,
        max: 2
      },
      stripeSecretKey: secretKey
    });
  }
  return stripeSync;
}
var connectionSettings2, stripeSync;
var init_stripeClient = __esm({
  "server/stripeClient.ts"() {
    "use strict";
    stripeSync = null;
  }
});

// server/lib/local-mockup-generator.ts
var local_mockup_generator_exports = {};
__export(local_mockup_generator_exports, {
  generateAllColorMockups: () => generateAllColorMockups,
  generateLocalMockup: () => generateLocalMockup
});
import { createCanvas as createCanvas2, loadImage as loadImage2 } from "canvas";
import { Client as ObjectStorageClient } from "@replit/object-storage";
async function generateLocalMockup(config, blueprintId, printProviderId) {
  try {
    const baseUrl = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "http://localhost:5000";
    const artworkFullUrl = config.artworkUrl.startsWith("http") ? config.artworkUrl : `${baseUrl}${config.artworkUrl}`;
    console.log(`[LocalMockup] Loading artwork from: ${artworkFullUrl}`);
    const artworkImg = await loadImage2(artworkFullUrl);
    const canvasWidth = 800;
    const canvasHeight = 1e3;
    const canvas = createCanvas2(canvasWidth, canvasHeight);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = config.shirtHex || "#FFFFFF";
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    const shirtShape = createShirtShape(ctx, canvasWidth, canvasHeight, config.shirtHex);
    const placement = PLACEMENT_CONFIG["front-chest"];
    const artworkSize = Math.min(canvasWidth, canvasHeight) * placement.scale;
    const artworkX = canvasWidth * placement.x - artworkSize / 2;
    const artworkY = canvasHeight * placement.y - artworkSize / 2;
    ctx.drawImage(artworkImg, artworkX, artworkY, artworkSize, artworkSize);
    const buffer = canvas.toBuffer("image/jpeg", { quality: 0.9 });
    const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
    if (!bucketId) {
      console.error("[LocalMockup] No bucket ID configured");
      return null;
    }
    const client = new ObjectStorageClient({ bucketId });
    const colorSlug = config.shirtColor.toLowerCase().replace(/\s+/g, "-");
    const filename = `local-mockup-${blueprintId}-${printProviderId}-${colorSlug}.jpg`;
    const fullPath = `custom-designs/${filename}`;
    await client.uploadFromBytes(fullPath, buffer);
    const publicUrl = `/api/files/${filename}`;
    console.log(`[LocalMockup] Generated mockup: ${publicUrl}`);
    return {
      flatUrl: publicUrl,
      lifestyleUrl: null
    };
  } catch (err) {
    console.error("[LocalMockup] Failed to generate mockup:", err);
    return null;
  }
}
function createShirtShape(ctx, width, height, color) {
  ctx.fillStyle = "#f0f0f0";
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = color;
  ctx.beginPath();
  const neckWidth = width * 0.15;
  const shoulderWidth = width * 0.9;
  const sleeveLength = width * 0.2;
  const bodyTop = height * 0.15;
  const bodyBottom = height * 0.95;
  ctx.moveTo(width * 0.5 - neckWidth / 2, bodyTop);
  ctx.lineTo(width * 0.05, bodyTop + height * 0.05);
  ctx.lineTo(width * 0.05 - sleeveLength * 0.3, bodyTop + height * 0.2);
  ctx.lineTo(width * 0.05, bodyTop + height * 0.25);
  ctx.lineTo(width * 0.1, bodyBottom);
  ctx.lineTo(width * 0.9, bodyBottom);
  ctx.lineTo(width * 0.95, bodyTop + height * 0.25);
  ctx.lineTo(width * 0.95 + sleeveLength * 0.3, bodyTop + height * 0.2);
  ctx.lineTo(width * 0.95, bodyTop + height * 0.05);
  ctx.lineTo(width * 0.5 + neckWidth / 2, bodyTop);
  ctx.arc(width * 0.5, bodyTop, neckWidth / 2, 0, Math.PI, true);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(0,0,0,0.1)";
  ctx.lineWidth = 2;
  ctx.stroke();
}
async function generateAllColorMockups(blueprintId, printProviderId, colors, artworkBlackUrl, artworkWhiteUrl) {
  const results = {};
  for (const color of colors) {
    const isDark = isColorDark2(color.hex);
    const artworkUrl = isDark ? artworkWhiteUrl : artworkBlackUrl;
    const artworkVariant = isDark ? "white" : "black";
    console.log(`[LocalMockup] Generating for ${color.name} (${isDark ? "dark" : "light"} shirt, ${artworkVariant} QR)`);
    const mockup = await generateLocalMockup({
      shirtColor: color.name,
      shirtHex: color.hex,
      artworkUrl,
      artworkVariant
    }, blueprintId, printProviderId);
    if (mockup) {
      results[color.name] = {
        front: mockup.flatUrl,
        lifestyle: mockup.lifestyleUrl
      };
    }
  }
  return results;
}
function isColorDark2(hexColor) {
  const hex = hexColor.replace("#", "");
  const r = parseInt(hex.substr(0, 2), 16) / 255;
  const g = parseInt(hex.substr(2, 2), 16) / 255;
  const b = parseInt(hex.substr(4, 2), 16) / 255;
  const toLinear = (c) => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  const luminance = 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
  return luminance < 0.5;
}
var PLACEMENT_CONFIG;
var init_local_mockup_generator = __esm({
  "server/lib/local-mockup-generator.ts"() {
    "use strict";
    PLACEMENT_CONFIG = {
      "front-chest": {
        x: 0.5,
        y: 0.35,
        scale: 0.25
      }
    };
  }
});

// server/lib/printful.ts
var printful_exports = {};
__export(printful_exports, {
  printfulClient: () => printfulClient,
  syncPrintfulCatalog: () => syncPrintfulCatalog
});
async function syncPrintfulCatalog(db4, options) {
  const { printfulProducts: printfulProducts2, printfulVariants: printfulVariants2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
  const { eq: eq7 } = await import("drizzle-orm");
  const result = {
    productsAdded: 0,
    productsUpdated: 0,
    variantsAdded: 0,
    variantsUpdated: 0,
    errors: []
  };
  if (!printfulClient.isConfigured) {
    result.errors.push("Printful API key not configured");
    return result;
  }
  try {
    console.log("[Printful Sync] Starting catalog sync...");
    const allProducts = await printfulClient.getProducts();
    const productsToSync = options?.productIds ? allProducts.filter((p) => options.productIds.includes(p.id)) : allProducts;
    console.log(`[Printful Sync] Found ${productsToSync.length} products to sync`);
    for (const product of productsToSync) {
      try {
        const existing = await db4.select().from(printfulProducts2).where(eq7(printfulProducts2.id, product.id)).limit(1);
        const details = await printfulClient.getProduct(product.id);
        let printfileInfo = null;
        try {
          printfileInfo = await printfulClient.getPrintfiles(product.id);
        } catch (e) {
        }
        const productData = {
          id: product.id,
          type: product.type,
          typeName: product.type_name,
          brand: product.brand || null,
          model: product.model || null,
          title: details.product.type_name || product.type_name,
          image: product.image || null,
          variantCount: details.variants.length,
          currency: product.currency || "USD",
          minPrice: details.variants.length > 0 ? Math.min(...details.variants.map((v) => parseFloat(v.price))).toString() : null,
          maxPrice: details.variants.length > 0 ? Math.max(...details.variants.map((v) => parseFloat(v.price))).toString() : null,
          printfileWidth: printfileInfo?.printfiles?.[0]?.width || null,
          printfileHeight: printfileInfo?.printfiles?.[0]?.height || null,
          printfileDpi: printfileInfo?.printfiles?.[0]?.dpi || null,
          avgFulfillmentTime: product.avg_fulfillment_time || null,
          originCountry: product.origin_country || null,
          isDiscontinued: product.is_discontinued || false,
          availablePlacements: printfileInfo?.available_placements?.map((p) => p.placement) || null,
          lastSyncedAt: /* @__PURE__ */ new Date()
        };
        if (existing.length > 0) {
          await db4.update(printfulProducts2).set(productData).where(eq7(printfulProducts2.id, product.id));
          result.productsUpdated++;
        } else {
          await db4.insert(printfulProducts2).values(productData);
          result.productsAdded++;
        }
        for (const variant of details.variants) {
          const existingVariant = await db4.select().from(printfulVariants2).where(eq7(printfulVariants2.id, variant.id)).limit(1);
          const variantData = {
            id: variant.id,
            productId: product.id,
            name: variant.name,
            size: variant.size || null,
            color: variant.color || null,
            colorCode: variant.color_code || null,
            colorCode2: variant.color_code2 || null,
            image: variant.image || null,
            price: variant.price,
            inStock: variant.in_stock !== false,
            availabilityStatus: variant.availability_status || "active",
            lastSyncedAt: /* @__PURE__ */ new Date()
          };
          if (existingVariant.length > 0) {
            await db4.update(printfulVariants2).set(variantData).where(eq7(printfulVariants2.id, variant.id));
            result.variantsUpdated++;
          } else {
            await db4.insert(printfulVariants2).values(variantData);
            result.variantsAdded++;
          }
        }
        await new Promise((resolve) => setTimeout(resolve, 2e3));
      } catch (productError) {
        console.error(`[Printful Sync] Error syncing product ${product.id}:`, productError.message);
        result.errors.push(`Product ${product.id}: ${productError.message}`);
      }
    }
    console.log(`[Printful Sync] Complete - Products: ${result.productsAdded} added, ${result.productsUpdated} updated`);
    console.log(`[Printful Sync] Complete - Variants: ${result.variantsAdded} added, ${result.variantsUpdated} updated`);
  } catch (error) {
    console.error("[Printful Sync] Fatal error:", error.message);
    result.errors.push(`Fatal error: ${error.message}`);
  }
  return result;
}
var PRINTFUL_API_BASE, PrintfulClient, printfulClient;
var init_printful = __esm({
  "server/lib/printful.ts"() {
    "use strict";
    PRINTFUL_API_BASE = "https://api.printful.com";
    PrintfulClient = class {
      getApiKey() {
        return (process.env.PRINTFUL_API_KEY || "").trim();
      }
      getStoreId() {
        return (process.env.PRINTFUL_STORE_ID || "").trim();
      }
      get headers() {
        const headers = {
          "Authorization": `Bearer ${this.getApiKey()}`,
          "Content-Type": "application/json"
        };
        const storeId = this.getStoreId();
        if (storeId) {
          headers["X-PF-Store-Id"] = storeId;
        }
        return headers;
      }
      get isConfigured() {
        const key = this.getApiKey();
        return !!key && key.length > 10;
      }
      async request(method, endpoint, body) {
        const url = `${PRINTFUL_API_BASE}${endpoint}`;
        const options = {
          method,
          headers: this.headers
        };
        if (body) {
          options.body = JSON.stringify(body);
        }
        const response = await fetch(url, options);
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Printful API error: ${response.status} - ${errorText}`);
        }
        const data = await response.json();
        return data.result;
      }
      /**
       * Get all available Printful products (catalog)
       */
      async getProducts() {
        return this.request("GET", "/products");
      }
      /**
       * Get a specific product by ID
       */
      async getProduct(productId) {
        return this.request("GET", `/products/${productId}`);
      }
      /**
       * Get printfile specifications for a product variant
       * This tells us the correct image dimensions and placements
       */
      async getPrintfiles(productId) {
        return this.request("GET", `/mockup-generator/printfiles/${productId}`);
      }
      /**
       * Create a mockup generation task
       * This is the core function - generates rendered mockups with artwork on products
       */
      async createMockupTask(productId, variantIds, files, format = "jpg", optionGroups) {
        const body = {
          variant_ids: variantIds,
          format,
          files
        };
        if (optionGroups && optionGroups.length > 0) {
          body.option_groups = optionGroups;
        }
        console.log("[Printful] Creating mockup task for product", productId, "variants:", variantIds, "option_groups:", optionGroups);
        return this.request("POST", `/mockup-generator/create-task/${productId}`, body);
      }
      /**
       * Get the result of a mockup generation task
       */
      async getMockupTaskResult(taskKey) {
        return this.request("GET", `/mockup-generator/task?task_key=${encodeURIComponent(taskKey)}`);
      }
      /**
       * Poll for mockup task completion with timeout
       */
      async waitForMockupTask(taskKey, maxWaitMs = 6e4, pollIntervalMs = 2e3) {
        const startTime = Date.now();
        while (Date.now() - startTime < maxWaitMs) {
          const result = await this.getMockupTaskResult(taskKey);
          if (result.status === "completed") {
            console.log("[Printful] Mockup task completed:", taskKey);
            return result;
          }
          if (result.status === "failed") {
            throw new Error(`Printful mockup task failed: ${result.error || "Unknown error"}`);
          }
          await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
        }
        throw new Error(`Printful mockup task timed out after ${maxWaitMs}ms`);
      }
      /**
       * Generate mockups for a product variant with artwork
       * This is the high-level function that creates a task and waits for results
       */
      async generateMockup(productId, variantIds, artworkUrl, placement = "front", format = "jpg") {
        if (!this.isConfigured) {
          throw new Error("Printful API key not configured");
        }
        console.log(`[Printful] Generating mockup for product ${productId}, placement: ${placement}`);
        console.log(`[Printful] Artwork URL: ${artworkUrl}`);
        const task = await this.createMockupTask(
          productId,
          variantIds,
          [{ placement, image_url: artworkUrl }],
          format
        );
        if (!task.task_key) {
          throw new Error("Printful did not return a task key");
        }
        console.log(`[Printful] Task created: ${task.task_key}, status: ${task.status}`);
        if (task.status === "completed" && task.mockups) {
          return task.mockups;
        }
        const result = await this.waitForMockupTask(task.task_key);
        if (!result.mockups || result.mockups.length === 0) {
          throw new Error("Printful mockup task completed but returned no mockups");
        }
        return result.mockups;
      }
      /**
       * Search for a Printful product that matches a Printify blueprint
       * This is used for the mapping between the two providers
       */
      async findMatchingProduct(brand, model) {
        try {
          const products2 = await this.getProducts();
          let match = products2.find(
            (p) => p.brand.toLowerCase() === brand.toLowerCase() && p.model.toLowerCase() === model.toLowerCase()
          );
          if (match) return match;
          match = products2.find(
            (p) => p.model.toLowerCase().includes(model.toLowerCase()) || model.toLowerCase().includes(p.model.toLowerCase())
          );
          return match || null;
        } catch (error) {
          console.error("[Printful] Error finding matching product:", error);
          return null;
        }
      }
      /**
       * Common color name synonyms between Printify and Printful
       */
      colorSynonyms = {
        "heather grey": ["sport grey", "athletic heather", "heather gray"],
        "sport grey": ["heather grey", "heather gray", "athletic heather"],
        "solid black": ["black"],
        "black": ["solid black"],
        "solid white": ["white"],
        "white": ["solid white"],
        "navy": ["navy blue", "dark navy", "midnight navy"],
        "navy blue": ["navy", "dark navy", "midnight navy"],
        "midnight navy": ["navy", "navy blue", "dark navy"],
        "heather": ["heather grey", "sport grey"],
        // Blue variants - Printify uses "Solid Cool Blue", Printful uses "Royal"
        "cool blue": ["royal", "true royal", "royal blue"],
        "solid cool blue": ["royal", "true royal", "royal blue", "cool blue"],
        "solid royal": ["royal", "true royal", "royal blue"],
        "royal": ["solid royal", "true royal", "royal blue", "cool blue"],
        // Tahiti/Turquoise/Teal variants
        "tahiti blue": ["teal", "turquoise", "aqua", "ocean blue", "tropical blue"],
        "solid tahiti blue": ["teal", "turquoise", "aqua", "ocean blue", "tropical blue"],
        "solid turquoise": ["turquoise", "teal", "aqua"],
        "turquoise": ["solid turquoise", "teal", "aqua"],
        // Military/Army green
        "solid military green": ["military green", "army", "olive", "army green"],
        "military green": ["solid military green", "army", "olive", "army green"],
        // Red variants
        "solid red": ["red", "true red", "cardinal"],
        "red": ["solid red", "true red", "cardinal"],
        // Light blue variants
        "solid light blue": ["light blue", "baby blue", "sky blue", "carolina blue"],
        "light blue": ["solid light blue", "baby blue", "sky blue", "carolina blue"],
        "carolina blue": ["light blue", "solid light blue", "sky blue"],
        // Forest/Kelly green
        "solid forest green": ["forest green", "forest", "kelly green"],
        "solid kelly green": ["kelly green", "kelly", "forest green"],
        "forest green": ["solid forest green", "irish green"],
        "irish green": ["forest green", "solid forest green", "kelly green"],
        // Purple variants
        "solid purple rush": ["purple", "purple rush", "team purple"],
        "purple": ["solid purple rush", "purple rush", "team purple"],
        // Maroon
        "solid maroon": ["maroon", "burgundy", "wine"],
        "maroon": ["solid maroon", "burgundy", "wine"],
        // Yellow/Gold variants - Printify "Solid Banana Cream" to Printful "Gold"
        "banana cream": ["gold", "yellow", "daisy"],
        "solid banana cream": ["gold", "yellow", "daisy"],
        "gold": ["banana cream", "solid banana cream", "yellow"],
        // Pink variants
        "solid light pink": ["light pink", "pink", "soft pink"],
        "light pink": ["solid light pink", "pink"],
        // Orange variants
        "solid orange": ["orange", "burnt orange"],
        "orange": ["solid orange", "burnt orange"],
        // Charcoal/Dark grey
        "solid dark heather": ["dark heather", "charcoal", "graphite heather"],
        "dark heather": ["solid dark heather", "charcoal", "graphite heather"],
        "charcoal": ["dark heather", "graphite heather"],
        // Sand/Tan
        "solid sand": ["sand", "tan", "khaki"],
        "sand": ["solid sand", "tan", "khaki"],
        // Ash
        "solid ash": ["ash", "ash grey", "ash gray"],
        "ash": ["solid ash", "ash grey"],
        // Indigo/Deep blue
        "solid indigo": ["indigo blue", "indigo", "deep blue"],
        "indigo blue": ["solid indigo", "indigo"],
        // Heliconia/Hot pink
        "solid heliconia": ["heliconia", "hot pink", "fuchsia"],
        "heliconia": ["solid heliconia", "hot pink", "fuchsia"],
        // Chocolate/Brown
        "solid dark chocolate": ["dark chocolate", "brown", "chocolate"],
        "dark chocolate": ["solid dark chocolate", "brown", "chocolate"]
      };
      /**
       * Get variants for a product, optionally filtered by color
       * Includes synonym matching for cross-provider compatibility
       */
      async getVariantsByColor(productId, colorName) {
        const { variants } = await this.getProduct(productId);
        if (!colorName) return variants;
        const strippedColor = colorName.toLowerCase().replace(/^solid\s+/i, "");
        const originalColor = colorName.toLowerCase();
        const colorsToTry = /* @__PURE__ */ new Set([originalColor, strippedColor]);
        const originalSynonyms = this.colorSynonyms[originalColor];
        const strippedSynonyms = this.colorSynonyms[strippedColor];
        if (originalSynonyms) originalSynonyms.forEach((s) => colorsToTry.add(s));
        if (strippedSynonyms) strippedSynonyms.forEach((s) => colorsToTry.add(s));
        const colorsArray = Array.from(colorsToTry);
        const matches = variants.filter((v) => {
          const variantColor = v.color.toLowerCase();
          const variantColorNormalized = variantColor.replace(/\s+/g, "");
          return colorsArray.some((c) => {
            const cNormalized = c.replace(/\s+/g, "");
            return variantColorNormalized === cNormalized || variantColorNormalized.includes(cNormalized) || cNormalized.includes(variantColorNormalized);
          });
        });
        if (matches.length === 0) {
          console.log(`[Printful] Color "${colorName}" not found. Tried: ${colorsArray.join(", ")}`);
          const uniqueColors = Array.from(new Set(variants.map((v) => v.color)));
          console.log(`[Printful] Available colors: ${uniqueColors.join(", ")}`);
        }
        return matches;
      }
      /**
       * Create an order in Printful
       */
      async createOrder(orderData) {
        console.log("[Printful] Creating order:", JSON.stringify(orderData, null, 2));
        return this.request("POST", "/orders", orderData);
      }
      /**
       * Get order status
       */
      async getOrder(orderId) {
        return this.request("GET", `/orders/${orderId}`);
      }
      /**
       * Confirm a draft order (submit for fulfillment)
       */
      async confirmOrder(orderId) {
        console.log("[Printful] Confirming order:", orderId);
        return this.request("POST", `/orders/${orderId}/confirm`);
      }
      /**
       * Estimate shipping costs
       */
      async estimateShipping(recipient, items) {
        return this.request("POST", "/shipping/rates", { recipient, items });
      }
    };
    printfulClient = new PrintfulClient();
  }
});

// server/lib/mockup-service.ts
var mockup_service_exports = {};
__export(mockup_service_exports, {
  generatePrintfulMockup: () => generatePrintfulMockup,
  getCachedMockupsForProduct: () => getCachedMockupsForProduct,
  getCanonicalPlacements: () => getCanonicalPlacements,
  getLifestyleMockupForColor: () => getLifestyleMockupForColor,
  getMockupWithFallback: () => getMockupWithFallback,
  getProviderPlacementKey: () => getProviderPlacementKey,
  isColorDark: () => isColorDark3,
  isValidHexColor: () => isValidHexColor,
  preGenerateMockupsForProduct: () => preGenerateMockupsForProduct
});
import { eq as eq2, and as and2 } from "drizzle-orm";
function isValidHexColor(hexColor) {
  if (!hexColor) return false;
  const hex = hexColor.replace("#", "");
  return /^[0-9A-Fa-f]{6}$/.test(hex);
}
function isColorDark3(hexColor) {
  if (!isValidHexColor(hexColor)) {
    console.warn(`[MockupService] Invalid hex color "${hexColor}", defaulting to light (black QR)`);
    return false;
  }
  const hex = hexColor.replace("#", "");
  const r = parseInt(hex.substr(0, 2), 16) / 255;
  const g = parseInt(hex.substr(2, 2), 16) / 255;
  const b = parseInt(hex.substr(4, 2), 16) / 255;
  if (isNaN(r) || isNaN(g) || isNaN(b)) {
    console.warn(`[MockupService] Failed to parse hex color "${hexColor}", defaulting to light`);
    return false;
  }
  const toLinear = (c) => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  const luminance = 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
  return luminance < 0.5;
}
async function downloadAndStoreImage(imageUrl, storagePath) {
  return downloadAndStoreFromUrl(imageUrl, storagePath);
}
async function getMockupWithFallback(request, storage2) {
  const {
    blueprintId,
    printProviderId,
    colorName,
    colorHex,
    canonicalPlacementId,
    artworkUrl,
    artworkVariant = "black",
    productId,
    qrSize = "medium"
  } = request;
  if (!canonicalPlacementId) {
    throw new Error("canonicalPlacementId is required");
  }
  const placementExists = await db3.select({ id: canonicalPlacements.id }).from(canonicalPlacements).where(eq2(canonicalPlacements.id, canonicalPlacementId)).limit(1);
  if (placementExists.length === 0) {
    throw new Error(`Unknown canonical placement: ${canonicalPlacementId}`);
  }
  if (productId) {
    const placementAvailable = await db3.select({ id: productPlacementAvailability.id }).from(productPlacementAvailability).where(
      and2(
        eq2(productPlacementAvailability.productId, productId),
        eq2(productPlacementAvailability.canonicalPlacementId, canonicalPlacementId),
        eq2(productPlacementAvailability.isEnabled, true)
      )
    ).limit(1);
    if (placementAvailable.length === 0) {
      console.warn(`[MockupService] Placement ${canonicalPlacementId} not available for product ${productId}. Proceeding anyway for blueprint-level cache.`);
    }
  }
  const cached = await db3.select().from(mockupCache).where(
    and2(
      eq2(mockupCache.blueprintId, blueprintId),
      eq2(mockupCache.printProviderId, printProviderId),
      eq2(mockupCache.colorName, colorName),
      eq2(mockupCache.canonicalPlacementId, canonicalPlacementId),
      eq2(mockupCache.artworkVariant, artworkVariant)
    )
  ).limit(1);
  if (cached.length > 0 && cached[0].status === "active") {
    console.log(`[MockupService] Cache HIT: ${colorName} ${canonicalPlacementId}`);
    return {
      mockupUrl: cached[0].mockupUrl,
      lifestyleMockupUrl: cached[0].lifestyleMockupUrl,
      fromCache: true,
      generatedAt: cached[0].generatedAt
    };
  }
  console.log(`[MockupService] Cache MISS: ${colorName} ${canonicalPlacementId} - generating via Printful`);
  const mockupResult = await generatePrintfulMockupInternal({
    blueprintId,
    printProviderId,
    colorName,
    colorHex,
    artworkUrl,
    canonicalPlacementId,
    qrSize
  });
  if (!mockupResult || !mockupResult.flat) {
    throw new Error("Failed to generate mockup from Printful");
  }
  const mockupUrl = mockupResult.flat;
  const lifestyleMockupUrl = mockupResult.lifestyle || null;
  const now = /* @__PURE__ */ new Date();
  await db3.insert(mockupCache).values({
    blueprintId,
    printProviderId,
    colorName,
    colorHex,
    canonicalPlacementId,
    artworkUrl,
    artworkVariant,
    mockupUrl,
    lifestyleMockupUrl,
    podProviderId: "printify",
    status: "active",
    generatedAt: now
  }).onConflictDoUpdate({
    target: [
      mockupCache.blueprintId,
      mockupCache.printProviderId,
      mockupCache.colorName,
      mockupCache.canonicalPlacementId,
      mockupCache.artworkVariant
    ],
    set: {
      mockupUrl,
      lifestyleMockupUrl,
      colorHex,
      artworkUrl,
      status: "active",
      generatedAt: now
    }
  });
  console.log(`[MockupService] Generated and cached mockup for ${colorName} (lifestyle: ${!!lifestyleMockupUrl})`);
  return {
    mockupUrl,
    lifestyleMockupUrl,
    fromCache: false,
    generatedAt: now
  };
}
async function generatePrintfulMockupInternal(params) {
  const { blueprintId, printProviderId, colorName, colorHex, artworkUrl, canonicalPlacementId } = params;
  console.log(`[MockupService/Printful] Generating mockup for blueprint ${blueprintId}, color ${colorName}`);
  const mapping = await db3.select().from(printifyPrintfulMapping).where(
    and2(
      eq2(printifyPrintfulMapping.printifyBlueprintId, blueprintId),
      eq2(printifyPrintfulMapping.isActive, true)
    )
  ).limit(1);
  if (mapping.length === 0) {
    console.warn(`[MockupService/Printful] No mapping found for blueprint ${blueprintId}. Creating auto-mapping...`);
    const autoMapping = await createAutoMapping(blueprintId);
    if (!autoMapping) {
      console.error(`[MockupService/Printful] Could not create auto-mapping for blueprint ${blueprintId}`);
      return null;
    }
    mapping.push(autoMapping);
  }
  const printfulProductId = mapping[0].printfulProductId;
  const colorMappingData = mapping[0].colorMapping;
  let printfulColorName = colorName;
  if (colorMappingData && colorMappingData[colorName]) {
    printfulColorName = colorMappingData[colorName];
    console.log(`[MockupService/Printful] Mapped color: ${colorName} \u2192 ${printfulColorName}`);
  }
  const baseUrl = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "http://localhost:5000";
  const absoluteArtworkUrl = artworkUrl.startsWith("http") ? artworkUrl : `${baseUrl}${artworkUrl}`;
  console.log(`[MockupService/Printful] Using Printful product ${printfulProductId} for color ${printfulColorName}`);
  console.log(`[MockupService/Printful] Artwork URL: ${absoluteArtworkUrl}`);
  const variants = await printfulClient.getVariantsByColor(printfulProductId, printfulColorName);
  if (variants.length === 0) {
    console.error(`[MockupService/Printful] No Printful variants found for color: ${printfulColorName}`);
    return null;
  }
  const targetVariant = variants.find((v) => v.size === "M") || variants[0];
  console.log(`[MockupService/Printful] Using variant: ${targetVariant.id} (${targetVariant.size}, ${targetVariant.color})`);
  const printfiles = await printfulClient.getPrintfiles(printfulProductId);
  const frontPrintfile = printfiles.printfiles?.find((p) => p.printfile_id === 1) || printfiles.printfiles?.[0];
  const areaWidth = frontPrintfile?.width || 4500;
  const areaHeight = frontPrintfile?.height || 5400;
  const sizePercentages = {
    small: 0.25,
    // ~4" on a 12"x16" area
    medium: 0.45,
    // ~8" on a 12"x16" area  
    large: 0.65
    // ~12" on a 12"x16" area (near max)
  };
  const sizePercent = sizePercentages[params.qrSize || "medium"] || sizePercentages.medium;
  const minQrSize = Math.round(areaWidth * 0.15);
  const qrSize = Math.max(Math.round(areaWidth * sizePercent), minQrSize);
  console.log(`[MockupService/Printful] Print area: ${areaWidth}x${areaHeight}, QR size: ${qrSize}px (${Math.round(qrSize / areaWidth * 100)}%)`);
  const position = {
    area_width: areaWidth,
    area_height: areaHeight,
    width: qrSize,
    height: qrSize,
    top: Math.round(areaHeight * 0.15),
    // ~15% from top for chest placement
    left: Math.round((areaWidth - qrSize) / 2)
    // Centered horizontally
  };
  let printfulPlacement = "front";
  if (canonicalPlacementId === "BACK_FULL" || canonicalPlacementId === "BACK_UPPER") {
    printfulPlacement = "back";
  }
  const lifestyleOptionGroups = ["Men's Lifestyle", "Women's Lifestyle"];
  const task = await printfulClient.createMockupTask(
    printfulProductId,
    [targetVariant.id],
    [{
      placement: printfulPlacement,
      image_url: absoluteArtworkUrl,
      position
    }],
    "jpg",
    lifestyleOptionGroups
  );
  if (!task.task_key) {
    console.error(`[MockupService/Printful] Mockup task creation failed`);
    return null;
  }
  console.log(`[MockupService/Printful] Task created: ${task.task_key}`);
  const result = await printfulClient.waitForMockupTask(task.task_key, 6e4);
  if (!result.mockups || result.mockups.length === 0) {
    console.error(`[MockupService/Printful] No mockups returned`);
    return null;
  }
  const mockupImages = {};
  const mainMockup = result.mockups[0];
  mockupImages.flat = mainMockup.mockup_url;
  console.log(`[MockupService/Printful] Got flat mockup: ${mockupImages.flat.substring(0, 80)}...`);
  if (mainMockup.extra && mainMockup.extra.length > 0) {
    const lifestyleExtra = mainMockup.extra.find(
      (e) => e.option_group?.toLowerCase().includes("model") || e.option_group?.toLowerCase().includes("lifestyle") || e.title?.toLowerCase().includes("lifestyle")
    );
    if (lifestyleExtra?.url) {
      mockupImages.lifestyle = lifestyleExtra.url;
      console.log(`[MockupService/Printful] Got lifestyle mockup: ${lifestyleExtra.url.substring(0, 80)}...`);
    }
  }
  const permanentImages = {};
  if (mockupImages.flat) {
    const flatPath = `printful/${blueprintId}/${colorName.replace(/\s+/g, "-").toLowerCase()}-flat.jpg`;
    const permanentFlatUrl = await downloadAndStoreImage(mockupImages.flat, flatPath);
    if (permanentFlatUrl) {
      permanentImages.flat = permanentFlatUrl;
      console.log(`[MockupService/Printful] Stored flat mockup permanently: ${permanentFlatUrl}`);
    } else {
      permanentImages.flat = mockupImages.flat;
      console.warn(`[MockupService/Printful] Could not store, using Printful S3 URL directly`);
    }
  }
  if (mockupImages.lifestyle) {
    const lifestylePath = `printful/${blueprintId}/${colorName.replace(/\s+/g, "-").toLowerCase()}-lifestyle.jpg`;
    const permanentLifestyleUrl = await downloadAndStoreImage(mockupImages.lifestyle, lifestylePath);
    if (permanentLifestyleUrl) {
      permanentImages.lifestyle = permanentLifestyleUrl;
      console.log(`[MockupService/Printful] Stored lifestyle mockup permanently`);
    } else {
      permanentImages.lifestyle = mockupImages.lifestyle;
    }
  }
  return permanentImages;
}
async function createAutoMapping(printifyBlueprintId) {
  const knownMappings = {
    // Bella+Canvas 3001 Unisex Short Sleeve Jersey T-Shirt
    6: { printfulId: 71, brand: "Bella+Canvas", model: "3001", colorMapping: { "Solid Black": "Black", "Solid White": "White" } },
    // Gildan 64000 Unisex Softstyle T-Shirt
    5: { printfulId: 145, brand: "Gildan", model: "64000" }
    // Add more mappings as needed
  };
  const mapping = knownMappings[printifyBlueprintId];
  if (!mapping) {
    console.warn(`[MockupService/Printful] No known mapping for blueprint ${printifyBlueprintId}`);
    return null;
  }
  console.log(`[MockupService/Printful] Creating auto-mapping: Blueprint ${printifyBlueprintId} \u2192 Printful ${mapping.printfulId}`);
  const [inserted] = await db3.insert(printifyPrintfulMapping).values({
    printifyBlueprintId,
    printfulProductId: mapping.printfulId,
    printfulBrand: mapping.brand,
    printfulModel: mapping.model,
    colorMapping: mapping.colorMapping || null,
    matchConfidence: "auto",
    isActive: true
  }).returning();
  return inserted;
}
async function getCachedMockupsForProduct(blueprintId, printProviderId) {
  const cached = await db3.select().from(mockupCache).where(
    and2(
      eq2(mockupCache.blueprintId, blueprintId),
      eq2(mockupCache.printProviderId, printProviderId),
      eq2(mockupCache.status, "active")
    )
  );
  const result = {};
  for (const entry of cached) {
    if (!result[entry.colorName]) {
      result[entry.colorName] = {};
    }
    if (entry.canonicalPlacementId === "FRONT_CHEST" || entry.canonicalPlacementId === "FRONT_CENTER") {
      result[entry.colorName].front = entry.mockupUrl;
      if (entry.lifestyleMockupUrl) {
        result[entry.colorName].lifestyle = entry.lifestyleMockupUrl;
      }
    } else if (entry.canonicalPlacementId === "BACK_FULL" || entry.canonicalPlacementId === "BACK_UPPER") {
      result[entry.colorName].back = entry.mockupUrl;
    }
  }
  return result;
}
async function preGenerateMockupsForProduct(blueprintId, printProviderId, artworkBlackUrl, artworkWhiteUrl, storage2, colors) {
  let generated = 0;
  let failed = 0;
  for (const color of colors) {
    try {
      const useWhiteArtwork = color.hex ? isColorDark3(color.hex) : false;
      const artworkUrl = useWhiteArtwork && artworkWhiteUrl ? artworkWhiteUrl : artworkBlackUrl;
      const artworkVariant = useWhiteArtwork && artworkWhiteUrl ? "white" : "black";
      await getMockupWithFallback(
        {
          blueprintId,
          printProviderId,
          colorName: color.name,
          colorHex: color.hex,
          canonicalPlacementId: "FRONT_CHEST",
          artworkUrl,
          artworkVariant
        },
        storage2
      );
      generated++;
      console.log(`[MockupService] Pre-generated mockup for ${color.name} (${generated}/${colors.length})`);
    } catch (err) {
      failed++;
      console.error(`[MockupService] Failed to generate mockup for ${color.name}:`, err);
    }
  }
  return { generated, failed };
}
async function getCanonicalPlacements(category) {
  let query = db3.select().from(canonicalPlacements);
  if (category) {
    query = query.where(eq2(canonicalPlacements.category, category));
  }
  return query.orderBy(canonicalPlacements.sortOrder);
}
async function getProviderPlacementKey(providerId, canonicalPlacementId) {
  const mapping = await db3.select().from(providerPlacementMappings).where(
    and2(
      eq2(providerPlacementMappings.podProviderId, providerId),
      eq2(providerPlacementMappings.canonicalPlacementId, canonicalPlacementId)
    )
  ).limit(1);
  return mapping[0]?.providerPlacementKey || null;
}
async function getLifestyleMockupForColor(params, storage2) {
  const { blueprintId, printProviderId, colorName, colorHex, qrContent, productType = "shirt" } = params;
  const needsWhiteQR = colorHex ? isColorDark3(colorHex) : false;
  const qrVariant = needsWhiteQR ? "white" : "black";
  console.log(`[LifestyleMockup] Getting lifestyle for ${colorName} (hex: ${colorHex}, qrVariant: ${qrVariant})`);
  const cached = await db3.select().from(mockupCache).where(
    and2(
      eq2(mockupCache.blueprintId, blueprintId),
      eq2(mockupCache.printProviderId, printProviderId),
      eq2(mockupCache.colorName, colorName),
      eq2(mockupCache.artworkVariant, qrVariant)
    )
  ).limit(1);
  if (cached.length > 0 && cached[0].lifestyleMockupUrl) {
    console.log(`[LifestyleMockup] Cache HIT: ${colorName} has lifestyle mockup`);
    return {
      lifestyleUrl: cached[0].lifestyleMockupUrl,
      fromCache: true,
      qrVariant
    };
  }
  console.log(`[LifestyleMockup] Using AI composite (POD lifestyle rarely available)`);
  console.log(`[LifestyleMockup] No POD lifestyle, using AI composite fallback`);
  try {
    const { overlayGraphicOnProduct: overlayGraphicOnProduct2 } = await Promise.resolve().then(() => (init_composite_image_generator(), composite_image_generator_exports));
    const { generateTextQRCode: generateTextQRCode2 } = await Promise.resolve().then(() => (init_qr_generator(), qr_generator_exports));
    const path5 = await import("path");
    const fs3 = await import("fs");
    const basePath = path5.join(process.cwd(), "attached_assets", "lifestyle-bases", `${productType}-model.png`);
    if (!fs3.existsSync(basePath)) {
      console.warn(`[LifestyleMockup] No base lifestyle image for ${productType} at ${basePath}, using flat mockup`);
      return {
        lifestyleUrl: null,
        fromCache: false,
        qrVariant
      };
    }
    const qrColor = qrVariant === "white" ? "#FFFFFF" : "#000000";
    const qrBackground = qrVariant === "white" ? "#000000" : "#FFFFFF";
    const qrDataUrl = await generateTextQRCode2(qrContent, {
      color: qrColor,
      backgroundColor: qrBackground
    });
    console.log(`[LifestyleMockup] Generated ${qrVariant} QR data URL, compositing onto ${productType} base`);
    const compositeBuffer = await overlayGraphicOnProduct2({
      baseImageUrl: basePath,
      graphicUrl: qrDataUrl,
      productType,
      position: "chest",
      graphicScale: 0.25
    });
    const lifestyleDataUrl = `data:image/png;base64,${compositeBuffer.toString("base64")}`;
    console.log(`[LifestyleMockup] AI composite complete for ${colorName} (${qrVariant} QR)`);
    return {
      lifestyleUrl: lifestyleDataUrl,
      fromCache: false,
      qrVariant
    };
  } catch (err) {
    console.error(`[LifestyleMockup] AI composite failed:`, err);
    return {
      lifestyleUrl: null,
      fromCache: false,
      qrVariant
    };
  }
}
async function generatePrintfulMockup(params) {
  try {
    const result = await generatePrintfulMockupInternal({
      blueprintId: params.blueprintId,
      printProviderId: params.printProviderId,
      colorName: params.colorName,
      artworkUrl: params.artworkUrl,
      canonicalPlacementId: "FRONT_CHEST",
      qrSize: params.qrSize
    });
    if (!result) {
      return { error: "Mockup generation failed - no result returned" };
    }
    return {
      mockupUrl: result.flat,
      lifestyleUrl: result.lifestyle
    };
  } catch (err) {
    return { error: err.message || "Unknown error during mockup generation" };
  }
}
var init_mockup_service = __esm({
  "server/lib/mockup-service.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_firebase_storage_service();
    init_printful();
  }
});

// server/lib/mockup-job-queue.ts
var mockup_job_queue_exports = {};
__export(mockup_job_queue_exports, {
  MockupJobQueue: () => MockupJobQueue,
  mockupJobQueue: () => mockupJobQueue
});
import { eq as eq3, and as and3, lte, or as or2, asc, desc } from "drizzle-orm";
function calculateBackoff(attempts) {
  const exponentialDelay = Math.min(BASE_DELAY_MS * Math.pow(2, attempts), MAX_DELAY_MS);
  const jitter = Math.floor(Math.random() * JITTER_MS * 2) - JITTER_MS;
  return exponentialDelay + jitter;
}
var BASE_DELAY_MS, MAX_DELAY_MS, JITTER_MS, MockupJobQueue, mockupJobQueue;
var init_mockup_job_queue = __esm({
  "server/lib/mockup-job-queue.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_mockup_service();
    BASE_DELAY_MS = 2500;
    MAX_DELAY_MS = 12e4;
    JITTER_MS = 500;
    MockupJobQueue = class {
      isProcessing = false;
      processingInterval = null;
      POLL_INTERVAL_MS = 3e3;
      async createJob(params) {
        const jobData = {
          blueprintId: params.blueprintId,
          printProviderId: params.printProviderId,
          artworkUrl: params.artworkUrl,
          artworkVariant: params.artworkVariant
        };
        const [job] = await db3.insert(mockupJobs).values({
          productId: params.productId,
          colorName: params.colorName,
          qrSize: params.qrSize,
          placement: params.placement,
          jobData,
          status: "pending",
          priority: params.priority ?? 10,
          attempts: 0,
          maxAttempts: 5
        }).returning();
        return job;
      }
      async createBatchJobs(params) {
        const jobs = [];
        const qrSizes = params.qrSizes || ["small", "medium", "large"];
        const placements = params.placements || ["front-chest"];
        let priority = 0;
        for (const placement of placements) {
          for (const color of params.colors) {
            for (const qrSize of qrSizes) {
              const job = await this.createJob({
                productId: params.productId,
                colorName: color.name,
                qrSize,
                placement,
                blueprintId: params.blueprintId,
                printProviderId: params.printProviderId,
                artworkUrl: params.artworkUrl,
                artworkVariant: params.artworkVariant,
                priority: priority++
              });
              jobs.push(job);
            }
          }
        }
        return jobs;
      }
      async getJob(jobId) {
        const [job] = await db3.select().from(mockupJobs).where(eq3(mockupJobs.id, jobId));
        return job || null;
      }
      async getJobsByProduct(productId) {
        return db3.select().from(mockupJobs).where(eq3(mockupJobs.productId, productId)).orderBy(asc(mockupJobs.priority), asc(mockupJobs.createdAt));
      }
      async getStats() {
        const allJobs = await db3.select().from(mockupJobs);
        return {
          pending: allJobs.filter((j) => j.status === "pending").length,
          processing: allJobs.filter((j) => j.status === "processing").length,
          completed: allJobs.filter((j) => j.status === "completed").length,
          failed: allJobs.filter((j) => j.status === "failed").length,
          delayed: allJobs.filter((j) => j.status === "delayed").length
        };
      }
      async bumpPriority(params) {
        const now = /* @__PURE__ */ new Date();
        const expiresAt = new Date(now.getTime() + 5 * 60 * 1e3);
        const [existingJob] = await db3.select().from(mockupJobs).where(
          and3(
            eq3(mockupJobs.productId, params.productId),
            eq3(mockupJobs.colorName, params.colorName),
            eq3(mockupJobs.qrSize, params.qrSize),
            eq3(mockupJobs.placement, params.placement)
          )
        ).limit(1);
        if (!existingJob) {
          return null;
        }
        if (existingJob.status !== "pending" && existingJob.status !== "delayed") {
          return existingJob;
        }
        const [updatedJob] = await db3.update(mockupJobs).set({
          priority: -1,
          priorityUpdatedAt: now,
          priorityOwner: params.viewerId,
          priorityExpiresAt: expiresAt
        }).where(eq3(mockupJobs.id, existingJob.id)).returning();
        console.log(`[MockupQueue] Bumped priority for ${params.colorName}/${params.qrSize}/${params.placement} (job ${existingJob.id})`);
        return updatedJob;
      }
      async getNextJob() {
        const now = /* @__PURE__ */ new Date();
        const [job] = await db3.select().from(mockupJobs).where(
          or2(
            eq3(mockupJobs.status, "pending"),
            and3(
              eq3(mockupJobs.status, "delayed"),
              lte(mockupJobs.nextRetryAt, now)
            )
          )
        ).orderBy(asc(mockupJobs.priority), desc(mockupJobs.priorityUpdatedAt), asc(mockupJobs.createdAt)).limit(1);
        return job || null;
      }
      async markProcessing(jobId) {
        const [job] = await db3.select().from(mockupJobs).where(eq3(mockupJobs.id, jobId));
        if (!job) return;
        await db3.update(mockupJobs).set({
          status: "processing",
          startedAt: /* @__PURE__ */ new Date(),
          attempts: (job.attempts || 0) + 1
        }).where(eq3(mockupJobs.id, jobId));
      }
      async markCompleted(jobId, result) {
        await db3.update(mockupJobs).set({
          status: "completed",
          completedAt: /* @__PURE__ */ new Date(),
          resultData: result,
          errorMessage: null
        }).where(eq3(mockupJobs.id, jobId));
      }
      async markFailed(jobId, error) {
        const [job] = await db3.select().from(mockupJobs).where(eq3(mockupJobs.id, jobId));
        if (!job) return;
        const attempts = job.attempts || 0;
        const maxAttempts = job.maxAttempts || 5;
        if (attempts >= maxAttempts) {
          await db3.update(mockupJobs).set({
            status: "failed",
            completedAt: /* @__PURE__ */ new Date(),
            errorMessage: error
          }).where(eq3(mockupJobs.id, jobId));
        } else {
          const backoffMs = calculateBackoff(attempts);
          const nextRetry = new Date(Date.now() + backoffMs);
          await db3.update(mockupJobs).set({
            status: "delayed",
            nextRetryAt: nextRetry,
            errorMessage: error
          }).where(eq3(mockupJobs.id, jobId));
          console.log(`[JobQueue] Job ${jobId} delayed, retry at ${nextRetry.toISOString()} (attempt ${attempts}/${maxAttempts})`);
        }
      }
      async processJob(job) {
        const jobData = job.jobData;
        console.log(`[JobQueue] Processing job ${job.id}: ${job.productId} / ${job.colorName} / ${job.qrSize}`);
        try {
          const result = await generatePrintfulMockup({
            productId: job.productId,
            blueprintId: jobData.blueprintId,
            printProviderId: jobData.printProviderId,
            colorName: job.colorName,
            artworkUrl: jobData.artworkUrl,
            artworkVariant: jobData.artworkVariant,
            qrSize: job.qrSize
          });
          if (result.error) {
            return { error: result.error };
          }
          return {
            mockupUrl: result.mockupUrl,
            lifestyleMockupUrl: result.lifestyleUrl
          };
        } catch (err) {
          return { error: err.message || "Unknown error" };
        }
      }
      async processNextJob() {
        if (this.isProcessing) return false;
        const job = await this.getNextJob();
        if (!job) return false;
        this.isProcessing = true;
        try {
          await this.markProcessing(job.id);
          const result = await this.processJob(job);
          if (result.error) {
            await this.markFailed(job.id, result.error);
            if (result.error.includes("429")) {
              console.log("[JobQueue] Rate limited, pausing for 60 seconds...");
              await new Promise((resolve) => setTimeout(resolve, 6e4));
            }
          } else {
            await this.markCompleted(job.id, result);
            await this.updateProductMockups(job, result);
          }
          return true;
        } finally {
          this.isProcessing = false;
        }
      }
      async updateProductMockups(job, result) {
        try {
          const [product] = await db3.select().from(products).where(eq3(products.id, job.productId));
          if (!product) return;
          const mockupsByColor = product.mockupsByColor || {};
          const placement = job.placement || "front";
          const fullKey = `${job.colorName}_${job.qrSize}_${placement}`;
          mockupsByColor[fullKey] = {
            front: result.mockupUrl,
            lifestyle: result.lifestyleMockupUrl,
            qrSize: job.qrSize,
            placement,
            generatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          const colorSizeKey = `${job.colorName}_${job.qrSize}`;
          mockupsByColor[colorSizeKey] = {
            front: result.mockupUrl,
            lifestyle: result.lifestyleMockupUrl,
            qrSize: job.qrSize,
            placement,
            generatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          mockupsByColor[job.colorName] = {
            front: result.mockupUrl,
            lifestyle: result.lifestyleMockupUrl,
            qrSize: job.qrSize,
            placement,
            generatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          await db3.update(products).set({ mockupsByColor }).where(eq3(products.id, job.productId));
          console.log(`[JobQueue] Updated product ${job.productId} mockups for ${colorSizeKey}`);
        } catch (err) {
          console.error("[JobQueue] Error updating product mockups:", err);
        }
      }
      startWorker() {
        if (this.processingInterval) return;
        console.log("[JobQueue] Starting worker...");
        this.processingInterval = setInterval(async () => {
          try {
            await this.processNextJob();
          } catch (err) {
            console.error("[JobQueue] Worker error:", err);
          }
        }, this.POLL_INTERVAL_MS);
      }
      stopWorker() {
        if (this.processingInterval) {
          clearInterval(this.processingInterval);
          this.processingInterval = null;
          console.log("[JobQueue] Worker stopped");
        }
      }
      async clearCompletedJobs(olderThanHours = 24) {
        const cutoff = new Date(Date.now() - olderThanHours * 60 * 60 * 1e3);
        const result = await db3.delete(mockupJobs).where(
          and3(
            eq3(mockupJobs.status, "completed"),
            lte(mockupJobs.completedAt, cutoff)
          )
        ).returning();
        return result.length;
      }
      async cancelJobsByProduct(productId) {
        const result = await db3.delete(mockupJobs).where(
          and3(
            eq3(mockupJobs.productId, productId),
            or2(
              eq3(mockupJobs.status, "pending"),
              eq3(mockupJobs.status, "delayed")
            )
          )
        ).returning();
        return result.length;
      }
    };
    mockupJobQueue = new MockupJobQueue();
  }
});

// server/lib/svg-renderer.ts
var svg_renderer_exports = {};
__export(svg_renderer_exports, {
  buildDesignSvg: () => buildDesignSvg,
  buildPreviewSvg: () => buildPreviewSvg,
  getFontAllowlist: () => getFontAllowlist,
  getWarpPresets: () => getWarpPresets,
  renderDesignToPng: () => renderDesignToPng,
  renderQrOnlyToPng: () => renderQrOnlyToPng,
  renderSvgToPng: () => renderSvgToPng
});
import { Resvg } from "@resvg/resvg-js";
import QRCode3 from "qrcode-svg";
function getFontAllowlist() {
  return [...FONT_ALLOWLIST];
}
function getWarpPresets() {
  return [
    { value: "straight", label: "Straight" },
    { value: "arc-up", label: "Arc Up" },
    { value: "arc-down", label: "Arc Down" },
    { value: "arc-strong-up", label: "Arc Up (Strong)" },
    { value: "arc-strong-down", label: "Arc Down (Strong)" },
    { value: "wave", label: "Wave" },
    { value: "wave-strong", label: "Wave (Strong)" },
    { value: "circle-top", label: "Circle Top" },
    { value: "circle-bottom", label: "Circle Bottom" }
  ];
}
function getWarpPath(preset, centerY, width) {
  const startX = (CANVAS_WIDTH - width) / 2;
  const endX = startX + width;
  const midX = CANVAS_WIDTH / 2;
  switch (preset) {
    case "arc-up": {
      const curveHeight = 80;
      return {
        id: `path-arc-up-${centerY}`,
        path: `M ${startX} ${centerY} Q ${midX} ${centerY - curveHeight} ${endX} ${centerY}`
      };
    }
    case "arc-down": {
      const curveHeight = 80;
      return {
        id: `path-arc-down-${centerY}`,
        path: `M ${startX} ${centerY} Q ${midX} ${centerY + curveHeight} ${endX} ${centerY}`
      };
    }
    case "arc-strong-up": {
      const curveHeight = 180;
      return {
        id: `path-arc-strong-up-${centerY}`,
        path: `M ${startX} ${centerY} Q ${midX} ${centerY - curveHeight} ${endX} ${centerY}`
      };
    }
    case "arc-strong-down": {
      const curveHeight = 180;
      return {
        id: `path-arc-strong-down-${centerY}`,
        path: `M ${startX} ${centerY} Q ${midX} ${centerY + curveHeight} ${endX} ${centerY}`
      };
    }
    case "wave": {
      const waveHeight = 50;
      const quarterX = startX + width / 4;
      const threeQuarterX = startX + width * 3 / 4;
      return {
        id: `path-wave-${centerY}`,
        path: `M ${startX} ${centerY} Q ${quarterX} ${centerY - waveHeight} ${midX} ${centerY} Q ${threeQuarterX} ${centerY + waveHeight} ${endX} ${centerY}`
      };
    }
    case "wave-strong": {
      const waveHeight = 120;
      const quarterX = startX + width / 4;
      const threeQuarterX = startX + width * 3 / 4;
      return {
        id: `path-wave-strong-${centerY}`,
        path: `M ${startX} ${centerY} Q ${quarterX} ${centerY - waveHeight} ${midX} ${centerY} Q ${threeQuarterX} ${centerY + waveHeight} ${endX} ${centerY}`
      };
    }
    case "circle-top": {
      const radius = width / 2;
      return {
        id: `path-circle-top-${centerY}`,
        path: `M ${startX} ${centerY} A ${radius} ${radius} 0 0 1 ${endX} ${centerY}`
      };
    }
    case "circle-bottom": {
      const radius = width / 2;
      return {
        id: `path-circle-bottom-${centerY}`,
        path: `M ${startX} ${centerY} A ${radius} ${radius} 0 0 0 ${endX} ${centerY}`
      };
    }
    case "straight":
    default:
      return {
        id: `path-straight-${centerY}`,
        path: `M ${startX} ${centerY} L ${endX} ${centerY}`
      };
  }
}
function generateQrSvg(url, size, qrColor = "black") {
  const color = qrColor === "white" ? "#FFFFFF" : "#000000";
  const qr = new QRCode3({
    content: url,
    width: size,
    height: size,
    color,
    background: "transparent",
    ecl: "H",
    padding: 0,
    join: true
  });
  let svgContent = qr.svg();
  svgContent = svgContent.replace(/<\?xml[^?]*\?>/g, "");
  svgContent = svgContent.replace(/<!DOCTYPE[^>]*>/g, "");
  return svgContent;
}
function escapeXml(text2) {
  return text2.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function sanitizeFont(font) {
  if (FONT_ALLOWLIST.includes(font)) {
    return font;
  }
  return "Arial";
}
function buildTextElementResult(style, centerY, pathWidth) {
  const sanitizedFont = sanitizeFont(style.fontFamily);
  const escapedText = escapeXml(style.text);
  const letterSpacing = style.letterSpacing ?? 0;
  const fontSize = Math.min(Math.max(style.fontSize, 48), 400);
  const warp = getWarpPath(style.warpPreset || "straight", centerY, pathWidth);
  let textStyle = `font-family: '${sanitizedFont}', Arial, sans-serif; font-size: ${fontSize}px; fill: ${style.color || "#000000"}; font-weight: bold;`;
  if (letterSpacing !== 0) {
    textStyle += ` letter-spacing: ${letterSpacing}px;`;
  }
  let defs = `<path id="${warp.id}" d="${warp.path}" fill="none" stroke="none"/>`;
  let textContent = "";
  if (style.strokeColor && style.strokeWidth && style.strokeWidth > 0) {
    const strokeStyle = `font-family: '${sanitizedFont}', Arial, sans-serif; font-size: ${fontSize}px; stroke: ${style.strokeColor}; stroke-width: ${style.strokeWidth}px; fill: none; font-weight: bold;`;
    if (letterSpacing !== 0) {
      textStyle += ` letter-spacing: ${letterSpacing}px;`;
    }
    textContent = `
      <text style="${strokeStyle}" text-anchor="middle">
        <textPath href="#${warp.id}" startOffset="50%">${escapedText}</textPath>
      </text>
      <text style="${textStyle}" text-anchor="middle">
        <textPath href="#${warp.id}" startOffset="50%">${escapedText}</textPath>
      </text>
    `;
  } else {
    textContent = `
      <text style="${textStyle}" text-anchor="middle">
        <textPath href="#${warp.id}" startOffset="50%">${escapedText}</textPath>
      </text>
    `;
  }
  return { defs, textContent };
}
function buildDesignSvg(request) {
  const qrSize = request.qrSize || QR_SIZE;
  const qrX = (CANVAS_WIDTH - qrSize) / 2;
  const qrY = QR_CENTER_Y - qrSize / 2;
  const textPathWidth = 3600;
  let allDefs = "";
  let allContent = "";
  if (request.header && request.header.text) {
    const headerResult = buildTextElementResult(request.header, HEADER_CENTER_Y, textPathWidth);
    allDefs += headerResult.defs;
    allContent += headerResult.textContent;
  }
  const qrColor = request.qrColor || "black";
  const qrSvgRaw = generateQrSvg(request.qrUrl, qrSize, qrColor);
  const qrSvgMatch = qrSvgRaw.match(/<svg[^>]*>([\s\S]*)<\/svg>/i);
  const qrInnerContent = qrSvgMatch ? qrSvgMatch[1] : "";
  allContent += `
    <g transform="translate(${qrX}, ${qrY})">
      ${qrInnerContent}
    </g>
  `;
  if (request.footer && request.footer.text) {
    const footerResult = buildTextElementResult(request.footer, FOOTER_CENTER_Y, textPathWidth);
    allDefs += footerResult.defs;
    allContent += footerResult.textContent;
  }
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
     width="${CANVAS_WIDTH}" height="${CANVAS_HEIGHT}" viewBox="0 0 ${CANVAS_WIDTH} ${CANVAS_HEIGHT}">
  <defs>
    ${allDefs}
  </defs>
  ${allContent}
</svg>`;
  return svg;
}
function buildPreviewSvg(request, previewWidth = 450, previewHeight = 540) {
  const fullSvg = buildDesignSvg(request);
  return fullSvg.replace(
    `width="${CANVAS_WIDTH}" height="${CANVAS_HEIGHT}"`,
    `width="${previewWidth}" height="${previewHeight}"`
  );
}
async function renderSvgToPng(svgString) {
  const resvg = new Resvg(svgString, {
    fitTo: {
      mode: "original"
    },
    font: {
      loadSystemFonts: true
    },
    logLevel: "off"
  });
  const pngData = resvg.render();
  const pngBuffer = pngData.asPng();
  return {
    pngBuffer,
    width: CANVAS_WIDTH,
    height: CANVAS_HEIGHT
  };
}
async function renderDesignToPng(request) {
  const svg = buildDesignSvg(request);
  return renderSvgToPng(svg);
}
async function renderQrOnlyToPng(request) {
  const qrSize = request.qrSize || 2400;
  const qrColor = request.qrColor || "black";
  const qrX = (CANVAS_WIDTH - qrSize) / 2;
  const qrY = (CANVAS_HEIGHT - qrSize) / 2;
  const qrSvgRaw = generateQrSvg(request.qrUrl, qrSize, qrColor);
  const qrSvgMatch = qrSvgRaw.match(/<svg[^>]*>([\s\S]*)<\/svg>/i);
  const qrInnerContent = qrSvgMatch ? qrSvgMatch[1] : "";
  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" 
     width="${CANVAS_WIDTH}" height="${CANVAS_HEIGHT}" viewBox="0 0 ${CANVAS_WIDTH} ${CANVAS_HEIGHT}">
  <g transform="translate(${qrX}, ${qrY})">
    ${qrInnerContent}
  </g>
</svg>`;
  return renderSvgToPng(svg);
}
var CANVAS_WIDTH, CANVAS_HEIGHT, HEADER_CENTER_Y, QR_CENTER_Y, FOOTER_CENTER_Y, QR_SIZE, FONT_ALLOWLIST;
var init_svg_renderer = __esm({
  "server/lib/svg-renderer.ts"() {
    "use strict";
    CANVAS_WIDTH = 4500;
    CANVAS_HEIGHT = 5400;
    HEADER_CENTER_Y = 800;
    QR_CENTER_Y = 2700;
    FOOTER_CENTER_Y = 4600;
    QR_SIZE = 1200;
    FONT_ALLOWLIST = [
      "Arial",
      "Arial Black",
      "Helvetica",
      "Times New Roman",
      "Georgia",
      "Verdana",
      "Impact",
      "Comic Sans MS",
      "Trebuchet MS",
      "Courier New",
      "Orbitron",
      "Roboto",
      "Open Sans",
      "Montserrat",
      "Oswald",
      "Playfair Display",
      "Bebas Neue",
      "Permanent Marker",
      "Bangers",
      "Lobster"
    ];
  }
});

// server/adapters/base.ts
var BasePrintProviderAdapter, BaseMarketplaceAdapter;
var init_base = __esm({
  "server/adapters/base.ts"() {
    "use strict";
    BasePrintProviderAdapter = class {
    };
    BaseMarketplaceAdapter = class {
    };
  }
});

// server/adapters/index.ts
var AdapterRegistry, adapterRegistry;
var init_adapters = __esm({
  "server/adapters/index.ts"() {
    "use strict";
    init_base();
    AdapterRegistry = class {
      printProviders = /* @__PURE__ */ new Map();
      marketplaces = /* @__PURE__ */ new Map();
      registerPrintProvider(adapter) {
        this.printProviders.set(adapter.providerType, adapter);
        console.log(`[AdapterRegistry] Registered print provider: ${adapter.displayName}`);
      }
      registerMarketplace(adapter) {
        this.marketplaces.set(adapter.marketplaceType, adapter);
        console.log(`[AdapterRegistry] Registered marketplace: ${adapter.displayName}`);
      }
      getPrintProvider(type) {
        return this.printProviders.get(type);
      }
      getMarketplace(type) {
        return this.marketplaces.get(type);
      }
      getAllPrintProviders() {
        return Array.from(this.printProviders.values());
      }
      getAllMarketplaces() {
        return Array.from(this.marketplaces.values());
      }
      getEnabledPrintProviders() {
        return Array.from(this.printProviders.keys());
      }
      getEnabledMarketplaces() {
        return Array.from(this.marketplaces.keys());
      }
    };
    adapterRegistry = new AdapterRegistry();
  }
});

// server/services/health-monitor.ts
var health_monitor_exports = {};
__export(health_monitor_exports, {
  healthMonitor: () => healthMonitor
});
var HealthMonitorService, healthMonitor;
var init_health_monitor = __esm({
  "server/services/health-monitor.ts"() {
    "use strict";
    init_adapters();
    init_storage();
    HealthMonitorService = class {
      checkInterval = null;
      isRunning = false;
      async checkAllProviders() {
        const providers = adapterRegistry.getAllPrintProviders();
        const results = [];
        for (const provider of providers) {
          try {
            const healthResult = await provider.healthCheck();
            await storage.logProviderHealth({
              providerType: provider.providerType,
              isHealthy: healthResult.isHealthy,
              responseTimeMs: healthResult.responseTimeMs,
              errorMessage: healthResult.error || null,
              errorCode: healthResult.errorCode || null
            });
            const stats = await storage.getProviderHealthStats(provider.providerType, 24);
            results.push({
              providerType: provider.providerType,
              displayName: provider.displayName,
              isHealthy: healthResult.isHealthy,
              responseTimeMs: healthResult.responseTimeMs,
              lastCheck: /* @__PURE__ */ new Date(),
              errorMessage: healthResult.error,
              errorCode: healthResult.errorCode,
              stats24h: stats
            });
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : "Unknown error";
            await storage.logProviderHealth({
              providerType: provider.providerType,
              isHealthy: false,
              responseTimeMs: 0,
              errorMessage: errorMsg,
              errorCode: "CHECK_FAILED"
            });
            const stats = await storage.getProviderHealthStats(provider.providerType, 24);
            results.push({
              providerType: provider.providerType,
              displayName: provider.displayName,
              isHealthy: false,
              responseTimeMs: 0,
              lastCheck: /* @__PURE__ */ new Date(),
              errorMessage: errorMsg,
              errorCode: "CHECK_FAILED",
              stats24h: stats
            });
          }
        }
        return results;
      }
      async checkProvider(providerType) {
        const provider = adapterRegistry.getPrintProvider(providerType);
        if (!provider) return null;
        try {
          const healthResult = await provider.healthCheck();
          await storage.logProviderHealth({
            providerType: provider.providerType,
            isHealthy: healthResult.isHealthy,
            responseTimeMs: healthResult.responseTimeMs,
            errorMessage: healthResult.error || null,
            errorCode: healthResult.errorCode || null
          });
          const stats = await storage.getProviderHealthStats(provider.providerType, 24);
          return {
            providerType: provider.providerType,
            displayName: provider.displayName,
            isHealthy: healthResult.isHealthy,
            responseTimeMs: healthResult.responseTimeMs,
            lastCheck: /* @__PURE__ */ new Date(),
            errorMessage: healthResult.error,
            errorCode: healthResult.errorCode,
            stats24h: stats
          };
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : "Unknown error";
          await storage.logProviderHealth({
            providerType: provider.providerType,
            isHealthy: false,
            responseTimeMs: 0,
            errorMessage: errorMsg,
            errorCode: "CHECK_FAILED"
          });
          const stats = await storage.getProviderHealthStats(provider.providerType, 24);
          return {
            providerType: provider.providerType,
            displayName: provider.displayName,
            isHealthy: false,
            responseTimeMs: 0,
            lastCheck: /* @__PURE__ */ new Date(),
            errorMessage: errorMsg,
            errorCode: "CHECK_FAILED",
            stats24h: stats
          };
        }
      }
      async getHealthDashboard() {
        const providers = adapterRegistry.getAllPrintProviders();
        const statuses = [];
        for (const provider of providers) {
          const latest = await storage.getLatestProviderHealth(provider.providerType);
          const stats = await storage.getProviderHealthStats(provider.providerType, 24);
          statuses.push({
            providerType: provider.providerType,
            displayName: provider.displayName,
            isHealthy: latest?.isHealthy ?? false,
            responseTimeMs: latest?.responseTimeMs ?? 0,
            lastCheck: latest?.checkTime ?? /* @__PURE__ */ new Date(0),
            errorMessage: latest?.errorMessage ?? void 0,
            errorCode: latest?.errorCode ?? void 0,
            stats24h: stats
          });
        }
        const healthyCount = statuses.filter((s) => s.isHealthy).length;
        const totalCount = statuses.length;
        let overallHealth;
        if (healthyCount === totalCount) {
          overallHealth = "healthy";
        } else if (healthyCount > 0) {
          overallHealth = "degraded";
        } else {
          overallHealth = "critical";
        }
        return {
          providers: statuses,
          summary: {
            totalProviders: totalCount,
            healthyProviders: healthyCount,
            unhealthyProviders: totalCount - healthyCount,
            overallHealth
          }
        };
      }
      async getProviderHistory(providerType, limit = 100) {
        return storage.getProviderHealthLogs(providerType, limit);
      }
      startPeriodicChecks(intervalMinutes = 5) {
        if (this.isRunning) {
          console.log("[HealthMonitor] Already running");
          return;
        }
        this.isRunning = true;
        console.log(`[HealthMonitor] Starting periodic checks every ${intervalMinutes} minutes`);
        this.checkAllProviders().catch(console.error);
        this.checkInterval = setInterval(() => {
          this.checkAllProviders().catch(console.error);
        }, intervalMinutes * 60 * 1e3);
      }
      stopPeriodicChecks() {
        if (this.checkInterval) {
          clearInterval(this.checkInterval);
          this.checkInterval = null;
        }
        this.isRunning = false;
        console.log("[HealthMonitor] Stopped periodic checks");
      }
    };
    healthMonitor = new HealthMonitorService();
  }
});

// server/services/auto-router.ts
var auto_router_exports = {};
__export(auto_router_exports, {
  autoRouter: () => autoRouter
});
var AutoRouter, autoRouter;
var init_auto_router = __esm({
  "server/services/auto-router.ts"() {
    "use strict";
    init_storage();
    init_health_monitor();
    AutoRouter = class {
      routingHistory = [];
      /**
       * Route an order to the optimal provider based on criteria
       */
      async routeOrder(criteria) {
        try {
          const providers = await storage.getPrintifyPrintProviders(criteria.blueprintId);
          if (!providers || providers.length === 0) {
            return {
              success: false,
              selectedProvider: null,
              alternativeProviders: [],
              reason: `No providers found for blueprint ${criteria.blueprintId}`,
              timestamp: /* @__PURE__ */ new Date()
            };
          }
          const healthDashboard = await healthMonitor.getHealthDashboard();
          const providerHealthMap = /* @__PURE__ */ new Map();
          for (const status of healthDashboard.providers) {
            providerHealthMap.set(status.providerType.toLowerCase(), {
              uptime: status.stats24h.uptimePercent,
              avgResponseTime: status.stats24h.avgResponseTime
            });
          }
          const scoredProviders = [];
          for (const provider of providers) {
            if (criteria.excludeProviders?.includes(provider.providerId)) {
              continue;
            }
            if (criteria.requireUSA && !provider.isUSA) {
              continue;
            }
            if (criteria.maxCostCents && provider.minCost && provider.minCost > criteria.maxCostCents) {
              continue;
            }
            const printifyHealth = providerHealthMap.get("printify");
            const isHealthy = printifyHealth ? printifyHealth.uptime >= 90 : true;
            const healthScore = printifyHealth ? printifyHealth.uptime : 100;
            const responseTime = printifyHealth ? printifyHealth.avgResponseTime : null;
            const combinedScore = this.calculateCombinedScore(
              provider.minCost,
              provider.isUSA ?? false,
              healthScore,
              responseTime,
              criteria.prioritize
            );
            scoredProviders.push({
              providerId: provider.providerId,
              providerName: provider.title,
              blueprintId: criteria.blueprintId,
              costCents: provider.minCost,
              isUSA: provider.isUSA ?? false,
              isHealthy,
              healthScore,
              responseTimeMs: responseTime,
              combinedScore,
              reason: this.getScoreReason(criteria.prioritize, provider.minCost, provider.isUSA ?? false, healthScore)
            });
          }
          if (scoredProviders.length === 0) {
            return {
              success: false,
              selectedProvider: null,
              alternativeProviders: [],
              reason: "No providers meet the specified criteria",
              timestamp: /* @__PURE__ */ new Date()
            };
          }
          scoredProviders.sort((a, b) => b.combinedScore - a.combinedScore);
          const selectedProvider = scoredProviders[0];
          const alternativeProviders = scoredProviders.slice(1, 4);
          this.routingHistory.push({
            timestamp: /* @__PURE__ */ new Date(),
            blueprintId: criteria.blueprintId,
            selectedProviderId: selectedProvider.providerId,
            costCents: selectedProvider.costCents,
            criteria
          });
          if (this.routingHistory.length > 1e3) {
            this.routingHistory = this.routingHistory.slice(-1e3);
          }
          return {
            success: true,
            selectedProvider,
            alternativeProviders,
            reason: `Selected ${selectedProvider.providerName} based on ${criteria.prioritize} priority`,
            timestamp: /* @__PURE__ */ new Date()
          };
        } catch (error) {
          const message = error instanceof Error ? error.message : "Unknown error";
          return {
            success: false,
            selectedProvider: null,
            alternativeProviders: [],
            reason: `Routing error: ${message}`,
            timestamp: /* @__PURE__ */ new Date()
          };
        }
      }
      /**
       * Calculate combined score based on priority
       */
      calculateCombinedScore(costCents, isUSA, healthScore, responseTimeMs, priority) {
        let score = 0;
        const healthWeight = priority === "balanced" ? 0.25 : 0.2;
        score += healthScore / 100 * 100 * healthWeight;
        if (costCents !== null) {
          const normalizedCost = Math.max(0, Math.min(100, 100 - (costCents - 500) / 4500 * 100));
          const costWeight = priority === "cost" ? 0.6 : priority === "speed" ? 0.2 : 0.35;
          score += normalizedCost * costWeight;
        }
        const speedScore = isUSA ? 100 : 50;
        const speedWeight = priority === "speed" ? 0.5 : priority === "cost" ? 0.1 : 0.25;
        score += speedScore * speedWeight;
        if (responseTimeMs !== null) {
          const rtScore = Math.max(0, Math.min(100, 100 - responseTimeMs / 50));
          score += rtScore * 0.1;
        }
        return Math.round(score);
      }
      /**
       * Get human-readable reason for score
       */
      getScoreReason(priority, costCents, isUSA, healthScore) {
        const parts = [];
        if (costCents !== null) {
          parts.push(`$${(costCents / 100).toFixed(2)} base cost`);
        }
        if (isUSA) {
          parts.push("USA-based (faster shipping)");
        }
        parts.push(`${healthScore.toFixed(0)}% uptime`);
        return parts.join(", ");
      }
      /**
       * Get cheapest available provider for a blueprint
       */
      async getCheapestProvider(blueprintId, requireUSA = false) {
        return this.routeOrder({
          blueprintId,
          prioritize: "cost",
          requireUSA
        });
      }
      /**
       * Get fastest available provider for a blueprint
       */
      async getFastestProvider(blueprintId) {
        return this.routeOrder({
          blueprintId,
          prioritize: "speed",
          requireUSA: true
          // USA providers are fastest for US shipping
        });
      }
      /**
       * Get balanced recommendation (cost + speed)
       */
      async getBalancedProvider(blueprintId) {
        return this.routeOrder({
          blueprintId,
          prioritize: "balanced"
        });
      }
      /**
       * Get routing statistics
       */
      getStats() {
        if (this.routingHistory.length === 0) {
          return {
            totalRoutings: 0,
            byProvider: {},
            avgSelectedCost: 0,
            routingTimestamp: /* @__PURE__ */ new Date()
          };
        }
        const byProvider = {};
        let totalCost = 0;
        let costCount = 0;
        for (const routing of this.routingHistory) {
          const key = routing.selectedProviderId.toString();
          byProvider[key] = (byProvider[key] || 0) + 1;
          if (routing.costCents !== null) {
            totalCost += routing.costCents;
            costCount++;
          }
        }
        const lastRouting = this.routingHistory[this.routingHistory.length - 1];
        return {
          totalRoutings: this.routingHistory.length,
          byProvider,
          avgSelectedCost: costCount > 0 ? totalCost / costCount / 100 : 0,
          routingTimestamp: lastRouting?.timestamp || /* @__PURE__ */ new Date()
        };
      }
      /**
       * Get recent routing history
       */
      getRecentRoutings(limit = 20) {
        return this.routingHistory.slice(-limit).reverse();
      }
      /**
       * Find best providers for multiple blueprints (batch routing)
       */
      async routeBatch(blueprintIds, defaultCriteria) {
        const results = /* @__PURE__ */ new Map();
        await Promise.all(
          blueprintIds.map(async (blueprintId) => {
            const result = await this.routeOrder({
              ...defaultCriteria,
              blueprintId
            });
            results.set(blueprintId, result);
          })
        );
        return results;
      }
      /**
       * Get provider recommendations with explanations
       */
      async getRecommendations(blueprintId) {
        const [cheapest, fastest, balanced] = await Promise.all([
          this.getCheapestProvider(blueprintId),
          this.getFastestProvider(blueprintId),
          this.getBalancedProvider(blueprintId)
        ]);
        return { cheapest, fastest, balanced };
      }
    };
    autoRouter = new AutoRouter();
  }
});

// server/services/profit-calculator.ts
var profit_calculator_exports = {};
__export(profit_calculator_exports, {
  profitCalculator: () => profitCalculator
});
var PLATFORM_FEES, PAYMENT_PROCESSING_RATE, PAYMENT_PROCESSING_FIXED, ProfitCalculator, profitCalculator;
var init_profit_calculator = __esm({
  "server/services/profit-calculator.ts"() {
    "use strict";
    init_storage();
    PLATFORM_FEES = {
      direct: 0,
      // No marketplace fees for direct sales
      etsy: 0.065,
      // 6.5% transaction fee
      ebay: 0.13,
      // ~13% final value fee
      amazon: 0.15,
      // ~15% referral fee
      printify: 0,
      // Printify doesn't charge marketplace fees
      printful: 0,
      apliiq: 0
    };
    PAYMENT_PROCESSING_RATE = 0.029;
    PAYMENT_PROCESSING_FIXED = 0.3;
    ProfitCalculator = class {
      /**
       * Calculate profit breakdown for a single order
       */
      calculateOrderProfit(revenue, productionCost, shippingCost = 0, channel = "direct") {
        const platformFeeRate = PLATFORM_FEES[channel.toLowerCase()] || 0;
        const platformFees = revenue * platformFeeRate;
        const paymentProcessingFees = revenue * PAYMENT_PROCESSING_RATE + PAYMENT_PROCESSING_FIXED;
        const totalCosts = productionCost + shippingCost + platformFees + paymentProcessingFees;
        const netProfit = revenue - totalCosts;
        const marginPercent = revenue > 0 ? netProfit / revenue * 100 : 0;
        return {
          grossRevenue: revenue,
          productionCost,
          shippingCost,
          platformFees,
          paymentProcessingFees,
          netProfit,
          marginPercent
        };
      }
      /**
       * Calculate recommended retail price for a given production cost and target margin
       */
      calculateRecommendedPrice(productionCost, targetMarginPercent = 50, channel = "direct") {
        const platformFeeRate = PLATFORM_FEES[channel.toLowerCase()] || 0;
        const effectiveMargin = 1 - targetMarginPercent / 100 - platformFeeRate - PAYMENT_PROCESSING_RATE;
        if (effectiveMargin <= 0) {
          return productionCost * 3;
        }
        const price = (productionCost + PAYMENT_PROCESSING_FIXED) / effectiveMargin;
        return Math.ceil(price * 100) / 100;
      }
      /**
       * Determine price health based on margin
       */
      getPriceHealth(marginPercent) {
        if (marginPercent >= 60) return "excellent";
        if (marginPercent >= 40) return "good";
        if (marginPercent >= 20) return "marginal";
        return "loss";
      }
      /**
       * Get profit summary by channel from orders
       * Groups orders by source and calculates profit metrics
       */
      async getChannelProfitSummaries() {
        const completedOrders = await storage.getOrdersByStatus("completed");
        const processingOrders = await storage.getOrdersByStatus("processing");
        const allOrders = [...completedOrders, ...processingOrders];
        const channelData = {};
        for (const order of allOrders) {
          const channel = "direct";
          if (!channelData[channel]) {
            channelData[channel] = {
              orderCount: 0,
              totalRevenue: 0,
              totalCosts: 0
            };
          }
          const revenue = parseFloat(order.totalAmount || "0");
          const estimatedCost = revenue * 0.4;
          channelData[channel].orderCount++;
          channelData[channel].totalRevenue += revenue;
          channelData[channel].totalCosts += estimatedCost;
        }
        const summaries = [];
        for (const [channel, data] of Object.entries(channelData)) {
          const totalProfit = data.totalRevenue - data.totalCosts;
          const averageMargin = data.totalRevenue > 0 ? totalProfit / data.totalRevenue * 100 : 0;
          const averageOrderValue = data.orderCount > 0 ? data.totalRevenue / data.orderCount : 0;
          let channelType = "direct";
          if (["etsy", "ebay", "amazon"].includes(channel.toLowerCase())) {
            channelType = "marketplace";
          } else if (["printify", "printful", "apliiq"].includes(channel.toLowerCase())) {
            channelType = "print_provider";
          }
          summaries.push({
            channel,
            channelType,
            orderCount: data.orderCount,
            totalRevenue: data.totalRevenue,
            totalCosts: data.totalCosts,
            totalProfit,
            averageMargin,
            averageOrderValue
          });
        }
        return summaries.sort((a, b) => b.totalRevenue - a.totalRevenue);
      }
      /**
       * Analyze product profitability across all sales
       * Uses master products from orchestration system
       */
      async getProductProfitAnalysis() {
        const masterProducts2 = await storage.getAllMasterProducts();
        const analyses = [];
        for (const product of masterProducts2) {
          const baseCost = parseFloat(product.baseCost || "0");
          const retailPrice = parseFloat(product.retailPrice || "0");
          const profitPerUnit = retailPrice - baseCost;
          const marginPercent = retailPrice > 0 ? profitPerUnit / retailPrice * 100 : 0;
          const analysis = {
            masterProductId: product.id,
            productName: product.title,
            sku: product.sku,
            totalSold: 0,
            // Will be populated when order tracking is integrated
            totalRevenue: 0,
            averageCost: baseCost,
            averagePrice: retailPrice,
            marginPercent,
            profitPerUnit,
            recommendedPrice: this.calculateRecommendedPrice(baseCost, 50),
            priceHealth: this.getPriceHealth(marginPercent)
          };
          analyses.push(analysis);
        }
        return analyses.sort((a, b) => b.marginPercent - a.marginPercent);
      }
      /**
       * Generate profit alerts for issues that need attention
       */
      async generateAlerts() {
        const alerts = [];
        const analyses = await this.getProductProfitAnalysis();
        for (const product of analyses) {
          if (product.totalSold > 0) {
            if (product.priceHealth === "loss") {
              alerts.push({
                type: "critical",
                message: `${product.productName} is selling at a loss (${product.marginPercent.toFixed(1)}% margin)`,
                productId: product.masterProductId
              });
            } else if (product.priceHealth === "marginal") {
              alerts.push({
                type: "warning",
                message: `${product.productName} has low margin (${product.marginPercent.toFixed(1)}%)`,
                productId: product.masterProductId
              });
            }
          }
        }
        const channelSummaries = await this.getChannelProfitSummaries();
        for (const channel of channelSummaries) {
          if (channel.orderCount > 0 && channel.averageMargin < 25) {
            alerts.push({
              type: "warning",
              message: `${channel.channel} channel has low average margin (${channel.averageMargin.toFixed(1)}%)`,
              channel: channel.channel
            });
          }
        }
        return alerts;
      }
      /**
       * Get complete profit dashboard with all metrics
       */
      async getDashboard() {
        const [channelSummaries, productAnalyses, alerts] = await Promise.all([
          this.getChannelProfitSummaries(),
          this.getProductProfitAnalysis(),
          this.generateAlerts()
        ]);
        const totalRevenue = channelSummaries.reduce((sum, c) => sum + c.totalRevenue, 0);
        const totalCosts = channelSummaries.reduce((sum, c) => sum + c.totalCosts, 0);
        const totalProfit = channelSummaries.reduce((sum, c) => sum + c.totalProfit, 0);
        const overallMargin = totalRevenue > 0 ? totalProfit / totalRevenue * 100 : 0;
        const marginDistribution = {
          excellent: 0,
          good: 0,
          marginal: 0,
          loss: 0
        };
        for (const product of productAnalyses) {
          if (product.totalSold > 0) {
            marginDistribution[product.priceHealth]++;
          }
        }
        return {
          totalRevenue,
          totalCosts,
          totalProfit,
          overallMargin,
          channelSummaries,
          topProducts: productAnalyses.slice(0, 10),
          marginDistribution,
          alerts
        };
      }
      /**
       * Calculate break-even quantity for a product
       */
      calculateBreakEven(fixedCosts, unitPrice, unitCost) {
        const marginPerUnit = unitPrice - unitCost;
        if (marginPerUnit <= 0) {
          return Infinity;
        }
        return Math.ceil(fixedCosts / marginPerUnit);
      }
      /**
       * Compare profitability across channels for a specific product
       */
      compareChannelsForProduct(productionCost, basePrice) {
        const channels = ["direct", "etsy", "ebay", "amazon"];
        const comparisons = {};
        for (const channel of channels) {
          comparisons[channel] = this.calculateOrderProfit(
            basePrice,
            productionCost,
            0,
            channel
          );
        }
        return comparisons;
      }
    };
    profitCalculator = new ProfitCalculator();
  }
});

// server/services/auto-repricer.ts
var auto_repricer_exports = {};
__export(auto_repricer_exports, {
  autoRepricer: () => autoRepricer
});
import { eq as eq4, desc as desc2, sql as sql3 } from "drizzle-orm";
var AutoRepricerService, autoRepricer;
var init_auto_repricer = __esm({
  "server/services/auto-repricer.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_profit_calculator();
    AutoRepricerService = class {
      /**
       * Get all repricing rules, sorted by priority
       */
      async getRules() {
        const rules = await db3.select().from(repricingRules).orderBy(desc2(repricingRules.priority), repricingRules.createdAt);
        return rules;
      }
      /**
       * Get a specific rule by ID
       */
      async getRule(ruleId) {
        const [rule] = await db3.select().from(repricingRules).where(eq4(repricingRules.id, ruleId));
        return rule || null;
      }
      /**
       * Create a new repricing rule
       */
      async createRule(data) {
        const [rule] = await db3.insert(repricingRules).values({
          name: data.name,
          description: data.description,
          isActive: data.isActive ?? true,
          priority: data.priority ?? 0,
          conditions: data.conditions,
          actionType: data.actionType,
          actionParams: data.actionParams,
          appliesTo: data.appliesTo ?? "all",
          appliesToIds: data.appliesToIds
        }).returning();
        return rule;
      }
      /**
       * Update an existing rule
       */
      async updateRule(ruleId, updates) {
        const [updated] = await db3.update(repricingRules).set({ ...updates, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(repricingRules.id, ruleId)).returning();
        return updated || null;
      }
      /**
       * Delete a rule
       */
      async deleteRule(ruleId) {
        const result = await db3.delete(repricingRules).where(eq4(repricingRules.id, ruleId));
        return true;
      }
      /**
       * Toggle rule active status
       */
      async toggleRule(ruleId) {
        const rule = await this.getRule(ruleId);
        if (!rule) return null;
        return this.updateRule(ruleId, { isActive: !rule.isActive });
      }
      /**
       * Evaluate if a product matches rule conditions
       */
      evaluateConditions(product, channel, conditions, currentMargin) {
        if (conditions.marginBelow !== void 0 && currentMargin >= conditions.marginBelow) {
          return false;
        }
        if (conditions.marginAbove !== void 0 && currentMargin <= conditions.marginAbove) {
          return false;
        }
        if (conditions.channel && channel !== conditions.channel) {
          return false;
        }
        if (conditions.productCategory && product.category !== conditions.productCategory) {
          return false;
        }
        return true;
      }
      /**
       * Calculate new price based on action type and params
       */
      calculateNewPrice(currentPrice, baseCost, actionType, params, channel) {
        let newPrice = currentPrice;
        switch (actionType) {
          case "adjust_margin":
            if (params.targetMarginPercent !== void 0) {
              newPrice = profitCalculator.calculateRecommendedPrice(
                baseCost,
                params.targetMarginPercent,
                channel
              );
            }
            break;
          case "increase_percent":
            if (params.adjustPercent !== void 0) {
              newPrice = currentPrice * (1 + params.adjustPercent / 100);
            }
            break;
          case "decrease_percent":
            if (params.adjustPercent !== void 0) {
              newPrice = currentPrice * (1 - params.adjustPercent / 100);
            }
            break;
          case "match_target":
            if (params.targetMarginPercent !== void 0) {
              newPrice = profitCalculator.calculateRecommendedPrice(
                baseCost,
                params.targetMarginPercent,
                channel
              );
            }
            break;
        }
        if (params.minPrice !== void 0 && newPrice < params.minPrice) {
          newPrice = params.minPrice;
        }
        if (params.maxPrice !== void 0 && newPrice > params.maxPrice) {
          newPrice = params.maxPrice;
        }
        if (params.roundTo !== void 0 && params.roundTo > 0) {
          const roundTo = params.roundTo;
          if (roundTo === 0.99) {
            newPrice = Math.floor(newPrice) + 0.99;
          } else if (roundTo === 0.95) {
            newPrice = Math.floor(newPrice) + 0.95;
          } else {
            newPrice = Math.round(newPrice / roundTo) * roundTo;
          }
        }
        return Math.round(newPrice * 100) / 100;
      }
      /**
       * Run repricing evaluation for all products
       */
      async evaluateAllProducts(dryRun = true) {
        const results = [];
        const activeRules = await db3.select().from(repricingRules).where(eq4(repricingRules.isActive, true)).orderBy(desc2(repricingRules.priority));
        if (activeRules.length === 0) {
          return results;
        }
        const products2 = await db3.select().from(masterProducts);
        for (const product of products2) {
          const baseCost = parseFloat(product.baseCost || "0");
          const retailPrice = parseFloat(product.retailPrice || "0");
          if (baseCost <= 0 || retailPrice <= 0) continue;
          const profit = profitCalculator.calculateOrderProfit(
            retailPrice,
            baseCost,
            0,
            "direct"
          );
          const currentMargin = profit.marginPercent;
          for (const rule of activeRules) {
            const conditions = rule.conditions || {};
            const actionParams = rule.actionParams || {};
            const appliesTo = rule.appliesTo || "all";
            const appliesToIds = rule.appliesToIds || [];
            if (appliesTo === "product" && !appliesToIds.includes(product.id)) {
              continue;
            }
            if (this.evaluateConditions(product, null, conditions, currentMargin)) {
              const newPrice = this.calculateNewPrice(
                retailPrice,
                baseCost,
                rule.actionType,
                actionParams,
                "direct"
              );
              if (Math.abs(newPrice - retailPrice) > 0.01) {
                const newProfit = profitCalculator.calculateOrderProfit(
                  newPrice,
                  baseCost,
                  0,
                  "direct"
                );
                const result = {
                  productId: product.id,
                  productName: product.title,
                  channel: null,
                  previousPrice: retailPrice,
                  newPrice,
                  ruleApplied: rule.name,
                  reason: `Applied rule "${rule.name}" (${rule.actionType})`,
                  marginChange: {
                    from: currentMargin,
                    to: newProfit.marginPercent
                  }
                };
                results.push(result);
                if (!dryRun) {
                  await db3.update(masterProducts).set({
                    retailPrice: newPrice.toFixed(2),
                    updatedAt: /* @__PURE__ */ new Date()
                  }).where(eq4(masterProducts.id, product.id));
                  await db3.insert(repricingHistory).values({
                    ruleId: rule.id,
                    masterProductId: product.id,
                    channel: null,
                    previousPrice: retailPrice.toFixed(2),
                    newPrice: newPrice.toFixed(2),
                    reason: result.reason,
                    previousMargin: currentMargin.toFixed(2),
                    newMargin: newProfit.marginPercent.toFixed(2),
                    wasAutomatic: true
                  });
                }
                break;
              }
            }
          }
        }
        return results;
      }
      /**
       * Get repricing history
       */
      async getHistory(limit = 50) {
        const history = await db3.select({
          id: repricingHistory.id,
          ruleId: repricingHistory.ruleId,
          masterProductId: repricingHistory.masterProductId,
          channel: repricingHistory.channel,
          previousPrice: repricingHistory.previousPrice,
          newPrice: repricingHistory.newPrice,
          reason: repricingHistory.reason,
          previousMargin: repricingHistory.previousMargin,
          newMargin: repricingHistory.newMargin,
          appliedAt: repricingHistory.appliedAt,
          wasAutomatic: repricingHistory.wasAutomatic,
          productTitle: masterProducts.title,
          ruleName: repricingRules.name
        }).from(repricingHistory).leftJoin(masterProducts, eq4(repricingHistory.masterProductId, masterProducts.id)).leftJoin(repricingRules, eq4(repricingHistory.ruleId, repricingRules.id)).orderBy(desc2(repricingHistory.appliedAt)).limit(limit);
        return history;
      }
      /**
       * Get repricing statistics
       */
      async getStats() {
        const allRules = await db3.select().from(repricingRules);
        const activeRules = allRules.filter((r) => r.isActive);
        const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1e3);
        const recentHistory = await db3.select().from(repricingHistory).where(sql3`${repricingHistory.appliedAt} > ${twentyFourHoursAgo}`);
        const avgPriceChange = recentHistory.length > 0 ? recentHistory.reduce((sum, h) => {
          const prev = parseFloat(h.previousPrice || "0");
          const next = parseFloat(h.newPrice || "0");
          return sum + Math.abs(next - prev);
        }, 0) / recentHistory.length : 0;
        const lastEntry = await db3.select().from(repricingHistory).orderBy(desc2(repricingHistory.appliedAt)).limit(1);
        return {
          totalRules: allRules.length,
          activeRules: activeRules.length,
          lastRunTime: lastEntry[0]?.appliedAt || null,
          productsAdjusted24h: recentHistory.length,
          avgPriceChange: Math.round(avgPriceChange * 100) / 100
        };
      }
      /**
       * Preview what a rule would do without applying changes
       */
      async previewRule(ruleId) {
        const rule = await this.getRule(ruleId);
        if (!rule) return [];
        const results = [];
        const products2 = await db3.select().from(masterProducts);
        const conditions = rule.conditions || {};
        const actionParams = rule.actionParams || {};
        const appliesTo = rule.appliesTo || "all";
        const appliesToIds = rule.appliesToIds || [];
        for (const product of products2) {
          const baseCost = parseFloat(product.baseCost || "0");
          const retailPrice = parseFloat(product.retailPrice || "0");
          if (baseCost <= 0 || retailPrice <= 0) continue;
          if (appliesTo === "product" && !appliesToIds.includes(product.id)) {
            continue;
          }
          const profit = profitCalculator.calculateOrderProfit(
            retailPrice,
            baseCost,
            0,
            "direct"
          );
          const currentMargin = profit.marginPercent;
          if (this.evaluateConditions(product, null, conditions, currentMargin)) {
            const newPrice = this.calculateNewPrice(
              retailPrice,
              baseCost,
              rule.actionType,
              actionParams,
              "direct"
            );
            if (Math.abs(newPrice - retailPrice) > 0.01) {
              const newProfit = profitCalculator.calculateOrderProfit(
                newPrice,
                baseCost,
                0,
                "direct"
              );
              results.push({
                productId: product.id,
                productName: product.title,
                channel: null,
                previousPrice: retailPrice,
                newPrice,
                ruleApplied: rule.name,
                reason: `Would apply rule "${rule.name}" (${rule.actionType})`,
                marginChange: {
                  from: currentMargin,
                  to: newProfit.marginPercent
                }
              });
            }
          }
        }
        return results;
      }
    };
    autoRepricer = new AutoRepricerService();
  }
});

// server/services/qr-analytics.ts
var qr_analytics_exports = {};
__export(qr_analytics_exports, {
  qrAnalyticsService: () => qrAnalyticsService
});
import { eq as eq5, sql as sql4, and as and5, gte, desc as desc3, inArray as inArray2 } from "drizzle-orm";
var QrAnalyticsService, qrAnalyticsService;
var init_qr_analytics = __esm({
  "server/services/qr-analytics.ts"() {
    "use strict";
    init_db();
    init_schema();
    QrAnalyticsService = class {
      async logScan(input) {
        const now = /* @__PURE__ */ new Date();
        const today = new Date(now);
        today.setHours(0, 0, 0, 0);
        const conditions = [];
        if (input.masterProductId) {
          conditions.push(eq5(qrScanEvents.masterProductId, input.masterProductId));
        } else {
          conditions.push(sql4`${qrScanEvents.masterProductId} IS NULL`);
        }
        if (input.customDesignId) {
          conditions.push(eq5(qrScanEvents.customDesignId, input.customDesignId));
        } else {
          conditions.push(sql4`${qrScanEvents.customDesignId} IS NULL`);
        }
        if (input.qrUrl) {
          conditions.push(eq5(qrScanEvents.qrUrl, input.qrUrl));
        } else {
          conditions.push(sql4`${qrScanEvents.qrUrl} IS NULL`);
        }
        conditions.push(gte(qrScanEvents.scanDate, today));
        const existing = await db3.select().from(qrScanEvents).where(and5(...conditions)).limit(1);
        if (existing.length > 0 && existing[0].scanCount !== null) {
          await db3.update(qrScanEvents).set({
            scanCount: (existing[0].scanCount || 0) + 1,
            deviceType: input.deviceType || existing[0].deviceType,
            userAgent: input.userAgent || existing[0].userAgent,
            country: input.country || existing[0].country,
            region: input.region || existing[0].region
          }).where(eq5(qrScanEvents.id, existing[0].id));
        } else {
          await db3.insert(qrScanEvents).values({
            masterProductId: input.masterProductId,
            customDesignId: input.customDesignId,
            qrUrl: input.qrUrl,
            country: input.country,
            region: input.region,
            deviceType: input.deviceType,
            userAgent: input.userAgent,
            scanCount: 1,
            scanDate: now
          });
        }
      }
      async getSummary() {
        const now = /* @__PURE__ */ new Date();
        const todayStart = new Date(now);
        todayStart.setHours(0, 0, 0, 0);
        const weekStart = new Date(now);
        weekStart.setDate(weekStart.getDate() - 7);
        weekStart.setHours(0, 0, 0, 0);
        const monthStart = new Date(now);
        monthStart.setMonth(monthStart.getMonth() - 1);
        monthStart.setHours(0, 0, 0, 0);
        const [totalResult] = await db3.select({ total: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)` }).from(qrScanEvents);
        const [todayResult] = await db3.select({ total: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)` }).from(qrScanEvents).where(gte(qrScanEvents.scanDate, todayStart));
        const [weekResult] = await db3.select({ total: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)` }).from(qrScanEvents).where(gte(qrScanEvents.scanDate, weekStart));
        const [monthResult] = await db3.select({ total: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)` }).from(qrScanEvents).where(gte(qrScanEvents.scanDate, monthStart));
        const uniqueProductsResult = await db3.select({ productId: qrScanEvents.masterProductId }).from(qrScanEvents).where(sql4`${qrScanEvents.masterProductId} IS NOT NULL`).groupBy(qrScanEvents.masterProductId);
        const topCountries = await db3.select({
          country: qrScanEvents.country,
          scans: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)`
        }).from(qrScanEvents).where(sql4`${qrScanEvents.country} IS NOT NULL`).groupBy(qrScanEvents.country).orderBy(sql4`SUM(${qrScanEvents.scanCount}) DESC`).limit(5);
        const topDevices = await db3.select({
          deviceType: qrScanEvents.deviceType,
          scans: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)`
        }).from(qrScanEvents).where(sql4`${qrScanEvents.deviceType} IS NOT NULL`).groupBy(qrScanEvents.deviceType).orderBy(sql4`SUM(${qrScanEvents.scanCount}) DESC`).limit(5);
        return {
          totalScans: Number(totalResult?.total || 0),
          scansToday: Number(todayResult?.total || 0),
          scansThisWeek: Number(weekResult?.total || 0),
          scansThisMonth: Number(monthResult?.total || 0),
          uniqueProducts: uniqueProductsResult.length,
          topCountries: topCountries.map((c) => ({
            country: c.country || "Unknown",
            scans: Number(c.scans)
          })),
          topDevices: topDevices.map((d) => ({
            deviceType: d.deviceType || "Unknown",
            scans: Number(d.scans)
          }))
        };
      }
      async getProductAnalytics(limit = 20) {
        const now = /* @__PURE__ */ new Date();
        const todayStart = new Date(now);
        todayStart.setHours(0, 0, 0, 0);
        const weekStart = new Date(now);
        weekStart.setDate(weekStart.getDate() - 7);
        weekStart.setHours(0, 0, 0, 0);
        const productScans = await db3.select({
          productId: qrScanEvents.masterProductId,
          totalScans: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)`,
          scansToday: sql4`COALESCE(SUM(CASE WHEN ${qrScanEvents.scanDate} >= ${todayStart} THEN ${qrScanEvents.scanCount} ELSE 0 END), 0)`,
          scansThisWeek: sql4`COALESCE(SUM(CASE WHEN ${qrScanEvents.scanDate} >= ${weekStart} THEN ${qrScanEvents.scanCount} ELSE 0 END), 0)`,
          lastScanned: sql4`MAX(${qrScanEvents.scanDate})`
        }).from(qrScanEvents).where(sql4`${qrScanEvents.masterProductId} IS NOT NULL`).groupBy(qrScanEvents.masterProductId).orderBy(sql4`SUM(${qrScanEvents.scanCount}) DESC`).limit(limit);
        if (productScans.length === 0) {
          return [];
        }
        const productIds = productScans.map((s) => s.productId).filter((id) => id !== null);
        const products2 = productIds.length > 0 ? await db3.select({ id: masterProducts.id, title: masterProducts.title }).from(masterProducts).where(inArray2(masterProducts.id, productIds)) : [];
        const productMap = new Map(products2.map((p) => [p.id, p.title]));
        return productScans.map((scan) => ({
          productId: scan.productId || "",
          productName: productMap.get(scan.productId || "") || "Unknown Product",
          totalScans: Number(scan.totalScans),
          scansToday: Number(scan.scansToday),
          scansThisWeek: Number(scan.scansThisWeek),
          lastScanned: scan.lastScanned
        }));
      }
      async getTrends(days = 30) {
        const startDate = /* @__PURE__ */ new Date();
        startDate.setDate(startDate.getDate() - days);
        startDate.setHours(0, 0, 0, 0);
        const trends = await db3.select({
          date: sql4`DATE(${qrScanEvents.scanDate})`,
          scans: sql4`COALESCE(SUM(${qrScanEvents.scanCount}), 0)`
        }).from(qrScanEvents).where(gte(qrScanEvents.scanDate, startDate)).groupBy(sql4`DATE(${qrScanEvents.scanDate})`).orderBy(sql4`DATE(${qrScanEvents.scanDate}) ASC`);
        const allDates = [];
        const current = new Date(startDate);
        const now = /* @__PURE__ */ new Date();
        while (current <= now) {
          const dateStr = current.toISOString().split("T")[0];
          const existing = trends.find((t) => t.date === dateStr);
          allDates.push({
            date: dateStr,
            scans: existing ? Number(existing.scans) : 0
          });
          current.setDate(current.getDate() + 1);
        }
        return allDates;
      }
      async getRecentScans(limit = 50) {
        const events = await db3.select().from(qrScanEvents).orderBy(desc3(qrScanEvents.scanDate)).limit(limit);
        if (events.length === 0) {
          return [];
        }
        const productIds = events.map((e) => e.masterProductId).filter((id) => id !== null);
        const products2 = productIds.length > 0 ? await db3.select({ id: masterProducts.id, title: masterProducts.title }).from(masterProducts).where(inArray2(masterProducts.id, productIds)) : [];
        const productMap = new Map(products2.map((p) => [p.id, p.title]));
        return events.map((event) => ({
          ...event,
          productName: event.masterProductId ? productMap.get(event.masterProductId) || null : null
        }));
      }
      detectDeviceType(userAgent) {
        const ua = userAgent.toLowerCase();
        if (/mobile|android|iphone|ipod|blackberry|windows phone/.test(ua)) {
          return "mobile";
        }
        if (/ipad|tablet|kindle|silk/.test(ua)) {
          return "tablet";
        }
        return "desktop";
      }
    };
    qrAnalyticsService = new QrAnalyticsService();
  }
});

// server/adapters/print-providers/printify.ts
var printify_exports2 = {};
__export(printify_exports2, {
  PrintifyAdapter: () => PrintifyAdapter
});
var PRINTIFY_API_BASE2, PrintifyAdapter;
var init_printify2 = __esm({
  "server/adapters/print-providers/printify.ts"() {
    "use strict";
    init_base();
    PRINTIFY_API_BASE2 = "https://api.printify.com/v1";
    PrintifyAdapter = class extends BasePrintProviderAdapter {
      providerType = "printify";
      displayName = "Printify";
      getApiKey() {
        const key = process.env.PRINTIFY_API_KEY;
        if (!key) throw new Error("PRINTIFY_API_KEY not configured");
        return key;
      }
      getShopId() {
        const shopId = process.env.PRINTIFY_SHOP_ID;
        if (!shopId) throw new Error("PRINTIFY_SHOP_ID not configured");
        return shopId;
      }
      async apiRequest(endpoint, options = {}) {
        const response = await fetch(`${PRINTIFY_API_BASE2}${endpoint}`, {
          ...options,
          headers: {
            "Authorization": `Bearer ${this.getApiKey()}`,
            "Content-Type": "application/json",
            ...options.headers
          }
        });
        if (!response.ok) {
          const error = await response.text();
          throw new Error(`Printify API error: ${response.status} - ${error}`);
        }
        return response.json();
      }
      async publishProduct(input) {
        try {
          const shopId = this.getShopId();
          const { masterProduct, designVersion, variants, retailPrice } = input;
          const printifyVariants = variants.map((v) => ({
            id: 1,
            price: Math.round(retailPrice * 100),
            is_enabled: true
          }));
          const productData = {
            title: masterProduct.title,
            description: masterProduct.description || "",
            blueprint_id: 6,
            print_provider_id: 99,
            variants: printifyVariants,
            print_areas: [
              {
                variant_ids: printifyVariants.map((v) => v.id),
                placeholders: [
                  {
                    position: "front",
                    images: [
                      {
                        id: designVersion.renderedPngUrl,
                        x: 0.5,
                        y: 0.5,
                        scale: 1,
                        angle: 0
                      }
                    ]
                  }
                ]
              }
            ]
          };
          const result = await this.apiRequest(`/shops/${shopId}/products.json`, {
            method: "POST",
            body: JSON.stringify(productData)
          });
          return {
            success: true,
            externalProductId: result.id
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async updateProduct(externalProductId, input) {
        try {
          const shopId = this.getShopId();
          await this.apiRequest(`/shops/${shopId}/products/${externalProductId}.json`, {
            method: "PUT",
            body: JSON.stringify({
              title: input.masterProduct.title,
              description: input.masterProduct.description || ""
            })
          });
          return {
            success: true,
            externalProductId
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async unpublishProduct(externalProductId) {
        try {
          const shopId = this.getShopId();
          await this.apiRequest(`/shops/${shopId}/products/${externalProductId}.json`, {
            method: "DELETE"
          });
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return { success: false, error: errorMessage };
        }
      }
      async getQuote(masterProduct, variant) {
        return {
          productionCost: 15,
          shippingCost: 5,
          estimatedDays: 7,
          isAvailable: true
        };
      }
      async submitOrder(input) {
        try {
          const shopId = this.getShopId();
          const { order, masterProduct, designVersion, variant, quantity, shippingAddress } = input;
          const orderData = {
            external_id: order.id,
            line_items: [
              {
                product_id: masterProduct.id,
                variant_id: 1,
                quantity
              }
            ],
            shipping_method: 1,
            address_to: {
              first_name: shippingAddress.name.split(" ")[0],
              last_name: shippingAddress.name.split(" ").slice(1).join(" ") || "",
              email: order.customerEmail || "",
              phone: shippingAddress.phone || "",
              country: shippingAddress.country,
              region: shippingAddress.state,
              address1: shippingAddress.address1,
              address2: shippingAddress.address2 || "",
              city: shippingAddress.city,
              zip: shippingAddress.zip
            }
          };
          const result = await this.apiRequest(`/shops/${shopId}/orders.json`, {
            method: "POST",
            body: JSON.stringify(orderData)
          });
          return {
            success: true,
            providerOrderId: result.id
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async getOrderStatus(providerOrderId) {
        try {
          const shopId = this.getShopId();
          const order = await this.apiRequest(`/shops/${shopId}/orders/${providerOrderId}.json`);
          return {
            status: order.status,
            trackingNumber: order.shipments?.[0]?.tracking_number,
            trackingUrl: order.shipments?.[0]?.tracking_url
          };
        } catch (error) {
          return { status: "unknown" };
        }
      }
      async healthCheck() {
        const startTime = Date.now();
        try {
          await this.apiRequest("/shops.json");
          return {
            isHealthy: true,
            responseTimeMs: Date.now() - startTime
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return {
            isHealthy: false,
            responseTimeMs: Date.now() - startTime,
            error: errorMessage
          };
        }
      }
      parseWebhook(payload) {
        if (!payload || typeof payload !== "object") return null;
        const p = payload;
        return {
          type: String(p.type || "unknown"),
          data: p.data,
          timestamp: /* @__PURE__ */ new Date()
        };
      }
    };
  }
});

// server/adapters/print-providers/printful.ts
var printful_exports2 = {};
__export(printful_exports2, {
  PrintfulAdapter: () => PrintfulAdapter
});
var PRINTFUL_API_BASE2, PrintfulAdapter;
var init_printful2 = __esm({
  "server/adapters/print-providers/printful.ts"() {
    "use strict";
    init_base();
    PRINTFUL_API_BASE2 = "https://api.printful.com";
    PrintfulAdapter = class extends BasePrintProviderAdapter {
      providerType = "printful";
      displayName = "Printful";
      getApiKey() {
        const key = process.env.PRINTFUL_API_KEY;
        if (!key) throw new Error("PRINTFUL_API_KEY not configured");
        return key;
      }
      async apiRequest(endpoint, options = {}) {
        const response = await fetch(`${PRINTFUL_API_BASE2}${endpoint}`, {
          ...options,
          headers: {
            "Authorization": `Bearer ${this.getApiKey()}`,
            "Content-Type": "application/json",
            ...options.headers
          }
        });
        if (!response.ok) {
          const errorText = await response.text();
          let errorMessage;
          try {
            const errorJson = JSON.parse(errorText);
            errorMessage = errorJson.result || errorJson.error?.message || errorText;
          } catch {
            errorMessage = errorText;
          }
          throw new Error(`Printful API error: ${response.status} - ${errorMessage}`);
        }
        const data = await response.json();
        return data.result;
      }
      mapVariantToPrintfulVariantId(variant, productId) {
        return productId;
      }
      async publishProduct(input) {
        try {
          const { masterProduct, designVersion, variants, retailPrice } = input;
          const renderedImageUrl = designVersion.renderedPngUrl;
          if (!renderedImageUrl) {
            return { success: false, error: "No rendered image URL available for design" };
          }
          const syncVariants = variants.map((v, index2) => ({
            variant_id: this.mapVariantToPrintfulVariantId(v, 4012 + index2),
            retail_price: retailPrice.toFixed(2),
            files: [
              {
                type: "front",
                url: renderedImageUrl
              }
            ],
            options: []
          }));
          const productData = {
            sync_product: {
              name: masterProduct.title,
              thumbnail: renderedImageUrl
            },
            sync_variants: syncVariants
          };
          const result = await this.apiRequest("/store/products", {
            method: "POST",
            body: JSON.stringify(productData)
          });
          return {
            success: true,
            externalProductId: String(result.id)
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[PrintfulAdapter] publishProduct error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async updateProduct(externalProductId, input) {
        try {
          const { masterProduct, designVersion } = input;
          const renderedImageUrl = designVersion.renderedPngUrl;
          const updateData = {
            sync_product: {
              name: masterProduct.title,
              thumbnail: renderedImageUrl || void 0
            }
          };
          await this.apiRequest(`/store/products/${externalProductId}`, {
            method: "PUT",
            body: JSON.stringify(updateData)
          });
          return {
            success: true,
            externalProductId
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[PrintfulAdapter] updateProduct error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async unpublishProduct(externalProductId) {
        try {
          await this.apiRequest(`/store/products/${externalProductId}`, {
            method: "DELETE"
          });
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[PrintfulAdapter] unpublishProduct error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async getQuote(masterProduct, variant) {
        try {
          const productCostEstimate = 15.5;
          const shippingEstimate = 4.99;
          return {
            productionCost: productCostEstimate,
            shippingCost: shippingEstimate,
            estimatedDays: 5,
            isAvailable: true
          };
        } catch (error) {
          console.error("[PrintfulAdapter] getQuote error:", error);
          return {
            productionCost: 0,
            isAvailable: false
          };
        }
      }
      async getCatalogProduct(productId) {
        try {
          const result = await this.apiRequest(`/products/${productId}`);
          return result.variants;
        } catch (error) {
          console.error("[PrintfulAdapter] getCatalogProduct error:", error);
          return null;
        }
      }
      async submitOrder(input) {
        try {
          const { order, designVersion, variant, quantity, shippingAddress } = input;
          const renderedImageUrl = designVersion.renderedPngUrl;
          if (!renderedImageUrl) {
            return { success: false, error: "No rendered image URL available for design" };
          }
          const nameParts = shippingAddress.name.trim().split(/\s+/);
          const firstName = nameParts[0] || "";
          const lastName = nameParts.slice(1).join(" ") || firstName;
          const orderData = {
            external_id: String(order.id),
            recipient: {
              name: shippingAddress.name,
              address1: shippingAddress.address1,
              address2: shippingAddress.address2 || void 0,
              city: shippingAddress.city,
              state_code: shippingAddress.state,
              country_code: shippingAddress.country,
              zip: shippingAddress.zip,
              phone: shippingAddress.phone || void 0,
              email: order.customerEmail || void 0
            },
            items: [
              {
                variant_id: 4012,
                quantity,
                files: [
                  {
                    type: "front",
                    url: renderedImageUrl
                  }
                ]
              }
            ],
            retail_costs: {
              retail_price: variant.price.toFixed(2),
              currency: "USD"
            }
          };
          const result = await this.apiRequest("/orders", {
            method: "POST",
            body: JSON.stringify(orderData)
          });
          return {
            success: true,
            providerOrderId: String(result.id),
            estimatedDelivery: result.shipments?.[0]?.ship_date ? new Date(result.shipments[0].ship_date) : void 0
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[PrintfulAdapter] submitOrder error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async getOrderStatus(providerOrderId) {
        try {
          const order = await this.apiRequest(`/orders/${providerOrderId}`);
          const latestShipment = order.shipments?.[order.shipments.length - 1];
          return {
            status: this.mapPrintfulStatus(order.status),
            trackingNumber: latestShipment?.tracking_number,
            trackingUrl: latestShipment?.tracking_url
          };
        } catch (error) {
          console.error("[PrintfulAdapter] getOrderStatus error:", error);
          return { status: "unknown" };
        }
      }
      mapPrintfulStatus(printfulStatus) {
        const statusMap = {
          draft: "pending",
          pending: "pending",
          failed: "failed",
          canceled: "cancelled",
          inprocess: "processing",
          onhold: "on_hold",
          partial: "partially_shipped",
          fulfilled: "shipped"
        };
        return statusMap[printfulStatus.toLowerCase()] || printfulStatus;
      }
      async healthCheck() {
        const startTime = Date.now();
        try {
          await this.apiRequest("/store");
          return {
            isHealthy: true,
            responseTimeMs: Date.now() - startTime
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          let errorCode;
          if (errorMessage.includes("401")) {
            errorCode = "AUTH_ERROR";
          } else if (errorMessage.includes("429")) {
            errorCode = "RATE_LIMITED";
          } else if (errorMessage.includes("500") || errorMessage.includes("502") || errorMessage.includes("503")) {
            errorCode = "SERVER_ERROR";
          }
          return {
            isHealthy: false,
            responseTimeMs: Date.now() - startTime,
            error: errorMessage,
            errorCode
          };
        }
      }
      parseWebhook(payload) {
        if (!payload || typeof payload !== "object") return null;
        const p = payload;
        const type = p.type;
        const data = p.data;
        if (!type) return null;
        return {
          type,
          data,
          timestamp: /* @__PURE__ */ new Date()
        };
      }
      async getShippingRates(recipient, items) {
        try {
          const result = await this.apiRequest("/shipping/rates", {
            method: "POST",
            body: JSON.stringify({ recipient, items })
          });
          return result;
        } catch (error) {
          console.error("[PrintfulAdapter] getShippingRates error:", error);
          return null;
        }
      }
    };
  }
});

// server/adapters/print-providers/apliiq.ts
var apliiq_exports = {};
__export(apliiq_exports, {
  ApliiqAdapter: () => ApliiqAdapter
});
var ApliiqAdapter;
var init_apliiq = __esm({
  "server/adapters/print-providers/apliiq.ts"() {
    "use strict";
    init_base();
    ApliiqAdapter = class extends BasePrintProviderAdapter {
      providerType = "apliiq";
      displayName = "Apliiq";
      async publishProduct(input) {
        return { success: false, error: "Apliiq adapter not yet implemented" };
      }
      async updateProduct(externalProductId, input) {
        return { success: false, error: "Apliiq adapter not yet implemented" };
      }
      async unpublishProduct(externalProductId) {
        return { success: false, error: "Apliiq adapter not yet implemented" };
      }
      async getQuote(masterProduct, variant) {
        return { productionCost: 0, isAvailable: false };
      }
      async submitOrder(input) {
        return { success: false, error: "Apliiq adapter not yet implemented" };
      }
      async getOrderStatus(providerOrderId) {
        return { status: "not_implemented" };
      }
      async healthCheck() {
        return { isHealthy: false, responseTimeMs: 0, error: "Not implemented" };
      }
      parseWebhook(payload) {
        return null;
      }
    };
  }
});

// server/adapters/marketplaces/etsy.ts
var etsy_exports = {};
__export(etsy_exports, {
  EtsyAdapter: () => EtsyAdapter
});
var ETSY_API_BASE, EtsyAdapter;
var init_etsy = __esm({
  "server/adapters/marketplaces/etsy.ts"() {
    "use strict";
    init_base();
    ETSY_API_BASE = "https://api.etsy.com/v3/application";
    EtsyAdapter = class extends BaseMarketplaceAdapter {
      marketplaceType = "etsy";
      displayName = "Etsy";
      getApiKeyString() {
        const keystring = process.env.ETSY_API_KEYSTRING;
        if (!keystring) throw new Error("ETSY_API_KEYSTRING not configured");
        return keystring;
      }
      getSharedSecret() {
        const secret = process.env.ETSY_SHARED_SECRET;
        if (!secret) throw new Error("ETSY_SHARED_SECRET not configured");
        return secret;
      }
      getAccessToken() {
        const token = process.env.ETSY_ACCESS_TOKEN;
        if (!token) throw new Error("ETSY_ACCESS_TOKEN not configured");
        return token;
      }
      getShopId() {
        const shopId = process.env.ETSY_SHOP_ID;
        if (!shopId) throw new Error("ETSY_SHOP_ID not configured");
        return shopId;
      }
      async apiRequest(endpoint, options = {}) {
        const url = `${ETSY_API_BASE}${endpoint}`;
        const response = await fetch(url, {
          ...options,
          headers: {
            "x-api-key": `${this.getApiKeyString()}:${this.getSharedSecret()}`,
            "Authorization": `Bearer ${this.getAccessToken()}`,
            ...options.headers
          }
        });
        if (!response.ok) {
          const errorText = await response.text();
          let errorMessage;
          try {
            const errorJson = JSON.parse(errorText);
            errorMessage = errorJson.error || errorJson.message || errorText;
          } catch {
            errorMessage = errorText;
          }
          throw new Error(`Etsy API error: ${response.status} - ${errorMessage}`);
        }
        return response.json();
      }
      async uploadImageFromUrl(listingId, imageUrl, rank = 1) {
        try {
          const imageResponse = await fetch(imageUrl);
          if (!imageResponse.ok) {
            throw new Error(`Failed to fetch image from ${imageUrl}`);
          }
          const imageBuffer = await imageResponse.arrayBuffer();
          const imageBlob = new Blob([imageBuffer], { type: "image/png" });
          const formData = new FormData();
          formData.append("image", imageBlob, "design.png");
          formData.append("rank", String(rank));
          formData.append("overwrite", "true");
          const shopId = this.getShopId();
          const response = await fetch(`${ETSY_API_BASE}/shops/${shopId}/listings/${listingId}/images`, {
            method: "POST",
            headers: {
              "x-api-key": `${this.getApiKeyString()}:${this.getSharedSecret()}`,
              "Authorization": `Bearer ${this.getAccessToken()}`
            },
            body: formData
          });
          if (!response.ok) {
            const error = await response.text();
            console.error(`[EtsyAdapter] Image upload failed: ${error}`);
            return null;
          }
          return response.json();
        } catch (error) {
          console.error(`[EtsyAdapter] uploadImageFromUrl error:`, error);
          return null;
        }
      }
      async createListing(input) {
        try {
          const { masterProduct, designVersion, retailPrice, title, description, tags, images } = input;
          const shopId = this.getShopId();
          const priceInCents = Math.round(retailPrice * 100);
          const formData = new URLSearchParams();
          formData.append("quantity", "999");
          formData.append("title", title.substring(0, 140));
          formData.append("description", description);
          formData.append("price", String(priceInCents / 100));
          formData.append("who_made", "i_did");
          formData.append("when_made", "made_to_order");
          formData.append("taxonomy_id", "482");
          formData.append("is_supply", "false");
          formData.append("should_auto_renew", "true");
          if (tags && tags.length > 0) {
            const tagString = tags.slice(0, 13).join(",");
            formData.append("tags", tagString);
          }
          const listing = await this.apiRequest(`/shops/${shopId}/listings`, {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
            },
            body: formData.toString()
          });
          const allImages = [...images || []];
          if (designVersion.renderedPngUrl && !allImages.includes(designVersion.renderedPngUrl)) {
            allImages.unshift(designVersion.renderedPngUrl);
          }
          for (let i = 0; i < allImages.length && i < 10; i++) {
            await this.uploadImageFromUrl(listing.listing_id, allImages[i], i + 1);
          }
          if (allImages.length > 0) {
            await this.apiRequest(`/shops/${shopId}/listings/${listing.listing_id}`, {
              method: "PATCH",
              headers: {
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
              },
              body: new URLSearchParams({ state: "active" }).toString()
            });
          }
          return {
            success: true,
            externalListingId: String(listing.listing_id),
            externalUrl: `https://www.etsy.com/listing/${listing.listing_id}`
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EtsyAdapter] createListing error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async updateListing(externalListingId, input) {
        try {
          const { retailPrice, title, description, tags } = input;
          const shopId = this.getShopId();
          const formData = new URLSearchParams();
          formData.append("title", title.substring(0, 140));
          formData.append("description", description);
          formData.append("price", String(retailPrice));
          if (tags && tags.length > 0) {
            formData.append("tags", tags.slice(0, 13).join(","));
          }
          await this.apiRequest(`/shops/${shopId}/listings/${externalListingId}`, {
            method: "PATCH",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
            },
            body: formData.toString()
          });
          return {
            success: true,
            externalListingId,
            externalUrl: `https://www.etsy.com/listing/${externalListingId}`
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EtsyAdapter] updateListing error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async deleteListing(externalListingId) {
        try {
          const shopId = this.getShopId();
          await this.apiRequest(`/shops/${shopId}/listings/${externalListingId}`, {
            method: "DELETE"
          });
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EtsyAdapter] deleteListing error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async syncInventory(externalListingId, inStock) {
        try {
          const shopId = this.getShopId();
          const formData = new URLSearchParams();
          formData.append("quantity", inStock ? "999" : "0");
          formData.append("state", inStock ? "active" : "inactive");
          await this.apiRequest(`/shops/${shopId}/listings/${externalListingId}`, {
            method: "PATCH",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
            },
            body: formData.toString()
          });
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EtsyAdapter] syncInventory error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async getListing(externalListingId) {
        try {
          const listing = await this.apiRequest(`/listings/${externalListingId}`);
          return listing;
        } catch (error) {
          console.error("[EtsyAdapter] getListing error:", error);
          return null;
        }
      }
      async getShopInfo() {
        try {
          const shopId = this.getShopId();
          const shop = await this.apiRequest(`/shops/${shopId}`);
          return shop;
        } catch (error) {
          console.error("[EtsyAdapter] getShopInfo error:", error);
          return null;
        }
      }
      async healthCheck() {
        const startTime = Date.now();
        try {
          const shopId = this.getShopId();
          await this.apiRequest(`/shops/${shopId}`);
          return {
            isHealthy: true,
            responseTimeMs: Date.now() - startTime
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          let errorCode;
          if (errorMessage.includes("401") || errorMessage.includes("403")) {
            errorCode = "AUTH_ERROR";
          } else if (errorMessage.includes("429")) {
            errorCode = "RATE_LIMITED";
          } else if (errorMessage.includes("500") || errorMessage.includes("502") || errorMessage.includes("503")) {
            errorCode = "SERVER_ERROR";
          } else if (errorMessage.includes("not configured")) {
            errorCode = "NOT_CONFIGURED";
          }
          return {
            isHealthy: false,
            responseTimeMs: Date.now() - startTime,
            error: errorMessage,
            errorCode
          };
        }
      }
      parseWebhook(payload) {
        if (!payload || typeof payload !== "object") return null;
        const p = payload;
        const type = p.type;
        if (!type) return null;
        return {
          type,
          data: p,
          timestamp: /* @__PURE__ */ new Date()
        };
      }
    };
  }
});

// server/adapters/marketplaces/ebay.ts
var ebay_exports = {};
__export(ebay_exports, {
  EbayAdapter: () => EbayAdapter
});
var EBAY_API_BASE, INVENTORY_API, EbayAdapter;
var init_ebay = __esm({
  "server/adapters/marketplaces/ebay.ts"() {
    "use strict";
    init_base();
    EBAY_API_BASE = "https://api.ebay.com";
    INVENTORY_API = `${EBAY_API_BASE}/sell/inventory/v1`;
    EbayAdapter = class extends BaseMarketplaceAdapter {
      marketplaceType = "ebay";
      displayName = "eBay";
      listingToOfferCache = /* @__PURE__ */ new Map();
      skuToInventoryCache = /* @__PURE__ */ new Map();
      getAccessToken() {
        const token = process.env.EBAY_ACCESS_TOKEN;
        if (!token) throw new Error("EBAY_ACCESS_TOKEN not configured");
        return token;
      }
      getPaymentPolicyId() {
        const policyId = process.env.EBAY_PAYMENT_POLICY_ID;
        if (!policyId) throw new Error("EBAY_PAYMENT_POLICY_ID not configured");
        return policyId;
      }
      getReturnPolicyId() {
        const policyId = process.env.EBAY_RETURN_POLICY_ID;
        if (!policyId) throw new Error("EBAY_RETURN_POLICY_ID not configured");
        return policyId;
      }
      getFulfillmentPolicyId() {
        const policyId = process.env.EBAY_FULFILLMENT_POLICY_ID;
        if (!policyId) throw new Error("EBAY_FULFILLMENT_POLICY_ID not configured");
        return policyId;
      }
      getMerchantLocationKey() {
        return process.env.EBAY_MERCHANT_LOCATION_KEY;
      }
      getMarketplaceId() {
        return process.env.EBAY_MARKETPLACE_ID || "EBAY_US";
      }
      getCategoryId() {
        return process.env.EBAY_DEFAULT_CATEGORY_ID || "1059";
      }
      async apiRequest(endpoint, options = {}) {
        const url = endpoint.startsWith("http") ? endpoint : `${INVENTORY_API}${endpoint}`;
        const response = await fetch(url, {
          ...options,
          headers: {
            "Authorization": `Bearer ${this.getAccessToken()}`,
            "Content-Type": "application/json",
            "Content-Language": "en-US",
            "Accept": "application/json",
            ...options.headers
          }
        });
        if (!response.ok) {
          const errorText = await response.text();
          let errorMessage;
          try {
            const errorJson = JSON.parse(errorText);
            if (errorJson.errors && errorJson.errors.length > 0) {
              errorMessage = errorJson.errors.map((e) => e.message).join("; ");
            } else {
              errorMessage = errorText;
            }
          } catch {
            errorMessage = errorText;
          }
          throw new Error(`eBay API error: ${response.status} - ${errorMessage}`);
        }
        if (response.status === 204) {
          return {};
        }
        const text2 = await response.text();
        if (!text2) {
          return {};
        }
        return JSON.parse(text2);
      }
      generateSku(masterProductId) {
        return `QRGEAR-${masterProductId.substring(0, 8).toUpperCase()}`;
      }
      async createOrReplaceInventoryItem(sku, input) {
        const { masterProduct, designVersion, title, description, images } = input;
        const allImages = [];
        if (designVersion.renderedPngUrl) {
          allImages.push(designVersion.renderedPngUrl);
        }
        if (images) {
          allImages.push(...images.filter((img) => !allImages.includes(img)));
        }
        const inventoryItem = {
          sku,
          product: {
            title: title.substring(0, 80),
            description: description.substring(0, 4e3),
            aspects: {
              "Brand": ["QR Gear"],
              "Type": ["Apparel"]
            },
            imageUrls: allImages.slice(0, 12)
          },
          condition: "NEW",
          availability: {
            shipToLocationAvailability: {
              quantity: 999
            }
          }
        };
        await this.apiRequest(`/inventory_item/${encodeURIComponent(sku)}`, {
          method: "PUT",
          body: JSON.stringify(inventoryItem)
        });
        this.skuToInventoryCache.set(sku, inventoryItem);
        return inventoryItem;
      }
      async createOffer(sku, input) {
        const { retailPrice, description } = input;
        const offerData = {
          sku,
          marketplaceId: this.getMarketplaceId(),
          format: "FIXED_PRICE",
          listingDescription: description.substring(0, 4e3),
          categoryId: this.getCategoryId(),
          listingPolicies: {
            paymentPolicyId: this.getPaymentPolicyId(),
            returnPolicyId: this.getReturnPolicyId(),
            fulfillmentPolicyId: this.getFulfillmentPolicyId()
          },
          pricingSummary: {
            price: {
              value: retailPrice.toFixed(2),
              currency: "USD"
            }
          },
          quantityLimitPerBuyer: 10,
          ...this.getMerchantLocationKey() && { merchantLocationKey: this.getMerchantLocationKey() }
        };
        const response = await this.apiRequest("/offer", {
          method: "POST",
          body: JSON.stringify(offerData)
        });
        return response.offerId;
      }
      async publishOffer(offerId) {
        const response = await this.apiRequest(`/offer/${offerId}/publish`, {
          method: "POST",
          body: JSON.stringify({})
        });
        return response.listingId;
      }
      async getOfferByListingId(listingId) {
        const cached = this.listingToOfferCache.get(listingId);
        if (cached) {
          return cached;
        }
        try {
          let offset = 0;
          const limit = 100;
          while (true) {
            const response = await this.apiRequest(
              `/offer?marketplace_id=${this.getMarketplaceId()}&limit=${limit}&offset=${offset}`
            );
            if (!response.offers || response.offers.length === 0) {
              break;
            }
            for (const offer of response.offers) {
              if (offer.listing?.listingId) {
                this.listingToOfferCache.set(offer.listing.listingId, {
                  offerId: offer.offerId,
                  sku: offer.sku
                });
              }
              if (offer.listing?.listingId === listingId) {
                return { offerId: offer.offerId, sku: offer.sku };
              }
            }
            if (response.offers.length < limit) {
              break;
            }
            offset += limit;
            if (offset > 1e4) {
              console.warn("[EbayAdapter] getOfferByListingId: exceeded max offset, stopping scan");
              break;
            }
          }
          return null;
        } catch (error) {
          console.error("[EbayAdapter] getOfferByListingId error:", error);
          return null;
        }
      }
      async getOfferBySku(sku) {
        try {
          const response = await this.apiRequest(`/offer?sku=${encodeURIComponent(sku)}`);
          if (response.offers && response.offers.length > 0) {
            return response.offers[0];
          }
          return null;
        } catch (error) {
          console.error("[EbayAdapter] getOfferBySku error:", error);
          return null;
        }
      }
      async getInventoryItem(sku) {
        try {
          const item = await this.apiRequest(`/inventory_item/${encodeURIComponent(sku)}`);
          this.skuToInventoryCache.set(sku, item);
          return item;
        } catch (error) {
          console.error("[EbayAdapter] getInventoryItem error:", error);
          return null;
        }
      }
      async createListing(input) {
        try {
          const sku = this.generateSku(input.masterProduct.id);
          await this.createOrReplaceInventoryItem(sku, input);
          const offerId = await this.createOffer(sku, input);
          const listingId = await this.publishOffer(offerId);
          this.listingToOfferCache.set(listingId, { offerId, sku });
          return {
            success: true,
            externalListingId: listingId,
            externalUrl: `https://www.ebay.com/itm/${listingId}`
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EbayAdapter] createListing error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async updateListing(externalListingId, input) {
        try {
          const offerInfo = await this.getOfferByListingId(externalListingId);
          if (!offerInfo) {
            return {
              success: false,
              error: `Offer not found for listing ${externalListingId}. eBay API requires paginated scan to resolve listing\u2192offer mapping.`
            };
          }
          await this.createOrReplaceInventoryItem(offerInfo.sku, input);
          const { retailPrice, description } = input;
          const updateData = {
            sku: offerInfo.sku,
            marketplaceId: this.getMarketplaceId(),
            format: "FIXED_PRICE",
            listingDescription: description.substring(0, 4e3),
            categoryId: this.getCategoryId(),
            listingPolicies: {
              paymentPolicyId: this.getPaymentPolicyId(),
              returnPolicyId: this.getReturnPolicyId(),
              fulfillmentPolicyId: this.getFulfillmentPolicyId()
            },
            pricingSummary: {
              price: {
                value: retailPrice.toFixed(2),
                currency: "USD"
              }
            },
            quantityLimitPerBuyer: 10,
            ...this.getMerchantLocationKey() && { merchantLocationKey: this.getMerchantLocationKey() }
          };
          await this.apiRequest(`/offer/${offerInfo.offerId}`, {
            method: "PUT",
            body: JSON.stringify(updateData)
          });
          return {
            success: true,
            externalListingId,
            externalUrl: `https://www.ebay.com/itm/${externalListingId}`
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EbayAdapter] updateListing error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async deleteListing(externalListingId) {
        try {
          const offerInfo = await this.getOfferByListingId(externalListingId);
          if (!offerInfo) {
            this.listingToOfferCache.delete(externalListingId);
            return { success: true };
          }
          try {
            await this.apiRequest(`/offer/${offerInfo.offerId}/withdraw`, {
              method: "POST",
              body: JSON.stringify({})
            });
          } catch (withdrawError) {
            console.warn("[EbayAdapter] Withdraw failed, attempting delete:", withdrawError);
          }
          try {
            await this.apiRequest(`/offer/${offerInfo.offerId}`, {
              method: "DELETE"
            });
          } catch (deleteOfferError) {
            console.warn("[EbayAdapter] Delete offer failed:", deleteOfferError);
          }
          try {
            await this.apiRequest(`/inventory_item/${encodeURIComponent(offerInfo.sku)}`, {
              method: "DELETE"
            });
          } catch (deleteItemError) {
            console.warn("[EbayAdapter] Delete inventory item failed:", deleteItemError);
          }
          this.listingToOfferCache.delete(externalListingId);
          this.skuToInventoryCache.delete(offerInfo.sku);
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EbayAdapter] deleteListing error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async syncInventory(externalListingId, inStock) {
        try {
          const offerInfo = await this.getOfferByListingId(externalListingId);
          if (!offerInfo) {
            return { success: false, error: `Offer not found for listing ${externalListingId}. eBay API requires paginated scan to resolve listing\u2192offer mapping.` };
          }
          let existingItem = this.skuToInventoryCache.get(offerInfo.sku);
          if (!existingItem) {
            existingItem = await this.getInventoryItem(offerInfo.sku);
          }
          if (!existingItem) {
            return { success: false, error: `Inventory item not found for SKU ${offerInfo.sku}` };
          }
          const updatedItem = {
            ...existingItem,
            availability: {
              shipToLocationAvailability: {
                quantity: inStock ? 999 : 0
              }
            }
          };
          await this.apiRequest(`/inventory_item/${encodeURIComponent(offerInfo.sku)}`, {
            method: "PUT",
            body: JSON.stringify(updatedItem)
          });
          this.skuToInventoryCache.set(offerInfo.sku, updatedItem);
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[EbayAdapter] syncInventory error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async healthCheck() {
        const startTime = Date.now();
        try {
          await this.apiRequest("/location?limit=1");
          return {
            isHealthy: true,
            responseTimeMs: Date.now() - startTime
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          let errorCode;
          if (errorMessage.includes("401") || errorMessage.includes("403")) {
            errorCode = "AUTH_ERROR";
          } else if (errorMessage.includes("429")) {
            errorCode = "RATE_LIMITED";
          } else if (errorMessage.includes("500") || errorMessage.includes("502") || errorMessage.includes("503")) {
            errorCode = "SERVER_ERROR";
          } else if (errorMessage.includes("not configured")) {
            errorCode = "NOT_CONFIGURED";
          }
          return {
            isHealthy: false,
            responseTimeMs: Date.now() - startTime,
            error: errorMessage,
            errorCode
          };
        }
      }
      parseWebhook(payload) {
        if (!payload || typeof payload !== "object") return null;
        const p = payload;
        const metadata = p.metadata;
        const notification = p.notification;
        if (!metadata || !notification) return null;
        const topic = metadata.topic;
        if (!topic) return null;
        let type;
        switch (topic) {
          case "MARKETPLACE.ITEM.LISTED":
            type = "item.listed";
            break;
          case "MARKETPLACE.ITEM.ENDED":
            type = "item.ended";
            break;
          case "MARKETPLACE.ITEM.SOLD":
            type = "item.sold";
            break;
          case "MARKETPLACE.ORDER.CREATED":
            type = "order.created";
            break;
          case "MARKETPLACE.ORDER.SHIPPED":
            type = "order.shipped";
            break;
          default:
            type = topic;
        }
        return {
          type,
          data: notification.data || notification,
          timestamp: new Date(metadata.eventDate || Date.now())
        };
      }
      async getOffer(offerId) {
        try {
          const offer = await this.apiRequest(`/offer/${offerId}`);
          return offer;
        } catch (error) {
          console.error("[EbayAdapter] getOffer error:", error);
          return null;
        }
      }
    };
  }
});

// server/adapters/marketplaces/amazon.ts
var amazon_exports = {};
__export(amazon_exports, {
  AmazonAdapter: () => AmazonAdapter
});
import crypto3 from "crypto";
var AMAZON_ENDPOINTS, MARKETPLACE_IDS, AmazonAdapter;
var init_amazon = __esm({
  "server/adapters/marketplaces/amazon.ts"() {
    "use strict";
    init_base();
    AMAZON_ENDPOINTS = {
      na: "https://sellingpartnerapi-na.amazon.com",
      eu: "https://sellingpartnerapi-eu.amazon.com",
      fe: "https://sellingpartnerapi-fe.amazon.com"
    };
    MARKETPLACE_IDS = {
      US: "ATVPDKIKX0DER",
      CA: "A2EUQ1WTGCTBG2",
      MX: "A1AM78C64UM0Y8",
      UK: "A1F83G8C2ARO7P",
      DE: "A1PA6795UKMFR9",
      FR: "A13V1IB3VIYBER",
      IT: "APJ6JRA9NG5V4",
      ES: "A1RKKUPIHCS9HS",
      JP: "A1VC38T7YXB528",
      AU: "A39IBJ37TRP1C6"
    };
    AmazonAdapter = class extends BaseMarketplaceAdapter {
      marketplaceType = "amazon";
      displayName = "Amazon";
      accessToken = null;
      tokenExpiry = 0;
      skuToAsinCache = /* @__PURE__ */ new Map();
      getConfig() {
        return {
          clientId: process.env.AMAZON_SP_CLIENT_ID || "",
          clientSecret: process.env.AMAZON_SP_CLIENT_SECRET || "",
          refreshToken: process.env.AMAZON_SP_REFRESH_TOKEN || "",
          sellerId: process.env.AMAZON_SELLER_ID || "",
          marketplaceId: process.env.AMAZON_MARKETPLACE_ID || MARKETPLACE_IDS.US,
          awsAccessKeyId: process.env.AMAZON_AWS_ACCESS_KEY_ID || "",
          awsSecretKey: process.env.AMAZON_AWS_SECRET_KEY || "",
          region: process.env.AMAZON_REGION || "us-east-1"
        };
      }
      getEndpoint() {
        const config = this.getConfig();
        if (config.region.startsWith("eu")) return AMAZON_ENDPOINTS.eu;
        if (config.region.startsWith("ap") || config.region === "fe-south-1") return AMAZON_ENDPOINTS.fe;
        return AMAZON_ENDPOINTS.na;
      }
      async refreshAccessToken() {
        const config = this.getConfig();
        if (this.accessToken && Date.now() < this.tokenExpiry) {
          return this.accessToken;
        }
        const response = await fetch("https://api.amazon.com/auth/o2/token", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded"
          },
          body: new URLSearchParams({
            grant_type: "refresh_token",
            refresh_token: config.refreshToken,
            client_id: config.clientId,
            client_secret: config.clientSecret
          })
        });
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Amazon OAuth token refresh failed: ${errorText}`);
        }
        const tokenData = await response.json();
        this.accessToken = tokenData.access_token;
        this.tokenExpiry = Date.now() + (tokenData.expires_in - 60) * 1e3;
        return this.accessToken;
      }
      getAmzDate() {
        return (/* @__PURE__ */ new Date()).toISOString().replace(/[:-]|\.\d{3}/g, "");
      }
      getDateStamp() {
        return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replace(/-/g, "");
      }
      hmacSha256(key, data) {
        return crypto3.createHmac("sha256", key).update(data).digest();
      }
      sha256(data) {
        return crypto3.createHash("sha256").update(data).digest("hex");
      }
      getSignatureKey(key, dateStamp, region, service) {
        const kDate = this.hmacSha256("AWS4" + key, dateStamp);
        const kRegion = this.hmacSha256(kDate, region);
        const kService = this.hmacSha256(kRegion, service);
        return this.hmacSha256(kService, "aws4_request");
      }
      async signRequest(method, path5, host, queryParams = {}, body = "") {
        const config = this.getConfig();
        const accessToken = await this.refreshAccessToken();
        const amzDate = this.getAmzDate();
        const dateStamp = this.getDateStamp();
        const service = "execute-api";
        const queryString = Object.keys(queryParams).sort().map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(queryParams[k])}`).join("&");
        const payloadHash = this.sha256(body);
        const canonicalHeaders = `host:${host}
x-amz-access-token:${accessToken}
x-amz-content-sha256:${payloadHash}
x-amz-date:${amzDate}
`;
        const signedHeaders = "host;x-amz-access-token;x-amz-content-sha256;x-amz-date";
        const canonicalRequest = method + "\n" + path5 + "\n" + queryString + "\n" + canonicalHeaders + "\n" + signedHeaders + "\n" + payloadHash;
        const algorithm = "AWS4-HMAC-SHA256";
        const credentialScope = `${dateStamp}/${config.region}/${service}/aws4_request`;
        const stringToSign = algorithm + "\n" + amzDate + "\n" + credentialScope + "\n" + this.sha256(canonicalRequest);
        const signingKey = this.getSignatureKey(config.awsSecretKey, dateStamp, config.region, service);
        const signature = this.hmacSha256(signingKey, stringToSign).toString("hex");
        const authorizationHeader = `${algorithm} Credential=${config.awsAccessKeyId}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
        return {
          "x-amz-access-token": accessToken,
          "x-amz-content-sha256": payloadHash,
          "x-amz-date": amzDate,
          "Authorization": authorizationHeader,
          "Content-Type": "application/json"
        };
      }
      async apiRequest(method, path5, queryParams = {}, body) {
        const endpoint = this.getEndpoint();
        const endpointUrl = new URL(endpoint);
        const host = endpointUrl.host;
        const bodyStr = body ? JSON.stringify(body) : "";
        const headers = await this.signRequest(method, path5, host, queryParams, bodyStr);
        const queryString = Object.keys(queryParams).sort().map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(queryParams[k])}`).join("&");
        const url = `${endpoint}${path5}${queryString ? "?" + queryString : ""}`;
        const response = await fetch(url, {
          method,
          headers,
          body: body ? bodyStr : void 0
        });
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Amazon SP-API error ${response.status}: ${errorText}`);
        }
        const text2 = await response.text();
        if (!text2) return {};
        return JSON.parse(text2);
      }
      generateSku(masterProductId) {
        return `QG-${masterProductId.substring(0, 12).toUpperCase()}`;
      }
      async createListing(input) {
        try {
          const config = this.getConfig();
          if (!config.clientId || !config.refreshToken) {
            return {
              success: false,
              error: "Amazon SP-API credentials not configured. Required: AMAZON_SP_CLIENT_ID, AMAZON_SP_CLIENT_SECRET, AMAZON_SP_REFRESH_TOKEN, AMAZON_SELLER_ID, AMAZON_AWS_ACCESS_KEY_ID, AMAZON_AWS_SECRET_KEY"
            };
          }
          const { masterProduct, designVersion, title, description, images, retailPrice, variants } = input;
          const sku = this.generateSku(masterProduct.id);
          const listingData = {
            productType: "SHIRT",
            requirements: "LISTING",
            attributes: {
              condition_type: [{ value: "new_new" }],
              item_name: [{ value: title.substring(0, 500), language_tag: "en_US" }],
              product_description: [{ value: description.substring(0, 2e3), language_tag: "en_US" }],
              brand: [{ value: "QR Gear", language_tag: "en_US" }],
              bullet_point: [
                { value: "Premium quality print-on-demand apparel", language_tag: "en_US" },
                { value: "Featuring custom QR code design", language_tag: "en_US" },
                { value: "Made in USA", language_tag: "en_US" }
              ],
              main_product_image_locator: images.length > 0 ? [{ media_location: images[0] }] : void 0,
              other_product_image_locator_1: images.length > 1 ? [{ media_location: images[1] }] : void 0,
              other_product_image_locator_2: images.length > 2 ? [{ media_location: images[2] }] : void 0,
              purchasable_offer: [{
                currency: "USD",
                our_price: [{
                  schedule: [{
                    value_with_tax: retailPrice
                  }]
                }]
              }],
              fulfillment_availability: [{
                fulfillment_channel_code: "DEFAULT",
                quantity: 999
              }]
            }
          };
          const response = await this.apiRequest(
            "PUT",
            `/listings/2021-08-01/items/${config.sellerId}/${encodeURIComponent(sku)}`,
            { marketplaceIds: config.marketplaceId },
            listingData
          );
          if (response.issues && response.issues.some((i) => i.severity === "ERROR")) {
            const errors = response.issues.filter((i) => i.severity === "ERROR").map((i) => i.message).join("; ");
            return {
              success: false,
              error: `Amazon listing rejected: ${errors}`
            };
          }
          this.skuToAsinCache.set(sku, response.submissionId || sku);
          return {
            success: true,
            externalListingId: sku,
            externalUrl: `https://sellercentral.amazon.com/skucentral?mSku=${encodeURIComponent(sku)}`
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[AmazonAdapter] createListing error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async updateListing(externalListingId, input) {
        try {
          const config = this.getConfig();
          const { title, description, images, retailPrice } = input;
          const patchData = {
            productType: "SHIRT",
            patches: [
              {
                op: "replace",
                path: "/attributes/item_name",
                value: [{ value: title.substring(0, 500), language_tag: "en_US" }]
              },
              {
                op: "replace",
                path: "/attributes/product_description",
                value: [{ value: description.substring(0, 2e3), language_tag: "en_US" }]
              },
              {
                op: "replace",
                path: "/attributes/purchasable_offer",
                value: [{
                  currency: "USD",
                  our_price: [{
                    schedule: [{
                      value_with_tax: retailPrice
                    }]
                  }]
                }]
              }
            ]
          };
          if (images.length > 0) {
            patchData.patches.push({
              op: "replace",
              path: "/attributes/main_product_image_locator",
              value: [{ media_location: images[0] }]
            });
          }
          await this.apiRequest(
            "PATCH",
            `/listings/2021-08-01/items/${config.sellerId}/${encodeURIComponent(externalListingId)}`,
            { marketplaceIds: config.marketplaceId },
            patchData
          );
          return {
            success: true,
            externalListingId,
            externalUrl: `https://sellercentral.amazon.com/skucentral?mSku=${encodeURIComponent(externalListingId)}`
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[AmazonAdapter] updateListing error:", errorMessage);
          return {
            success: false,
            error: errorMessage
          };
        }
      }
      async deleteListing(externalListingId) {
        try {
          const config = this.getConfig();
          await this.apiRequest(
            "DELETE",
            `/listings/2021-08-01/items/${config.sellerId}/${encodeURIComponent(externalListingId)}`,
            { marketplaceIds: config.marketplaceId }
          );
          this.skuToAsinCache.delete(externalListingId);
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[AmazonAdapter] deleteListing error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async syncInventory(externalListingId, inStock) {
        try {
          const config = this.getConfig();
          const patchData = {
            productType: "SHIRT",
            patches: [
              {
                op: "replace",
                path: "/attributes/fulfillment_availability",
                value: [{
                  fulfillment_channel_code: "DEFAULT",
                  quantity: inStock ? 999 : 0
                }]
              }
            ]
          };
          await this.apiRequest(
            "PATCH",
            `/listings/2021-08-01/items/${config.sellerId}/${encodeURIComponent(externalListingId)}`,
            { marketplaceIds: config.marketplaceId },
            patchData
          );
          return { success: true };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          console.error("[AmazonAdapter] syncInventory error:", errorMessage);
          return { success: false, error: errorMessage };
        }
      }
      async healthCheck() {
        const startTime = Date.now();
        try {
          const config = this.getConfig();
          if (!config.clientId || !config.refreshToken) {
            return {
              isHealthy: false,
              responseTimeMs: Date.now() - startTime,
              error: "Amazon SP-API credentials not configured"
            };
          }
          await this.refreshAccessToken();
          await this.apiRequest(
            "GET",
            "/sellers/v1/marketplaceParticipations",
            {}
          );
          return {
            isHealthy: true,
            responseTimeMs: Date.now() - startTime
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Unknown error";
          return {
            isHealthy: false,
            responseTimeMs: Date.now() - startTime,
            error: errorMessage
          };
        }
      }
      parseWebhook(payload) {
        try {
          const rawData = payload;
          if (!rawData.NotificationType || !rawData.Payload) {
            return null;
          }
          const notificationType = rawData.NotificationType;
          if (notificationType === "ORDER_CHANGE") {
            const orderStatus = rawData.Payload.OrderStatus;
            let eventType = "order:created";
            switch (orderStatus) {
              case "Shipped":
                eventType = "order:shipped";
                break;
              case "Canceled":
              case "Cancelled":
                eventType = "order:cancelled";
                break;
              case "Delivered":
                eventType = "order:delivered";
                break;
              case "Pending":
              case "Unshipped":
                eventType = "order:created";
                break;
            }
            return {
              type: eventType,
              data: {
                orderId: rawData.Payload.AmazonOrderId || "",
                externalOrderId: rawData.Payload.AmazonOrderId || "",
                rawPayload: rawData
              },
              timestamp: /* @__PURE__ */ new Date()
            };
          }
          if (notificationType === "LISTINGS_ITEM_STATUS_CHANGE") {
            return {
              type: "product:updated",
              data: {
                sku: rawData.Payload.SellerSKU || "",
                rawPayload: rawData
              },
              timestamp: /* @__PURE__ */ new Date()
            };
          }
          return null;
        } catch {
          console.error("[AmazonAdapter] parseWebhook error");
          return null;
        }
      }
    };
  }
});

// server/services/bulk-publisher.ts
var bulk_publisher_exports = {};
__export(bulk_publisher_exports, {
  BulkPublisher: () => BulkPublisher,
  bulkPublisher: () => bulkPublisher
});
var activeJobs, BulkPublisher, bulkPublisher;
var init_bulk_publisher = __esm({
  "server/services/bulk-publisher.ts"() {
    "use strict";
    init_storage();
    activeJobs = /* @__PURE__ */ new Map();
    BulkPublisher = class {
      concurrencyLimit = 3;
      async createJob(request) {
        const jobId = `bulk_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const job = {
          jobId,
          status: "pending",
          totalItems: request.productIds.length * request.channelTypes.length,
          completedItems: 0,
          successCount: 0,
          failureCount: 0,
          results: [],
          startedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        activeJobs.set(jobId, job);
        this.executeJob(jobId, request).catch((err) => {
          console.error(`[BulkPublisher] Job ${jobId} failed:`, err);
          const job2 = activeJobs.get(jobId);
          if (job2) {
            job2.status = "failed";
            job2.completedAt = (/* @__PURE__ */ new Date()).toISOString();
          }
        });
        return jobId;
      }
      getJob(jobId) {
        return activeJobs.get(jobId);
      }
      getAllJobs() {
        return Array.from(activeJobs.values()).sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()).slice(0, 50);
      }
      async executeJob(jobId, request) {
        const job = activeJobs.get(jobId);
        if (!job) return;
        job.status = "running";
        const startTime = Date.now();
        const products2 = await Promise.all(
          request.productIds.map((id) => storage.getMasterProduct(id))
        );
        const validProducts = products2.filter((p) => p !== void 0);
        const configs = await Promise.all(
          request.channelTypes.map((type) => storage.getChannelConfig(type))
        );
        const validConfigs = configs.filter((c) => c !== void 0 && c.isEnabled === true);
        const tasks = [];
        for (const product of validProducts) {
          for (const config of validConfigs) {
            tasks.push({ product, config });
          }
        }
        job.totalItems = tasks.length;
        for (let i = 0; i < tasks.length; i += this.concurrencyLimit) {
          const batch = tasks.slice(i, i + this.concurrencyLimit);
          const batchResults = await Promise.all(
            batch.map(({ product, config }) => this.publishSingle(product, config))
          );
          for (const result of batchResults) {
            job.results.push(result);
            job.completedItems++;
            if (result.success) {
              job.successCount++;
            } else {
              job.failureCount++;
            }
          }
        }
        job.status = "completed";
        job.completedAt = (/* @__PURE__ */ new Date()).toISOString();
        job.durationMs = Date.now() - startTime;
      }
      async publishSingle(product, config, maxRetries = 2) {
        const startTime = Date.now();
        let lastError = "";
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
          try {
            const existingState = await storage.getPublishState(product.id, config.channelType);
            if (existingState?.status === "published" && existingState.externalListingId) {
              return {
                productId: product.id,
                productTitle: product.title,
                channelType: config.channelType,
                success: true,
                listingId: existingState.externalListingId,
                durationMs: Date.now() - startTime
              };
            }
            const adapterModule = await this.getAdapter(config.channelType);
            if (!adapterModule) {
              throw new Error(`No adapter available for channel: ${config.channelType}`);
            }
            const adapter = new adapterModule.default();
            await storage.upsertPublishState({
              masterProductId: product.id,
              channelType: config.channelType,
              status: "pending",
              lastSyncedAt: /* @__PURE__ */ new Date()
            });
            const listingData = this.buildListingData(product, config);
            const result = await adapter.createListing(listingData);
            await storage.upsertPublishState({
              masterProductId: product.id,
              channelType: config.channelType,
              status: "published",
              externalListingId: result.listingId,
              lastSyncedAt: /* @__PURE__ */ new Date(),
              lastPublishedAt: /* @__PURE__ */ new Date()
            });
            return {
              productId: product.id,
              productTitle: product.title,
              channelType: config.channelType,
              success: true,
              listingId: result.listingId,
              durationMs: Date.now() - startTime
            };
          } catch (error) {
            lastError = error.message;
            console.log(`[BulkPublisher] Attempt ${attempt + 1}/${maxRetries + 1} failed for ${product.sku} -> ${config.channelType}: ${lastError}`);
            if (attempt < maxRetries) {
              await new Promise((resolve) => setTimeout(resolve, 1e3 * (attempt + 1)));
              continue;
            }
            await storage.upsertPublishState({
              masterProductId: product.id,
              channelType: config.channelType,
              status: "failed",
              lastError,
              lastSyncedAt: /* @__PURE__ */ new Date()
            });
          }
        }
        return {
          productId: product.id,
          productTitle: product.title,
          channelType: config.channelType,
          success: false,
          error: lastError,
          durationMs: Date.now() - startTime
        };
      }
      async getAdapter(channelType) {
        try {
          switch (channelType) {
            case "printify":
              return await Promise.resolve().then(() => (init_printify2(), printify_exports2));
            case "printful":
              return await Promise.resolve().then(() => (init_printful2(), printful_exports2));
            case "apliiq":
              return await Promise.resolve().then(() => (init_apliiq(), apliiq_exports));
            case "etsy":
              return await Promise.resolve().then(() => (init_etsy(), etsy_exports));
            case "ebay":
              return await Promise.resolve().then(() => (init_ebay(), ebay_exports));
            case "amazon":
              return await Promise.resolve().then(() => (init_amazon(), amazon_exports));
            default:
              return null;
          }
        } catch (err) {
          console.error(`[BulkPublisher] Failed to load adapter for ${channelType}:`, err);
          return null;
        }
      }
      buildListingData(product, config) {
        const settings = config.settings || {};
        const priceMultiplier = settings.priceMultiplier || 1;
        const basePrice = product.retailPrice ? parseFloat(product.retailPrice) : 0;
        const channelPrice = basePrice * priceMultiplier;
        return {
          title: product.title,
          description: product.description || "",
          price: channelPrice,
          sku: product.sku,
          images: [],
          tags: product.tags || [],
          variants: [],
          productType: product.productType
        };
      }
    };
    bulkPublisher = new BulkPublisher();
  }
});

// server/index.ts
import express2 from "express";
import rateLimit from "express-rate-limit";
import path4 from "path";
import { fileURLToPath } from "url";

// server/routes.ts
init_storage();
init_db();
init_qr_generator();
init_schema();
import { createServer } from "http";
import { eq as eq6, and as and6, or as or3, isNull, lte as lte2, gte as gte2 } from "drizzle-orm";

// server/lib/widget-auth.ts
import jwt from "jsonwebtoken";
import { z } from "zod";
var JWT_SECRET = process.env.WIDGET_JWT_SECRET || "dev-secret-change-in-production";
var JWT_EXPIRY = "1h";
var widgetTokenSchema = z.object({
  // Entity identification
  businessId: z.string().optional(),
  businessName: z.string().optional(),
  businessSlug: z.string().optional(),
  businessLogoUrl: z.string().url().optional().nullable(),
  churchId: z.string().optional(),
  churchName: z.string().optional(),
  churchSlug: z.string().optional(),
  memberId: z.string().optional(),
  memberEmail: z.string().email().optional(),
  // URLs and contact
  kcListingUrl: z.string().url().optional(),
  ownerEmail: z.string().email().optional(),
  // Partner and placement
  partnerId: z.string().optional(),
  placement: z.enum(["homepage", "church", "business", "member", "dashboard", "listing"]).optional(),
  allowedSegments: z.array(z.string()).optional()
});
function signWidgetToken(payload) {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRY
  });
}
function verifyWidgetToken(token) {
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const validated = widgetTokenSchema.parse(decoded);
    return {
      ...validated,
      iat: decoded.iat,
      exp: decoded.exp
    };
  } catch (error) {
    console.error("Widget token verification failed:", error);
    return null;
  }
}

// server/routes.ts
init_printify();

// server/lib/printify-cost-sync.ts
init_storage();
init_printify();
var activeSyncId = null;
var isSyncRunning = false;
function isCostSyncRunning() {
  return isSyncRunning;
}
async function startCostSync(options = {}) {
  const {
    forceRefresh = false,
    batchSize = 50,
    delayBetweenRequests = 3e3
  } = options;
  if (isSyncRunning) {
    console.log("[Cost Sync] Sync already in progress, skipping...");
    return null;
  }
  if (!printify.isConfigured) {
    console.error("[Cost Sync] Printify API not configured");
    return null;
  }
  const allProviders = await storage.getAllPrintifyProviders();
  if (allProviders.length === 0) {
    console.log("[Cost Sync] No providers cached. Run catalog sync first.");
    return null;
  }
  let providers = allProviders;
  let previousSync = await storage.getLatestCostSync();
  let startingCounts = { processedCount: 0, successCount: 0, failedCount: 0, skippedCount: 0 };
  if (previousSync?.status === "paused" && previousSync.lastProcessedProviderId) {
    const lastIdx = allProviders.findIndex((p) => p.id === previousSync.lastProcessedProviderId);
    if (lastIdx >= 0 && lastIdx < allProviders.length - 1) {
      providers = allProviders.slice(lastIdx + 1);
      startingCounts = {
        processedCount: previousSync.processedCount ?? 0,
        successCount: previousSync.successCount ?? 0,
        failedCount: previousSync.failedCount ?? 0,
        skippedCount: previousSync.skippedCount ?? 0
      };
      console.log(`[Cost Sync] Resuming from provider ${lastIdx + 1}/${allProviders.length}`);
    }
  }
  const costSync = await storage.createCostSync({
    status: "running",
    totalProviders: allProviders.length,
    processedCount: startingCounts.processedCount,
    successCount: startingCounts.successCount,
    failedCount: startingCounts.failedCount,
    skippedCount: startingCounts.skippedCount
  });
  activeSyncId = costSync.id;
  isSyncRunning = true;
  runCostSyncBackground(costSync.id, providers, { forceRefresh, delayBetweenRequests, startingCounts });
  return costSync;
}
async function runCostSyncBackground(syncId, providers, options) {
  const { forceRefresh, delayBetweenRequests, startingCounts } = options;
  console.log(`[Cost Sync] Starting background sync for ${providers.length} providers...`);
  let processedCount = startingCounts?.processedCount ?? 0;
  let successCount = startingCounts?.successCount ?? 0;
  let failedCount = startingCounts?.failedCount ?? 0;
  let skippedCount = startingCounts?.skippedCount ?? 0;
  let lastCompletedProviderId = null;
  let imageId = null;
  try {
    imageId = await printify.getOrCreatePlaceholderImage();
    console.log(`[Cost Sync] Using placeholder image: ${imageId}`);
  } catch (err) {
    console.error(`[Cost Sync] Failed to upload placeholder image:`, err.message);
    await storage.updateCostSync(syncId, {
      status: "failed",
      errorMessage: `Failed to upload placeholder image: ${err.message}`,
      completedAt: /* @__PURE__ */ new Date()
    });
    isSyncRunning = false;
    activeSyncId = null;
    return;
  }
  for (const provider of providers) {
    if (!isSyncRunning) {
      console.log("[Cost Sync] Sync was cancelled");
      await storage.updateCostSync(syncId, {
        status: "paused",
        processedCount,
        successCount,
        failedCount,
        skippedCount,
        lastProcessedProviderId: lastCompletedProviderId
      });
      activeSyncId = null;
      return;
    }
    const hasCost = provider.minCost && provider.minCost > 0;
    const hasColors = provider.availableColors && Array.isArray(provider.availableColors) && provider.availableColors.length > 0;
    const hasSizes = provider.availableSizes && Array.isArray(provider.availableSizes) && provider.availableSizes.length > 0;
    if (!forceRefresh && hasCost && hasColors && hasSizes) {
      console.log(`[Cost Sync] Skipping ${provider.blueprintId}/${provider.providerId} - already has cost $${(provider.minCost / 100).toFixed(2)} and ${provider.availableColors.length} colors`);
      skippedCount++;
      processedCount++;
      lastCompletedProviderId = provider.id;
      continue;
    }
    if (!hasColors || !hasSizes) {
      console.log(`[Cost Sync] Refreshing ${provider.blueprintId}/${provider.providerId} - missing colors/sizes`);
    }
    let tempProductId = null;
    try {
      const { placement, variantIds } = await printify.getCommonPlacement(provider.blueprintId, provider.providerId);
      const placeholderProduct = await printify.createPlaceholderProduct(
        provider.blueprintId,
        provider.providerId,
        variantIds,
        imageId,
        placement
      );
      tempProductId = placeholderProduct.id;
      const costs = printify.extractCostsFromProduct(placeholderProduct);
      const catalogData = await syncProductVariants(provider.blueprintId, provider.providerId);
      const colorsWithHex = catalogData.colors;
      const sizes = catalogData.sizes;
      await storage.updatePrintifyProviderCosts(provider.blueprintId, provider.providerId, {
        minCost: costs.minCost,
        maxCost: costs.maxCost,
        placeholderProductId: placeholderProduct.id,
        availableColors: colorsWithHex,
        availableSizes: sizes
      });
      const productionCostDollars = costs.minCost / 100;
      const settings = await storage.getAdminSettings();
      const markupPercent = settings?.globalMarkupPercent ? parseFloat(settings.globalMarkupPercent) : 25;
      const markupFixed = settings?.globalMarkupFixed ? parseFloat(settings.globalMarkupFixed) : 0;
      const qrCost = settings?.globalQrProductionCost ? parseFloat(settings.globalQrProductionCost) : 2;
      const totalCost = productionCostDollars + qrCost + markupFixed;
      const retailPrice = Math.ceil(totalCost * (1 + markupPercent / 100) * 100) / 100;
      const updatedCount = await storage.updateProductPricesByProvider(
        provider.blueprintId,
        provider.providerId,
        retailPrice.toFixed(2)
      );
      if (updatedCount > 0) {
        console.log(`[Cost Sync] Updated ${updatedCount} product(s) with price $${retailPrice.toFixed(2)}`);
      }
      console.log(`[Cost Sync] ${provider.blueprintId}/${provider.providerId}: $${(costs.minCost / 100).toFixed(2)} - $${(costs.maxCost / 100).toFixed(2)}, ${colorsWithHex.length} colors, ${sizes.length} sizes`);
      successCount++;
    } catch (err) {
      console.error(`[Cost Sync] Failed for ${provider.blueprintId}/${provider.providerId}:`, err.message);
      failedCount++;
    } finally {
      if (tempProductId) {
        try {
          await printify.deleteProduct(tempProductId);
        } catch {
        }
      }
    }
    processedCount++;
    lastCompletedProviderId = provider.id;
    if (processedCount % 10 === 0) {
      await storage.updateCostSync(syncId, {
        processedCount,
        successCount,
        failedCount,
        skippedCount,
        lastProcessedProviderId: lastCompletedProviderId
      });
    }
    await new Promise((r) => setTimeout(r, delayBetweenRequests));
  }
  await storage.updateCostSync(syncId, {
    status: "completed",
    processedCount,
    successCount,
    failedCount,
    skippedCount,
    completedAt: /* @__PURE__ */ new Date()
  });
  console.log(`[Cost Sync] Complete! Success: ${successCount}, Failed: ${failedCount}, Skipped: ${skippedCount}`);
  isSyncRunning = false;
  activeSyncId = null;
}
function cancelCostSync() {
  if (isSyncRunning) {
    console.log("[Cost Sync] Cancelling sync...");
    isSyncRunning = false;
  }
}
async function getCostSyncStatus() {
  const [currentSync, stats] = await Promise.all([
    storage.getLatestCostSync(),
    storage.getProviderCostStats()
  ]);
  return {
    isRunning: isSyncRunning,
    currentSync,
    stats
  };
}

// server/routes.ts
init_composite_image_generator();

// server/lib/image-upload.ts
init_firebase_storage_service();
var ALLOWED_MIME_TYPES2 = ALLOWED_MIME_TYPES;
var MAX_FILE_SIZE2 = MAX_FILE_SIZE;
async function uploadImage(base64Data, originalName, mimeType) {
  if (!ALLOWED_MIME_TYPES2.includes(mimeType)) {
    throw new Error(`Invalid file type: ${mimeType}. Allowed: ${ALLOWED_MIME_TYPES2.join(", ")}`);
  }
  const base64Match = base64Data.match(/^data:([^;]+);base64,(.+)$/);
  const actualBase64 = base64Match ? base64Match[2] : base64Data;
  const buffer = Buffer.from(actualBase64, "base64");
  if (buffer.length > MAX_FILE_SIZE2) {
    throw new Error(`File too large. Maximum size is ${MAX_FILE_SIZE2 / 1024 / 1024}MB`);
  }
  return uploadToFirebaseStorage(buffer, originalName, mimeType, "hosted-images");
}
async function getImageBuffer(fileName) {
  return getFileFromFirebaseStorage(fileName, "hosted-images");
}
async function deleteImage(fileName) {
  return deleteFromFirebaseStorage(fileName, "hosted-images");
}
async function uploadImageFromBuffer(buffer, originalName, mimeType, folderPath) {
  if (!ALLOWED_MIME_TYPES2.includes(mimeType)) {
    throw new Error(`Invalid file type: ${mimeType}. Allowed: ${ALLOWED_MIME_TYPES2.join(", ")}`);
  }
  if (buffer.length > MAX_FILE_SIZE2) {
    throw new Error(`File too large. Maximum size is ${MAX_FILE_SIZE2 / 1024 / 1024}MB`);
  }
  const folder = folderPath || "custom-designs";
  return uploadToFirebaseStorage(buffer, originalName, mimeType, folder);
}

// server/routes.ts
init_firebase_storage_service();
init_firebase_admin();

// server/firebaseAuth.ts
init_firebase_admin();
init_storage();
import session from "express-session";
import { getAuth as getAuth2 } from "firebase-admin/auth";
import MemoryStore from "memorystore";
function ensureFirebaseInitialized2() {
  if (!isFirebaseInitialized()) {
    initializeFirebase();
  }
}
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1e3;
  const MemStore = MemoryStore(session);
  return session({
    secret: process.env.SESSION_SECRET || "qrgear-session-secret-change-in-production",
    store: new MemStore({
      checkPeriod: 864e5
      // 24 hours
    }),
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: sessionTtl
    }
  });
}
async function upsertUser(claims) {
  await storage.upsertUser({
    id: claims.uid,
    email: claims.email || "",
    firstName: claims.name?.split(" ")[0] || "",
    lastName: claims.name?.split(" ").slice(1).join(" ") || "",
    profileImageUrl: claims.picture || ""
  });
}
async function setupAuth(app3) {
  app3.set("trust proxy", 1);
  app3.use(getSession());
  ensureFirebaseInitialized2();
  app3.use("/api", async (req, res, next) => {
    const publicPaths = [
      "/api/health",
      "/api/products",
      "/api/storefront",
      "/api/widget",
      "/api/qr",
      "/api/files",
      "/api/library-files",
      "/api/stripe/webhook"
    ];
    const isPublic = publicPaths.some((path5) => req.path.startsWith(path5.replace("/api", "")));
    if (isPublic) {
      return next();
    }
    if (req.path.includes("/admin/background")) {
      console.log("[Auth Debug] Path:", req.path);
      console.log("[Auth Debug] Session user:", req.session?.user?.email || "none");
      console.log("[Auth Debug] Auth header present:", !!req.headers.authorization);
    }
    if (req.session?.user) {
      req.user = req.session.user;
      req.isAuthenticated = () => true;
      return next();
    }
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith("Bearer ")) {
      const idToken = authHeader.substring(7);
      try {
        const auth = getAuth2();
        const decodedToken = await auth.verifyIdToken(idToken);
        await upsertUser(decodedToken);
        req.session.user = {
          claims: {
            sub: decodedToken.uid,
            email: decodedToken.email
          },
          uid: decodedToken.uid,
          email: decodedToken.email
        };
        req.user = req.session.user;
        req.isAuthenticated = () => true;
        if (req.path.includes("/admin/background")) {
          console.log("[Auth Debug] Token verified for:", decodedToken.email);
        }
        return next();
      } catch (error) {
        console.error("Firebase token verification failed:", error);
      }
    }
    if (req.path.includes("/admin/background")) {
      console.log("[Auth Debug] No auth - setting isAuthenticated to false");
    }
    req.isAuthenticated = () => false;
    next();
  });
  app3.get("/api/login", (req, res) => {
    res.json({
      message: "Use Firebase Authentication",
      authType: "firebase"
    });
  });
  app3.get("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Session destroy error:", err);
      }
      res.redirect("/");
    });
  });
  app3.post("/api/auth/firebase-callback", async (req, res) => {
    const { idToken } = req.body;
    if (!idToken) {
      return res.status(400).json({ error: "ID token required" });
    }
    try {
      ensureFirebaseInitialized2();
      const auth = getAuth2();
      const decodedToken = await auth.verifyIdToken(idToken);
      await upsertUser(decodedToken);
      req.session.user = {
        claims: {
          sub: decodedToken.uid,
          email: decodedToken.email
        },
        uid: decodedToken.uid,
        email: decodedToken.email
      };
      res.json({
        success: true,
        user: {
          id: decodedToken.uid,
          email: decodedToken.email
        }
      });
    } catch (error) {
      console.error("Firebase auth callback error:", error);
      res.status(401).json({ error: "Invalid token" });
    }
  });
}
var isAuthenticated = async (req, res, next) => {
  if (req.isAuthenticated && req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
};
var isAdmin = async (req, res, next) => {
  if (!req.isAuthenticated || !req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const userId = req.user?.claims?.sub || req.user?.uid;
  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const adminIds = (process.env.ADMIN_USER_IDS || "").split(",").map((id) => id.trim()).filter(Boolean);
  if (adminIds.length === 0 || adminIds.includes(userId)) {
    return next();
  }
  return res.status(403).json({ message: "Admin access required" });
};

// server/lib/email.ts
import { Resend } from "resend";
var connectionSettings;
async function getCredentials() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY ? "repl " + process.env.REPL_IDENTITY : process.env.WEB_REPL_RENEWAL ? "depl " + process.env.WEB_REPL_RENEWAL : null;
  if (!xReplitToken) {
    throw new Error("X_REPLIT_TOKEN not found for repl/depl");
  }
  connectionSettings = await fetch(
    "https://" + hostname + "/api/v2/connection?include_secrets=true&connector_names=resend",
    {
      headers: {
        "Accept": "application/json",
        "X_REPLIT_TOKEN": xReplitToken
      }
    }
  ).then((res) => res.json()).then((data) => data.items?.[0]);
  if (!connectionSettings || !connectionSettings.settings.api_key) {
    throw new Error("Resend not connected");
  }
  return {
    apiKey: connectionSettings.settings.api_key,
    fromEmail: connectionSettings.settings.from_email
  };
}
async function getResendClient() {
  const { apiKey } = await getCredentials();
  return {
    client: new Resend(apiKey),
    fromEmail: connectionSettings.settings.from_email
  };
}
async function sendOrderConfirmationEmail(data) {
  try {
    const { client, fromEmail } = await getResendClient();
    const itemsHtml = data.items.map((item) => `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">Product #${item.productId.slice(0, 8)}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: center;">${item.quantity}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: right;">$${item.price.toFixed(2)}</td>
      </tr>
    `).join("");
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f9fafb;">
        <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
          <div style="background-color: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 32px;">
            <div style="text-align: center; margin-bottom: 32px;">
              <h1 style="color: #111827; margin: 0 0 8px;">Order Confirmed!</h1>
              <p style="color: #6b7280; margin: 0;">Thank you for your purchase, ${data.customerName}!</p>
            </div>
            
            <div style="background-color: #f3f4f6; border-radius: 6px; padding: 16px; margin-bottom: 24px;">
              <p style="margin: 0; color: #374151;"><strong>Order Number:</strong> ${data.orderId.slice(0, 8).toUpperCase()}</p>
              <p style="margin: 8px 0 0; color: #374151;"><strong>Order Date:</strong> ${data.orderDate.toLocaleDateString()}</p>
            </div>
            
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
              <thead>
                <tr style="background-color: #f9fafb;">
                  <th style="padding: 12px; text-align: left; border-bottom: 2px solid #e5e7eb;">Product</th>
                  <th style="padding: 12px; text-align: center; border-bottom: 2px solid #e5e7eb;">Qty</th>
                  <th style="padding: 12px; text-align: right; border-bottom: 2px solid #e5e7eb;">Price</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHtml}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="2" style="padding: 16px 12px; text-align: right; font-weight: bold;">Total:</td>
                  <td style="padding: 16px 12px; text-align: right; font-weight: bold; font-size: 18px;">$${data.totalAmount.toFixed(2)}</td>
                </tr>
              </tfoot>
            </table>
            
            <div style="border-top: 1px solid #e5e7eb; padding-top: 24px;">
              <h3 style="color: #111827; margin: 0 0 12px;">What happens next?</h3>
              <ol style="color: #6b7280; margin: 0; padding-left: 20px;">
                <li style="margin-bottom: 8px;">Your order is being sent to our production partner</li>
                <li style="margin-bottom: 8px;">Your custom QR products will be printed and quality checked</li>
                <li style="margin-bottom: 8px;">You'll receive shipping updates via email</li>
                <li>Typical delivery time is 5-7 business days</li>
              </ol>
            </div>
          </div>
          
          <div style="text-align: center; margin-top: 24px; color: #9ca3af; font-size: 14px;">
            <p>Questions? Reply to this email or contact support.</p>
            <p>&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} QR Gear. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
    await client.emails.send({
      from: fromEmail || "QR Gear <noreply@qrgear.com>",
      to: data.customerEmail,
      subject: `Order Confirmed - #${data.orderId.slice(0, 8).toUpperCase()}`,
      html
    });
    console.log(`Order confirmation email sent to ${data.customerEmail}`);
    return true;
  } catch (error) {
    console.error("Failed to send order confirmation email:", error);
    return false;
  }
}
async function sendHostingExpirationReminder(data) {
  try {
    const { client, fromEmail } = await getResendClient();
    const urgencyText = data.daysRemaining === 0 ? "expires today" : data.daysRemaining === 1 ? "expires tomorrow" : `expires in ${data.daysRemaining} days`;
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f9fafb;">
        <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
          <div style="background-color: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 32px;">
            <div style="text-align: center; margin-bottom: 32px;">
              <h1 style="color: #111827; margin: 0 0 8px;">Image Hosting Reminder</h1>
              <p style="color: #6b7280; margin: 0;">Hi ${data.customerName}, your hosted image ${urgencyText}!</p>
            </div>
            
            <div style="background-color: ${data.daysRemaining <= 7 ? "#fef2f2" : "#fffbeb"}; border-radius: 6px; padding: 16px; margin-bottom: 24px; border: 1px solid ${data.daysRemaining <= 7 ? "#fecaca" : "#fde68a"};">
              <p style="margin: 0; color: #374151;"><strong>Image:</strong> ${data.imageTitle || "Your QR Image"}</p>
              <p style="margin: 8px 0 0; color: #374151;"><strong>Expiration Date:</strong> ${data.expirationDate.toLocaleDateString()}</p>
            </div>
            
            <p style="color: #6b7280; line-height: 1.6;">
              When your image hosting expires, the QR code on your products will no longer display your image. 
              To keep your image accessible, please renew your hosting before the expiration date.
            </p>
            
            <div style="text-align: center; margin: 32px 0;">
              <a href="${data.renewalUrl}" style="display: inline-block; background-color: #2563eb; color: white; text-decoration: none; padding: 14px 28px; border-radius: 6px; font-weight: 600;">
                Renew Now
              </a>
            </div>
            
            <p style="color: #9ca3af; font-size: 14px; text-align: center;">
              If you no longer need this image hosted, you can ignore this email.
            </p>
          </div>
          
          <div style="text-align: center; margin-top: 24px; color: #9ca3af; font-size: 14px;">
            <p>&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} QR Gear. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
    await client.emails.send({
      from: fromEmail || "QR Gear <noreply@qrgear.com>",
      to: data.customerEmail,
      subject: data.daysRemaining === 0 ? `URGENT: Your QR image hosting expires today!` : `Your QR image hosting ${urgencyText}`,
      html
    });
    console.log(`Hosting reminder email sent to ${data.customerEmail}`);
    return true;
  } catch (error) {
    console.error("Failed to send hosting reminder email:", error);
    return false;
  }
}
async function sendShippingUpdateEmail(customerEmail, customerName, orderId, trackingNumber, carrier) {
  try {
    const { client, fromEmail } = await getResendClient();
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 0; background-color: #f9fafb;">
        <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
          <div style="background-color: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 32px;">
            <div style="text-align: center; margin-bottom: 32px;">
              <h1 style="color: #111827; margin: 0 0 8px;">Your Order Has Shipped!</h1>
              <p style="color: #6b7280; margin: 0;">Great news, ${customerName}! Your QR Gear order is on its way.</p>
            </div>
            
            <div style="background-color: #ecfdf5; border-radius: 6px; padding: 16px; margin-bottom: 24px; border: 1px solid #a7f3d0;">
              <p style="margin: 0; color: #374151;"><strong>Order Number:</strong> ${orderId.slice(0, 8).toUpperCase()}</p>
              <p style="margin: 8px 0 0; color: #374151;"><strong>Carrier:</strong> ${carrier}</p>
              <p style="margin: 8px 0 0; color: #374151;"><strong>Tracking Number:</strong> ${trackingNumber}</p>
            </div>
            
            <p style="color: #6b7280; line-height: 1.6;">
              You can track your package using the tracking number above. Most orders arrive within 5-7 business days.
            </p>
          </div>
          
          <div style="text-align: center; margin-top: 24px; color: #9ca3af; font-size: 14px;">
            <p>&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} QR Gear. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `;
    await client.emails.send({
      from: fromEmail || "QR Gear <noreply@qrgear.com>",
      to: customerEmail,
      subject: `Your QR Gear Order Has Shipped! - #${orderId.slice(0, 8).toUpperCase()}`,
      html
    });
    console.log(`Shipping update email sent to ${customerEmail}`);
    return true;
  } catch (error) {
    console.error("Failed to send shipping update email:", error);
    return false;
  }
}

// server/lib/printify-orders.ts
init_printify();
init_storage();
async function submitOrderToPrintify(orderId, shippingAddress) {
  try {
    if (!printify.isConfigured) {
      return { success: false, error: "Printify API not configured" };
    }
    const order = await storage.getOrder(orderId);
    if (!order) {
      return { success: false, error: "Order not found" };
    }
    if (order.printifyOrderId) {
      return { success: true, printifyOrderId: order.printifyOrderId };
    }
    const orderItems2 = await storage.getOrderItems(orderId);
    if (!orderItems2.length) {
      return { success: false, error: "No order items found" };
    }
    const lineItems = [];
    for (const item of orderItems2) {
      const customization = item.customization;
      if (!customization?.printifyProductId || !customization?.printifyVariantId) {
        console.warn(`Order item ${item.id} missing Printify product/variant IDs`);
        continue;
      }
      lineItems.push({
        product_id: customization.printifyProductId,
        variant_id: customization.printifyVariantId,
        quantity: item.quantity,
        print_areas: customization.printAreas
      });
    }
    if (!lineItems.length) {
      return { success: false, error: "No valid line items for Printify" };
    }
    const addressTo = {
      first_name: shippingAddress.firstName,
      last_name: shippingAddress.lastName,
      email: shippingAddress.email,
      phone: shippingAddress.phone,
      country: shippingAddress.country,
      region: shippingAddress.region,
      address1: shippingAddress.address1,
      address2: shippingAddress.address2,
      city: shippingAddress.city,
      zip: shippingAddress.zip
    };
    const printifyOrderRequest = {
      external_id: orderId,
      label: `QR Gear Order ${orderId.slice(0, 8).toUpperCase()}`,
      line_items: lineItems,
      shipping_method: 1,
      send_shipping_notification: true,
      address_to: addressTo
    };
    const printifyOrder = await printify.createOrder(printifyOrderRequest);
    await storage.updateOrder(orderId, {
      printifyOrderId: printifyOrder.id,
      status: "processing"
    });
    await printify.submitOrderToProduction(printifyOrder.id);
    await storage.updateOrder(orderId, {
      status: "in_production"
    });
    console.log(`Order ${orderId} submitted to Printify: ${printifyOrder.id}`);
    return { success: true, printifyOrderId: printifyOrder.id };
  } catch (error) {
    console.error(`Failed to submit order ${orderId} to Printify:`, error);
    return { success: false, error: error.message };
  }
}
async function checkPrintifyOrderStatus(orderId) {
  try {
    const order = await storage.getOrder(orderId);
    if (!order?.printifyOrderId) {
      return { status: "not_submitted" };
    }
    const printifyOrder = await printify.getOrder(order.printifyOrderId);
    const status = printifyOrder.status?.toLowerCase() || "unknown";
    const shipments = printifyOrder.shipments || [];
    if (shipments.length > 0) {
      const latestShipment = shipments[shipments.length - 1];
      return {
        status,
        trackingNumber: latestShipment.tracking_number,
        trackingUrl: latestShipment.tracking_url,
        carrier: latestShipment.carrier
      };
    }
    return { status };
  } catch (error) {
    console.error(`Failed to check Printify order status for ${orderId}:`, error);
    return { status: "error" };
  }
}
async function syncPrintifyOrderStatuses() {
  try {
    const orders2 = await storage.getOrdersByStatus("in_production");
    for (const order of orders2) {
      if (!order.printifyOrderId) continue;
      const { status, trackingNumber, carrier } = await checkPrintifyOrderStatus(order.id);
      if (status === "shipped" && trackingNumber && order.status !== "shipped") {
        await storage.updateOrder(order.id, {
          status: "shipped",
          trackingNumber,
          carrier: carrier || "Standard Shipping"
        });
        const user = await storage.getUser(order.userId);
        if (user?.email) {
          sendShippingUpdateEmail(
            user.email,
            user.firstName || "Customer",
            order.id,
            trackingNumber,
            carrier || "Standard Shipping"
          ).catch((err) => console.error("Failed to send shipping email:", err));
        }
      } else if (status === "delivered" && order.status !== "delivered") {
        await storage.updateOrder(order.id, { status: "delivered" });
      }
    }
  } catch (error) {
    console.error("Failed to sync Printify order statuses:", error);
  }
}

// server/lib/cron-jobs.ts
init_storage();
init_printify();
var REMINDER_INTERVALS = [30, 7, 0];
async function syncPrintifyCatalog() {
  console.log("[Cron] Starting Printify catalog sync...");
  try {
    if (!printify.isConfigured) {
      console.log("[Cron] Printify not configured, skipping sync");
      return;
    }
    const localProducts = await storage.getAllProducts();
    const printifyProducts = localProducts.filter((p) => p.printifyId);
    console.log(`[Cron] Syncing ${printifyProducts.length} products with Printify...`);
    for (const product of printifyProducts) {
      try {
        const blueprintId = parseInt(product.printifyId);
        if (isNaN(blueprintId)) continue;
        const blueprint = await printify.getBlueprintDetails(blueprintId);
        if (!blueprint) continue;
        const syncedAt = (/* @__PURE__ */ new Date()).toISOString();
        await storage.updateProduct(product.id, {
          metadata: {
            ...typeof product.metadata === "object" ? product.metadata : {},
            syncedAt,
            blueprintId
          }
        });
        console.log(`[Cron] Synced product: ${product.name}`);
      } catch (err) {
        console.error(`[Cron] Failed to sync product ${product.id}:`, err.message);
      }
    }
    console.log("[Cron] Printify catalog sync complete");
  } catch (error) {
    console.error("[Cron] Error syncing Printify catalog:", error);
  }
}
async function checkHostingExpirations() {
  console.log("[Cron] Checking hosting expirations...");
  try {
    const hostedImages2 = await storage.getAllHostedImages();
    const now = /* @__PURE__ */ new Date();
    for (const image of hostedImages2) {
      if (!image.expiresAt) continue;
      const expiresAt = new Date(image.expiresAt);
      const daysRemaining = Math.ceil((expiresAt.getTime() - now.getTime()) / (1e3 * 60 * 60 * 24));
      if (daysRemaining < 0) {
        console.log(`[Cron] Image ${image.id} has expired, marking as inactive`);
        await storage.updateHostedImage(image.id, { isActive: false });
        continue;
      }
      if (REMINDER_INTERVALS.includes(daysRemaining)) {
        const existingReminder = await storage.getHostingReminderByImageAndDays(image.id, daysRemaining);
        if (existingReminder) continue;
        const user = image.userId ? await storage.getUser(image.userId) : null;
        if (user?.email) {
          console.log(`[Cron] Sending ${daysRemaining}-day reminder for image ${image.id}`);
          const baseUrl = process.env.REPLIT_DOMAIN ? `https://${process.env.REPLIT_DOMAIN}` : "http://localhost:5000";
          const sent = await sendHostingExpirationReminder({
            customerEmail: user.email,
            customerName: user.firstName || "Customer",
            imageId: image.id,
            imageTitle: image.originalName || "Your QR Image",
            expirationDate: expiresAt,
            daysRemaining,
            renewalUrl: `${baseUrl}/account?renew=${image.id}`
          });
          if (sent) {
            await storage.createHostingReminder({
              customGiftId: image.id,
              reminderType: `${daysRemaining}_day`,
              scheduledFor: /* @__PURE__ */ new Date()
            });
          }
        }
      }
    }
    console.log("[Cron] Hosting expiration check complete");
  } catch (error) {
    console.error("[Cron] Error checking hosting expirations:", error);
  }
}
async function runAllCronJobs() {
  console.log("[Cron] Running scheduled jobs...");
  await Promise.allSettled([
    checkHostingExpirations(),
    syncPrintifyOrderStatuses(),
    syncPrintifyCatalog()
  ]);
  console.log("[Cron] All scheduled jobs completed");
}
var cronInterval = null;
var costSyncInterval = null;
async function runWeeklyCostSync() {
  console.log("[Cron] Starting weekly Printify cost sync...");
  try {
    const status = await getCostSyncStatus();
    if (status.isRunning) {
      console.log("[Cron] Cost sync already running, skipping");
      return;
    }
    await startCostSync({ forceRefresh: false });
    console.log("[Cron] Weekly cost sync started in background");
  } catch (error) {
    console.error("[Cron] Error starting weekly cost sync:", error);
  }
}
async function startCronJobs() {
  if (cronInterval) {
    console.log("[Cron] Jobs already running");
    return;
  }
  runAllCronJobs();
  cronInterval = setInterval(runAllCronJobs, 60 * 60 * 1e3);
  costSyncInterval = setInterval(runWeeklyCostSync, 7 * 24 * 60 * 60 * 1e3);
  console.log("[Cron] Jobs scheduled to run every hour");
  console.log("[Cron] Cost sync scheduled to run weekly");
  setTimeout(async () => {
    try {
      const status = await getCostSyncStatus();
      if (!status.isRunning) {
        console.log("[Cron] Checking if initial cost sync is needed...");
        await startCostSync({ forceRefresh: false });
        console.log("[Cron] Initial cost sync started in background");
      }
    } catch (error) {
      console.error("[Cron] Error starting initial cost sync:", error);
    }
  }, 5e3);
}

// server/lib/sitemap.ts
init_storage();
var BASE_URL = process.env.SITE_URL || "https://qrgear.com";
var staticPages = [
  { loc: "/", changefreq: "daily", priority: 1 },
  { loc: "/creator", changefreq: "weekly", priority: 0.9 },
  { loc: "/shop", changefreq: "daily", priority: 0.9 },
  { loc: "/qr-static", changefreq: "monthly", priority: 0.8 },
  { loc: "/qr-static-plus", changefreq: "monthly", priority: 0.8 },
  { loc: "/qr-url", changefreq: "monthly", priority: 0.8 },
  { loc: "/qr-video", changefreq: "monthly", priority: 0.8 },
  { loc: "/qr-dynamics", changefreq: "monthly", priority: 0.8 },
  { loc: "/login", changefreq: "yearly", priority: 0.3 },
  { loc: "/register", changefreq: "yearly", priority: 0.3 }
];
var auxiliaryFiles = [
  { loc: "/llms.txt", changefreq: "weekly", priority: 0.5 },
  { loc: "/ai.txt", changefreq: "weekly", priority: 0.5 },
  { loc: "/robots.txt", changefreq: "monthly", priority: 0.2 }
];
async function generateSitemap() {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const urls = [];
  urls.push(...staticPages.map((page) => ({ ...page, lastmod: today })));
  urls.push(...auxiliaryFiles.map((file) => ({ ...file, lastmod: today })));
  try {
    const products2 = await storage.getProducts();
    const enabledProducts = products2.filter((p) => p.isEnabled);
    for (const product of enabledProducts) {
      urls.push({
        loc: `/shop/product/${product.id}`,
        lastmod: today,
        changefreq: "weekly",
        priority: 0.7
      });
    }
  } catch (error) {
    console.error("[Sitemap] Error fetching products:", error);
  }
  try {
    const categories = await storage.getProductCategories();
    for (const category of categories) {
      urls.push({
        loc: `/shop/category/${category.slug}`,
        lastmod: today,
        changefreq: "weekly",
        priority: 0.6
      });
    }
  } catch (error) {
    console.error("[Sitemap] Error fetching categories:", error);
  }
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((url) => `  <url>
    <loc>${BASE_URL}${url.loc}</loc>
    ${url.lastmod ? `<lastmod>${url.lastmod}</lastmod>` : ""}
    ${url.changefreq ? `<changefreq>${url.changefreq}</changefreq>` : ""}
    ${url.priority !== void 0 ? `<priority>${url.priority}</priority>` : ""}
  </url>`).join("\n")}
</urlset>`;
  return xml;
}

// server/routes.ts
import { z as z2 } from "zod";
import QRCode4 from "qrcode";
import bcrypt from "bcryptjs";
import Stripe2 from "stripe";
var widgetCorsMiddleware = async (req, res, next) => {
  const origin = req.headers.origin;
  const envAllowedOrigins = (process.env.ALLOWED_WIDGET_ORIGINS || "").split(",").map((o) => o.trim()).filter(Boolean);
  let partnerAllowedOrigins = [];
  try {
    const stores = await storage.getPartnerStores();
    for (const store of stores) {
      if (store.allowedOrigins && Array.isArray(store.allowedOrigins)) {
        partnerAllowedOrigins.push(...store.allowedOrigins);
      }
    }
  } catch (e) {
  }
  const allAllowedOrigins = Array.from(/* @__PURE__ */ new Set([...envAllowedOrigins, ...partnerAllowedOrigins]));
  if (origin && allAllowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-API-Key");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Max-Age", "86400");
  }
  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }
  next();
};
async function checkProviderHealth() {
  const providers = [];
  const printifyKey = process.env.PRINTIFY_API_KEY;
  if (printifyKey) {
    try {
      const response = await fetch("https://api.printify.com/v1/shops.json", {
        headers: { Authorization: `Bearer ${printifyKey}` },
        signal: AbortSignal.timeout(5e3)
      });
      providers.push({
        name: "Printify",
        status: response.ok ? "healthy" : "degraded",
        configured: true
      });
    } catch (e) {
      providers.push({ name: "Printify", status: "down", configured: true });
    }
  }
  const printfulKey = process.env.PRINTFUL_API_KEY;
  if (printfulKey) {
    try {
      const response = await fetch("https://api.printful.com/stores", {
        headers: { Authorization: `Bearer ${printfulKey}` },
        signal: AbortSignal.timeout(5e3)
      });
      providers.push({
        name: "Printful",
        status: response.ok ? "healthy" : "degraded",
        configured: true
      });
    } catch (e) {
      providers.push({ name: "Printful", status: "down", configured: true });
    }
  }
  const apliiqKey = process.env.APLIIQ_API_KEY;
  if (apliiqKey) {
    providers.push({ name: "Apliiq", status: "healthy", configured: true });
  }
  if (providers.length === 0) {
    providers.push({ name: "No POD providers", status: "not_configured", configured: false });
  }
  let stripeStatus = "not_configured";
  const stripeKey = process.env.STRIPE_SECRET_KEY;
  if (stripeKey) {
    try {
      const stripe = new Stripe2(stripeKey);
      await stripe.balance.retrieve();
      stripeStatus = "healthy";
    } catch (e) {
      stripeStatus = "down";
    }
  }
  const primaryProvider = providers.find((p) => p.configured) || providers[0];
  return {
    // New format: array of all configured providers
    providers,
    stripe: stripeStatus,
    lastCheck: (/* @__PURE__ */ new Date()).toISOString(),
    // Legacy format for backward compatibility
    printify: primaryProvider?.name === "Printify" ? primaryProvider.status : printifyKey ? "down" : "not_configured"
  };
}
async function autoSyncVariantsFromLocalCatalog(productId, blueprintId, printProviderId, basePrice, existingMetadata) {
  let variantsSeeded = 0;
  let syncWarning = null;
  if (!blueprintId || !printProviderId) {
    return { variantsSeeded: 0, syncWarning: "Missing blueprintId or printProviderId" };
  }
  try {
    const localProvider = await storage.getPrintifyPrintProvider(blueprintId, printProviderId);
    if (localProvider && localProvider.availableColors && localProvider.availableSizes) {
      const colors = localProvider.availableColors;
      const sizes = localProvider.availableSizes;
      let variantIdCounter = 1;
      for (const color of colors) {
        for (const size of sizes) {
          await storage.upsertProductVariant({
            productId,
            printifyVariantId: variantIdCounter++,
            title: `${size} / ${color.name}`,
            size,
            color: color.name,
            colorHex: color.hex || null,
            price: basePrice,
            isEnabled: true,
            isInStock: true
          });
          variantsSeeded++;
        }
      }
      const mergedMetadata = {
        ...existingMetadata || {},
        autoSyncedFromLocalCatalog: true,
        syncedAt: (/* @__PURE__ */ new Date()).toISOString(),
        variantIdsArePlaceholders: true
        // Flag that real IDs need to be fetched for fulfillment
      };
      await storage.updateProduct(productId, {
        availableColors: colors,
        availableSizes: sizes,
        metadata: mergedMetadata
      });
      console.log(`[Auto-Sync] Seeded ${variantsSeeded} variants for ${productId} from local catalog`);
      return { variantsSeeded, syncWarning, colors, sizes };
    } else {
      syncWarning = "Local catalog data not available. Run catalog sync first.";
      console.log(`[Auto-Sync] No local data for blueprint ${blueprintId}/provider ${printProviderId}`);
    }
  } catch (syncError) {
    syncWarning = `Auto-sync failed: ${syncError.message}`;
    console.error(`[Auto-Sync] Error:`, syncError);
  }
  return { variantsSeeded, syncWarning };
}
async function registerRoutes(app3) {
  await setupAuth(app3);
  app3.get("/sitemap.xml", async (req, res) => {
    try {
      const xml = await generateSitemap();
      res.set("Content-Type", "application/xml");
      res.set("Cache-Control", "public, max-age=3600");
      res.send(xml);
    } catch (error) {
      console.error("[Sitemap] Error generating sitemap:", error);
      res.status(500).send("Error generating sitemap");
    }
  });
  app3.get("/api/auth/user", async (req, res) => {
    try {
      const checkIsAdmin = (userId) => {
        const adminIds = (process.env.ADMIN_USER_IDS || "").split(",").map((id) => id.trim()).filter(Boolean);
        return adminIds.length === 0 || adminIds.includes(userId);
      };
      const authHeader = req.headers.authorization;
      if (authHeader?.startsWith("Bearer ")) {
        const idToken = authHeader.substring(7);
        const decodedToken = await verifyFirebaseToken(idToken);
        if (decodedToken) {
          const firebaseUserId = decodedToken.uid;
          let user = await storage.getUser(firebaseUserId);
          if (!user) {
            user = await storage.createUser({
              id: firebaseUserId,
              email: decodedToken.email || null,
              firstName: decodedToken.name?.split(" ")[0] || null,
              lastName: decodedToken.name?.split(" ").slice(1).join(" ") || null,
              profileImageUrl: decodedToken.picture || null
            });
          }
          const { passwordHash, ...safeUser } = user;
          return res.json({ ...safeUser, isAdmin: checkIsAdmin(firebaseUserId) });
        }
      }
      if (req.session?.userId) {
        const user = await storage.getUser(req.session.userId);
        if (user) {
          const { passwordHash, ...safeUser } = user;
          return res.json({ ...safeUser, isAdmin: checkIsAdmin(user.id) });
        }
      }
      if (req.isAuthenticated?.() && req.user?.claims?.sub) {
        const userId = req.user.claims.sub;
        const user = await storage.getUser(userId);
        if (user) {
          return res.json({ ...user, isAdmin: checkIsAdmin(userId) });
        }
      }
      res.json(null);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.json(null);
    }
  });
  const registerSchema = z2.object({
    email: z2.string().email("Invalid email format"),
    password: z2.string().min(8, "Password must be at least 8 characters"),
    firstName: z2.string().optional(),
    lastName: z2.string().optional()
  });
  const loginSchema = z2.object({
    email: z2.string().email("Invalid email format"),
    password: z2.string().min(1, "Password is required")
  });
  app3.post("/api/auth/register", async (req, res) => {
    try {
      const parseResult = registerSchema.safeParse(req.body);
      if (!parseResult.success) {
        const errorMsg = parseResult.error.errors[0]?.message || "Invalid input";
        return res.status(400).json({ error: errorMsg });
      }
      const { email, password, firstName, lastName } = parseResult.data;
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "An account with this email already exists" });
      }
      const passwordHash = await bcrypt.hash(password, 12);
      const user = await storage.createUser({
        email,
        passwordHash,
        firstName: firstName || null,
        lastName: lastName || null
      });
      req.session.regenerate?.(() => {
      });
      req.session.userId = user.id;
      const { passwordHash: _, ...safeUser } = user;
      res.json({ user: safeUser, message: "Account created successfully" });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Failed to create account" });
    }
  });
  app3.post("/api/auth/login", async (req, res) => {
    try {
      const parseResult = loginSchema.safeParse(req.body);
      if (!parseResult.success) {
        const errorMsg = parseResult.error.errors[0]?.message || "Invalid input";
        return res.status(400).json({ error: errorMsg });
      }
      const { email, password } = parseResult.data;
      const user = await storage.getUserByEmail(email);
      if (!user || !user.passwordHash) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      const isValid = await bcrypt.compare(password, user.passwordHash);
      if (!isValid) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      req.session.regenerate?.(() => {
      });
      req.session.userId = user.id;
      const { passwordHash: _, ...safeUser } = user;
      res.json({ user: safeUser, message: "Logged in successfully" });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Failed to log in" });
    }
  });
  app3.post("/api/auth/email-logout", async (req, res) => {
    try {
      req.session.userId = null;
      res.json({ message: "Logged out successfully" });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ error: "Failed to log out" });
    }
  });
  app3.get("/api/browsing-history", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const history = await storage.getBrowsingHistory(userId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/browsing-history", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { productId } = req.body;
      const entry = await storage.addBrowsingHistory({ userId, productId });
      res.json(entry);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/widget/session", widgetCorsMiddleware, async (req, res) => {
    try {
      const token = req.query.token;
      const segment = req.query.segment;
      if (!token) {
        return res.status(400).json({ error: "Token required" });
      }
      const payload = verifyWidgetToken(token);
      if (!payload) {
        return res.status(401).json({ error: "Invalid or expired token" });
      }
      if (segment && payload.allowedSegments && payload.allowedSegments.length > 0) {
        if (!payload.allowedSegments.includes(segment)) {
          return res.status(403).json({ error: "Segment not authorized for this token" });
        }
      }
      let productsToShow = [];
      if (payload.partnerId) {
        const store = await storage.getPartnerStoreBySlug(payload.partnerId);
        if (store) {
          const storeProducts = await storage.getPartnerStoreProducts(store.id);
          const enabledProducts = storeProducts.filter((sp) => sp.isEnabled);
          for (const sp of enabledProducts) {
            const product = await storage.getProduct(sp.productId);
            if (product && product.isEnabled) {
              productsToShow.push({
                id: product.id,
                name: sp.customName || product.name,
                imageUrl: product.imageUrl || "",
                basePrice: sp.customPrice || product.basePrice,
                category: product.category,
                segment: product.productLine,
                mockupsByColor: sp.mockupsByColor || product.mockupsByColor
              });
            }
          }
        }
      } else {
        const allProducts = await storage.getAllProducts();
        productsToShow = allProducts.filter((p) => p.isEnabled).map((p) => ({
          id: p.id,
          name: p.name,
          imageUrl: p.imageUrl || "",
          basePrice: p.basePrice,
          category: p.category,
          segment: p.productLine,
          mockupsByColor: p.mockupsByColor
        }));
      }
      if (segment) {
        productsToShow = productsToShow.filter(
          (p) => p.segment === segment || p.category === segment
        );
      }
      const featuredProducts = productsToShow.slice(0, 12);
      const qrCodeDataUrl = payload.kcListingUrl ? await generateTextQRCode(payload.kcListingUrl, {
        color: "#1e40af",
        backgroundColor: "#ffffff"
      }) : null;
      res.json({
        businessName: payload.businessName,
        businessLogoUrl: payload.businessLogoUrl,
        kcListingUrl: payload.kcListingUrl,
        qrCodeDataUrl,
        products: featuredProducts,
        segment: segment || null,
        totalProducts: productsToShow.length
      });
    } catch (error) {
      console.error("Widget session error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/widget/token", async (req, res) => {
    try {
      const apiKey = req.headers["x-api-key"] || req.headers["authorization"]?.replace("Bearer ", "");
      const expectedKey = process.env.WIDGET_API_KEY;
      if (!expectedKey || apiKey !== expectedKey) {
        return res.status(401).json({ error: "Invalid or missing API key" });
      }
      const allowedOrigins = (process.env.ALLOWED_WIDGET_ORIGINS || "https://kingdomconnects.com").split(",");
      const origin = req.headers.origin || req.headers.referer || "";
      const isAllowedOrigin = allowedOrigins.some((allowed) => origin.startsWith(allowed.trim()));
      if (!isAllowedOrigin && origin) {
        console.warn("Widget token request from unauthorized origin:", origin);
      }
      const validated = widgetTokenSchema.parse(req.body);
      const token = signWidgetToken(validated);
      res.json({
        token,
        expiresIn: 3600
      });
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: "Invalid widget configuration", details: error.errors });
      }
      console.error("Widget token error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/partner/products", async (req, res) => {
    try {
      const apiKey = req.headers["x-api-key"];
      const expectedKey = process.env.WIDGET_API_KEY;
      if (!expectedKey || apiKey !== expectedKey) {
        return res.status(401).json({ error: "Invalid or missing API key" });
      }
      const { partnerId, context, slug } = req.query;
      if (!partnerId || typeof partnerId !== "string") {
        return res.status(400).json({ error: "partnerId query parameter required" });
      }
      const store = await storage.getPartnerStoreBySlug(partnerId);
      if (!store || !store.isActive) {
        return res.status(404).json({ error: "Partner not found or inactive" });
      }
      const storeProducts = await storage.getPartnerStoreProducts(store.id);
      const enabledProducts = storeProducts.filter((sp) => sp.isEnabled);
      const productDetails = await Promise.all(
        enabledProducts.map(async (sp) => {
          const product = await storage.getProduct(sp.productId);
          if (!product || !product.isEnabled) return null;
          return {
            id: product.id,
            blueprintId: product.blueprintId,
            name: sp.customName || product.name,
            description: product.description,
            imageUrl: product.imageUrl,
            basePrice: sp.customPrice || product.basePrice,
            category: product.category,
            kcBusinessSlug: sp.kcBusinessSlug,
            sortOrder: sp.sortOrder
          };
        })
      );
      let filteredProducts = productDetails.filter(Boolean);
      if (context === "listing" && slug && typeof slug === "string") {
        filteredProducts = filteredProducts.filter((p) => p.kcBusinessSlug === slug);
      } else if (context === "homepage") {
        filteredProducts = filteredProducts.filter((p) => !p.kcBusinessSlug);
      }
      res.json({
        partner: {
          id: store.id,
          name: store.name,
          slug: store.slug,
          primaryColor: store.primaryColor,
          accentColor: store.accentColor
        },
        products: filteredProducts.sort((a, b) => (a?.sortOrder || 0) - (b?.sortOrder || 0))
      });
    } catch (error) {
      console.error("Partner API error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/qr/generate", async (req, res) => {
    try {
      const { content, type, style } = req.body;
      if (!validateQRContent(content, type)) {
        return res.status(400).json({ error: "Invalid QR code content" });
      }
      const qrCodeDataUrl = type === "text" ? await generateTextQRCode(content, style) : await generateImageQRCode(content, style);
      res.json({ qrCode: qrCodeDataUrl });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/qr/image", async (req, res) => {
    try {
      const { text: text2, color = "black" } = req.query;
      if (!text2 || typeof text2 !== "string") {
        return res.status(400).json({ error: "Missing 'text' query parameter" });
      }
      const qrColor = color === "white" ? "#FFFFFF" : "#000000";
      const qrCodeDataUrl = await generateTextQRCode(text2, { color: qrColor, backgroundColor: "transparent" });
      const base64Data = qrCodeDataUrl.replace(/^data:image\/png;base64,/, "");
      const buffer = Buffer.from(base64Data, "base64");
      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.send(buffer);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/products", async (req, res) => {
    try {
      const { store, segment, featured } = req.query;
      if (store && typeof store === "string") {
        const products3 = await storage.getProductsForStore(
          store,
          segment && typeof segment === "string" ? segment : void 0
        );
        return res.json(products3);
      }
      const products2 = await storage.getAllProducts();
      let enabledProducts = products2.filter((p) => p.isEnabled);
      if (featured === "true") {
        enabledProducts = enabledProducts.filter((p) => p.isFeatured);
        const settings = await storage.getAdminSettings();
        const globalMarkupPercent = parseFloat(settings?.globalMarkupPercent || "25");
        const globalMarkupFixed = parseFloat(settings?.globalMarkupFixed || "0");
        const globalQrCost = parseFloat(settings?.globalQrProductionCost || "2");
        const additionalPlacementCost = parseFloat(settings?.additionalPlacementCost || "4");
        const designs = await storage.getCustomDesigns();
        const enrichedProducts = enabledProducts.map((product) => {
          let retailPrice;
          if (product.customerPrice) {
            retailPrice = parseFloat(product.customerPrice);
          } else {
            const baseCost = parseFloat(product.basePrice) || 0;
            const qrCost = parseFloat(product.qrProductionCost || "0") || globalQrCost;
            const markupFixed = parseFloat(product.markupFixed || "0") || globalMarkupFixed;
            const markupPercent = parseFloat(product.markupPercent || "0") || globalMarkupPercent;
            const placements = product.availablePlacements || [];
            const extraPlacementCount = Math.max(0, placements.length - 1);
            const placementUpcharge = extraPlacementCount * additionalPlacementCost;
            const totalCost = baseCost + qrCost + placementUpcharge;
            retailPrice = Math.ceil((totalCost * (1 + markupPercent / 100) + markupFixed) * 100) / 100;
          }
          const customDesignId = product.id.replace(/^custom_/, "").replace(/-\d+$/, "");
          const matchingDesign = designs.find((d) => d.id === customDesignId || d.productId?.toString() === product.blueprintId?.toString());
          let placementImages = null;
          let frontChestImage = null;
          let frontChestImageWhite = null;
          if (matchingDesign?.placementImages) {
            const placements = typeof matchingDesign.placementImages === "string" ? JSON.parse(matchingDesign.placementImages) : matchingDesign.placementImages;
            placementImages = placements;
            frontChestImage = placements?.["front-chest"] || null;
            frontChestImageWhite = placements?.["front-chest-white"] || null;
          }
          let mockupsByColor = null;
          const productMockups = product?.mockupsByColor;
          const rawMockups = productMockups || matchingDesign?.mockupsByColor;
          if (rawMockups) {
            if (typeof rawMockups === "string") {
              try {
                mockupsByColor = JSON.parse(rawMockups);
              } catch {
                mockupsByColor = null;
              }
            } else if (typeof rawMockups === "object") {
              mockupsByColor = rawMockups;
            }
          }
          let selectedColors = null;
          const rawSelectedColors = matchingDesign?.selectedColors;
          if (rawSelectedColors) {
            if (typeof rawSelectedColors === "string") {
              try {
                const parsed = JSON.parse(rawSelectedColors);
                selectedColors = Array.isArray(parsed) ? parsed : null;
              } catch {
                selectedColors = null;
              }
            } else if (Array.isArray(rawSelectedColors)) {
              selectedColors = rawSelectedColors;
            }
          }
          if (!selectedColors && mockupsByColor) {
            selectedColors = Object.keys(mockupsByColor);
          }
          const rawDefaultColor = matchingDesign?.defaultColor;
          let defaultColor = typeof rawDefaultColor === "string" ? rawDefaultColor : null;
          const validDefaultColor = defaultColor && selectedColors?.includes(defaultColor) ? defaultColor : defaultColor && mockupsByColor && mockupsByColor[defaultColor] ? defaultColor : mockupsByColor ? Object.keys(mockupsByColor)[0] : null;
          let defaultMockupImage = null;
          if (mockupsByColor && validDefaultColor && mockupsByColor[validDefaultColor]?.front) {
            defaultMockupImage = mockupsByColor[validDefaultColor].front;
          } else if (mockupsByColor) {
            const firstColor = Object.keys(mockupsByColor)[0];
            if (firstColor) {
              defaultMockupImage = mockupsByColor[firstColor]?.front || null;
            }
          }
          let availableColorsWithHex = [];
          const rawAvailableColors = product.availableColors;
          if (rawAvailableColors) {
            if (Array.isArray(rawAvailableColors)) {
              availableColorsWithHex = rawAvailableColors;
            }
          }
          const metadata = typeof product.metadata === "object" ? product.metadata : {};
          const isCustomizable = metadata?.allowCustomization !== false && !product.id.startsWith("custom_") && !product.id.includes("-template-");
          return {
            ...product,
            retailPrice,
            // Calculated final price with markup and QR cost
            qrCodeUrl: matchingDesign?.qrCodeUrl || null,
            frontChestImage,
            frontChestImageWhite,
            placementImages,
            // All placements including white variants (e.g., back, back-white, left-sleeve, left-sleeve-white)
            // New mockup fields (normalized and validated)
            mockupsByColor,
            defaultColor: validDefaultColor,
            // Use validated color that exists in mockups
            selectedColors,
            defaultMockupImage,
            // Pre-computed default image for quick display
            availableColorsWithHex,
            // Colors with hex values for color swatches
            isCustomizable
            // Whether user can customize the design
          };
        });
        return res.json(enrichedProducts);
      }
      res.json(enabledProducts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/products/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/printify/status", async (req, res) => {
    res.json({
      configured: printify.isConfigured,
      message: printify.isConfigured ? "Printify API is connected" : "Printify API key or Shop ID not configured"
    });
  });
  app3.get("/api/printify/catalog", async (req, res) => {
    try {
      if (!printify.isConfigured) {
        return res.status(503).json({ error: "Printify not configured" });
      }
      const blueprints = await printify.getCatalogBlueprints();
      res.json(blueprints);
    } catch (error) {
      console.error("Printify catalog error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/printify/catalog/:blueprintId", async (req, res) => {
    try {
      if (!printify.isConfigured) {
        return res.status(503).json({ error: "Printify not configured" });
      }
      const blueprintId = parseInt(req.params.blueprintId);
      const [blueprint, providers] = await Promise.all([
        printify.getBlueprintDetails(blueprintId),
        getUSAPrintProviders(blueprintId)
      ]);
      res.json({ blueprint, providers });
    } catch (error) {
      console.error("Printify blueprint error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/printify/catalog/:blueprintId/variants", async (req, res) => {
    try {
      if (!printify.isConfigured) {
        return res.status(503).json({ error: "Printify not configured" });
      }
      const blueprintId = parseInt(req.params.blueprintId);
      const printProviderId = parseInt(req.query.providerId);
      if (!printProviderId) {
        return res.status(400).json({ error: "providerId query param required" });
      }
      const variants = await printify.getVariants(blueprintId, printProviderId);
      res.json(variants);
    } catch (error) {
      console.error("Printify variants error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/printify/products", async (req, res) => {
    try {
      if (!printify.isConfigured) {
        return res.status(503).json({ error: "Printify not configured" });
      }
      const products2 = await printify.getShopProducts();
      res.json(products2);
    } catch (error) {
      console.error("Printify products error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/upload", async (req, res) => {
    try {
      const chunks = [];
      let fileName = "upload";
      let mimeType = "image/png";
      let boundary = "";
      const contentType = req.headers["content-type"] || "";
      const boundaryMatch = contentType.match(/boundary=(.+)/);
      if (boundaryMatch) {
        boundary = boundaryMatch[1];
      }
      const rawBody = await new Promise((resolve, reject) => {
        const chunks2 = [];
        req.on("data", (chunk) => chunks2.push(chunk));
        req.on("end", () => resolve(Buffer.concat(chunks2)));
        req.on("error", reject);
      });
      const boundaryBuffer = Buffer.from(`--${boundary}`);
      const parts = [];
      let start = 0;
      while (true) {
        const boundaryIndex = rawBody.indexOf(boundaryBuffer, start);
        if (boundaryIndex === -1) break;
        if (start > 0) {
          parts.push(rawBody.slice(start, boundaryIndex - 2));
        }
        start = boundaryIndex + boundaryBuffer.length + 2;
      }
      let fileBuffer = null;
      for (const part of parts) {
        const headerEnd = part.indexOf("\r\n\r\n");
        if (headerEnd === -1) continue;
        const headers = part.slice(0, headerEnd).toString();
        const body = part.slice(headerEnd + 4);
        const filenameMatch = headers.match(/filename="([^"]+)"/);
        const contentTypeMatch = headers.match(/Content-Type:\s*([^\r\n]+)/i);
        if (filenameMatch) {
          fileName = filenameMatch[1];
          if (contentTypeMatch) {
            mimeType = contentTypeMatch[1].trim();
          }
          fileBuffer = body;
        }
      }
      if (!fileBuffer || fileBuffer.length === 0) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const uploadResult = await uploadImageFromBuffer(fileBuffer, fileName, mimeType);
      res.json({ url: uploadResult.publicUrl });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/files/:filename", async (req, res) => {
    try {
      const { filename } = req.params;
      const served = await downloadAndStreamFile(filename, res, "custom-designs", 31536e3);
      if (served) {
        return;
      }
      return res.status(404).json({ error: "File not found" });
    } catch (error) {
      console.error("File serve error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/library-files/:filename", async (req, res) => {
    try {
      const { filename } = req.params;
      const served = await downloadAndStreamFile(filename, res, "library", 31536e3);
      if (served) {
        return;
      }
      return res.status(404).json({ error: "Library file not found" });
    } catch (error) {
      console.error("Library file serve error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/background-files/*", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ error: "Authentication required" });
      }
      const idToken = authHeader.split("Bearer ")[1];
      const decodedToken = await verifyFirebaseToken(idToken);
      if (!decodedToken) {
        return res.status(401).json({ error: "Invalid token" });
      }
      const firebaseUid = decodedToken.uid;
      const adminIds = (process.env.ADMIN_USER_IDS || "").split(",").map((id) => id.trim()).filter(Boolean);
      if (adminIds.length > 0 && !adminIds.includes(firebaseUid)) {
        return res.status(403).json({ error: "Admin access required" });
      }
      const fullPath = decodeURIComponent(req.params[0]);
      console.log(`[BackgroundFiles] Serving: ${fullPath}`);
      const served = await downloadAndStreamFile(fullPath, res, "", 31536e3);
      if (served) {
        return;
      }
      console.log(`[BackgroundFiles] Not found: ${fullPath}`);
      return res.status(404).json({ error: "Background file not found" });
    } catch (error) {
      console.error("Background file serve error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/images/upload", async (req, res) => {
    try {
      const { imageData, originalName, mimeType, title, description, businessName, businessLogo, userId } = req.body;
      if (!imageData || !originalName || !mimeType) {
        return res.status(400).json({ error: "Missing required fields: imageData, originalName, mimeType" });
      }
      const uploadResult = await uploadImage(imageData, originalName, mimeType);
      const hostedImage = await storage.createHostedImage({
        userId: userId || null,
        fileName: uploadResult.fileName,
        originalName,
        mimeType: uploadResult.mimeType,
        sizeBytes: uploadResult.sizeBytes,
        storageUrl: uploadResult.storageUrl,
        publicUrl: uploadResult.publicUrl,
        title: title || null,
        description: description || null,
        businessName: businessName || null,
        businessLogo: businessLogo || null,
        isActive: true,
        expiresAt: null
      });
      res.json({
        id: hostedImage.id,
        publicUrl: `/view/${hostedImage.id}`,
        directUrl: uploadResult.publicUrl,
        landingUrl: `/view/${hostedImage.id}`
      });
    } catch (error) {
      console.error("Image upload error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/images/:imageId", async (req, res) => {
    try {
      const { imageId } = req.params;
      const images = await storage.getHostedImagesByUser("");
      const allImages = images.length > 0 ? images : [];
      const hostedImage = await storage.getHostedImage(imageId);
      if (!hostedImage) {
        const fileName = `hosted-images/${imageId}.jpeg`;
        const imageBuffer2 = await getImageBuffer(fileName);
        if (!imageBuffer2) {
          const pngFileName = `hosted-images/${imageId}.png`;
          const pngBuffer = await getImageBuffer(pngFileName);
          if (!pngBuffer) {
            return res.status(404).json({ error: "Image not found" });
          }
          res.setHeader("Content-Type", pngBuffer.mimeType);
          res.setHeader("Cache-Control", "public, max-age=31536000");
          return res.send(pngBuffer.buffer);
        }
        res.setHeader("Content-Type", imageBuffer2.mimeType);
        res.setHeader("Cache-Control", "public, max-age=31536000");
        return res.send(imageBuffer2.buffer);
      }
      const imageBuffer = await getImageBuffer(hostedImage.storageUrl);
      if (!imageBuffer) {
        return res.status(404).json({ error: "Image file not found" });
      }
      await storage.incrementImageViews(imageId);
      res.setHeader("Content-Type", imageBuffer.mimeType);
      res.setHeader("Cache-Control", "public, max-age=31536000");
      res.send(imageBuffer.buffer);
    } catch (error) {
      console.error("Image serve error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/images/info/:imageId", async (req, res) => {
    try {
      const { imageId } = req.params;
      const hostedImage = await storage.getHostedImage(imageId);
      if (!hostedImage || !hostedImage.isActive) {
        return res.status(404).json({ error: "Image not found" });
      }
      res.json({
        id: hostedImage.id,
        title: hostedImage.title,
        description: hostedImage.description,
        businessName: hostedImage.businessName,
        businessLogo: hostedImage.businessLogo,
        views: hostedImage.views,
        createdAt: hostedImage.createdAt
      });
    } catch (error) {
      console.error("Image info error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/images/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const images = await storage.getHostedImagesByUser(userId);
      res.json(images);
    } catch (error) {
      console.error("User images error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/images/:imageId", async (req, res) => {
    try {
      const { imageId } = req.params;
      const hostedImage = await storage.getHostedImage(imageId);
      if (!hostedImage) {
        return res.status(404).json({ error: "Image not found" });
      }
      await deleteImage(hostedImage.storageUrl);
      await storage.deleteHostedImage(imageId);
      res.json({ success: true });
    } catch (error) {
      console.error("Image delete error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/cart", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const items = await storage.getCartItemsByUser(userId);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/cart", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertCartItemSchema.parse({
        ...req.body,
        userId
      });
      const item = await storage.addCartItem(validatedData);
      res.json(item);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/cart/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { quantity } = req.body;
      const item = await storage.updateCartItem(id, quantity);
      if (!item) {
        return res.status(404).json({ error: "Cart item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/cart/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCartItem(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/stripe/publishable-key", async (req, res) => {
    try {
      const { getStripePublishableKey: getStripePublishableKey2 } = await Promise.resolve().then(() => (init_stripeClient(), stripeClient_exports));
      const key = await getStripePublishableKey2();
      res.json({ publishableKey: key });
    } catch (error) {
      res.status(500).json({ error: "Stripe not configured" });
    }
  });
  app3.post("/api/checkout", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const cartItems2 = await storage.getCartItemsByUser(userId);
      if (!cartItems2 || cartItems2.length === 0) {
        return res.status(400).json({ error: "Cart is empty" });
      }
      const { getUncachableStripeClient: getUncachableStripeClient2 } = await Promise.resolve().then(() => (init_stripeClient(), stripeClient_exports));
      const stripe = await getUncachableStripeClient2();
      const lineItems = cartItems2.map((item) => {
        const customization = item.customization || {};
        return {
          price_data: {
            currency: "usd",
            product_data: {
              name: customization.productName || "QR Gear Product",
              description: `${customization.productLine || "Custom"} QR - ${customization.variantName || "Standard"}`
            },
            unit_amount: Math.round(parseFloat(item.price || "0") * 100)
          },
          quantity: item.quantity || 1
        };
      });
      const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;
      const session2 = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: lineItems,
        mode: "payment",
        success_url: `${baseUrl}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${baseUrl}/cart`,
        metadata: {
          userId
        }
      });
      res.json({ url: session2.url, sessionId: session2.id });
    } catch (error) {
      console.error("Checkout error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/checkout/verify/:sessionId", isAuthenticated, async (req, res) => {
    try {
      const { sessionId } = req.params;
      const userId = req.user.claims.sub;
      const { getUncachableStripeClient: getUncachableStripeClient2 } = await Promise.resolve().then(() => (init_stripeClient(), stripeClient_exports));
      const stripe = await getUncachableStripeClient2();
      const session2 = await stripe.checkout.sessions.retrieve(sessionId);
      if (session2.payment_status !== "paid") {
        return res.status(400).json({ error: "Payment not completed" });
      }
      const existingOrder = await storage.getOrderByStripeSession(sessionId);
      if (existingOrder) {
        const items = await storage.getOrderItems(existingOrder.id);
        return res.json({ order: existingOrder, items, alreadyProcessed: true });
      }
      const cartItems2 = await storage.getCartItemsByUser(userId);
      const totalAmount = cartItems2.reduce((sum, item) => {
        return sum + parseFloat(item.price || "0") * (item.quantity || 1);
      }, 0);
      const order = await storage.createOrder({
        userId,
        status: "paid",
        totalAmount: totalAmount.toFixed(2),
        stripeSessionId: sessionId,
        stripePaymentIntentId: session2.payment_intent
      });
      const orderItemsList = [];
      for (const item of cartItems2) {
        await storage.createOrderItem({
          orderId: order.id,
          productId: item.productId,
          quantity: item.quantity || 1,
          price: item.price,
          customization: item.customization
        });
        orderItemsList.push({
          productId: item.productId,
          quantity: item.quantity || 1,
          price: item.price,
          customization: item.customization
        });
      }
      const user = await storage.getUser(userId);
      try {
        const unifiedItems = await Promise.all(orderItemsList.map(async (item) => {
          const product = await storage.getProduct(item.productId.toString());
          const customization = item.customization || {};
          return {
            masterProductId: customization.masterProductId || null,
            variantSku: customization.variantSku || customization.sku || `product-${item.productId}`,
            quantity: item.quantity,
            price: parseFloat(item.price),
            productTitle: product?.name || customization.productName || `Product #${item.productId}`,
            size: customization.selectedSize || customization.size || null,
            color: customization.selectedColor || customization.color || null
          };
        }));
        await storage.createOrderUnified({
          sourceChannel: "direct",
          externalOrderId: order.id,
          customerEmail: user?.email || null,
          customerName: user?.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : null,
          shippingAddress: null,
          // Will be collected during fulfillment
          items: unifiedItems,
          subtotal: totalAmount.toFixed(2),
          total: totalAmount.toFixed(2),
          status: "pending",
          // Pending fulfillment, payment is complete
          statusHistory: [
            { status: "paid", timestamp: (/* @__PURE__ */ new Date()).toISOString(), note: "Payment received via Stripe" },
            { status: "pending", timestamp: (/* @__PURE__ */ new Date()).toISOString(), note: "Awaiting fulfillment routing" }
          ]
        });
      } catch (unifiedErr) {
        console.error("Failed to create unified order:", unifiedErr);
      }
      for (const item of cartItems2) {
        await storage.deleteCartItem(item.id);
      }
      const orderItems2 = await storage.getOrderItems(order.id);
      if (user?.email) {
        sendOrderConfirmationEmail({
          orderId: order.id,
          customerEmail: user.email,
          customerName: user.firstName || "Customer",
          items: orderItems2.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            price: parseFloat(item.price)
          })),
          totalAmount,
          orderDate: /* @__PURE__ */ new Date()
        }).catch((err) => console.error("Failed to send order confirmation:", err));
      }
      res.json({ order, items: orderItems2 });
    } catch (error) {
      console.error("Verify checkout error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const orders2 = await storage.getOrdersByUser(userId);
      const ordersWithItems = await Promise.all(
        orders2.map(async (order) => {
          const items = await storage.getOrderItems(order.id);
          return { ...order, items };
        })
      );
      res.json(ordersWithItems);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/orders/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      if (order.userId !== userId) {
        return res.status(403).json({ error: "Access denied" });
      }
      const items = await storage.getOrderItems(id);
      res.json({ ...order, items });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedOrder = insertOrderSchema.parse({
        ...req.body.order,
        userId
      });
      const order = await storage.createOrder(validatedOrder);
      if (req.body.items && Array.isArray(req.body.items)) {
        for (const item of req.body.items) {
          const validatedItem = insertOrderItemSchema.parse({
            ...item,
            orderId: order.id
          });
          await storage.createOrderItem(validatedItem);
        }
      }
      res.json(order);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/orders/:id/submit-printify", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      if (order.userId !== userId) {
        return res.status(403).json({ error: "Access denied" });
      }
      const { shippingAddress } = req.body;
      if (!shippingAddress) {
        return res.status(400).json({ error: "Shipping address required" });
      }
      const result = await submitOrderToPrintify(id, shippingAddress);
      if (result.success) {
        res.json({ success: true, printifyOrderId: result.printifyOrderId });
      } else {
        res.status(500).json({ error: result.error });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/orders/:id/status", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      if (order.userId !== userId) {
        return res.status(403).json({ error: "Access denied" });
      }
      const status = await checkPrintifyOrderStatus(id);
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/settings", isAdmin, async (req, res) => {
    try {
      let settings = await storage.getAdminSettings();
      if (!settings) {
        settings = await storage.upsertAdminSettings({});
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/settings", isAdmin, async (req, res) => {
    try {
      const validated = insertAdminSettingsSchema.partial().parse(req.body);
      const settings = await storage.upsertAdminSettings(validated);
      res.json(settings);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/pricing-rules", isAdmin, async (req, res) => {
    try {
      const rules = await storage.getPricingRules();
      res.json(rules);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/pricing-rules", isAdmin, async (req, res) => {
    try {
      const validated = insertPricingRuleSchema.parse(req.body);
      const rule = await storage.createPricingRule(validated);
      res.json(rule);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/pricing-rules/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertPricingRuleSchema.partial().parse(req.body);
      const rule = await storage.updatePricingRule(id, validated);
      if (!rule) {
        return res.status(404).json({ error: "Pricing rule not found" });
      }
      res.json(rule);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/pricing-rules/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deletePricingRule(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/products", isAdmin, async (req, res) => {
    try {
      const products2 = await storage.getAllProducts();
      const enrichedProducts = await Promise.all(
        products2.map(async (product) => {
          const assignments = await storage.getProductCategoryAssignments(product.id);
          let cachedMinCost = null;
          let cachedMaxCost = null;
          let providerColors = null;
          let providerSizes = null;
          if (product.blueprintId && product.printProviderId) {
            const provider = await storage.getPrintifyPrintProvider(
              product.blueprintId,
              product.printProviderId
            );
            if (provider?.minCost) {
              cachedMinCost = Number(provider.minCost) / 100;
              cachedMaxCost = provider.maxCost ? Number(provider.maxCost) / 100 : cachedMinCost;
            }
            if (provider?.availableColors && Array.isArray(provider.availableColors)) {
              providerColors = provider.availableColors;
            }
            if (provider?.availableSizes && Array.isArray(provider.availableSizes)) {
              providerSizes = provider.availableSizes;
            }
          }
          let qrProductType = null;
          const meta = product.metadata;
          if (meta?.customDesignId) {
            const design = await storage.getCustomDesign(meta.customDesignId);
            if (design) {
              const hasTopText = design.topText && typeof design.topText === "object" && design.topText.text;
              const hasBottomText = design.bottomText && typeof design.bottomText === "object" && design.bottomText.text;
              const hasBackground = !!design.backgroundImageUrl;
              const hasVideo = !!design.videoUrl;
              const overlay = design.landingOverlay;
              const hasLandingOverlay = overlay?.enabled;
              if (design.templateVariant === "plain-text") {
                qrProductType = "qr-basics";
              } else if (design.templateVariant === "dynamics") {
                qrProductType = "qr-dynamics";
              } else if (design.templateVariant === "external-url") {
                qrProductType = "qr-basics";
              } else if (design.templateVariant === "url") {
                if (hasVideo) {
                  qrProductType = "qr-play";
                } else if (hasBackground || hasLandingOverlay) {
                  qrProductType = "qr-canvas";
                } else if (hasTopText || hasBottomText) {
                  qrProductType = "qr-plus";
                } else {
                  qrProductType = "qr-canvas";
                }
              }
            }
          }
          const finalColors = providerColors || product.availableColors || [];
          const finalSizes = providerSizes || product.availableSizes || [];
          return {
            ...product,
            availableColors: finalColors,
            availableSizes: finalSizes,
            categoryIds: assignments.map((a) => a.categoryId),
            cachedMinCost,
            cachedMaxCost,
            qrProductType
          };
        })
      );
      res.json(enrichedProducts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/products/:id/toggle", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { enabled } = req.body;
      const product = await storage.toggleProductEnabled(id, enabled);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/products/:id/options", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { enabledSizes, enabledColors } = req.body;
      const currentProduct = await storage.getProduct(id);
      if (!currentProduct) {
        return res.status(404).json({ error: "Product not found" });
      }
      const existingMetadata = currentProduct.metadata || {};
      const newMetadata = {
        ...existingMetadata,
        enabledSizes,
        enabledColors
      };
      const product = await storage.updateProduct(id, { metadata: newMetadata });
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/products/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validated);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/products/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteProduct(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/products/:id/regenerate-mockups", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      if (!product.blueprintId || !product.printProviderId) {
        return res.status(400).json({ error: "Product missing blueprint or provider info" });
      }
      const metadata = product.metadata;
      const designId = metadata?.customDesignId;
      if (!designId) {
        return res.status(400).json({ error: "Product has no custom design associated" });
      }
      const design = await storage.getCustomDesign(designId);
      if (!design) {
        return res.status(404).json({ error: "Custom design not found" });
      }
      const placementImages = design.placementImages;
      const artworkBlackUrl = placementImages?.["front-center"] || placementImages?.["front-chest"];
      const artworkWhiteUrl = placementImages?.["front-center-white"] || placementImages?.["front-chest-white"];
      if (!artworkBlackUrl) {
        return res.status(400).json({ error: "No artwork found for this design" });
      }
      const { generateAllColorMockups: generateAllColorMockups2 } = await Promise.resolve().then(() => (init_local_mockup_generator(), local_mockup_generator_exports));
      const colors = product.availableColors || [];
      console.log(`[Admin] Regenerating mockups for ${product.name} with ${colors.length} colors`);
      const mockupsByColor = await generateAllColorMockups2(
        product.blueprintId,
        product.printProviderId,
        colors,
        artworkBlackUrl,
        artworkWhiteUrl || artworkBlackUrl
      );
      await storage.updateProduct(id, { mockupsByColor });
      await db3.delete(mockupCache).where(
        and6(
          eq6(mockupCache.blueprintId, product.blueprintId),
          eq6(mockupCache.printProviderId, product.printProviderId)
        )
      );
      res.json({
        success: true,
        message: `Regenerated mockups for ${Object.keys(mockupsByColor).length} colors`,
        mockupsByColor
      });
    } catch (error) {
      console.error("[Admin] Failed to regenerate mockups:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/products/:id/generate-all-mockups", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      if (!product.blueprintId) {
        return res.status(400).json({ error: "Product missing blueprint info" });
      }
      const metadata = product.metadata;
      const designId = metadata?.customDesignId || id.replace("custom_", "");
      const design = await storage.getCustomDesign(designId);
      if (!design) {
        return res.status(404).json({ error: "Custom design not found" });
      }
      const allColors = product.availableColors || [];
      if (allColors.length === 0) {
        return res.status(400).json({ error: "No colors available for this product" });
      }
      console.log(`[Admin] Generating Printful mockups for ${product.name} - ${allColors.length} colors`);
      let designPlacements = {};
      try {
        if (typeof design.placementImages === "string") {
          designPlacements = JSON.parse(design.placementImages);
        } else if (design.placementImages && typeof design.placementImages === "object") {
          designPlacements = design.placementImages;
        }
      } catch (e) {
        console.error("[Admin] Failed to parse placementImages:", e);
      }
      const blackArtwork = designPlacements["front-chest"] || designPlacements["front-center"] || designPlacements["front"];
      const whiteArtwork = designPlacements["front-chest-white"] || designPlacements["front-center-white"];
      if (!blackArtwork) {
        return res.status(400).json({ error: "No artwork found for this design" });
      }
      const { getMockupWithFallback: getMockupWithFallback2, isColorDark: isColorDark4 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const results = [];
      const mockupsByColor = {};
      for (const colorInfo of allColors) {
        const color = colorInfo.name;
        const colorHex = colorInfo.hex;
        try {
          const needsWhiteQR = colorHex ? isColorDark4(colorHex) : false;
          const artworkUrl = needsWhiteQR && whiteArtwork ? whiteArtwork : blackArtwork;
          const artworkVariant = needsWhiteQR && whiteArtwork ? "white" : "black";
          console.log(`[Admin] Generating mockup for ${color} (${artworkVariant} QR)...`);
          const result = await getMockupWithFallback2({
            blueprintId: product.blueprintId,
            printProviderId: product.printProviderId || 0,
            colorName: color,
            colorHex,
            canonicalPlacementId: "FRONT_CHEST",
            artworkUrl,
            artworkVariant
          }, storage);
          mockupsByColor[color] = {
            front: result.mockupUrl,
            lifestyle: result.lifestyleMockupUrl || void 0
          };
          results.push({
            color,
            success: true,
            mockupUrl: result.mockupUrl,
            lifestyleUrl: result.lifestyleMockupUrl || void 0
          });
          console.log(`[Admin] \u2713 ${color} mockup generated (lifestyle: ${!!result.lifestyleMockupUrl})`);
          if (allColors.indexOf(colorInfo) < allColors.length - 1) {
            await new Promise((resolve) => setTimeout(resolve, 2e3));
          }
        } catch (error) {
          console.error(`[Admin] \u2717 ${color} mockup failed:`, error.message);
          results.push({
            color,
            success: false,
            error: error.message
          });
        }
      }
      await storage.updateProduct(id, { mockupsByColor });
      const successCount = results.filter((r) => r.success).length;
      res.json({
        success: true,
        message: `Generated ${successCount}/${allColors.length} mockups`,
        results,
        mockupsByColor
      });
    } catch (error) {
      console.error("[Admin] Failed to generate all mockups:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/products/apply-costs", isAdmin, async (req, res) => {
    try {
      const products2 = await storage.getAllProducts();
      const settings = await storage.getAdminSettings();
      const markupPercent = settings?.globalMarkupPercent ? parseFloat(settings.globalMarkupPercent) : 25;
      const markupFixed = settings?.globalMarkupFixed ? parseFloat(settings.globalMarkupFixed) : 0;
      const qrCost = settings?.globalQrProductionCost ? parseFloat(settings.globalQrProductionCost) : 2;
      let updated = 0;
      let skipped = 0;
      const results = [];
      for (const product of products2) {
        if (!product.blueprintId || !product.printProviderId) {
          skipped++;
          continue;
        }
        const provider = await storage.getPrintifyPrintProvider(
          product.blueprintId,
          product.printProviderId
        );
        if (!provider?.minCost) {
          skipped++;
          continue;
        }
        const productionCost = Number(provider.minCost) / 100;
        const totalCost = productionCost + qrCost + markupFixed;
        const retailPrice = Math.ceil(totalCost * (1 + markupPercent / 100) * 100) / 100;
        await storage.updateProduct(product.id, {
          basePrice: retailPrice.toFixed(2),
          qrProductionCost: qrCost.toFixed(2)
        });
        updated++;
        results.push({
          productId: product.id,
          name: product.name,
          cost: productionCost,
          price: retailPrice
        });
      }
      res.json({
        success: true,
        updated,
        skipped,
        markupPercent,
        markupFixed,
        qrCost,
        results: results.slice(0, 20)
        // Return first 20 for preview
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/products/:id/variants", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const variants = await storage.getProductVariants(id);
      res.json(variants);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/variants/:id/toggle", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { enabled } = req.body;
      const variant = await storage.toggleVariantEnabled(id, enabled);
      if (!variant) {
        return res.status(404).json({ error: "Variant not found" });
      }
      res.json(variant);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/printify/blueprints", isAdmin, async (req, res) => {
    try {
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const blueprints = await printify.getCatalogBlueprints();
      res.json(blueprints);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  const USA_MADE_BRANDS = [
    "american apparel",
    "royal apparel",
    "bayside",
    "los angeles apparel",
    "bella+canvas",
    "bella canvas",
    "lane seven",
    "cotton heritage",
    "shaka wear",
    "backpacks usa",
    "american giant",
    "next level"
    // Some Next Level products made in USA
  ];
  app3.get("/api/admin/printify/catalog", isAdmin, async (req, res) => {
    try {
      const localBlueprints = await storage.getPrintifyBlueprints();
      let blueprints;
      if (localBlueprints.length > 0) {
        blueprints = localBlueprints.map((bp) => ({
          id: bp.id,
          title: bp.title,
          brand: bp.brand,
          model: bp.model,
          images: bp.images || []
        }));
      } else {
        if (!printify) {
          return res.status(503).json({ error: "Printify API not configured. Please sync catalog first." });
        }
        blueprints = await printify.getCatalogBlueprints();
      }
      const categories = {
        "T-Shirts": [],
        "Sweatshirts & Hoodies": [],
        "Hats & Caps": [],
        "Drinkware": [],
        "Bags": [],
        "Other": []
      };
      for (const bp of blueprints) {
        const title = bp.title.toLowerCase();
        const brandLower = (bp.brand || "").toLowerCase();
        const isUSABrand = USA_MADE_BRANDS.some((usaBrand) => brandLower.includes(usaBrand));
        const item = {
          id: bp.id,
          title: bp.title,
          brand: bp.brand,
          model: bp.model,
          imageUrl: bp.images?.[0] || null,
          madeInUSA: isUSABrand,
          usaProviderCount: isUSABrand ? 1 : 0,
          otherCountries: isUSABrand ? [] : ["Imported"]
        };
        if (title.includes("t-shirt") || title.includes("tee") || title.includes("tank")) {
          categories["T-Shirts"].push(item);
        } else if (title.includes("hoodie") || title.includes("sweatshirt") || title.includes("crew") || title.includes("pullover")) {
          categories["Sweatshirts & Hoodies"].push(item);
        } else if (title.includes("hat") || title.includes("cap") || title.includes("beanie") || title.includes("visor")) {
          categories["Hats & Caps"].push(item);
        } else if (title.includes("mug") || title.includes("tumbler") || title.includes("bottle") || title.includes("cup") || title.includes("glass")) {
          categories["Drinkware"].push(item);
        } else if (title.includes("bag") || title.includes("tote") || title.includes("backpack") || title.includes("pouch")) {
          categories["Bags"].push(item);
        } else {
          categories["Other"].push(item);
        }
      }
      const result = Object.entries(categories).filter(([_, items]) => items.length > 0).map(([name, items]) => ({
        name,
        items,
        count: items.length,
        usaCount: items.filter((i) => i.madeInUSA).length,
        otherCount: items.filter((i) => !i.madeInUSA).length
      }));
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/printify/catalog/:blueprintId", isAdmin, async (req, res) => {
    try {
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const blueprintId = parseInt(req.params.blueprintId);
      const [blueprint, providers] = await Promise.all([
        printify.getBlueprintDetails(blueprintId),
        printify.getPrintProviders(blueprintId)
      ]);
      const usaProviders = providers.filter(
        (p) => p.location?.country === "US" || p.location?.country === "USA"
      );
      let variants = [];
      let selectedProvider = usaProviders[0] || providers[0];
      if (selectedProvider) {
        const variantData = await printify.getVariants(blueprintId, selectedProvider.id);
        variants = variantData.variants || [];
      }
      const colors = Array.from(new Set(variants.map((v) => v.options?.color).filter(Boolean)));
      const sizes = Array.from(new Set(variants.map((v) => v.options?.size).filter(Boolean)));
      let basePrice = 0;
      let maxPrice = 0;
      let costsFromDatabase = false;
      let cachedColors = null;
      let cachedSizes = null;
      if (selectedProvider) {
        const storedProvider = await storage.getPrintifyPrintProvider(blueprintId, selectedProvider.id);
        if (storedProvider?.minCost && storedProvider.minCost > 0) {
          basePrice = storedProvider.minCost / 100;
          maxPrice = (storedProvider.maxCost || storedProvider.minCost) / 100;
          costsFromDatabase = true;
        }
        if (storedProvider?.availableColors && Array.isArray(storedProvider.availableColors)) {
          cachedColors = storedProvider.availableColors;
        }
        if (storedProvider?.availableSizes && Array.isArray(storedProvider.availableSizes)) {
          cachedSizes = storedProvider.availableSizes;
        }
      }
      if (basePrice === 0) {
        const costs = variants.map((v) => v.cost || v.price || 0).filter((c) => c > 0);
        basePrice = costs.length > 0 ? Math.min(...costs) / 100 : 0;
        maxPrice = costs.length > 0 ? Math.max(...costs) / 100 : 0;
      }
      const finalColors = cachedColors || colors;
      const finalSizes = cachedSizes || sizes;
      const responseData = {
        blueprint,
        providers: usaProviders.length > 0 ? usaProviders : providers,
        selectedProvider,
        madeInUSA: usaProviders.length > 0,
        variants,
        colors: finalColors,
        sizes: finalSizes,
        basePrice,
        maxPrice,
        costsFromDatabase,
        colorsFromDatabase: cachedColors !== null,
        sizesFromDatabase: cachedSizes !== null,
        costsAvailable: basePrice > 0,
        imageUrl: blueprint.images?.[0] || null
      };
      res.json(responseData);
    } catch (error) {
      console.error(`Printify API error for blueprint ${req.params.blueprintId}:`, error.message);
      res.status(500).json({ error: `Printify API error: ${error.message}` });
    }
  });
  app3.post("/api/admin/printify/catalog/batch-details", isAdmin, async (req, res) => {
    try {
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const { blueprintIds } = req.body;
      if (!Array.isArray(blueprintIds) || blueprintIds.length === 0) {
        return res.status(400).json({ error: "blueprintIds array required" });
      }
      const limitedIds = blueprintIds.slice(0, 20);
      const results = {};
      for (const blueprintId of limitedIds) {
        try {
          const [blueprint, providers] = await Promise.all([
            printify.getBlueprintDetails(blueprintId),
            printify.getPrintProviders(blueprintId)
          ]);
          const usaProviders = providers.filter(
            (p) => p.location?.country === "US" || p.location?.country === "USA"
          );
          let variants = [];
          const selectedProvider = usaProviders[0] || providers[0];
          if (selectedProvider) {
            try {
              const variantData = await printify.getVariants(blueprintId, selectedProvider.id);
              variants = variantData.variants || [];
            } catch {
            }
          }
          const liveColors = Array.from(new Set(variants.map((v) => v.options?.color).filter(Boolean)));
          const liveSizes = Array.from(new Set(variants.map((v) => v.options?.size).filter(Boolean)));
          let basePrice = 0;
          let maxPrice = 0;
          let costsFromDatabase = false;
          let cachedColors = null;
          let cachedSizes = null;
          if (selectedProvider) {
            const storedProvider = await storage.getPrintifyPrintProvider(blueprintId, selectedProvider.id);
            if (storedProvider?.minCost && storedProvider.minCost > 0) {
              basePrice = storedProvider.minCost / 100;
              maxPrice = (storedProvider.maxCost || storedProvider.minCost) / 100;
              costsFromDatabase = true;
            }
            if (storedProvider?.availableColors && Array.isArray(storedProvider.availableColors)) {
              cachedColors = storedProvider.availableColors;
            }
            if (storedProvider?.availableSizes && Array.isArray(storedProvider.availableSizes)) {
              cachedSizes = storedProvider.availableSizes;
            }
          }
          if (basePrice === 0) {
            const costs = variants.map((v) => v.cost || 0).filter((c) => c > 0);
            basePrice = costs.length > 0 ? Math.min(...costs) / 100 : 0;
            maxPrice = costs.length > 0 ? Math.max(...costs) / 100 : 0;
          }
          const finalColors = cachedColors || liveColors;
          const finalSizes = cachedSizes || liveSizes;
          const data = {
            blueprintId,
            basePrice,
            maxPrice,
            costsAvailable: basePrice > 0,
            costsFromDatabase,
            colors: finalColors,
            sizes: finalSizes,
            colorsFromDatabase: cachedColors !== null,
            sizesFromDatabase: cachedSizes !== null,
            madeInUSA: usaProviders.length > 0,
            providerId: selectedProvider?.id,
            providerName: selectedProvider?.title
          };
          results[blueprintId] = data;
          await new Promise((resolve) => setTimeout(resolve, 100));
        } catch (err) {
          results[blueprintId] = {
            blueprintId,
            error: true,
            message: err.message || "Failed to fetch details"
          };
        }
      }
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/printify/blueprints/:id/providers", isAdmin, async (req, res) => {
    try {
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const { id } = req.params;
      const providers = await printify.getPrintProviders(parseInt(id));
      res.json(providers);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/printify/blueprints/:blueprintId/providers/:providerId/variants", isAdmin, async (req, res) => {
    try {
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const { blueprintId, providerId } = req.params;
      const variants = await printify.getVariants(parseInt(blueprintId), parseInt(providerId));
      res.json(variants);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/blueprints", isAdmin, async (req, res) => {
    try {
      const blueprints = await storage.getPrintifyBlueprints();
      const usaFilter = req.query.usaOnly === "true";
      const category = req.query.category;
      let filteredBlueprints = blueprints;
      if (category) {
        filteredBlueprints = filteredBlueprints.filter((bp) => bp.category === category);
      }
      if (usaFilter) {
        const blueprintIds = /* @__PURE__ */ new Set();
        for (const bp of filteredBlueprints) {
          const providers = await storage.getPrintifyPrintProviders(bp.id);
          if (providers.some((p) => p.isUSA)) {
            blueprintIds.add(bp.id);
          }
        }
        filteredBlueprints = filteredBlueprints.filter((bp) => blueprintIds.has(bp.id));
      }
      res.json({
        blueprints: filteredBlueprints,
        total: filteredBlueprints.length
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/blueprints/:id", isAdmin, async (req, res) => {
    try {
      const blueprintId = parseInt(req.params.id);
      const blueprint = await storage.getPrintifyBlueprint(blueprintId);
      if (!blueprint) {
        return res.status(404).json({ error: "Blueprint not found in local catalog" });
      }
      const providers = await storage.getPrintifyPrintProviders(blueprintId);
      const usaProviders = providers.filter((p) => p.isUSA);
      const selectedProvider = usaProviders[0] || providers[0];
      let colors = [];
      let sizes = [];
      let basePrice = 0;
      let maxPrice = 0;
      if (selectedProvider) {
        if (selectedProvider.availableColors && Array.isArray(selectedProvider.availableColors)) {
          colors = selectedProvider.availableColors;
        }
        if (selectedProvider.availableSizes && Array.isArray(selectedProvider.availableSizes)) {
          sizes = selectedProvider.availableSizes;
        }
        if (selectedProvider.minCost) {
          basePrice = selectedProvider.minCost / 100;
          maxPrice = (selectedProvider.maxCost || selectedProvider.minCost) / 100;
        }
      }
      res.json({
        ...blueprint,
        providers,
        usaProviders,
        selectedProvider,
        colors,
        sizes,
        basePrice,
        maxPrice,
        costsAvailable: basePrice > 0,
        colorsFromDatabase: colors.length > 0,
        sizesFromDatabase: sizes.length > 0
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/providers/:blueprintId/:providerId", isAdmin, async (req, res) => {
    try {
      const blueprintId = parseInt(req.params.blueprintId);
      const providerId = parseInt(req.params.providerId);
      const provider = await storage.getPrintifyPrintProvider(blueprintId, providerId);
      if (!provider) {
        return res.status(404).json({ error: "Provider not found in local catalog" });
      }
      const colors = provider.availableColors && Array.isArray(provider.availableColors) ? provider.availableColors : [];
      const sizes = provider.availableSizes && Array.isArray(provider.availableSizes) ? provider.availableSizes : [];
      res.json({
        ...provider,
        colors,
        sizes,
        basePrice: provider.minCost ? provider.minCost / 100 : 0,
        maxPrice: provider.maxCost ? provider.maxCost / 100 : provider.minCost ? provider.minCost / 100 : 0,
        costsAvailable: provider.minCost !== null && provider.minCost > 0,
        colorsFromDatabase: colors.length > 0,
        sizesFromDatabase: sizes.length > 0
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/sync-status", isAdmin, async (req, res) => {
    try {
      const latestSync = await storage.getLatestCatalogSync();
      const totalBlueprints = (await storage.getPrintifyBlueprints()).length;
      res.json({
        latestSync,
        totalBlueprints,
        isConfigured: printify?.isConfigured || false
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/sync-history", isAdmin, async (req, res) => {
    try {
      const history = await storage.getCatalogSyncHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/catalog/sync", isAdmin, async (req, res) => {
    try {
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const latestSync = await storage.getLatestCatalogSync();
      if (latestSync?.status === "running") {
        return res.status(409).json({ error: "Sync already in progress" });
      }
      const syncRecord = await storage.createCatalogSync({
        syncType: "full",
        status: "running",
        blueprintsCount: 0,
        providersCount: 0
      });
      res.json({ syncId: syncRecord.id, status: "started" });
      (async () => {
        try {
          console.log("[Catalog Sync] Starting full catalog sync...");
          const blueprints = await printify.getCatalogBlueprints();
          console.log(`[Catalog Sync] Found ${blueprints.length} blueprints`);
          let blueprintsCount = 0;
          let providersCount = 0;
          for (const bp of blueprints) {
            try {
              await storage.upsertPrintifyBlueprint({
                id: bp.id,
                title: bp.title,
                description: bp.description || null,
                brand: bp.brand || null,
                model: bp.model || null,
                images: bp.images || null,
                primaryImageUrl: bp.images?.[0] || null,
                category: detectCategory(bp.title, bp.brand || "")
              });
              blueprintsCount++;
              const providers = await printify.getPrintProviders(bp.id);
              for (const provider of providers) {
                const isUSA = provider.location?.country === "US" || provider.location?.country === "USA";
                await storage.upsertPrintifyPrintProvider({
                  blueprintId: bp.id,
                  providerId: provider.id,
                  title: provider.title,
                  country: provider.location?.country || null,
                  isUSA
                });
                providersCount++;
              }
              await new Promise((r) => setTimeout(r, 100));
            } catch (bpError) {
              console.error(`[Catalog Sync] Error syncing blueprint ${bp.id}:`, bpError.message);
            }
          }
          await storage.updateCatalogSync(syncRecord.id, {
            status: "completed",
            blueprintsCount,
            providersCount,
            completedAt: /* @__PURE__ */ new Date()
          });
          console.log(`[Catalog Sync] Completed. ${blueprintsCount} blueprints, ${providersCount} providers`);
        } catch (error) {
          console.error("[Catalog Sync] Error:", error.message);
          await storage.updateCatalogSync(syncRecord.id, {
            status: "failed",
            errorMessage: error.message,
            completedAt: /* @__PURE__ */ new Date()
          });
        }
      })();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/catalog/clear", isAdmin, async (req, res) => {
    try {
      await storage.clearPrintifyPrintProviders();
      await storage.clearPrintifyBlueprints();
      res.json({ success: true, message: "Local catalog cleared" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/catalog/fetch-costs", isAdmin, async (req, res) => {
    try {
      const { blueprintId, providerId, deleteAfter = true } = req.body;
      if (!blueprintId || !providerId) {
        return res.status(400).json({ error: "blueprintId and providerId are required" });
      }
      if (!printify) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      console.log(`[Cost Fetch] Fetching costs for blueprint ${blueprintId}, provider ${providerId}...`);
      const variantsResult = await printify.getVariants(blueprintId, providerId);
      const variantIds = variantsResult.variants.map((v) => v.id);
      if (variantIds.length === 0) {
        return res.status(404).json({ error: "No variants found for this blueprint/provider combo" });
      }
      const { placement, variantIds: compatibleVariantIds } = await printify.getCommonPlacement(blueprintId, providerId);
      console.log(`[Cost Fetch] Using placement '${placement}' with ${compatibleVariantIds.length} compatible variants`);
      const imageId = await printify.getOrCreatePlaceholderImage();
      console.log(`[Cost Fetch] Using placeholder image: ${imageId}`);
      const placeholderProduct = await printify.createPlaceholderProduct(
        blueprintId,
        providerId,
        compatibleVariantIds,
        imageId,
        placement
      );
      console.log(`[Cost Fetch] Created placeholder product ${placeholderProduct.id}, extracting costs...`);
      const costs = printify.extractCostsFromProduct(placeholderProduct);
      console.log(`[Cost Fetch] Extracted costs: min=$${(costs.minCost / 100).toFixed(2)}, max=$${(costs.maxCost / 100).toFixed(2)}`);
      const updatedProvider = await storage.updatePrintifyProviderCosts(
        blueprintId,
        providerId,
        {
          minCost: costs.minCost,
          maxCost: costs.maxCost,
          placeholderProductId: deleteAfter ? void 0 : placeholderProduct.id
        }
      );
      if (deleteAfter) {
        try {
          await printify.deleteProduct(placeholderProduct.id);
          console.log(`[Cost Fetch] Deleted placeholder product ${placeholderProduct.id}`);
        } catch (deleteError) {
          console.warn(`[Cost Fetch] Could not delete placeholder product: ${deleteError.message}`);
        }
      }
      res.json({
        success: true,
        blueprintId,
        providerId,
        placement,
        minCost: costs.minCost,
        maxCost: costs.maxCost,
        minCostFormatted: `$${(costs.minCost / 100).toFixed(2)}`,
        maxCostFormatted: `$${(costs.maxCost / 100).toFixed(2)}`,
        variantsChecked: compatibleVariantIds.length,
        placeholderDeleted: deleteAfter,
        note: `Cost includes: blank item + one print on '${placement}' position`
      });
    } catch (error) {
      console.error("[Cost Fetch] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/catalog/sync-all-costs", isAdmin, async (req, res) => {
    try {
      if (!printify.isConfigured) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      if (isCostSyncRunning()) {
        return res.status(409).json({ error: "Cost sync already in progress" });
      }
      const forceRefresh = req.body?.forceRefresh === true;
      const costSync = await startCostSync({ forceRefresh });
      if (!costSync) {
        return res.status(400).json({ error: "Failed to start cost sync. Check that catalog is synced first." });
      }
      res.json({
        success: true,
        message: "Cost sync started in background",
        syncId: costSync.id,
        totalProviders: costSync.totalProviders
      });
    } catch (error) {
      console.error("[Cost Sync] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/cost-sync-status", isAdmin, async (req, res) => {
    try {
      const status = await getCostSyncStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/catalog/cancel-cost-sync", isAdmin, async (req, res) => {
    try {
      cancelCostSync();
      res.json({ success: true, message: "Cost sync cancellation requested" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/catalog/refresh-color-hex", isAdmin, async (req, res) => {
    try {
      if (!printify.isConfigured) {
        return res.status(503).json({ error: "Printify API not configured" });
      }
      const allProviders = await storage.getAllPrintifyProviders();
      const providersNeedingHex = allProviders.filter((p) => {
        if (!p.availableColors || !Array.isArray(p.availableColors)) return false;
        return p.availableColors.some((c) => !c.hex);
      });
      console.log(`[Color Hex Refresh] Found ${providersNeedingHex.length} providers needing hex values`);
      let successCount = 0;
      let failedCount = 0;
      const errors = [];
      for (const provider of providersNeedingHex) {
        try {
          const catalogData = await syncProductVariants(provider.blueprintId, provider.providerId);
          await storage.updatePrintifyProviderCosts(provider.blueprintId, provider.providerId, {
            minCost: 0,
            // Preserve existing costs when just updating colors
            maxCost: 0,
            availableColors: catalogData.colors,
            availableSizes: catalogData.sizes
          });
          successCount++;
          console.log(`[Color Hex Refresh] Updated ${provider.blueprintId}/${provider.providerId} with ${catalogData.colors.length} colors`);
          await new Promise((r) => setTimeout(r, 1e3));
        } catch (err) {
          failedCount++;
          errors.push(`${provider.blueprintId}/${provider.providerId}: ${err.message}`);
        }
      }
      res.json({
        success: true,
        message: `Color hex refresh complete`,
        totalProcessed: providersNeedingHex.length,
        successCount,
        failedCount,
        errors: errors.slice(0, 10)
        // First 10 errors only
      });
    } catch (error) {
      console.error("[Color Hex Refresh] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/catalog/sync-printful", isAdmin, async (req, res) => {
    try {
      const { syncPrintfulCatalog: syncPrintfulCatalog2, printfulClient: printfulClient2 } = await Promise.resolve().then(() => (init_printful(), printful_exports));
      if (!printfulClient2.isConfigured) {
        return res.status(503).json({ error: "Printful API key not configured" });
      }
      const productIds = req.body?.productIds;
      res.json({
        success: true,
        message: "Printful catalog sync started in background",
        productIds: productIds || "all"
      });
      try {
        const result = await syncPrintfulCatalog2(db3, productIds ? { productIds } : void 0);
        console.log("[Printful Sync] Background sync complete:", result);
      } catch (syncError) {
        console.error("[Printful Sync] Background sync error:", syncError.message);
      }
    } catch (error) {
      console.error("[Printful Sync] Error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/printful-status", isAdmin, async (req, res) => {
    try {
      const { printfulClient: printfulClient2 } = await Promise.resolve().then(() => (init_printful(), printful_exports));
      const { printfulProducts: printfulProducts2, printfulVariants: printfulVariants2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const { count } = await import("drizzle-orm");
      const [productCount] = await db3.select({ count: count() }).from(printfulProducts2);
      const [variantCount] = await db3.select({ count: count() }).from(printfulVariants2);
      const isConfigured = printfulClient2.isConfigured;
      console.log("[Printful Status] isConfigured:", isConfigured);
      res.json({
        isConfigured,
        productCount: productCount?.count || 0,
        variantCount: variantCount?.count || 0
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/catalog/printful-products", isAdmin, async (req, res) => {
    try {
      const { printfulProducts: printfulProducts2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const { desc: desc4 } = await import("drizzle-orm");
      const products2 = await db3.select().from(printfulProducts2).orderBy(desc4(printfulProducts2.lastSyncedAt));
      res.json(products2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/products/from-printify", isAdmin, async (req, res) => {
    try {
      const { blueprintId, printProviderId, name, description, category, basePrice, imageUrl, manufacturer, madeInUSA, availablePlacements, availableColors, metadata } = req.body;
      const productId = `printify_${blueprintId}_${printProviderId}_${Date.now()}`;
      const product = await storage.createProduct({
        id: productId,
        printifyId: null,
        blueprintId,
        printProviderId,
        name,
        description,
        category,
        basePrice: basePrice.toString(),
        imageUrl,
        manufacturer,
        madeInUSA: madeInUSA || false,
        availablePlacements,
        availableColors,
        metadata,
        isEnabled: false,
        markupPercent: "0",
        markupFixed: "0",
        qrProductionCost: "0",
        sortOrder: 0
      });
      const { variantsSeeded, syncWarning } = await autoSyncVariantsFromLocalCatalog(
        product.id,
        blueprintId,
        printProviderId,
        basePrice.toString(),
        metadata || {}
        // Pass existing metadata to be merged, not overwritten
      );
      if (category === "Kingdom Connects" && metadata?.kcPlacements?.length > 0) {
        const partnerStores2 = await storage.getPartnerStores();
        const kcStore = partnerStores2.find((p) => p.slug === "kingdom-connects");
        if (kcStore) {
          await storage.addPartnerStoreProduct({
            partnerStoreId: kcStore.id,
            productId: product.id,
            kcPlacements: metadata.kcPlacements,
            kcBusinessSlug: metadata.kcBusinessSlug || null,
            sortOrder: 0,
            isEnabled: true
          });
        }
      }
      res.json({
        ...product,
        variantsSeeded,
        syncWarning
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/products/:id/sync-printify", isAdmin, async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      if (!product.blueprintId || !product.printProviderId) {
        return res.status(400).json({ error: "Product missing Printify blueprint or provider IDs" });
      }
      const { placements, mockupImageUrl } = await syncProductPlacements(
        product.blueprintId,
        product.printProviderId
      );
      const { colors, sizes, variants } = await syncProductVariants(
        product.blueprintId,
        product.printProviderId
      );
      for (const variant of variants) {
        await storage.upsertProductVariant({
          productId: product.id,
          printifyVariantId: variant.id,
          title: variant.title,
          size: variant.options?.size || null,
          color: variant.options?.color || null,
          colorHex: variant.options?.color ? colors.find((c) => c.name === variant.options?.color)?.hex || null : null,
          price: String((variant.price || 0) / 100),
          // Printify prices are in cents
          isEnabled: true,
          // Default all new variants to enabled
          isInStock: variant.is_available ?? true
        });
      }
      const updatedProduct = await storage.updateProduct(product.id, {
        availablePlacements: placements.map((p) => p.position),
        availableColors: colors,
        availableSizes: sizes,
        imageUrl: mockupImageUrl || product.imageUrl,
        metadata: {
          ...product.metadata || {},
          placementDetails: placements,
          lastSyncedAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      });
      res.json({
        success: true,
        product: updatedProduct,
        syncedData: { placements, colors, sizes, mockupImageUrl, variantsCount: variants.length }
      });
    } catch (error) {
      console.error("Product sync error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/gallery", async (req, res) => {
    try {
      const designs = await storage.getPublicGalleryDesigns();
      const enrichedDesigns = await Promise.all(
        designs.map(async (design) => {
          const product = design.productId ? await storage.getProduct(design.productId) : null;
          return { ...design, product };
        })
      );
      res.json(enrichedDesigns);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/sitemap.xml", async (req, res) => {
    try {
      const baseUrl = `${req.protocol}://${req.get("host")}`;
      const products2 = await storage.getAllProducts();
      const enabledProducts = products2.filter((p) => p.isEnabled);
      const staticPages2 = [
        { loc: "/", priority: "1.0", changefreq: "daily" },
        { loc: "/store", priority: "0.9", changefreq: "daily" },
        { loc: "/creator", priority: "0.9", changefreq: "weekly" },
        { loc: "/gallery", priority: "0.8", changefreq: "daily" },
        { loc: "/cart", priority: "0.5", changefreq: "weekly" }
      ];
      const productPages = enabledProducts.map((p) => ({
        loc: `/store?product=${p.id}`,
        priority: "0.7",
        changefreq: "weekly",
        lastmod: p.updatedAt?.toISOString().split("T")[0]
      }));
      const allPages = [...staticPages2, ...productPages];
      const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${allPages.map((page) => `  <url>
    <loc>${baseUrl}${page.loc}</loc>
    <priority>${page.priority}</priority>
    <changefreq>${page.changefreq}</changefreq>
    ${page.lastmod ? `<lastmod>${page.lastmod}</lastmod>` : ""}
  </url>`).join("\n")}
</urlset>`;
      res.set("Content-Type", "application/xml");
      res.send(xml);
    } catch (error) {
      res.status(500).send("Error generating sitemap");
    }
  });
  app3.get("/api/designs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const designs = await storage.getQrDesignsByUser(userId);
      res.json(designs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/designs/:id", isAuthenticated, async (req, res) => {
    try {
      const design = await storage.getQrDesign(req.params.id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      if (design.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      res.json(design);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/designs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertQrDesignSchema.parse({
        ...req.body,
        userId
      });
      const design = await storage.createQrDesign(validatedData);
      res.status(201).json(design);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/designs/:id", isAuthenticated, async (req, res) => {
    try {
      const design = await storage.getQrDesign(req.params.id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      if (design.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      const updated = await storage.updateQrDesign(req.params.id, req.body);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/designs/:id", isAuthenticated, async (req, res) => {
    try {
      const design = await storage.getQrDesign(req.params.id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      if (design.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      await storage.deleteQrDesign(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/product-categories", isAdmin, async (req, res) => {
    try {
      const categories = await storage.getAllProductCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/product-categories", async (req, res) => {
    try {
      const taxonomyType = req.query.taxonomy;
      let categories;
      if (taxonomyType) {
        categories = await storage.getProductCategoriesByTaxonomy(taxonomyType);
      } else {
        categories = await storage.getActiveProductCategories();
      }
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/product-categories/:id/products", async (req, res) => {
    try {
      const products2 = await storage.getProductsByCategory(req.params.id);
      const enabledProducts = products2.filter((p) => p.isEnabled);
      res.json(enabledProducts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/products/:id/categories", async (req, res) => {
    try {
      const assignments = await storage.getProductCategoryAssignments(req.params.id);
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/product-categories", isAdmin, async (req, res) => {
    try {
      const { name, slug, description, taxonomyType, icon, parentId, sortOrder, isActive } = req.body;
      const category = await storage.createProductCategory({
        name,
        slug: slug || name.toLowerCase().replace(/\s+/g, "-"),
        description,
        taxonomyType,
        icon,
        parentId,
        sortOrder,
        isActive
      });
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/product-categories/:id", isAdmin, async (req, res) => {
    try {
      const updated = await storage.updateProductCategory(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/product-categories/:id", isAdmin, async (req, res) => {
    try {
      await storage.deleteProductCategory(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/products/:id/categories", isAdmin, async (req, res) => {
    try {
      const { categoryIds } = req.body;
      await storage.syncProductCategories(req.params.id, categoryIds || []);
      const assignments = await storage.getProductCategoryAssignments(req.params.id);
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/product-categories/seed", isAdmin, async (req, res) => {
    try {
      const defaultCategories = [
        // Seasons
        { name: "Spring", slug: "spring", taxonomyType: "season", icon: "Flower2", sortOrder: 1 },
        { name: "Summer", slug: "summer", taxonomyType: "season", icon: "Sun", sortOrder: 2 },
        { name: "Fall", slug: "fall", taxonomyType: "season", icon: "Leaf", sortOrder: 3 },
        { name: "Winter", slug: "winter", taxonomyType: "season", icon: "Snowflake", sortOrder: 4 },
        // Holidays
        { name: "Christmas", slug: "christmas", taxonomyType: "holiday", icon: "Gift", sortOrder: 1 },
        { name: "Easter", slug: "easter", taxonomyType: "holiday", icon: "Egg", sortOrder: 2 },
        { name: "Valentine's Day", slug: "valentines", taxonomyType: "holiday", icon: "Heart", sortOrder: 3 },
        { name: "Halloween", slug: "halloween", taxonomyType: "holiday", icon: "Ghost", sortOrder: 4 },
        { name: "Thanksgiving", slug: "thanksgiving", taxonomyType: "holiday", icon: "Utensils", sortOrder: 5 },
        { name: "Fourth of July", slug: "july-4th", taxonomyType: "holiday", icon: "Flag", sortOrder: 6 },
        { name: "Mother's Day", slug: "mothers-day", taxonomyType: "holiday", icon: "Heart", sortOrder: 7 },
        { name: "Father's Day", slug: "fathers-day", taxonomyType: "holiday", icon: "Trophy", sortOrder: 8 },
        // Occasions
        { name: "Birthday", slug: "birthday", taxonomyType: "occasion", icon: "Cake", sortOrder: 1 },
        { name: "Anniversary", slug: "anniversary", taxonomyType: "occasion", icon: "HeartHandshake", sortOrder: 2 },
        { name: "Graduation", slug: "graduation", taxonomyType: "occasion", icon: "GraduationCap", sortOrder: 3 },
        { name: "Wedding", slug: "wedding", taxonomyType: "occasion", icon: "Gem", sortOrder: 4 },
        { name: "Baby Shower", slug: "baby-shower", taxonomyType: "occasion", icon: "Baby", sortOrder: 5 },
        // Other
        { name: "Religious", slug: "religious", taxonomyType: "other", icon: "Church", sortOrder: 1 },
        { name: "Sports", slug: "sports", taxonomyType: "other", icon: "Trophy", sortOrder: 2 },
        { name: "Business", slug: "business", taxonomyType: "other", icon: "Briefcase", sortOrder: 3 },
        { name: "Patriotic", slug: "patriotic", taxonomyType: "other", icon: "Flag", sortOrder: 4 }
      ];
      const created = [];
      for (const cat of defaultCategories) {
        try {
          const category = await storage.createProductCategory({
            ...cat,
            isActive: true
          });
          created.push(category);
        } catch (e) {
        }
      }
      res.json({ created: created.length, categories: created });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/partner-stores/:id/products", isAdmin, async (req, res) => {
    try {
      const storeProducts = await storage.getPartnerStoreProducts(req.params.id);
      const enrichedProducts = await Promise.all(
        storeProducts.map(async (sp) => {
          const product = await storage.getProduct(sp.productId);
          return {
            ...sp,
            availableSizes: product?.availableSizes || [],
            availableColors: product?.availableColors || []
          };
        })
      );
      res.json(enrichedProducts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/partner-stores/:id/products", isAdmin, async (req, res) => {
    try {
      const { productIds } = req.body;
      if (!Array.isArray(productIds)) {
        return res.status(400).json({ error: "productIds must be an array" });
      }
      await storage.syncPartnerStoreProducts(req.params.id, productIds);
      const products2 = await storage.getPartnerStoreProducts(req.params.id);
      res.json(products2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/partner-stores/:storeId/products/:productId", isAdmin, async (req, res) => {
    try {
      const { storeId, productId } = req.params;
      const { enabledSizes, enabledColors, defaultColor, kcPlacements, kcBusinessSlug, customPrice, customName, isEnabled } = req.body;
      const updated = await storage.updatePartnerStoreProductByIds(storeId, productId, {
        enabledSizes,
        enabledColors,
        defaultColor,
        kcPlacements,
        kcBusinessSlug,
        customPrice,
        customName,
        isEnabled
      });
      if (!updated) {
        return res.status(404).json({ error: "Partner store product not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/partner-stores/:storeId/products/:productId/generate-mockup", isAdmin, async (req, res) => {
    try {
      const { storeId, productId } = req.params;
      const { color } = req.body;
      if (!color) {
        return res.status(400).json({ error: "color is required" });
      }
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      const blueprintId = product.blueprintId;
      const printProviderId = product.printProviderId;
      if (!blueprintId || !printProviderId) {
        return res.status(400).json({ error: "Product missing blueprint or print provider" });
      }
      let artworkUrl = null;
      if (productId.startsWith("custom_")) {
        const designId = productId.replace("custom_", "");
        const design = await storage.getCustomDesign(designId);
        if (design) {
          let designPlacements = {};
          try {
            if (typeof design.placementImages === "string") {
              designPlacements = JSON.parse(design.placementImages);
            } else if (design.placementImages && typeof design.placementImages === "object") {
              designPlacements = design.placementImages;
            }
          } catch (e) {
            console.error("[Mockup] Failed to parse placementImages:", e);
          }
          const { getProviderColorsWithFallback: getProviderColorsWithFallback2 } = await Promise.resolve().then(() => (init_printify(), printify_exports));
          const colors = await getProviderColorsWithFallback2(blueprintId, printProviderId, storage);
          const colorInfo = colors.find(
            (c) => c.name?.toLowerCase() === color.toLowerCase()
          );
          const colorHex = colorInfo?.hex || null;
          const { isColorDark: isColorDark4 } = await Promise.resolve().then(() => (init_composite_image_generator(), composite_image_generator_exports));
          const needsWhiteQR = colorHex ? isColorDark4(colorHex) : false;
          const blackArtwork = designPlacements["front-chest"] || designPlacements["front-chest-black"];
          const whiteArtwork = designPlacements["front-chest-white"];
          if (needsWhiteQR && whiteArtwork) {
            artworkUrl = whiteArtwork;
            console.log(`[Mockup] Using WHITE artwork for dark shirt color: ${color} (${colorHex})`);
          } else if (blackArtwork) {
            artworkUrl = blackArtwork;
            console.log(`[Mockup] Using BLACK artwork for light shirt color: ${color} (${colorHex})`);
          } else {
            artworkUrl = design.printifyCompositeUrl || Object.values(designPlacements)[0];
          }
        }
      }
      if (!artworkUrl) {
        return res.status(400).json({ error: "No artwork found for this product" });
      }
      const baseUrl = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "http://localhost:5000";
      const absoluteArtworkUrl = artworkUrl.startsWith("http") ? artworkUrl : `${baseUrl}${artworkUrl}`;
      console.log(`[Mockup] Generating for product ${productId}, color ${color}`);
      console.log(`[Mockup] Blueprint: ${blueprintId}, Provider: ${printProviderId}`);
      console.log(`[Mockup] Artwork: ${absoluteArtworkUrl}`);
      const { printify: printify2, syncProductVariants: syncProductVariants2, syncProductPlacements: syncProductPlacements2 } = await Promise.resolve().then(() => (init_printify(), printify_exports));
      const { variants } = await syncProductVariants2(blueprintId, printProviderId);
      const colorVariants = variants.filter(
        (v) => v.options?.color && v.options.color.toLowerCase() === color.toLowerCase()
      );
      if (colorVariants.length === 0) {
        return res.status(400).json({ error: `No variants found for color: ${color}` });
      }
      const variantIds = colorVariants.slice(0, 1).map((v) => v.id);
      console.log(`[Mockup] Found ${colorVariants.length} variants for ${color}, using: ${variantIds[0]}`);
      const imageUpload = await printify2.uploadImage(absoluteArtworkUrl, `mockup-${productId}-${color}.png`);
      console.log(`[Mockup] Uploaded image ID: ${imageUpload.id}`);
      const { placements: providerPlacements } = await syncProductPlacements2(blueprintId, printProviderId);
      const placement = providerPlacements[0]?.position || "front";
      const productData = {
        title: `Mockup - ${product.name} - ${color}`,
        description: `Mockup generation for ${color}`,
        blueprint_id: blueprintId,
        print_provider_id: printProviderId,
        variants: variantIds.map((vid) => ({
          id: vid,
          price: 2500,
          is_enabled: true
        })),
        print_areas: [{
          variant_ids: variantIds,
          placeholders: [{
            position: placement,
            images: [{
              id: imageUpload.id,
              x: 0.5,
              y: 0.5,
              scale: 1,
              angle: 0
            }]
          }]
        }]
      };
      const printifyProduct = await printify2.createProduct(productData);
      console.log(`[Mockup] Created Printify product: ${printifyProduct.id}`);
      let attempts = 0;
      const maxAttempts = 10;
      let mockupUrl = null;
      while (attempts < maxAttempts && !mockupUrl) {
        const delay = Math.min(2e3 * Math.pow(1.5, attempts), 8e3);
        await new Promise((resolve) => setTimeout(resolve, delay));
        attempts++;
        const productDetails = await printify2.getProduct(printifyProduct.id);
        if (productDetails.images && productDetails.images.length > 0) {
          mockupUrl = productDetails.images[0].src;
          console.log(`[Mockup] Got mockup URL: ${mockupUrl}`);
        }
      }
      if (!mockupUrl) {
        await printify2.deleteProduct(printifyProduct.id).catch(() => {
        });
        return res.status(500).json({ error: "Mockup generation timed out" });
      }
      const storeProduct = await storage.getPartnerStoreProduct(storeId, productId);
      const existingMockups = storeProduct?.mockupsByColor || {};
      existingMockups[color] = { front: mockupUrl };
      await storage.updatePartnerStoreProductByIds(storeId, productId, {
        mockupsByColor: existingMockups
      });
      await printify2.deleteProduct(printifyProduct.id).catch(() => {
      });
      console.log(`[Mockup] Saved mockup for ${color}`);
      res.json({ success: true, color, mockupUrl, mockupsByColor: existingMockups });
    } catch (error) {
      console.error("[Mockup] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/placements", async (req, res) => {
    try {
      const { category } = req.query;
      const { getCanonicalPlacements: getCanonicalPlacements2 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const placements = await getCanonicalPlacements2(category);
      res.json(placements);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/mockups/get-or-generate", async (req, res) => {
    try {
      const {
        blueprintId,
        printProviderId,
        colorName,
        colorHex,
        canonicalPlacementId = "FRONT_CHEST",
        artworkUrl,
        artworkVariant = "black"
      } = req.body;
      if (!blueprintId || !printProviderId || !colorName || !artworkUrl) {
        return res.status(400).json({
          error: "Missing required fields: blueprintId, printProviderId, colorName, artworkUrl"
        });
      }
      const { getMockupWithFallback: getMockupWithFallback2 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const result = await getMockupWithFallback2({
        blueprintId: parseInt(blueprintId),
        printProviderId: parseInt(printProviderId),
        colorName,
        colorHex,
        canonicalPlacementId,
        artworkUrl,
        artworkVariant
      }, storage);
      res.json(result);
    } catch (error) {
      console.error("[MockupAPI] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/mockups/cached/:blueprintId/:printProviderId", async (req, res) => {
    try {
      const { blueprintId, printProviderId } = req.params;
      const { getCachedMockupsForProduct: getCachedMockupsForProduct2 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const mockups = await getCachedMockupsForProduct2(
        parseInt(blueprintId),
        parseInt(printProviderId)
      );
      res.json({ mockups, count: Object.keys(mockups).length });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/mockups/lifestyle", async (req, res) => {
    try {
      const {
        blueprintId,
        printProviderId,
        colorName,
        colorHex,
        qrContent = "https://qrgear.shop",
        productType = "shirt"
      } = req.body;
      if (!blueprintId || !printProviderId || !colorName) {
        return res.status(400).json({
          error: "Missing required fields: blueprintId, printProviderId, colorName"
        });
      }
      const { getLifestyleMockupForColor: getLifestyleMockupForColor2 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const result = await getLifestyleMockupForColor2({
        blueprintId: parseInt(blueprintId),
        printProviderId: parseInt(printProviderId),
        colorName,
        colorHex,
        qrContent,
        productType
      }, storage);
      res.json(result);
    } catch (error) {
      console.error("[LifestyleMockupAPI] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/mockups/pre-generate", isAdmin, async (req, res) => {
    try {
      const { blueprintId, printProviderId, artworkBlackUrl, artworkWhiteUrl } = req.body;
      if (!blueprintId || !printProviderId || !artworkBlackUrl) {
        return res.status(400).json({
          error: "Missing required fields: blueprintId, printProviderId, artworkBlackUrl"
        });
      }
      const { getProviderColorsWithFallback: getProviderColorsWithFallback2 } = await Promise.resolve().then(() => (init_printify(), printify_exports));
      const colors = await getProviderColorsWithFallback2(
        parseInt(blueprintId),
        parseInt(printProviderId),
        storage
      );
      if (!colors.length) {
        return res.status(400).json({ error: "No colors found for this provider" });
      }
      const { preGenerateMockupsForProduct: preGenerateMockupsForProduct2 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      res.json({
        message: `Pre-generating mockups for ${colors.length} colors...`,
        colors: colors.map((c) => c.name)
      });
      preGenerateMockupsForProduct2(
        parseInt(blueprintId),
        parseInt(printProviderId),
        artworkBlackUrl,
        artworkWhiteUrl || null,
        storage,
        colors
      ).then((result) => {
        console.log(`[MockupAPI] Pre-generation complete: ${result.generated} generated, ${result.failed} failed`);
      }).catch((err) => {
        console.error("[MockupAPI] Pre-generation error:", err);
      });
    } catch (error) {
      console.error("[MockupAPI] Pre-generate error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/library", isAdmin, async (req, res) => {
    try {
      const { ownerType, assetType, mediaType, category, season, event } = req.query;
      const assets = await storage.getLibraryAssets({
        ownerType,
        assetType,
        mediaType,
        category,
        season,
        event
      });
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/library/admin", isAdmin, async (req, res) => {
    try {
      const { assetType, mediaType, category, season, event } = req.query;
      const assets = await storage.getAdminLibraryAssets({
        assetType,
        mediaType,
        category,
        season,
        event
      });
      const assetsWithProxy = assets.map((asset) => ({
        ...asset,
        proxyUrl: asset.storageUrl ? `/api/background-files/${encodeURIComponent(asset.storageUrl)}` : null
      }));
      res.json(assetsWithProxy);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/library/templates", isAdmin, async (req, res) => {
    try {
      const templates = await storage.getCustomDesignsForLibrary();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/template-categories", isAdmin, async (req, res) => {
    try {
      const categories = await storage.getTemplateCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/template-categories/by-parent", isAdmin, async (req, res) => {
    try {
      const { parentId } = req.query;
      const categories = await storage.getTemplateCategoriesByParent(parentId || null);
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/template-categories", isAdmin, async (req, res) => {
    try {
      const category = await storage.createTemplateCategory(req.body);
      res.json(category);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/template-categories/:id", isAdmin, async (req, res) => {
    try {
      const updated = await storage.updateTemplateCategory(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "Template category not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/template-categories/:id", isAdmin, async (req, res) => {
    try {
      await storage.deleteTemplateCategory(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/graphic-sets", isAdmin, async (req, res) => {
    try {
      const graphicSets2 = await storage.getGraphicSets();
      res.json(graphicSets2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/graphic-sets/:id", isAdmin, async (req, res) => {
    try {
      const graphicSet = await storage.getGraphicSet(req.params.id);
      if (!graphicSet) {
        return res.status(404).json({ error: "Graphic set not found" });
      }
      res.json(graphicSet);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/graphic-sets/category/:categoryId", isAdmin, async (req, res) => {
    try {
      const graphicSets2 = await storage.getGraphicSetsByCategory(req.params.categoryId);
      res.json(graphicSets2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/graphic-sets", isAdmin, async (req, res) => {
    try {
      const { name, categoryId, subcategoryId, destinationUrl, description, topText, bottomText, qrContentType } = req.body;
      if (!name) {
        return res.status(400).json({ error: "Name is required" });
      }
      const graphicSetId = `gs_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      let fullGraphicUrl = null;
      let qrOnlyUrl = null;
      const qrDestination = destinationUrl || `${process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "http://localhost:5000"}/dynamic/${graphicSetId}`;
      const qrBuffer = await QRCode4.toBuffer(qrDestination, {
        width: 1e3,
        margin: 2,
        color: { dark: "#000000", light: "#ffffff" },
        errorCorrectionLevel: "H"
      });
      const qrFileName = `qr-only-${graphicSetId}.png`;
      const qrUploadResult = await uploadImageFromBuffer(qrBuffer, qrFileName, "image/png", `graphic-sets/${graphicSetId}`);
      qrOnlyUrl = qrUploadResult.publicUrl;
      if (topText || bottomText) {
        const compositeDataUrl = await generatePrintifyComposite(
          qrDestination,
          topText,
          bottomText,
          1200,
          // width
          1800,
          // height
          "black"
          // qrColor
        );
        const base64Data = compositeDataUrl.replace(/^data:image\/png;base64,/, "");
        const compositeBuffer = Buffer.from(base64Data, "base64");
        const fullFileName = `full-graphic-${graphicSetId}.png`;
        const fullUploadResult = await uploadImageFromBuffer(compositeBuffer, fullFileName, "image/png", `graphic-sets/${graphicSetId}`);
        fullGraphicUrl = fullUploadResult.publicUrl;
      } else {
        fullGraphicUrl = qrOnlyUrl;
      }
      const graphicSet = await storage.createGraphicSet({
        name,
        description: description || null,
        categoryId: categoryId || null,
        subcategoryId: subcategoryId || null,
        fullGraphicUrl,
        qrOnlyUrl,
        destinationUrl: destinationUrl || null,
        storagePath: `graphic-sets/${graphicSetId}`,
        isActive: true,
        isFeatured: false
      });
      res.json(graphicSet);
    } catch (error) {
      console.error("[GraphicSet] Create error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/graphic-sets/:id", isAdmin, async (req, res) => {
    try {
      const updated = await storage.updateGraphicSet(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "Graphic set not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/graphic-sets/:id", isAdmin, async (req, res) => {
    try {
      await storage.deleteGraphicSet(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/graphic-sets/:id/use", isAdmin, async (req, res) => {
    try {
      await storage.incrementGraphicSetUsage(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/library", isAdmin, async (req, res) => {
    try {
      const asset = await storage.createLibraryAsset(req.body);
      res.json(asset);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/library/:id", isAdmin, async (req, res) => {
    try {
      const updated = await storage.updateLibraryAsset(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ error: "Library asset not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/library/:id", isAdmin, async (req, res) => {
    try {
      await storage.deleteLibraryAsset(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/library/upload", isAdmin, async (req, res) => {
    try {
      const chunks = [];
      let fileName = "upload";
      let mimeType = "image/png";
      let boundary = "";
      let assetType = "background";
      let mediaType = "image";
      let category = "";
      let season = "";
      let event = "";
      let name = "";
      let description = "";
      const contentType = req.headers["content-type"] || "";
      const boundaryMatch = contentType.match(/boundary=(.+)/);
      if (boundaryMatch) {
        boundary = boundaryMatch[1];
      }
      const rawBody = await new Promise((resolve, reject) => {
        const chunks2 = [];
        req.on("data", (chunk) => chunks2.push(chunk));
        req.on("end", () => resolve(Buffer.concat(chunks2)));
        req.on("error", reject);
      });
      const boundaryBuffer = Buffer.from(`--${boundary}`);
      const parts = [];
      let start = 0;
      while (true) {
        const boundaryIndex = rawBody.indexOf(boundaryBuffer, start);
        if (boundaryIndex === -1) break;
        if (start > 0) {
          parts.push(rawBody.slice(start, boundaryIndex - 2));
        }
        start = boundaryIndex + boundaryBuffer.length + 2;
      }
      let fileBuffer = null;
      for (const part of parts) {
        const headerEnd = part.indexOf("\r\n\r\n");
        if (headerEnd === -1) continue;
        const headers = part.slice(0, headerEnd).toString();
        const body = part.slice(headerEnd + 4);
        const nameMatch = headers.match(/name="([^"]+)"/);
        const filenameMatch = headers.match(/filename="([^"]+)"/);
        const contentTypeMatch = headers.match(/Content-Type:\s*([^\r\n]+)/i);
        if (filenameMatch) {
          fileName = filenameMatch[1];
          if (contentTypeMatch) {
            mimeType = contentTypeMatch[1].trim();
          }
          fileBuffer = body;
        } else if (nameMatch) {
          const fieldName = nameMatch[1];
          const fieldValue = body.toString().trim();
          if (fieldName === "assetType") assetType = fieldValue;
          else if (fieldName === "mediaType") mediaType = fieldValue;
          else if (fieldName === "category") category = fieldValue;
          else if (fieldName === "season") season = fieldValue;
          else if (fieldName === "event") event = fieldValue;
          else if (fieldName === "name") name = fieldValue;
          else if (fieldName === "description") description = fieldValue;
        }
      }
      if (!fileBuffer || fileBuffer.length === 0) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      let folderPath = "library/admin";
      if (assetType === "background") {
        folderPath += "/backgrounds";
        if (season) folderPath += `/seasonal/${season}`;
        else if (event) folderPath += `/events/${event}`;
        else if (category) folderPath += `/${category}`;
      } else if (assetType === "design") {
        folderPath += "/designs";
        if (category) folderPath += `/${category}`;
      } else if (assetType === "video") {
        folderPath += "/videos";
        if (season) folderPath += `/seasonal/${season}`;
        else if (event) folderPath += `/events/${event}`;
      }
      const uploadResult = await uploadImageFromBuffer(fileBuffer, fileName, mimeType, folderPath);
      const asset = await storage.createLibraryAsset({
        ownerType: "admin",
        userId: null,
        assetType,
        mediaType: mimeType.startsWith("video") ? "video" : "image",
        name: name || fileName,
        originalName: fileName,
        mimeType: uploadResult.mimeType,
        sizeBytes: uploadResult.sizeBytes,
        description: description || null,
        fileName: uploadResult.fileName,
        storageUrl: uploadResult.storageUrl,
        publicUrl: uploadResult.publicUrl,
        category: category || null,
        season: season || null,
        event: event || null,
        tags: null,
        sortOrder: 0,
        isActive: true
      });
      res.json(asset);
    } catch (error) {
      console.error("Library upload error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/library/my", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { assetType, mediaType } = req.query;
      const assets = await storage.getUserLibraryAssets(userId, { assetType, mediaType });
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/library/upload", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const chunks = [];
      let fileName = "upload";
      let mimeType = "image/png";
      let boundary = "";
      let assetType = "background";
      let name = "";
      const contentType = req.headers["content-type"] || "";
      const boundaryMatch = contentType.match(/boundary=(.+)/);
      if (boundaryMatch) {
        boundary = boundaryMatch[1];
      }
      const rawBody = await new Promise((resolve, reject) => {
        const chunks2 = [];
        req.on("data", (chunk) => chunks2.push(chunk));
        req.on("end", () => resolve(Buffer.concat(chunks2)));
        req.on("error", reject);
      });
      const boundaryBuffer = Buffer.from(`--${boundary}`);
      const parts = [];
      let start = 0;
      while (true) {
        const boundaryIndex = rawBody.indexOf(boundaryBuffer, start);
        if (boundaryIndex === -1) break;
        if (start > 0) {
          parts.push(rawBody.slice(start, boundaryIndex - 2));
        }
        start = boundaryIndex + boundaryBuffer.length + 2;
      }
      let fileBuffer = null;
      for (const part of parts) {
        const headerEnd = part.indexOf("\r\n\r\n");
        if (headerEnd === -1) continue;
        const headers = part.slice(0, headerEnd).toString();
        const body = part.slice(headerEnd + 4);
        const nameMatch = headers.match(/name="([^"]+)"/);
        const filenameMatch = headers.match(/filename="([^"]+)"/);
        const contentTypeMatch = headers.match(/Content-Type:\s*([^\r\n]+)/i);
        if (filenameMatch) {
          fileName = filenameMatch[1];
          if (contentTypeMatch) {
            mimeType = contentTypeMatch[1].trim();
          }
          fileBuffer = body;
        } else if (nameMatch) {
          const fieldName = nameMatch[1];
          const fieldValue = body.toString().trim();
          if (fieldName === "assetType") assetType = fieldValue;
          else if (fieldName === "name") name = fieldValue;
        }
      }
      if (!fileBuffer || fileBuffer.length === 0) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      const folderPath = `library/users/${userId}/${assetType}s`;
      const uploadResult = await uploadImageFromBuffer(fileBuffer, fileName, mimeType, folderPath);
      const asset = await storage.createLibraryAsset({
        ownerType: "user",
        userId,
        assetType,
        mediaType: mimeType.startsWith("video") ? "video" : "image",
        name: name || fileName,
        originalName: fileName,
        mimeType: uploadResult.mimeType,
        sizeBytes: uploadResult.sizeBytes,
        description: null,
        fileName: uploadResult.fileName,
        storageUrl: uploadResult.storageUrl,
        publicUrl: uploadResult.publicUrl,
        category: null,
        season: null,
        event: null,
        tags: null,
        sortOrder: 0,
        isActive: true
      });
      res.json(asset);
    } catch (error) {
      console.error("User library upload error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/widget/stores/:slug", async (req, res) => {
    try {
      const store = await storage.getPartnerStoreBySlug(req.params.slug);
      if (!store || !store.isActive) {
        return res.status(404).json({ error: "Partner store not found" });
      }
      const storeProducts = await storage.getPartnerStoreProducts(store.id);
      const placement = req.query.placement;
      let filteredProducts = storeProducts.filter((sp) => sp.isEnabled);
      if (placement) {
        filteredProducts = filteredProducts.filter(
          (sp) => sp.kcPlacements && sp.kcPlacements.includes(placement)
        );
      }
      const productDetails = await Promise.all(
        filteredProducts.map(async (sp) => {
          const product = await storage.getProduct(sp.productId);
          if (!product || !product.isEnabled) return null;
          let availableColors = [];
          if (sp.enabledColors && Array.isArray(sp.enabledColors)) {
            availableColors = sp.enabledColors;
          } else if (product.availableColors) {
            try {
              const parsed = typeof product.availableColors === "string" ? JSON.parse(product.availableColors) : product.availableColors;
              if (Array.isArray(parsed)) {
                availableColors = parsed.map((c) => typeof c === "string" ? c : c?.name || "");
              }
            } catch {
              availableColors = [];
            }
          }
          return {
            id: product.id,
            name: sp.customName || product.name,
            imageUrl: product.imageUrl,
            customPrice: sp.customPrice,
            sortOrder: sp.sortOrder,
            kcPlacements: sp.kcPlacements,
            selectedColors: availableColors,
            defaultColor: sp.defaultColor || availableColors[0] || null
          };
        })
      );
      res.json({
        id: store.id,
        name: store.name,
        slug: store.slug,
        logoUrl: store.logoUrl,
        primaryColor: store.primaryColor,
        accentColor: store.accentColor,
        availableSegments: store.availableSegments,
        products: productDetails.filter(Boolean).sort((a, b) => (a?.sortOrder || 0) - (b?.sortOrder || 0))
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/store/:storeType/:storeName", async (req, res) => {
    try {
      const { storeType: rawStoreType, storeName } = req.params;
      const segment = req.query.segment;
      const normalizedType = rawStoreType.toLowerCase();
      if (!["internal", "external"].includes(normalizedType)) {
        return res.status(400).json({ error: "Invalid store type. Use 'Internal' or 'External'" });
      }
      const storeType = normalizedType === "internal" ? "Internal" : "External";
      const designs = await storage.getCustomDesignsByStoreSegment(storeType, storeName, segment);
      const allStores = await storage.getPartnerStores();
      const matchingStore = allStores.find(
        (s) => s.name.toLowerCase() === storeName.toLowerCase() && (storeType === "Internal" ? s.isInternal === true : s.isInternal !== true)
      );
      let storeProducts = [];
      if (matchingStore) {
        storeProducts = await storage.getPartnerStoreProducts(matchingStore.id);
      }
      const storeProductMap = /* @__PURE__ */ new Map();
      for (const sp of storeProducts) {
        storeProductMap.set(sp.productId, sp);
      }
      const products2 = designs.map((d) => {
        let qrProductType = "qr-basics";
        const hasTopText = d.topText && typeof d.topText === "object" && d.topText.text;
        const hasBottomText = d.bottomText && typeof d.bottomText === "object" && d.bottomText.text;
        const hasBackground = !!d.backgroundImageUrl;
        const hasVideo = !!d.videoUrl;
        const overlay = d.landingOverlay;
        const hasLandingOverlay = overlay?.enabled;
        if (d.templateVariant === "plain-text") {
          qrProductType = "qr-basics";
        } else if (d.templateVariant === "dynamics") {
          qrProductType = "qr-dynamics";
        } else if (d.templateVariant === "external-url") {
          qrProductType = "qr-basics";
        } else if (d.templateVariant === "url") {
          if (hasVideo) {
            qrProductType = "qr-play";
          } else if (hasBackground || hasLandingOverlay) {
            qrProductType = "qr-canvas";
          } else if (hasTopText || hasBottomText) {
            qrProductType = "qr-plus";
          } else {
            qrProductType = "qr-canvas";
          }
        }
        const qrCodeUrl = d.qrCodeUrl || null;
        const productId = d.id.startsWith("custom_") ? d.id : `custom_${d.id}`;
        const storeProduct = storeProductMap.get(productId) || storeProductMap.get(d.id);
        const selectedColors = storeProduct?.enabledColors || d.selectedColors || null;
        const defaultColor = storeProduct?.defaultColor || d.defaultColor || null;
        const mockupsByColor = storeProduct?.mockupsByColor || d.mockupsByColor || null;
        return {
          id: d.id,
          name: d.productName,
          imageUrl: d.productImage || d.printifyCompositeUrl,
          segment: d.segment,
          isFeatured: d.isFeatured,
          isSeasonalPromo: d.isSeasonalPromo,
          templateVariant: d.templateVariant,
          qrProductType,
          qrCodeUrl,
          selectedColors,
          defaultColor,
          mockupsByColor,
          createdAt: d.createdAt
        };
      });
      res.json({
        storeType,
        storeName,
        segment: segment || null,
        products: products2
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/storefront/generate-mockup", async (req, res) => {
    try {
      const { productId, color, storeId, qrSize, qrSizePercent } = req.body;
      if (!productId || !color) {
        return res.status(400).json({ error: "productId and color are required" });
      }
      let resolvedQrSize = "medium";
      if (qrSize && ["small", "medium", "large"].includes(qrSize)) {
        resolvedQrSize = qrSize;
      } else if (qrSizePercent) {
        if (qrSizePercent <= 30) resolvedQrSize = "small";
        else if (qrSizePercent <= 50) resolvedQrSize = "medium";
        else resolvedQrSize = "large";
      }
      console.log(`[StorefrontMockup] QR size: ${resolvedQrSize} (from percent: ${qrSizePercent || "default"})`);
      const canonicalProductId = productId.startsWith("custom_") ? productId : `custom_${productId}`;
      const designId = productId.startsWith("custom_") ? productId.replace("custom_", "") : productId;
      const product = await storage.getProduct(canonicalProductId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      const blueprintId = product.blueprintId;
      const printProviderId = product.printProviderId;
      if (!blueprintId || !printProviderId) {
        return res.status(400).json({ error: "Product missing blueprint or print provider" });
      }
      const existingMockups = product.mockupsByColor || {};
      const normalizeColor = (c) => c.toLowerCase().trim();
      const requestColorNorm = normalizeColor(color);
      const placement = "front-chest";
      const fullKey = `${color}_${resolvedQrSize}_${placement}`;
      const colorSizeKey = `${color}_${resolvedQrSize}`;
      const fullKeyNorm = `${requestColorNorm}_${resolvedQrSize}_${placement}`;
      const colorSizeKeyNorm = `${requestColorNorm}_${resolvedQrSize}`;
      console.log(`[StorefrontMockup] Looking for mockup: full="${fullKey}", size="${colorSizeKey}", color="${color}"`);
      let existingMockup = null;
      let matchedColorKey = fullKey;
      let usedFallback = false;
      for (const [storedKey, mockup] of Object.entries(existingMockups)) {
        const storedKeyNorm = storedKey.toLowerCase().trim();
        if (storedKeyNorm === fullKeyNorm && mockup && mockup.front) {
          existingMockup = mockup;
          matchedColorKey = storedKey;
          console.log(`[StorefrontMockup] Found EXACT match: "${storedKey}"`);
          break;
        }
      }
      if (!existingMockup) {
        for (const [storedKey, mockup] of Object.entries(existingMockups)) {
          const storedKeyNorm = storedKey.toLowerCase().trim();
          if (storedKeyNorm === colorSizeKeyNorm && mockup && mockup.front) {
            existingMockup = mockup;
            matchedColorKey = storedKey;
            usedFallback = true;
            console.log(`[StorefrontMockup] Found SIZE match: "${storedKey}" (requested: ${fullKey})`);
            break;
          }
        }
      }
      if (!existingMockup) {
        for (const [storedKey, mockup] of Object.entries(existingMockups)) {
          const storedKeyNorm = storedKey.toLowerCase().trim();
          const matchesColor = storedKeyNorm === requestColorNorm || storedKeyNorm.startsWith(`${requestColorNorm}_`);
          if (matchesColor && mockup && mockup.front) {
            existingMockup = mockup;
            matchedColorKey = storedKey;
            usedFallback = true;
            console.log(`[StorefrontMockup] Using COLOR fallback: "${storedKey}" (requested: ${fullKey})`);
            break;
          }
        }
      }
      if (existingMockup && existingMockup.front) {
        console.log(`[StorefrontMockup] Using ${usedFallback ? "fallback" : "cached"} mockup for "${matchedColorKey}"`);
        const defaultImage = existingMockup.lifestyle || existingMockup.front;
        await storage.updateProduct(canonicalProductId, {
          defaultColor: color,
          imageUrl: defaultImage
        });
        console.log(`[StorefrontMockup] Updated product defaultColor=${color}, imageUrl=${defaultImage}`);
        return res.json({
          success: true,
          color,
          graphicSize: resolvedQrSize,
          mockupUrl: existingMockup.front,
          lifestyleMockupUrl: existingMockup.lifestyle || null,
          fromCache: true,
          usedFallback,
          matchedKey: matchedColorKey,
          mockupsByColor: existingMockups
        });
      }
      const design = await storage.getCustomDesign(designId);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      let designPlacements = {};
      try {
        if (typeof design.placementImages === "string") {
          designPlacements = JSON.parse(design.placementImages);
        } else if (design.placementImages && typeof design.placementImages === "object") {
          designPlacements = design.placementImages;
        }
      } catch (e) {
        console.error("[StorefrontMockup] Failed to parse placementImages:", e);
      }
      let colorHex = null;
      if (product.availableColors && Array.isArray(product.availableColors)) {
        const colorInfo = product.availableColors.find(
          (c) => c.name?.toLowerCase() === color.toLowerCase()
        );
        colorHex = colorInfo?.hex || null;
      }
      if (!colorHex) {
        const { getProviderColorsWithFallback: getProviderColorsWithFallback2 } = await Promise.resolve().then(() => (init_printify(), printify_exports));
        const colors = await getProviderColorsWithFallback2(blueprintId, printProviderId, storage);
        const colorInfo = colors.find(
          (c) => c.name?.toLowerCase() === color.toLowerCase()
        );
        colorHex = colorInfo?.hex || null;
      }
      const { isColorDark: isColorDark4 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const needsWhiteQR = colorHex ? isColorDark4(colorHex) : false;
      const blackArtwork = designPlacements["front-chest"] || designPlacements["front-chest-black"] || designPlacements["front-center"] || designPlacements["front-center-black"] || designPlacements["front"];
      const whiteArtwork = designPlacements["front-chest-white"] || designPlacements["front-center-white"] || designPlacements["front-white"];
      let artworkUrl;
      let artworkVariant = "black";
      console.log(`[StorefrontMockup] Color ${color} hex=${colorHex}, needsWhiteQR=${needsWhiteQR}`);
      console.log(`[StorefrontMockup] Available placements: ${Object.keys(designPlacements).join(", ")}`);
      console.log(`[StorefrontMockup] Black artwork: ${blackArtwork}, White artwork: ${whiteArtwork}`);
      if (needsWhiteQR && whiteArtwork) {
        artworkUrl = whiteArtwork;
        artworkVariant = "white";
        console.log(`[StorefrontMockup] Using WHITE artwork for dark shirt: ${color}`);
      } else if (blackArtwork) {
        artworkUrl = blackArtwork;
        artworkVariant = "black";
        console.log(`[StorefrontMockup] Using BLACK artwork for light shirt: ${color}`);
      } else {
        artworkUrl = design.printifyCompositeUrl || Object.values(designPlacements)[0];
        console.log(`[StorefrontMockup] Using fallback artwork: ${artworkUrl}`);
      }
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const pendingJobs = await mockupJobQueue2.getJobsByProduct(canonicalProductId);
      const colorJobs = pendingJobs.filter(
        (j) => j.colorName.toLowerCase() === color.toLowerCase() && ["pending", "processing", "delayed"].includes(j.status)
      );
      if (colorJobs.length > 0) {
        console.log(`[StorefrontMockup] Mockup for ${color} is pending (${colorJobs.length} jobs in queue)`);
        return res.json({
          success: false,
          pending: true,
          color,
          message: `Mockup for ${color} is being generated. Please wait.`,
          jobCount: colorJobs.length
        });
      }
      console.log(`[StorefrontMockup] No mockup found for ${color} and none pending`);
      return res.status(404).json({
        error: `No mockup available for ${color}. Mockups are generated when the product is saved.`,
        color
      });
    } catch (error) {
      console.error("[StorefrontMockup] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/test-mockup-sizes", async (req, res) => {
    try {
      const { productId, color } = req.body;
      if (!productId || !color) {
        return res.status(400).json({ error: "productId and color are required" });
      }
      const canonicalProductId = productId.startsWith("custom_") ? productId : `custom_${productId}`;
      const designId = productId.startsWith("custom_") ? productId.replace("custom_", "") : productId;
      const product = await storage.getProduct(canonicalProductId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      const { blueprintId, printProviderId } = product;
      if (!blueprintId || !printProviderId) {
        return res.status(400).json({ error: "Product missing blueprint or print provider" });
      }
      const design = await storage.getCustomDesign(designId);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      let designPlacements = {};
      if (typeof design.placementImages === "string") {
        designPlacements = JSON.parse(design.placementImages);
      } else if (design.placementImages && typeof design.placementImages === "object") {
        designPlacements = design.placementImages;
      }
      let colorHex = null;
      if (product.availableColors && Array.isArray(product.availableColors)) {
        const colorInfo = product.availableColors.find(
          (c) => c.name?.toLowerCase() === color.toLowerCase()
        );
        colorHex = colorInfo?.hex || null;
      }
      const { isColorDark: isColorDark4 } = await Promise.resolve().then(() => (init_mockup_service(), mockup_service_exports));
      const needsWhiteQR = colorHex ? isColorDark4(colorHex) : false;
      const blackArtwork = designPlacements["front-chest"] || designPlacements["front-center"] || designPlacements["front"];
      const whiteArtwork = designPlacements["front-chest-white"] || designPlacements["front-center-white"];
      const artworkUrl = needsWhiteQR && whiteArtwork ? whiteArtwork : blackArtwork;
      if (!artworkUrl) {
        return res.status(400).json({ error: "No artwork found" });
      }
      const { printfulClient: printfulClient2 } = await Promise.resolve().then(() => (init_printful(), printful_exports));
      const { printifyPrintfulMapping: printifyPrintfulMapping2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const { eq: eq7, and: and7 } = await import("drizzle-orm");
      const mapping = await db3.select().from(printifyPrintfulMapping2).where(and7(
        eq7(printifyPrintfulMapping2.printifyBlueprintId, blueprintId),
        eq7(printifyPrintfulMapping2.isActive, true)
      )).limit(1);
      if (mapping.length === 0) {
        return res.status(400).json({ error: "No Printful mapping for this blueprint" });
      }
      const printfulProductId = mapping[0].printfulProductId;
      const variants = await printfulClient2.getVariantsByColor(printfulProductId, color);
      if (variants.length === 0) {
        return res.status(400).json({ error: `No Printful variants for color: ${color}` });
      }
      const targetVariant = variants.find((v) => v.size === "M") || variants[0];
      const printfiles = await printfulClient2.getPrintfiles(printfulProductId);
      const frontPrintfile = printfiles.printfiles?.find((p) => p.printfile_id === 1) || printfiles.printfiles?.[0];
      const areaWidth = frontPrintfile?.width || 4500;
      const areaHeight = frontPrintfile?.height || 5400;
      const baseUrl = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : "http://localhost:5000";
      const absoluteArtworkUrl = artworkUrl.startsWith("http") ? artworkUrl : `${baseUrl}${artworkUrl}`;
      const sizes = [
        { name: "small", percent: 0.25 },
        { name: "medium", percent: 0.45 },
        { name: "large", percent: 0.65 }
      ];
      const results = [];
      for (const sizeConfig of sizes) {
        try {
          console.log(`[TestMockupSizes] Generating ${sizeConfig.name} (${Math.round(sizeConfig.percent * 100)}%)...`);
          const qrSize = Math.round(areaWidth * sizeConfig.percent);
          const position = {
            area_width: areaWidth,
            area_height: areaHeight,
            width: qrSize,
            height: qrSize,
            top: Math.round(areaHeight * 0.15),
            left: Math.round((areaWidth - qrSize) / 2)
          };
          const task = await printfulClient2.createMockupTask(
            printfulProductId,
            [targetVariant.id],
            [{
              placement: "front",
              image_url: absoluteArtworkUrl,
              position
            }],
            "jpg",
            ["Men's Lifestyle"]
          );
          if (!task.task_key) {
            results.push({ size: sizeConfig.name, qrPixels: qrSize, error: "Task creation failed" });
            continue;
          }
          const result = await printfulClient2.waitForMockupTask(task.task_key, 6e4);
          if (!result.mockups || result.mockups.length === 0) {
            results.push({ size: sizeConfig.name, qrPixels: qrSize, error: "No mockups returned" });
            continue;
          }
          const mainMockup = result.mockups[0];
          let lifestyleUrl = mainMockup.extra?.find(
            (e) => e.option_group?.toLowerCase().includes("lifestyle")
          )?.url;
          results.push({
            size: sizeConfig.name,
            qrPixels: qrSize,
            mockupUrl: mainMockup.mockup_url,
            lifestyleUrl: lifestyleUrl || mainMockup.mockup_url
          });
          if (sizeConfig !== sizes[sizes.length - 1]) {
            console.log(`[TestMockupSizes] Waiting 3 seconds for rate limit...`);
            await new Promise((resolve) => setTimeout(resolve, 3e3));
          }
        } catch (err) {
          results.push({ size: sizeConfig.name, qrPixels: 0, error: err.message });
        }
      }
      res.json({
        success: true,
        color,
        areaWidth,
        areaHeight,
        results
      });
    } catch (error) {
      console.error("[TestMockupSizes] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/mockup-jobs/batch", async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const { productId, fullGeneration = false, placements, qrSizes } = req.body;
      if (!productId) {
        return res.status(400).json({ error: "productId is required" });
      }
      const validQrSizes = ["small", "medium", "large"];
      if (qrSizes && !qrSizes.every((s) => validQrSizes.includes(s))) {
        return res.status(400).json({ error: "qrSizes must be array of 'small', 'medium', or 'large'" });
      }
      const canonicalProductId = productId.startsWith("custom_") ? productId : `custom_${productId}`;
      const designId = productId.startsWith("custom_") ? productId.replace("custom_", "") : productId;
      const product = await storage.getProduct(canonicalProductId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      const { blueprintId, printProviderId, availableColors } = product;
      if (!blueprintId || !printProviderId) {
        return res.status(400).json({ error: "Product missing blueprint or print provider" });
      }
      const colors = Array.isArray(availableColors) ? availableColors : [];
      if (colors.length === 0) {
        return res.status(400).json({ error: "Product has no colors defined" });
      }
      const design = await storage.getCustomDesign(designId);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      let designPlacements = {};
      if (typeof design.placementImages === "string") {
        designPlacements = JSON.parse(design.placementImages);
      } else if (design.placementImages && typeof design.placementImages === "object") {
        designPlacements = design.placementImages;
      }
      const blackArtwork = designPlacements["front-chest"] || designPlacements["front-center"] || designPlacements["front"];
      const whiteArtwork = designPlacements["front-chest-white"] || designPlacements["front-center-white"];
      if (!blackArtwork) {
        return res.status(400).json({ error: "No artwork found for product" });
      }
      const ALL_PLACEMENTS = ["front-chest", "back", "left-shoulder", "right-shoulder"];
      const ALL_QR_SIZES = ["small", "medium", "large"];
      let targetPlacements;
      let targetQrSizes;
      if (fullGeneration) {
        targetPlacements = placements || ALL_PLACEMENTS;
        targetQrSizes = qrSizes || ALL_QR_SIZES;
      } else {
        targetPlacements = placements || ["front-chest"];
        targetQrSizes = qrSizes || ALL_QR_SIZES;
      }
      const jobs = await mockupJobQueue2.createBatchJobs({
        productId: canonicalProductId,
        colors,
        qrSizes: targetQrSizes,
        placements: targetPlacements,
        blueprintId,
        printProviderId,
        artworkUrl: blackArtwork,
        artworkVariant: "black"
      });
      const totalCombos = `${colors.length} colors \xD7 ${targetQrSizes.length} QR sizes \xD7 ${targetPlacements.length} placements`;
      res.json({
        success: true,
        message: `Created ${jobs.length} mockup jobs (${totalCombos})`,
        jobCount: jobs.length,
        placements: targetPlacements,
        qrSizes: targetQrSizes,
        colorCount: colors.length,
        jobIds: jobs.map((j) => j.id)
      });
    } catch (error) {
      console.error("[MockupJobQueue] Batch create error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/mockup-jobs/stats", async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const stats = await mockupJobQueue2.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/mockup-jobs/product/:productId", async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const { productId } = req.params;
      const canonicalProductId = productId.startsWith("custom_") ? productId : `custom_${productId}`;
      const jobs = await mockupJobQueue2.getJobsByProduct(canonicalProductId);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/mockup-jobs/:jobId", async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const job = await mockupJobQueue2.getJob(req.params.jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/mockup-jobs/prioritize", async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const { productId, colorName, qrSize, placement, viewerId } = req.body;
      if (!productId || !colorName || !qrSize || !placement || !viewerId) {
        return res.status(400).json({ error: "Missing required fields: productId, colorName, qrSize, placement, viewerId" });
      }
      const canonicalProductId = productId.startsWith("custom_") ? productId : `custom_${productId}`;
      const job = await mockupJobQueue2.bumpPriority({
        productId: canonicalProductId,
        colorName,
        qrSize,
        placement,
        viewerId
      });
      if (!job) {
        return res.status(404).json({ error: "Job not found for this color/size combination" });
      }
      res.json({
        success: true,
        jobId: job.id,
        status: job.status,
        priority: job.priority
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/mockup-jobs/product/:productId", isAdmin, async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const { productId } = req.params;
      const canonicalProductId = productId.startsWith("custom_") ? productId : `custom_${productId}`;
      const cancelled = await mockupJobQueue2.cancelJobsByProduct(canonicalProductId);
      res.json({ success: true, cancelledCount: cancelled });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/mockup-jobs/worker/:action", isAdmin, async (req, res) => {
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      const { action } = req.params;
      if (action === "start") {
        mockupJobQueue2.startWorker();
        res.json({ success: true, message: "Worker started" });
      } else if (action === "stop") {
        mockupJobQueue2.stopWorker();
        res.json({ success: true, message: "Worker stopped" });
      } else {
        res.status(400).json({ error: "Action must be 'start' or 'stop'" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/dynamic-pages", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const pages = await storage.getDynamicPagesByUser(userId);
      const enrichedPages = await Promise.all(pages.map(async (page) => {
        let activeImage = null;
        if (page.activeAssetId) {
          const assets = await storage.getDynamicPageAssets(page.id);
          const activeAsset = assets.find((a) => a.id === page.activeAssetId);
          if (activeAsset && activeAsset.hostedImageId) {
            const image = await storage.getHostedImage(activeAsset.hostedImageId);
            if (image) {
              activeImage = {
                url: `/api/images/${image.id}`,
                title: activeAsset.title || image.title
              };
            }
          }
        }
        return { ...page, activeImage };
      }));
      res.json(enrichedPages);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/dynamic-pages/:id", isAuthenticated, async (req, res) => {
    try {
      const page = await storage.getDynamicPage(req.params.id);
      if (!page) {
        return res.status(404).json({ error: "Dynamic page not found" });
      }
      if (page.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      const assets = await storage.getDynamicPageAssets(page.id);
      res.json({ ...page, assets });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/dynamic-pages", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { title, description, hostingTierId } = req.body;
      const slug = crypto.randomUUID();
      let expiresAt = null;
      if (hostingTierId) {
        const tier = await storage.getHostingTier(hostingTierId);
        if (tier && tier.code !== "permanent") {
          expiresAt = /* @__PURE__ */ new Date();
          expiresAt.setDate(expiresAt.getDate() + tier.durationDays);
        }
      }
      const page = await storage.createDynamicPage({
        userId,
        slug,
        title,
        description,
        hostingTierId,
        expiresAt,
        status: "active"
      });
      res.status(201).json(page);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/dynamic-pages/:id", isAuthenticated, async (req, res) => {
    try {
      const page = await storage.getDynamicPage(req.params.id);
      if (!page) {
        return res.status(404).json({ error: "Dynamic page not found" });
      }
      if (page.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      const updated = await storage.updateDynamicPage(req.params.id, req.body);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/dynamic-pages/:id", isAuthenticated, async (req, res) => {
    try {
      const page = await storage.getDynamicPage(req.params.id);
      if (!page) {
        return res.status(404).json({ error: "Dynamic page not found" });
      }
      if (page.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      await storage.deleteDynamicPage(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/dynamic-pages/:id/assets", isAuthenticated, async (req, res) => {
    try {
      const page = await storage.getDynamicPage(req.params.id);
      if (!page) {
        return res.status(404).json({ error: "Dynamic page not found" });
      }
      if (page.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      const assets = await storage.getDynamicPageAssets(page.id);
      res.json(assets);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/dynamic-pages/:id/assets", isAuthenticated, async (req, res) => {
    try {
      const page = await storage.getDynamicPage(req.params.id);
      if (!page) {
        return res.status(404).json({ error: "Dynamic page not found" });
      }
      if (page.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      const { hostedImageId, title, setAsActive } = req.body;
      const asset = await storage.createDynamicPageAsset({
        pageId: page.id,
        hostedImageId,
        title,
        isActive: false
      });
      if (setAsActive) {
        await storage.setActiveAsset(page.id, asset.id);
      }
      res.status(201).json(asset);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/dynamic-pages/:id/set-active", isAuthenticated, async (req, res) => {
    try {
      const page = await storage.getDynamicPage(req.params.id);
      if (!page) {
        return res.status(404).json({ error: "Dynamic page not found" });
      }
      if (page.userId !== req.user.claims.sub) {
        return res.status(403).json({ error: "Access denied" });
      }
      const { assetId } = req.body;
      await storage.setActiveAsset(page.id, assetId);
      const updatedPage = await storage.getDynamicPage(page.id);
      res.json(updatedPage);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/dynamic/:slug", async (req, res) => {
    try {
      const page = await storage.getDynamicPageBySlug(req.params.slug);
      if (!page) {
        return res.status(404).json({ error: "Page not found" });
      }
      if (page.status !== "active") {
        return res.status(410).json({ error: "This page is no longer available" });
      }
      if (page.expiresAt && new Date(page.expiresAt) < /* @__PURE__ */ new Date()) {
        return res.status(410).json({ error: "This page has expired" });
      }
      await storage.incrementDynamicPageViews(page.id);
      let activeImage = null;
      if (page.activeAssetId) {
        const asset = await storage.getDynamicPageAsset(page.activeAssetId);
        if (asset) {
          activeImage = await storage.getHostedImage(asset.hostedImageId);
        }
      }
      res.json({
        title: page.title,
        description: page.description,
        image: activeImage ? {
          url: activeImage.publicUrl,
          title: activeImage.title
        } : null
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/hosting-tiers", async (req, res) => {
    try {
      const tiers = await storage.getHostingTiers();
      res.json(tiers);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/hosting-tiers/seed", isAdmin, async (req, res) => {
    try {
      const existingTiers = await storage.getHostingTiers();
      if (existingTiers.length > 0) {
        return res.json({ message: "Hosting tiers already exist", tiers: existingTiers });
      }
      const defaultTiers = [
        { code: "1_year", name: "1 Year", description: "Standard hosting", durationDays: 365, isIncluded: false, priceUpcharge: "5", sortOrder: 1 },
        { code: "2_year", name: "2 Years", description: "Save with 2-year commitment", durationDays: 730, isIncluded: false, priceUpcharge: "8", sortOrder: 2 },
        { code: "3_year", name: "3 Years", description: "Best value - 3-year hosting", durationDays: 1095, isIncluded: false, priceUpcharge: "10", sortOrder: 3 }
      ];
      const createdTiers = [];
      for (const tier of defaultTiers) {
        const created = await storage.createHostingTier(tier);
        createdTiers.push(created);
      }
      res.json({ message: "Default hosting tiers created", tiers: createdTiers });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/hosting-tiers/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updateSchema = z2.object({
        name: z2.string().optional(),
        description: z2.string().nullable().optional(),
        durationDays: z2.number().optional(),
        priceUpcharge: z2.string().optional(),
        isIncluded: z2.boolean().optional(),
        isActive: z2.boolean().optional(),
        sortOrder: z2.number().optional()
      });
      const validatedData = updateSchema.parse(req.body);
      const updated = await storage.updateHostingTier(id, validatedData);
      if (!updated) {
        return res.status(404).json({ error: "Hosting tier not found" });
      }
      res.json(updated);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/hosting-tiers", isAdmin, async (req, res) => {
    try {
      const tiers = await storage.getHostingTiers();
      res.json(tiers);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/hosting-tiers", isAdmin, async (req, res) => {
    try {
      const createSchema = z2.object({
        code: z2.string().min(1),
        name: z2.string().min(1),
        description: z2.string().nullable().optional(),
        durationDays: z2.number().min(1),
        priceUpcharge: z2.string().optional().default("0"),
        isIncluded: z2.boolean().optional().default(false),
        isActive: z2.boolean().optional().default(true),
        sortOrder: z2.number().optional().default(0)
      });
      const validated = createSchema.parse(req.body);
      const tier = await storage.createHostingTier(validated);
      res.json(tier);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/hosting-tiers/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteHostingTier(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/dashboard/metrics", isAdmin, async (req, res) => {
    try {
      const orders2 = await storage.getOrders();
      const now = /* @__PURE__ */ new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1e3);
      const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1e3);
      let todayRevenue = 0;
      let weekRevenue = 0;
      let monthRevenue = 0;
      let pendingOrders = 0;
      let inProductionOrders = 0;
      let shippedOrders = 0;
      for (const order of orders2) {
        const orderDate = order.createdAt ? new Date(order.createdAt) : null;
        const amount = parseFloat(order.total || "0");
        if (orderDate && orderDate >= today) todayRevenue += amount;
        if (orderDate && orderDate >= weekAgo) weekRevenue += amount;
        if (orderDate && orderDate >= monthAgo) monthRevenue += amount;
        if (order.status === "pending") pendingOrders++;
        if (order.status === "in_production") inProductionOrders++;
        if (order.status === "shipped") shippedOrders++;
      }
      const users2 = await storage.getUsers();
      const newUsersThisWeek = users2.filter((u) => {
        const created = u.createdAt ? new Date(u.createdAt) : null;
        return created && created >= weekAgo;
      }).length;
      const products2 = await storage.getProducts();
      const activeProducts = products2.filter((p) => p.isEnabled !== false).length;
      res.json({
        revenue: {
          today: todayRevenue,
          week: weekRevenue,
          month: monthRevenue,
          trend: 0
          // Would calculate vs previous period
        },
        orders: {
          total: orders2.length,
          pending: pendingOrders,
          inProduction: inProductionOrders,
          shipped: shippedOrders,
          trend: 0
        },
        customers: {
          total: users2.length,
          newThisWeek: newUsersThisWeek,
          returning: users2.length - newUsersThisWeek
        },
        products: {
          active: activeProducts,
          lowStock: 0,
          syncErrors: 0
        },
        health: await checkProviderHealth()
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orders-unified", isAdmin, async (req, res) => {
    try {
      const orders2 = await storage.getOrders();
      res.json(orders2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orders-unified/:id", isAdmin, async (req, res) => {
    try {
      const order = await storage.getOrderUnified(req.params.id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/orders-unified/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { status, trackingNumber, trackingUrl, routedProvider, providerOrderId, productionCost, profit, notes } = req.body;
      const currentOrder = await storage.getOrderUnified(id);
      if (!currentOrder) {
        return res.status(404).json({ error: "Order not found" });
      }
      let statusHistory = currentOrder.statusHistory || [];
      if (status && status !== currentOrder.status) {
        statusHistory = [
          ...statusHistory,
          { status, timestamp: (/* @__PURE__ */ new Date()).toISOString(), note: notes || void 0 }
        ];
      }
      const updates = {};
      if (status) updates.status = status;
      if (trackingNumber !== void 0) updates.trackingNumber = trackingNumber;
      if (trackingUrl !== void 0) updates.trackingUrl = trackingUrl;
      if (routedProvider !== void 0) updates.routedProvider = routedProvider;
      if (providerOrderId !== void 0) updates.providerOrderId = providerOrderId;
      if (productionCost !== void 0) updates.productionCost = productionCost;
      if (profit !== void 0) updates.profit = profit;
      if (statusHistory.length > 0) updates.statusHistory = statusHistory;
      if (status === "shipped" && !currentOrder.shippedAt) {
        updates.shippedAt = /* @__PURE__ */ new Date();
      }
      if (status === "delivered" && !currentOrder.deliveredAt) {
        updates.deliveredAt = /* @__PURE__ */ new Date();
      }
      const updated = await storage.updateOrderUnified(id, updates);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orders-unified/:id/sync-printify", isAdmin, async (req, res) => {
    try {
      const order = await storage.getOrderUnified(req.params.id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      if (!order.providerOrderId || order.routedProvider !== "printify") {
        return res.status(400).json({ error: "Order is not routed to Printify" });
      }
      const printifyStatus = await checkPrintifyOrderStatus(order.providerOrderId);
      if (printifyStatus) {
        const updates = {};
        const statusMap = {
          "pending": "pending",
          "on-hold": "pending",
          "payment-not-received": "pending",
          "in-production": "in_production",
          "fulfilled": "shipped",
          "canceled": "cancelled"
        };
        if (printifyStatus.status) {
          updates.status = statusMap[printifyStatus.status] || printifyStatus.status;
        }
        if (printifyStatus.trackingNumber) {
          updates.trackingNumber = printifyStatus.trackingNumber;
        }
        if (printifyStatus.trackingUrl) {
          updates.trackingUrl = printifyStatus.trackingUrl;
        }
        const updated = await storage.updateOrderUnified(req.params.id, updates);
        res.json({ synced: true, order: updated });
      } else {
        res.json({ synced: false, message: "Could not fetch status from Printify" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/customers", isAdmin, async (req, res) => {
    try {
      const users2 = await storage.getUsers();
      const orders2 = await storage.getOrders();
      const customerStats = users2.map((user) => {
        const userOrders = orders2.filter((o) => o.customerEmail === user.email);
        const totalSpent = userOrders.reduce((sum, o) => sum + parseFloat(o.total || "0"), 0);
        const lastOrder = userOrders.sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        })[0];
        return {
          ...user,
          orderCount: userOrders.length,
          totalSpent,
          lastOrderDate: lastOrder?.createdAt?.toISOString() || null
        };
      });
      customerStats.sort((a, b) => b.totalSpent - a.totalSpent);
      res.json(customerStats);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/customers/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ error: "Customer not found" });
      }
      const orders2 = await storage.getOrders();
      const userOrders = orders2.filter((o) => o.customerEmail === user.email);
      const totalSpent = userOrders.reduce((sum, o) => sum + parseFloat(o.total || "0"), 0);
      const lastOrder = userOrders[0];
      res.json({
        customer: {
          ...user,
          orderCount: userOrders.length,
          totalSpent,
          lastOrderDate: lastOrder?.createdAt?.toISOString() || null
        },
        recentOrders: userOrders.slice(0, 10)
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/health", isAdmin, async (req, res) => {
    try {
      const healthLogs = await storage.getProviderHealthLogs(50);
      const providerStatus = {};
      for (const log2 of healthLogs) {
        const provider = log2.providerType;
        if (!providerStatus[provider]) {
          providerStatus[provider] = { healthy: 0, total: 0, lastCheck: null, avgResponse: 0 };
        }
        providerStatus[provider].total++;
        if (log2.isHealthy) providerStatus[provider].healthy++;
        if (!providerStatus[provider].lastCheck || log2.checkTime > providerStatus[provider].lastCheck) {
          providerStatus[provider].lastCheck = log2.checkTime;
        }
        if (log2.responseTimeMs) {
          providerStatus[provider].avgResponse += log2.responseTimeMs;
        }
      }
      const providers = Object.entries(providerStatus).map(([provider, stats]) => {
        const successRate = stats.total > 0 ? stats.healthy / stats.total * 100 : 100;
        let status = "healthy";
        if (successRate < 50) status = "down";
        else if (successRate < 90) status = "degraded";
        return {
          provider,
          status,
          lastCheck: stats.lastCheck?.toISOString() || (/* @__PURE__ */ new Date()).toISOString(),
          responseMs: stats.total > 0 ? Math.round(stats.avgResponse / stats.total) : 0,
          successRate: Math.round(successRate * 10) / 10,
          recentErrors: stats.total - stats.healthy
        };
      });
      if (providers.length === 0) {
        providers.push(
          { provider: "printify", status: "healthy", lastCheck: (/* @__PURE__ */ new Date()).toISOString(), responseMs: 200, successRate: 100, recentErrors: 0 },
          { provider: "stripe", status: "healthy", lastCheck: (/* @__PURE__ */ new Date()).toISOString(), responseMs: 100, successRate: 100, recentErrors: 0 }
        );
      }
      res.json({
        providers,
        recentLogs: healthLogs.slice(0, 20)
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/coupons", isAdmin, async (req, res) => {
    try {
      const coupons2 = await storage.getCoupons();
      res.json(coupons2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/coupons", isAdmin, async (req, res) => {
    try {
      const createSchema = z2.object({
        code: z2.string().min(1).max(50),
        name: z2.string().min(1),
        discountType: z2.enum(["percent", "fixed"]),
        discountValue: z2.string().refine((val) => parseFloat(val) > 0, "Must be greater than 0"),
        currency: z2.string().optional().default("usd"),
        minOrderAmount: z2.string().nullable().optional(),
        maxRedemptions: z2.number().nullable().optional(),
        validFrom: z2.string().nullable().optional(),
        validUntil: z2.string().nullable().optional(),
        isActive: z2.boolean().optional().default(true)
      });
      const validated = createSchema.parse(req.body);
      const existing = await storage.getCouponByCode(validated.code);
      if (existing) {
        return res.status(409).json({ error: "A coupon with this code already exists" });
      }
      let stripeCouponId = null;
      let stripePromotionCodeId = null;
      try {
        const { getUncachableStripeClient: getUncachableStripeClient2 } = await Promise.resolve().then(() => (init_stripeClient(), stripeClient_exports));
        const stripe = await getUncachableStripeClient2();
        const stripeCoupon = await stripe.coupons.create({
          ...validated.discountType === "percent" ? { percent_off: parseFloat(validated.discountValue) } : { amount_off: Math.round(parseFloat(validated.discountValue) * 100), currency: validated.currency },
          name: validated.name,
          ...validated.validUntil && { redeem_by: Math.floor(new Date(validated.validUntil).getTime() / 1e3) },
          ...validated.maxRedemptions && { max_redemptions: validated.maxRedemptions }
        });
        stripeCouponId = stripeCoupon.id;
        const promoCode = await stripe.promotionCodes.create({
          promotion: {
            type: "coupon",
            coupon: stripeCoupon.id
          },
          code: validated.code.toUpperCase(),
          active: validated.isActive
        });
        stripePromotionCodeId = promoCode.id;
      } catch (stripeError) {
        console.error("Stripe coupon creation failed:", stripeError.message);
      }
      const coupon = await storage.createCoupon({
        code: validated.code,
        name: validated.name,
        discountType: validated.discountType,
        discountValue: validated.discountValue,
        currency: validated.currency,
        minOrderAmount: validated.minOrderAmount ?? null,
        maxRedemptions: validated.maxRedemptions ?? null,
        validFrom: validated.validFrom ? new Date(validated.validFrom) : null,
        validUntil: validated.validUntil ? new Date(validated.validUntil) : null,
        stripeCouponId,
        stripePromotionCodeId,
        isActive: validated.isActive
      });
      res.json(coupon);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/coupons/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updateSchema = z2.object({
        name: z2.string().optional(),
        isActive: z2.boolean().optional(),
        maxRedemptions: z2.number().nullable().optional(),
        validUntil: z2.string().nullable().optional()
      });
      const validated = updateSchema.parse(req.body);
      const existingCoupon = await storage.getCoupon(id);
      if (existingCoupon?.stripePromotionCodeId && validated.isActive !== void 0) {
        try {
          const { getUncachableStripeClient: getUncachableStripeClient2 } = await Promise.resolve().then(() => (init_stripeClient(), stripeClient_exports));
          const stripe = await getUncachableStripeClient2();
          await stripe.promotionCodes.update(existingCoupon.stripePromotionCodeId, {
            active: validated.isActive
          });
        } catch (stripeError) {
          console.error("Stripe promo code update failed:", stripeError.message);
        }
      }
      const updated = await storage.updateCoupon(id, {
        ...validated.name && { name: validated.name },
        ...validated.isActive !== void 0 && { isActive: validated.isActive },
        ...validated.maxRedemptions !== void 0 && { maxRedemptions: validated.maxRedemptions },
        ...validated.validUntil !== void 0 && { validUntil: validated.validUntil ? new Date(validated.validUntil) : null }
      });
      if (!updated) {
        return res.status(404).json({ error: "Coupon not found" });
      }
      res.json(updated);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/coupons/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const existingCoupon = await storage.getCoupon(id);
      if (existingCoupon?.stripePromotionCodeId) {
        try {
          const { getUncachableStripeClient: getUncachableStripeClient2 } = await Promise.resolve().then(() => (init_stripeClient(), stripeClient_exports));
          const stripe = await getUncachableStripeClient2();
          await stripe.promotionCodes.update(existingCoupon.stripePromotionCodeId, {
            active: false
          });
        } catch (stripeError) {
          console.error("Stripe promo code deactivation failed:", stripeError.message);
        }
      }
      await storage.deleteCoupon(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/coupons/validate", async (req, res) => {
    try {
      const validateSchema = z2.object({
        code: z2.string().min(1),
        orderTotal: z2.number().optional()
      });
      const { code, orderTotal } = validateSchema.parse(req.body);
      const coupon = await storage.getCouponByCode(code);
      if (!coupon) {
        return res.status(404).json({ valid: false, error: "Invalid coupon code" });
      }
      if (!coupon.isActive) {
        return res.status(400).json({ valid: false, error: "This coupon is no longer active" });
      }
      const now = /* @__PURE__ */ new Date();
      if (coupon.validFrom && now < new Date(coupon.validFrom)) {
        return res.status(400).json({ valid: false, error: "This coupon is not yet active" });
      }
      if (coupon.validUntil && now > new Date(coupon.validUntil)) {
        return res.status(400).json({ valid: false, error: "This coupon has expired" });
      }
      if (coupon.maxRedemptions && (coupon.redemptionCount || 0) >= coupon.maxRedemptions) {
        return res.status(400).json({ valid: false, error: "This coupon has reached its usage limit" });
      }
      if (coupon.minOrderAmount && orderTotal && orderTotal < parseFloat(coupon.minOrderAmount)) {
        return res.status(400).json({
          valid: false,
          error: `Minimum order of $${coupon.minOrderAmount} required for this coupon`
        });
      }
      let discountAmount = 0;
      if (orderTotal) {
        if (coupon.discountType === "percent") {
          discountAmount = orderTotal * (parseFloat(coupon.discountValue) / 100);
        } else {
          discountAmount = Math.min(parseFloat(coupon.discountValue), orderTotal);
        }
      }
      res.json({
        valid: true,
        coupon: {
          id: coupon.id,
          code: coupon.code,
          name: coupon.name,
          discountType: coupon.discountType,
          discountValue: coupon.discountValue,
          stripePromotionCodeId: coupon.stripePromotionCodeId
        },
        discountAmount: discountAmount.toFixed(2)
      });
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ valid: false, error: error.errors });
      }
      res.status(500).json({ valid: false, error: error.message });
    }
  });
  app3.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getActiveQrTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/templates", isAdmin, async (req, res) => {
    try {
      const templates = await storage.getQrTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/templates", isAdmin, async (req, res) => {
    try {
      const createSchema = z2.object({
        name: z2.string().min(1),
        description: z2.string().nullable().optional(),
        category: z2.string().nullable().optional(),
        thumbnailUrl: z2.string().url(),
        fullImageUrl: z2.string().url(),
        storageUrl: z2.string().url(),
        priceUpcharge: z2.string().optional().default("0"),
        isActive: z2.boolean().optional().default(true),
        isFeatured: z2.boolean().optional().default(false)
      });
      const validatedData = createSchema.parse(req.body);
      const template = await storage.createQrTemplate(validatedData);
      res.json(template);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.put("/api/admin/templates/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const updateSchema = z2.object({
        name: z2.string().min(1).optional(),
        description: z2.string().nullable().optional(),
        category: z2.string().nullable().optional(),
        thumbnailUrl: z2.string().url().optional(),
        fullImageUrl: z2.string().url().optional(),
        storageUrl: z2.string().url().optional(),
        priceUpcharge: z2.string().optional(),
        isActive: z2.boolean().optional(),
        isFeatured: z2.boolean().optional()
      });
      const validatedData = updateSchema.parse(req.body);
      const template = await storage.updateQrTemplate(id, validatedData);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      res.json(template);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/templates/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteQrTemplate(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/customs/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const design = await storage.getCustomDesign(id);
      if (!design) {
        return res.status(404).json({ error: "Custom design not found" });
      }
      res.json(design);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/custom-designs", isAdmin, async (req, res) => {
    try {
      const createSchema = z2.object({
        projectName: z2.string().min(1, "Project name is required").max(100),
        productId: z2.number(),
        productName: z2.string(),
        productImage: z2.string().nullable().optional(),
        placements: z2.array(z2.string()).min(1),
        placementConfigs: z2.record(z2.string(), z2.enum(["full", "qr-only"])).optional(),
        // per-placement mode
        // QR content type: rich_media (hosted), plain_text (direct), external_url (user's URL)
        qrContentType: z2.enum(["rich_media", "plain_text", "external_url"]).optional().default("rich_media"),
        plainTextQrContent: z2.string().nullable().optional(),
        // For plain_text mode - encoded directly in QR
        // For external_url mode - require a valid URL with proper domain structure
        externalUrl: z2.string().nullable().optional().refine(
          (val) => {
            if (!val) return true;
            const normalized = val.match(/^https?:\/\//) ? val : `https://${val}`;
            try {
              const url = new URL(normalized);
              return url.hostname.includes(".") && url.hostname.length > 3;
            } catch {
              return false;
            }
          },
          { message: "Please enter a valid URL (e.g., https://example.com or example.com)" }
        ),
        backgroundImage: z2.string().nullable().optional(),
        topText: z2.object({
          text: z2.string(),
          fontFamily: z2.string(),
          fontSize: z2.string(),
          color: z2.string().optional(),
          letterSpacing: z2.number().optional(),
          warpPreset: z2.string().optional(),
          strokeColor: z2.string().optional(),
          strokeWidth: z2.number().optional()
        }).nullable().optional(),
        bottomText: z2.object({
          text: z2.string(),
          fontFamily: z2.string(),
          fontSize: z2.string(),
          color: z2.string().optional(),
          letterSpacing: z2.number().optional(),
          warpPreset: z2.string().optional(),
          strokeColor: z2.string().optional(),
          strokeWidth: z2.number().optional()
        }).nullable().optional(),
        // Landing page overlay - displayed when QR is scanned (not printed)
        landingOverlay: z2.object({
          enabled: z2.boolean(),
          title: z2.string().optional(),
          description: z2.string().optional(),
          position: z2.enum(["top", "bottom"]),
          fontFamily: z2.string(),
          color: z2.string()
        }).nullable().optional(),
        textUpcharge: z2.number().optional().default(2),
        storeType: z2.string().nullable().optional(),
        storeName: z2.string().nullable().optional(),
        segment: z2.string().nullable().optional(),
        isFeatured: z2.boolean().optional().default(false),
        isSeasonalPromo: z2.boolean().optional().default(false),
        saveTarget: z2.enum(["library", "store", "both"]),
        // Pricing data for product catalog entry
        basePrice: z2.number().optional().default(0),
        markupPercent: z2.number().optional().default(0),
        markupFixed: z2.number().optional().default(0),
        hostingPrice: z2.number().optional().default(0),
        // USA production flag for product
        madeInUSA: z2.boolean().optional().default(false),
        printProviderId: z2.number().nullable().optional()
      });
      const validatedData = createSchema.parse(req.body);
      if (validatedData.qrContentType === "external_url") {
        if (!validatedData.externalUrl || validatedData.externalUrl.trim() === "") {
          return res.status(400).json({
            error: "External URL is required when using External URL QR mode"
          });
        }
      }
      if (validatedData.qrContentType === "plain_text") {
        if (!validatedData.plainTextQrContent || validatedData.plainTextQrContent.trim() === "") {
          return res.status(400).json({
            error: "QR content is required when using Plain Text QR mode"
          });
        }
      }
      const slugify = (str) => str?.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "";
      let baseSlug = slugify(validatedData.projectName);
      if (!baseSlug) {
        const storePart = slugify(validatedData.storeName || "custom");
        const segmentPart = slugify(validatedData.segment || "general");
        const timestamp2 = Date.now().toString(36);
        baseSlug = `${storePart}-${segmentPart}-${timestamp2}`;
      }
      let designId = baseSlug;
      let counter = 1;
      while (await storage.getCustomDesign(designId)) {
        designId = `${baseSlug}-${counter}`;
        counter++;
      }
      const baseUrl = process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}` : "http://localhost:5000";
      let backgroundAssetId = null;
      if (validatedData.backgroundImage && validatedData.saveTarget !== "store") {
        const existingAsset = await storage.getLibraryAssetByUrl(validatedData.backgroundImage);
        if (existingAsset) {
          backgroundAssetId = existingAsset.id;
          await storage.incrementLibraryAssetUsage(existingAsset.id);
          if (!existingAsset.isActive) {
            await storage.updateLibraryAsset(existingAsset.id, { isActive: true });
          }
        } else {
          const bgFilename = validatedData.backgroundImage.split("/").pop() || "background.png";
          const newAsset = await storage.createLibraryAsset({
            name: `Background - ${validatedData.storeName || "Custom"} ${validatedData.segment || ""}`.trim(),
            originalName: bgFilename,
            mimeType: "image/png",
            fileName: bgFilename,
            sizeBytes: 0,
            // Unknown size when auto-saving from URL
            storageUrl: validatedData.backgroundImage,
            publicUrl: validatedData.backgroundImage,
            ownerType: "admin",
            assetType: "background",
            mediaType: "image",
            isActive: true,
            isFeatured: false,
            // Set visibility to the store/segment this design is for
            visibleStoreSlugs: validatedData.storeName ? [validatedData.storeName.toLowerCase().replace(/[^a-z0-9]+/g, "-")] : null,
            visibleSegments: validatedData.segment ? { segments: [validatedData.segment] } : null
          });
          backgroundAssetId = newAsset.id;
        }
      }
      const finalPlacementConfigs = validatedData.placementConfigs || Object.fromEntries(validatedData.placements.map((p) => [p, "full"]));
      const templateVariant = validatedData.qrContentType === "plain_text" ? "plain-text" : validatedData.qrContentType === "external_url" ? "external-url" : "url";
      const designData = {
        id: designId,
        projectName: validatedData.projectName,
        productId: validatedData.productId,
        productName: validatedData.productName,
        productImage: validatedData.productImage || null,
        placements: validatedData.placements,
        placementConfigs: finalPlacementConfigs,
        // per-placement mode map
        backgroundImageUrl: validatedData.backgroundImage || null,
        backgroundAssetId,
        topText: validatedData.topText || null,
        bottomText: validatedData.bottomText || null,
        landingOverlay: validatedData.landingOverlay || null,
        textUpcharge: String(validatedData.textUpcharge),
        storeType: validatedData.storeType || null,
        storeName: validatedData.storeName || null,
        segment: validatedData.segment || null,
        isFeatured: validatedData.isFeatured,
        isSeasonalPromo: validatedData.isSeasonalPromo,
        savedToLibrary: validatedData.saveTarget === "library" || validatedData.saveTarget === "both",
        savedToStore: validatedData.saveTarget === "store" || validatedData.saveTarget === "both",
        // New QR content type fields
        templateVariant,
        // Normalize external URL with https:// if missing protocol
        externalUrl: validatedData.externalUrl ? validatedData.externalUrl.match(/^https?:\/\//) ? validatedData.externalUrl : `https://${validatedData.externalUrl}` : null
        // Note: plainTextQrContent is not stored - it's encoded directly in the QR at generation time
      };
      const design = await storage.createCustomDesign(designData);
      let qrUrl;
      if (validatedData.qrContentType === "external_url" && validatedData.externalUrl) {
        const extUrl = validatedData.externalUrl;
        qrUrl = extUrl.match(/^https?:\/\//) ? extUrl : `https://${extUrl}`;
      } else if (validatedData.qrContentType === "plain_text" && validatedData.plainTextQrContent) {
        qrUrl = validatedData.plainTextQrContent;
      } else {
        qrUrl = `${baseUrl}/customs/${design.id}`;
      }
      const qrCodeDataUrl = await QRCode4.toDataURL(qrUrl, {
        width: 256,
        margin: 2,
        color: { dark: "#000000", light: "#ffffff" }
      });
      const placementImages = {};
      let primaryCompositeUrl = null;
      const { renderDesignToPng: renderDesignToPng2, renderQrOnlyToPng: renderQrOnlyToPng2 } = await Promise.resolve().then(() => (init_svg_renderer(), svg_renderer_exports));
      const generateFullArtworkWithFallback = async (placementId, qrColor = "black") => {
        const textColor = qrColor === "white" ? "#FFFFFF" : "#000000";
        const headerStyle = validatedData.topText ? {
          text: validatedData.topText.text,
          fontFamily: validatedData.topText.fontFamily || "Arial",
          fontSize: parseInt(validatedData.topText.fontSize) || 120,
          color: textColor,
          // Use appropriate color for shirt
          letterSpacing: validatedData.topText.letterSpacing || 0,
          warpPreset: validatedData.topText.warpPreset || "straight",
          strokeColor: validatedData.topText.strokeColor,
          strokeWidth: validatedData.topText.strokeWidth
        } : void 0;
        const footerStyle = validatedData.bottomText ? {
          text: validatedData.bottomText.text,
          fontFamily: validatedData.bottomText.fontFamily || "Arial",
          fontSize: parseInt(validatedData.bottomText.fontSize) || 96,
          color: textColor,
          // Use appropriate color for shirt
          letterSpacing: validatedData.bottomText.letterSpacing || 0,
          warpPreset: validatedData.bottomText.warpPreset || "straight",
          strokeColor: validatedData.bottomText.strokeColor,
          strokeWidth: validatedData.bottomText.strokeWidth
        } : void 0;
        try {
          const renderResult = await renderDesignToPng2({
            templateType: "shirt-front",
            header: headerStyle,
            footer: footerStyle,
            qrUrl,
            qrColor
            // Pass color to SVG renderer
          });
          const colorSuffix = qrColor === "white" ? "-white" : "";
          const fileName = `svg-composite-${design.id}-${placementId}${colorSuffix}-${Date.now()}.png`;
          const uploadResult = await uploadImageFromBuffer(
            renderResult.pngBuffer,
            fileName,
            "image/png"
          );
          console.log(`[Custom Design] Generated ${qrColor.toUpperCase()} full artwork for ${placementId}: ${uploadResult.publicUrl}`);
          return uploadResult.publicUrl;
        } catch (svgError) {
          console.error(`[Custom Design] SVG render failed for ${placementId}, falling back to canvas:`, svgError.message);
          const fallbackTopText = validatedData.topText ? {
            text: validatedData.topText.text,
            fontFamily: validatedData.topText.fontFamily || "Arial",
            fontSize: validatedData.topText.fontSize || "120",
            color: textColor,
            // Use appropriate color for shirt
            letterSpacing: validatedData.topText.letterSpacing || 0,
            warpPreset: validatedData.topText.warpPreset || "straight",
            strokeColor: validatedData.topText.strokeColor,
            strokeWidth: validatedData.topText.strokeWidth
          } : null;
          const fallbackBottomText = validatedData.bottomText ? {
            text: validatedData.bottomText.text,
            fontFamily: validatedData.bottomText.fontFamily || "Arial",
            fontSize: validatedData.bottomText.fontSize || "96",
            color: textColor,
            // Use appropriate color for shirt
            letterSpacing: validatedData.bottomText.letterSpacing || 0,
            warpPreset: validatedData.bottomText.warpPreset || "straight",
            strokeColor: validatedData.bottomText.strokeColor,
            strokeWidth: validatedData.bottomText.strokeWidth
          } : null;
          const canvasUrl = await generatePrintifyComposite(
            qrUrl,
            fallbackTopText,
            fallbackBottomText,
            4500,
            5400,
            qrColor
            // Pass color to canvas renderer
          );
          console.log(`[Custom Design] Generated ${qrColor.toUpperCase()} canvas fallback for ${placementId}: ${canvasUrl}`);
          return canvasUrl;
        }
      };
      for (const [placementId, mode] of Object.entries(finalPlacementConfigs)) {
        try {
          let imageUrl = null;
          let whiteImageUrl = null;
          if (mode === "qr-only") {
            const qrOnlyResult = await renderQrOnlyToPng2({ qrUrl });
            const fileName = `qr-only-${design.id}-${placementId}-${Date.now()}.png`;
            const uploadResult = await uploadImageFromBuffer(
              qrOnlyResult.pngBuffer,
              fileName,
              "image/png"
            );
            console.log(`[Custom Design] Generated QR-only for ${placementId}: ${uploadResult.publicUrl}`);
            imageUrl = uploadResult.publicUrl;
            const qrOnlyWhiteResult = await renderQrOnlyToPng2({ qrUrl, qrColor: "white" });
            const whiteFileName = `qr-only-white-${design.id}-${placementId}-${Date.now()}.png`;
            const whiteUploadResult = await uploadImageFromBuffer(
              qrOnlyWhiteResult.pngBuffer,
              whiteFileName,
              "image/png"
            );
            console.log(`[Custom Design] Generated WHITE QR-only for ${placementId}: ${whiteUploadResult.publicUrl}`);
            whiteImageUrl = whiteUploadResult.publicUrl;
          } else {
            imageUrl = await generateFullArtworkWithFallback(placementId, "black");
            whiteImageUrl = await generateFullArtworkWithFallback(placementId, "white");
          }
          if (imageUrl) {
            placementImages[placementId] = imageUrl;
            if (!primaryCompositeUrl && mode === "full") {
              primaryCompositeUrl = imageUrl;
            }
          }
          if (whiteImageUrl) {
            placementImages[`${placementId}-white`] = whiteImageUrl;
            console.log(`[Custom Design] Stored white version as ${placementId}-white`);
          }
        } catch (renderError) {
          console.error(`[Custom Design] Render failed for ${placementId}:`, renderError.message);
        }
      }
      if (!primaryCompositeUrl && Object.keys(placementImages).length > 0) {
        primaryCompositeUrl = Object.values(placementImages)[0];
      }
      const updatedDesign = await storage.updateCustomDesign(design.id, {
        qrCodeUrl: qrCodeDataUrl,
        printifyCompositeUrl: primaryCompositeUrl,
        // Primary image for backward compat
        placementImages
        // Per-placement images map
      });
      if (designData.savedToStore && designData.storeName) {
        const categoryPath = designData.segment ? `${designData.storeName}/${designData.segment}` : designData.storeName;
        const productId = `custom_${design.id}`;
        const textUpchargeTotal = (validatedData.topText ? validatedData.textUpcharge : 0) + (validatedData.bottomText ? validatedData.textUpcharge : 0);
        const totalCost = validatedData.basePrice + textUpchargeTotal + validatedData.hostingPrice;
        const customerPrice = totalCost * (1 + validatedData.markupPercent / 100) + validatedData.markupFixed;
        const existingProduct = await storage.getProduct(productId);
        if (existingProduct) {
          await storage.updateProduct(productId, {
            name: validatedData.productName,
            description: `Custom QR design for ${categoryPath}`,
            category: categoryPath,
            basePrice: String(totalCost.toFixed(2)),
            customerPrice: String(customerPrice.toFixed(2)),
            markupPercent: String(validatedData.markupPercent),
            markupFixed: String(validatedData.markupFixed),
            imageUrl: validatedData.productImage || null,
            blueprintId: validatedData.productId || null,
            printProviderId: validatedData.printProviderId || null,
            madeInUSA: validatedData.madeInUSA || false,
            isFeatured: validatedData.isFeatured || false,
            isEnabled: true,
            metadata: { customDesignId: design.id, source: "custom" }
          });
        } else {
          await storage.createProduct({
            id: productId,
            name: validatedData.productName,
            description: `Custom QR design for ${categoryPath}`,
            basePrice: String(totalCost.toFixed(2)),
            customerPrice: String(customerPrice.toFixed(2)),
            markupPercent: String(validatedData.markupPercent),
            markupFixed: String(validatedData.markupFixed),
            category: categoryPath,
            imageUrl: validatedData.productImage || null,
            blueprintId: validatedData.productId || null,
            printProviderId: validatedData.printProviderId || null,
            madeInUSA: validatedData.madeInUSA || false,
            isFeatured: validatedData.isFeatured || false,
            isEnabled: true,
            metadata: { customDesignId: design.id, source: "custom" }
          });
        }
        console.log(`[Custom Design] Created/updated product catalog entry: ${productId} in category: ${categoryPath} with price $${customerPrice.toFixed(2)}`);
        if (validatedData.productId && validatedData.printProviderId) {
          try {
            const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
            const { printifyPrintProviders: printifyPrintProviders2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
            const [provider] = await db3.select().from(printifyPrintProviders2).where(
              and6(
                eq6(printifyPrintProviders2.blueprintId, validatedData.productId),
                eq6(printifyPrintProviders2.providerId, validatedData.printProviderId)
              )
            );
            const availableColors = provider?.availableColors || [];
            if (availableColors.length > 0) {
              const artworkUrl = placementImages?.["front-chest"] || Object.values(placementImages || {})[0];
              if (artworkUrl) {
                const artworkVariant = "black";
                const jobs = await mockupJobQueue2.createBatchJobs({
                  productId,
                  colors: availableColors,
                  qrSizes: ["small", "medium", "large"],
                  placements: ["front-chest"],
                  blueprintId: validatedData.productId,
                  printProviderId: validatedData.printProviderId,
                  artworkUrl,
                  artworkVariant
                });
                console.log(`[Custom Design] Queued ${jobs.length} mockup jobs for ${availableColors.length} colors x 3 sizes`);
              } else {
                console.warn(`[Custom Design] No artwork URL found for auto-mockup generation`);
              }
            } else {
              console.warn(`[Custom Design] No colors found in local catalog for blueprint ${validatedData.productId} provider ${validatedData.printProviderId}`);
            }
          } catch (mockupError) {
            console.error(`[Custom Design] Failed to queue mockup jobs:`, mockupError.message);
          }
        }
      }
      res.json(updatedDesign);
    } catch (error) {
      console.error("[Custom Design Save] Error:", error);
      if (error instanceof z2.ZodError) {
        console.error("[Custom Design Save] Zod validation errors:", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ error: "Validation failed", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/custom-designs", isAdmin, async (req, res) => {
    try {
      const designs = await storage.getCustomDesigns();
      res.json(designs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  async function handleCustomDesignUpdate(req, res) {
    try {
      const { id } = req.params;
      const updates = req.body;
      const existing = await storage.getCustomDesign(id);
      if (!existing) {
        return res.status(404).json({ error: "Custom design not found" });
      }
      const updatedDesign = await storage.updateCustomDesign(id, updates);
      res.json(updatedDesign);
    } catch (error) {
      console.error("[Custom Design Update] Error:", error);
      res.status(500).json({ error: error.message });
    }
  }
  app3.put("/api/admin/custom-designs/:id", isAdmin, handleCustomDesignUpdate);
  app3.patch("/api/admin/custom-designs/:id", isAdmin, handleCustomDesignUpdate);
  app3.delete("/api/admin/custom-designs/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCustomDesign(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/designs/:id/publish", isAdmin, async (req, res) => {
    const { id } = req.params;
    const { selectedColors, defaultColor, blueprintId, printProviderId } = req.body;
    try {
      if (!selectedColors || !Array.isArray(selectedColors) || selectedColors.length === 0) {
        return res.status(400).json({ error: "selectedColors array is required" });
      }
      if (!defaultColor) {
        return res.status(400).json({ error: "defaultColor is required" });
      }
      if (!selectedColors.includes(defaultColor)) {
        return res.status(400).json({ error: "defaultColor must be one of the selectedColors" });
      }
      if (!blueprintId || !printProviderId) {
        return res.status(400).json({ error: "blueprintId and printProviderId are required" });
      }
      const design = await storage.getCustomDesign(id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      const printReadyArtUrl = design.printifyCompositeUrl || design.placementImages?.["front-chest"] || Object.values(design.placementImages || {})[0];
      if (!printReadyArtUrl) {
        return res.status(400).json({ error: "No print-ready artwork found. Save the design first." });
      }
      await storage.updateCustomDesign(id, {
        publishStatus: "processing",
        publishError: null,
        selectedColors,
        defaultColor,
        blueprintId,
        printProviderId
      });
      const { syncProductVariants: syncProductVariants2, printify: printify2 } = await Promise.resolve().then(() => (init_printify(), printify_exports));
      console.log(`[Publish] Starting mockup generation for design ${id}`);
      console.log(`[Publish] Blueprint: ${blueprintId}, Provider: ${printProviderId}`);
      console.log(`[Publish] Colors: ${selectedColors.join(", ")}, Default: ${defaultColor}`);
      const { variants } = await syncProductVariants2(blueprintId, printProviderId);
      const selectedVariants = variants.filter(
        (v) => v.options?.color && selectedColors.includes(v.options.color)
      );
      if (selectedVariants.length === 0) {
        await storage.updateCustomDesign(id, {
          publishStatus: "failed",
          publishError: "No matching variants found for selected colors"
        });
        return res.status(400).json({ error: "No matching variants found for selected colors" });
      }
      const variantIds = selectedVariants.map((v) => v.id);
      console.log(`[Publish] Found ${variantIds.length} variants for selected colors`);
      console.log(`[Publish] Uploading artwork to Printify: ${printReadyArtUrl}`);
      const imageUpload = await printify2.uploadImage(printReadyArtUrl, `design-${id}.png`);
      console.log(`[Publish] Uploaded image ID: ${imageUpload.id}`);
      const { syncProductPlacements: syncProductPlacements2 } = await Promise.resolve().then(() => (init_printify(), printify_exports));
      const { placements: providerPlacements } = await syncProductPlacements2(blueprintId, printProviderId);
      const placement = providerPlacements[0]?.position || "front";
      const productData = {
        title: design.projectName || `QR Design - ${id}`,
        description: `Custom QR design: ${design.projectName || id}`,
        blueprint_id: blueprintId,
        print_provider_id: printProviderId,
        variants: variantIds.map((vid) => ({
          id: vid,
          price: 2500,
          // $25 placeholder price
          is_enabled: true
        })),
        print_areas: [{
          variant_ids: variantIds,
          placeholders: [{
            position: placement,
            images: [{
              id: imageUpload.id,
              x: 0.5,
              y: 0.5,
              scale: 1,
              angle: 0
            }]
          }]
        }]
      };
      console.log(`[Publish] Creating Printify product...`);
      const printifyProduct = await printify2.createProduct(productData);
      console.log(`[Publish] Created Printify product: ${printifyProduct.id}`);
      let attempts = 0;
      const maxAttempts = 15;
      let productWithMockups = null;
      let mockupsReady = false;
      while (attempts < maxAttempts && !mockupsReady) {
        const delay = Math.min(2e3 * Math.pow(1.5, attempts), 1e4);
        await new Promise((resolve) => setTimeout(resolve, delay));
        try {
          productWithMockups = await printify2.getProduct(printifyProduct.id);
          if (productWithMockups.images && productWithMockups.images.length > 0) {
            console.log(`[Publish] Mockups ready: ${productWithMockups.images.length} images`);
            mockupsReady = true;
          }
        } catch (pollError) {
          if (pollError.message?.includes("429") || pollError.message?.includes("rate")) {
            console.warn(`[Publish] Rate limited, backing off... attempt ${attempts}/${maxAttempts}`);
            await new Promise((resolve) => setTimeout(resolve, 5e3));
          } else {
            console.error(`[Publish] Poll error: ${pollError.message}`);
          }
        }
        attempts++;
        if (!mockupsReady) {
          console.log(`[Publish] Waiting for mockups... attempt ${attempts}/${maxAttempts}`);
        }
      }
      if (!mockupsReady || !productWithMockups?.images?.length) {
        console.error(`[Publish] Mockups not ready after ${maxAttempts} attempts`);
        await storage.updateCustomDesign(id, {
          printifyProductId: printifyProduct.id,
          publishStatus: "failed",
          publishError: "Mockups not ready after timeout. Try again later."
        });
        return res.status(504).json({
          error: "Mockups not ready after timeout",
          printifyProductId: printifyProduct.id,
          message: "Product created on Printify but mockups not yet available. Try publishing again."
        });
      }
      const mockupsByColor = {};
      const selectedVariantIds = {};
      if (productWithMockups?.images) {
        for (const img of productWithMockups.images) {
          for (const variantId of img.variant_ids || []) {
            const variant = selectedVariants.find((v) => v.id === variantId);
            if (variant?.options?.color) {
              const color = variant.options.color;
              if (!mockupsByColor[color]) {
                mockupsByColor[color] = { angles: [] };
              }
              if (!mockupsByColor[color].front) {
                mockupsByColor[color].front = img.src;
              }
              mockupsByColor[color].angles?.push(img.src);
            }
          }
        }
      }
      for (const variant of selectedVariants) {
        if (variant.options?.color && variant.options?.size) {
          const key = `${variant.options.color}-${variant.options.size}`;
          selectedVariantIds[key] = variant.id;
        }
      }
      console.log(`[Publish] Extracted mockups for ${Object.keys(mockupsByColor).length} colors`);
      await storage.updateCustomDesign(id, {
        printifyProductId: printifyProduct.id,
        printReadyArtUrl,
        mockupsByColor,
        selectedVariantIds,
        publishStatus: "complete",
        publishError: null
      });
      console.log(`[Publish] Design ${id} published successfully`);
      res.json({
        success: true,
        printifyProductId: printifyProduct.id,
        mockupsByColor,
        selectedVariantIds,
        imagesCount: productWithMockups?.images?.length || 0
      });
    } catch (error) {
      console.error(`[Publish] Error publishing design ${id}:`, error);
      await storage.updateCustomDesign(id, {
        publishStatus: "failed",
        publishError: error.message
      });
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/designs/:id/publish-status", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const design = await storage.getCustomDesign(id);
      if (!design) {
        return res.status(404).json({ error: "Design not found" });
      }
      res.json({
        status: design.publishStatus || "draft",
        error: design.publishError,
        mockupsByColor: design.mockupsByColor,
        defaultColor: design.defaultColor,
        printifyProductId: design.printifyProductId
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/render/config", async (req, res) => {
    try {
      const { getFontAllowlist: getFontAllowlist2, getWarpPresets: getWarpPresets2 } = await Promise.resolve().then(() => (init_svg_renderer(), svg_renderer_exports));
      res.json({
        fonts: getFontAllowlist2(),
        warpPresets: getWarpPresets2()
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.all("/api/render/preview", async (req, res) => {
    try {
      const { buildPreviewSvg: buildPreviewSvg2 } = await Promise.resolve().then(() => (init_svg_renderer(), svg_renderer_exports));
      const params = req.method === "GET" ? req.query : req.body;
      const { header, footer, qrUrl, previewWidth, previewHeight } = params;
      if (!qrUrl) {
        return res.status(400).json({ error: "qrUrl is required" });
      }
      const svgString = buildPreviewSvg2(
        { templateType: "shirt-front", header, footer, qrUrl },
        previewWidth || 450,
        previewHeight || 540
      );
      res.type("image/svg+xml").send(svgString);
    } catch (error) {
      console.error("[SVG Preview] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/render/png", isAdmin, async (req, res) => {
    try {
      const { renderDesignToPng: renderDesignToPng2 } = await Promise.resolve().then(() => (init_svg_renderer(), svg_renderer_exports));
      const { header, footer, qrUrl, templateType } = req.body;
      if (!qrUrl) {
        return res.status(400).json({ error: "qrUrl is required" });
      }
      const result = await renderDesignToPng2({
        templateType: templateType || "shirt-front",
        header,
        footer,
        qrUrl
      });
      const fileName = `svg-render-${Date.now()}.png`;
      const uploadResult = await uploadImageFromBuffer(
        result.pngBuffer,
        fileName,
        "image/png"
      );
      res.json({
        url: uploadResult.publicUrl,
        width: result.width,
        height: result.height
      });
    } catch (error) {
      console.error("[PNG Render] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/render/png/download", isAdmin, async (req, res) => {
    try {
      const { renderDesignToPng: renderDesignToPng2 } = await Promise.resolve().then(() => (init_svg_renderer(), svg_renderer_exports));
      const { header, footer, qrUrl, templateType } = req.body;
      if (!qrUrl) {
        return res.status(400).json({ error: "qrUrl is required" });
      }
      const result = await renderDesignToPng2({
        templateType: templateType || "shirt-front",
        header,
        footer,
        qrUrl
      });
      res.set({
        "Content-Type": "image/png",
        "Content-Disposition": 'attachment; filename="printify-design.png"',
        "Content-Length": result.pngBuffer.length
      });
      res.send(result.pngBuffer);
    } catch (error) {
      console.error("[PNG Download] Error:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/pricing/quote", async (req, res) => {
    try {
      const {
        productId,
        productLine = "text",
        // 'text', 'template', 'custom', 'dynamic'
        hasTextAbove,
        hasTextBelow,
        templateId,
        hostingTierCode = "1_year"
      } = req.body;
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      const settings = await storage.getAdminSettings();
      const basePrice = parseFloat(product.basePrice);
      const markupPercent = parseFloat(product.markupPercent || "0") || parseFloat(settings?.globalMarkupPercent || "25");
      const markupFixed = parseFloat(product.markupFixed || "0") || parseFloat(settings?.globalMarkupFixed || "0");
      const qrCost = parseFloat(product.qrProductionCost || "0") || parseFloat(settings?.globalQrProductionCost || "2");
      let price = basePrice + qrCost;
      price = price * (1 + markupPercent / 100) + markupFixed;
      const breakdown = {
        base: basePrice,
        qrProduction: qrCost,
        markup: (basePrice + qrCost) * (markupPercent / 100) + markupFixed,
        textAboveUpcharge: 0,
        textBelowUpcharge: 0,
        templateUpcharge: 0,
        hostingUpcharge: 0,
        dynamicUpcharge: 0
      };
      if (hasTextAbove && productLine !== "dynamic") {
        const upcharge = parseFloat(settings?.textAboveUpcharge || "2");
        price += upcharge;
        breakdown.textAboveUpcharge = upcharge;
      }
      if (hasTextBelow && productLine !== "dynamic") {
        const upcharge = parseFloat(settings?.textBelowUpcharge || "2");
        price += upcharge;
        breakdown.textBelowUpcharge = upcharge;
      }
      if (productLine === "template" && templateId) {
        const template = await storage.getQrTemplate(templateId);
        if (template) {
          const upcharge = parseFloat(template.priceUpcharge || "0");
          price += upcharge;
          breakdown.templateUpcharge = upcharge;
        }
      }
      if (productLine === "dynamic") {
        const dynamicUpcharge = parseFloat(settings?.dynamicQrUpcharge || "25");
        price += dynamicUpcharge;
        breakdown.dynamicUpcharge = dynamicUpcharge;
      }
      if ((productLine === "template" || productLine === "custom" || productLine === "dynamic") && hostingTierCode !== "1_year") {
        const tier = await storage.getHostingTierByCode(hostingTierCode);
        if (tier && !tier.isIncluded) {
          const upcharge = parseFloat(tier.priceUpcharge || "0");
          price += upcharge;
          breakdown.hostingUpcharge = upcharge;
        }
      }
      res.json({
        productLine,
        basePrice,
        finalPrice: Math.round(price * 100) / 100,
        breakdown,
        hostingTier: hostingTierCode
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/store/products", async (req, res) => {
    try {
      const products2 = await storage.getEnabledProducts();
      const safeProducts = products2.map((p) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        category: p.category,
        imageUrl: p.imageUrl,
        manufacturer: p.manufacturer,
        madeInUSA: p.madeInUSA,
        availablePlacements: p.availablePlacements,
        availableColors: p.availableColors
      }));
      res.json(safeProducts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/master-products", isAdmin, async (req, res) => {
    try {
      const products2 = await storage.getAllMasterProducts();
      res.json(products2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/master-products/:id", isAdmin, async (req, res) => {
    try {
      const product = await storage.getMasterProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Master product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/master-products", isAdmin, async (req, res) => {
    try {
      const { title, description, productType, tags, channels, pricingProfileId, baseCost, retailPrice } = req.body;
      if (!title || !productType) {
        return res.status(400).json({ error: "Title and productType are required" });
      }
      const seq = Date.now().toString(36).toUpperCase();
      const sku = `QRG-${productType.toUpperCase().slice(0, 3)}-${seq}`;
      const product = await storage.createMasterProduct({
        sku,
        title,
        description: description || null,
        productType,
        tags: tags || [],
        channels: channels || null,
        pricingProfileId: pricingProfileId || null,
        baseCost: baseCost || null,
        retailPrice: retailPrice || null,
        status: "draft"
      });
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/orchestration/master-products/:id", isAdmin, async (req, res) => {
    try {
      const id = req.params.id;
      const updates = req.body;
      const product = await storage.updateMasterProduct(id, updates);
      if (!product) {
        return res.status(404).json({ error: "Master product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/orchestration/master-products/:id", isAdmin, async (req, res) => {
    try {
      const id = req.params.id;
      await storage.deleteMasterProduct(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/master-products/:id/design-versions", isAdmin, async (req, res) => {
    try {
      const masterProductId = req.params.id;
      const versions = await storage.getDesignVersions(masterProductId);
      res.json(versions);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/master-products/:id/design-versions", isAdmin, async (req, res) => {
    try {
      const masterProductId = req.params.id;
      const { headerText, headerStyle, footerText, footerStyle, qrUrl, renderedPngUrl, renderedSvgUrl, qrCodeUrl, placementImages } = req.body;
      if (!qrUrl) {
        return res.status(400).json({ error: "qrUrl is required" });
      }
      const existingVersions = await storage.getDesignVersions(masterProductId);
      const versionNumber = existingVersions.length + 1;
      const version = await storage.createDesignVersion({
        masterProductId,
        versionNumber,
        headerText: headerText || null,
        headerStyle: headerStyle || null,
        footerText: footerText || null,
        footerStyle: footerStyle || null,
        qrUrl,
        renderedPngUrl: renderedPngUrl || null,
        renderedSvgUrl: renderedSvgUrl || null,
        qrCodeUrl: qrCodeUrl || null,
        placementImages: placementImages || null,
        isActive: true
      });
      await storage.updateMasterProduct(masterProductId, {
        currentDesignVersionId: version.id
      });
      res.json(version);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/channel-configs", isAdmin, async (req, res) => {
    try {
      const configs = await storage.getAllChannelConfigs();
      res.json(configs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/channel-configs/:channelType", isAdmin, async (req, res) => {
    try {
      const config = await storage.getChannelConfig(req.params.channelType);
      if (!config) {
        return res.status(404).json({ error: "Channel config not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/channel-configs", isAdmin, async (req, res) => {
    try {
      const { channelType, displayName, isEnabled, apiKeySecretName, shopId, settings } = req.body;
      if (!channelType || !displayName) {
        return res.status(400).json({ error: "channelType and displayName are required" });
      }
      const config = await storage.createChannelConfig({
        channelType,
        displayName,
        isEnabled: isEnabled ?? false,
        apiKeySecretName: apiKeySecretName || null,
        shopId: shopId || null,
        settings: settings || {}
      });
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/orchestration/channel-configs/:channelType", isAdmin, async (req, res) => {
    try {
      const { displayName, isEnabled, apiKeySecretName, apiSecretSecretName, shopId, rateLimit: rateLimit2, rateLimitWindow, webhookSecret, settings } = req.body;
      const updates = {};
      if (displayName !== void 0) updates.displayName = displayName;
      if (isEnabled !== void 0) updates.isEnabled = isEnabled;
      if (apiKeySecretName !== void 0) updates.apiKeySecretName = apiKeySecretName;
      if (apiSecretSecretName !== void 0) updates.apiSecretSecretName = apiSecretSecretName;
      if (shopId !== void 0) updates.shopId = shopId;
      if (rateLimit2 !== void 0) updates.rateLimit = rateLimit2;
      if (rateLimitWindow !== void 0) updates.rateLimitWindow = rateLimitWindow;
      if (webhookSecret !== void 0) updates.webhookSecret = webhookSecret;
      if (settings !== void 0) updates.settings = settings;
      const config = await storage.updateChannelConfig(req.params.channelType, updates);
      if (!config) {
        return res.status(404).json({ error: "Channel config not found" });
      }
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/master-products/:id/publish-states", isAdmin, async (req, res) => {
    try {
      const masterProductId = req.params.id;
      const states = await storage.getPublishStates(masterProductId);
      res.json(states);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/provider-health", isAdmin, async (req, res) => {
    try {
      const { healthMonitor: healthMonitor2 } = await Promise.resolve().then(() => (init_health_monitor(), health_monitor_exports));
      const dashboard = await healthMonitor2.getHealthDashboard();
      res.json(dashboard);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/provider-health/check", isAdmin, async (req, res) => {
    try {
      const { healthMonitor: healthMonitor2 } = await Promise.resolve().then(() => (init_health_monitor(), health_monitor_exports));
      const results = await healthMonitor2.checkAllProviders();
      res.json({ success: true, results });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/provider-health/:providerType/check", isAdmin, async (req, res) => {
    try {
      const { healthMonitor: healthMonitor2 } = await Promise.resolve().then(() => (init_health_monitor(), health_monitor_exports));
      const result = await healthMonitor2.checkProvider(req.params.providerType);
      if (!result) {
        return res.status(404).json({ error: "Provider not found" });
      }
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/provider-health/:providerType/history", isAdmin, async (req, res) => {
    try {
      const { healthMonitor: healthMonitor2 } = await Promise.resolve().then(() => (init_health_monitor(), health_monitor_exports));
      const limit = parseInt(req.query.limit) || 100;
      const history = await healthMonitor2.getProviderHistory(req.params.providerType, limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/routing/route", isAdmin, async (req, res) => {
    try {
      const { autoRouter: autoRouter2 } = await Promise.resolve().then(() => (init_auto_router(), auto_router_exports));
      const { blueprintId, prioritize = "balanced", requireUSA, maxCostCents, excludeProviders } = req.body;
      if (!blueprintId) {
        return res.status(400).json({ error: "blueprintId is required" });
      }
      const result = await autoRouter2.routeOrder({
        blueprintId: parseInt(blueprintId),
        prioritize,
        requireUSA,
        maxCostCents,
        excludeProviders
      });
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/routing/recommendations/:blueprintId", isAdmin, async (req, res) => {
    try {
      const { autoRouter: autoRouter2 } = await Promise.resolve().then(() => (init_auto_router(), auto_router_exports));
      const blueprintId = parseInt(req.params.blueprintId);
      const recommendations = await autoRouter2.getRecommendations(blueprintId);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/routing/stats", isAdmin, async (req, res) => {
    try {
      const { autoRouter: autoRouter2 } = await Promise.resolve().then(() => (init_auto_router(), auto_router_exports));
      const stats = autoRouter2.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/routing/history", isAdmin, async (req, res) => {
    try {
      const { autoRouter: autoRouter2 } = await Promise.resolve().then(() => (init_auto_router(), auto_router_exports));
      const limit = parseInt(req.query.limit) || 20;
      const history = autoRouter2.getRecentRoutings(limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/routing/batch", isAdmin, async (req, res) => {
    try {
      const { autoRouter: autoRouter2 } = await Promise.resolve().then(() => (init_auto_router(), auto_router_exports));
      const { blueprintIds, prioritize = "balanced", requireUSA, maxCostCents } = req.body;
      if (!blueprintIds || !Array.isArray(blueprintIds)) {
        return res.status(400).json({ error: "blueprintIds array is required" });
      }
      const results = await autoRouter2.routeBatch(blueprintIds, {
        prioritize,
        requireUSA,
        maxCostCents
      });
      const resultsObj = {};
      for (const [id, result] of Array.from(results.entries())) {
        resultsObj[id] = result;
      }
      res.json(resultsObj);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/profit/dashboard", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const dashboard = await profitCalculator2.getDashboard();
      res.json(dashboard);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/profit/channels", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const summaries = await profitCalculator2.getChannelProfitSummaries();
      res.json(summaries);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/profit/products", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const products2 = await profitCalculator2.getProductProfitAnalysis();
      res.json(products2);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/profit/alerts", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const alerts = await profitCalculator2.generateAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/profit/calculate", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const { revenue, productionCost, shippingCost = 0, channel = "direct" } = req.body;
      if (typeof revenue !== "number" || !isFinite(revenue) || revenue < 0) {
        return res.status(400).json({ error: "revenue must be a non-negative number" });
      }
      if (typeof productionCost !== "number" || !isFinite(productionCost) || productionCost < 0) {
        return res.status(400).json({ error: "productionCost must be a non-negative number" });
      }
      if (typeof shippingCost !== "number" || !isFinite(shippingCost) || shippingCost < 0) {
        return res.status(400).json({ error: "shippingCost must be a non-negative number" });
      }
      if (typeof channel !== "string" || !["direct", "etsy", "ebay", "amazon", "printify", "printful", "apliiq"].includes(channel.toLowerCase())) {
        return res.status(400).json({ error: "channel must be one of: direct, etsy, ebay, amazon, printify, printful, apliiq" });
      }
      const breakdown = profitCalculator2.calculateOrderProfit(
        revenue,
        productionCost,
        shippingCost,
        channel
      );
      res.json(breakdown);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/profit/compare-channels", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const { productionCost, basePrice } = req.body;
      if (typeof productionCost !== "number" || !isFinite(productionCost) || productionCost < 0) {
        return res.status(400).json({ error: "productionCost must be a non-negative number" });
      }
      if (typeof basePrice !== "number" || !isFinite(basePrice) || basePrice < 0) {
        return res.status(400).json({ error: "basePrice must be a non-negative number" });
      }
      const comparison = profitCalculator2.compareChannelsForProduct(productionCost, basePrice);
      res.json(comparison);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/profit/recommended-price", isAdmin, async (req, res) => {
    try {
      const { profitCalculator: profitCalculator2 } = await Promise.resolve().then(() => (init_profit_calculator(), profit_calculator_exports));
      const { productionCost, targetMarginPercent = 50, channel = "direct" } = req.body;
      if (typeof productionCost !== "number" || !isFinite(productionCost) || productionCost < 0) {
        return res.status(400).json({ error: "productionCost must be a non-negative number" });
      }
      if (typeof targetMarginPercent !== "number" || !isFinite(targetMarginPercent) || targetMarginPercent < 0 || targetMarginPercent > 100) {
        return res.status(400).json({ error: "targetMarginPercent must be a number between 0 and 100" });
      }
      if (typeof channel !== "string") {
        return res.status(400).json({ error: "channel must be a string" });
      }
      const recommendedPrice = profitCalculator2.calculateRecommendedPrice(
        productionCost,
        targetMarginPercent,
        channel
      );
      res.json({
        productionCost,
        targetMarginPercent,
        channel,
        recommendedPrice
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/repricing/rules", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const rules = await autoRepricer2.getRules();
      res.json(rules);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/repricing/stats", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const stats = await autoRepricer2.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/repricing/history", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const limit = parseInt(req.query.limit) || 50;
      if (limit < 1 || limit > 500) {
        return res.status(400).json({ error: "limit must be between 1 and 500" });
      }
      const history = await autoRepricer2.getHistory(limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/repricing/rules", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const { name, description, isActive, priority, conditions, actionType, actionParams, appliesTo, appliesToIds } = req.body;
      if (!name || typeof name !== "string" || name.trim().length === 0) {
        return res.status(400).json({ error: "name is required and must be a non-empty string" });
      }
      if (!actionType || typeof actionType !== "string") {
        return res.status(400).json({ error: "actionType is required" });
      }
      const validActionTypes = ["adjust_margin", "match_target", "increase_percent", "decrease_percent"];
      if (!validActionTypes.includes(actionType)) {
        return res.status(400).json({ error: `actionType must be one of: ${validActionTypes.join(", ")}` });
      }
      const rule = await autoRepricer2.createRule({
        name: name.trim(),
        description,
        isActive,
        priority,
        conditions: conditions || {},
        actionType,
        actionParams: actionParams || {},
        appliesTo,
        appliesToIds
      });
      res.status(201).json(rule);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/orchestration/repricing/rules/:ruleId", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const { ruleId } = req.params;
      if (!ruleId) {
        return res.status(400).json({ error: "ruleId is required" });
      }
      const updated = await autoRepricer2.updateRule(ruleId, req.body);
      if (!updated) {
        return res.status(404).json({ error: "Rule not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/orchestration/repricing/rules/:ruleId", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const { ruleId } = req.params;
      if (!ruleId) {
        return res.status(400).json({ error: "ruleId is required" });
      }
      await autoRepricer2.deleteRule(ruleId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/repricing/rules/:ruleId/toggle", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const { ruleId } = req.params;
      const updated = await autoRepricer2.toggleRule(ruleId);
      if (!updated) {
        return res.status(404).json({ error: "Rule not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/repricing/rules/:ruleId/preview", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const { ruleId } = req.params;
      const preview = await autoRepricer2.previewRule(ruleId);
      res.json(preview);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/repricing/run", isAdmin, async (req, res) => {
    try {
      const { autoRepricer: autoRepricer2 } = await Promise.resolve().then(() => (init_auto_repricer(), auto_repricer_exports));
      const { dryRun = true } = req.body;
      const results = await autoRepricer2.evaluateAllProducts(dryRun);
      res.json({
        dryRun,
        productsAffected: results.length,
        results
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/qr-analytics/summary", isAdmin, async (req, res) => {
    try {
      const { qrAnalyticsService: qrAnalyticsService2 } = await Promise.resolve().then(() => (init_qr_analytics(), qr_analytics_exports));
      const summary = await qrAnalyticsService2.getSummary();
      res.json(summary);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/qr-analytics/products", isAdmin, async (req, res) => {
    try {
      const { qrAnalyticsService: qrAnalyticsService2 } = await Promise.resolve().then(() => (init_qr_analytics(), qr_analytics_exports));
      const limit = parseInt(req.query.limit) || 20;
      const analytics = await qrAnalyticsService2.getProductAnalytics(Math.min(Math.max(1, limit), 100));
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/qr-analytics/trends", isAdmin, async (req, res) => {
    try {
      const { qrAnalyticsService: qrAnalyticsService2 } = await Promise.resolve().then(() => (init_qr_analytics(), qr_analytics_exports));
      const days = parseInt(req.query.days) || 30;
      const trends = await qrAnalyticsService2.getTrends(Math.min(Math.max(1, days), 365));
      res.json(trends);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/qr-analytics/recent", isAdmin, async (req, res) => {
    try {
      const { qrAnalyticsService: qrAnalyticsService2 } = await Promise.resolve().then(() => (init_qr_analytics(), qr_analytics_exports));
      const limit = parseInt(req.query.limit) || 50;
      const recent = await qrAnalyticsService2.getRecentScans(Math.min(Math.max(1, limit), 200));
      res.json(recent);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/qr/scan", async (req, res) => {
    try {
      const { qrAnalyticsService: qrAnalyticsService2 } = await Promise.resolve().then(() => (init_qr_analytics(), qr_analytics_exports));
      const { masterProductId, customDesignId, qrUrl, country, region } = req.body;
      if (!masterProductId && !customDesignId && !qrUrl) {
        return res.status(400).json({ error: "At least one identifier required" });
      }
      const userAgent = req.headers["user-agent"] || "";
      const deviceType = qrAnalyticsService2.detectDeviceType(userAgent);
      await qrAnalyticsService2.logScan({
        masterProductId,
        customDesignId,
        qrUrl,
        country,
        region,
        deviceType,
        userAgent
      });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/bundles", isAdmin, async (req, res) => {
    try {
      const allBundles = await db3.select().from(productBundles).orderBy(productBundles.displayOrder);
      res.json(allBundles);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/bundles/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const bundle = await db3.select().from(productBundles).where(eq6(productBundles.id, id)).limit(1);
      if (!bundle.length) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      const items = await db3.select().from(bundleItems).where(eq6(bundleItems.bundleId, id)).orderBy(bundleItems.displayOrder);
      res.json({ ...bundle[0], items });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/bundles", isAdmin, async (req, res) => {
    try {
      const { items, ...bundleData } = req.body;
      const [bundle] = await db3.insert(productBundles).values(bundleData).returning();
      if (items && items.length > 0) {
        const itemsWithBundleId = items.map((item) => ({
          ...item,
          bundleId: bundle.id
        }));
        await db3.insert(bundleItems).values(itemsWithBundleId);
      }
      const finalItems = await db3.select().from(bundleItems).where(eq6(bundleItems.bundleId, bundle.id));
      res.json({ ...bundle, items: finalItems });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/orchestration/bundles/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { items, ...bundleData } = req.body;
      const [bundle] = await db3.update(productBundles).set({ ...bundleData, updatedAt: /* @__PURE__ */ new Date() }).where(eq6(productBundles.id, id)).returning();
      if (!bundle) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      if (items !== void 0) {
        await db3.delete(bundleItems).where(eq6(bundleItems.bundleId, id));
        if (items.length > 0) {
          const itemsWithBundleId = items.map((item) => ({
            ...item,
            bundleId: id
          }));
          await db3.insert(bundleItems).values(itemsWithBundleId);
        }
      }
      const finalItems = await db3.select().from(bundleItems).where(eq6(bundleItems.bundleId, id));
      res.json({ ...bundle, items: finalItems });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/orchestration/bundles/:id", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await db3.delete(productBundles).where(eq6(productBundles.id, id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/orchestration/bundles/:id/toggle", isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const [bundle] = await db3.select().from(productBundles).where(eq6(productBundles.id, id)).limit(1);
      if (!bundle) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      const [updated] = await db3.update(productBundles).set({ isActive: !bundle.isActive, updatedAt: /* @__PURE__ */ new Date() }).where(eq6(productBundles.id, id)).returning();
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/bundles/for-product/:productId", async (req, res) => {
    try {
      const { productId } = req.params;
      const now = /* @__PURE__ */ new Date();
      const activeBundles = await db3.select().from(productBundles).where(
        and6(
          eq6(productBundles.isActive, true),
          or3(
            isNull(productBundles.startDate),
            lte2(productBundles.startDate, now)
          ),
          or3(
            isNull(productBundles.endDate),
            gte2(productBundles.endDate, now)
          )
        )
      );
      const relevantBundles = activeBundles.filter((bundle) => {
        if (!bundle.triggerProductIds || bundle.triggerProductIds.length === 0) {
          return true;
        }
        return bundle.triggerProductIds.includes(productId);
      });
      const bundlesWithItems = await Promise.all(
        relevantBundles.map(async (bundle) => {
          const items = await db3.select().from(bundleItems).where(eq6(bundleItems.bundleId, bundle.id));
          return { ...bundle, items };
        })
      );
      res.json(bundlesWithItems);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/bundles/:id/calculate", async (req, res) => {
    try {
      const { id } = req.params;
      const { selectedItems } = req.body;
      const [bundle] = await db3.select().from(productBundles).where(eq6(productBundles.id, id)).limit(1);
      if (!bundle) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      const items = await db3.select().from(bundleItems).where(eq6(bundleItems.bundleId, id));
      let totalRetailPrice = 0;
      const itemDetails = [];
      for (const item of items) {
        if (selectedItems && !selectedItems.includes(item.id)) continue;
        let itemPrice = 0;
        let itemName = "";
        if (item.masterProductId) {
          const [mp] = await db3.select().from(masterProducts).where(eq6(masterProducts.id, item.masterProductId)).limit(1);
          if (mp && mp.retailPrice) {
            itemPrice = parseFloat(mp.retailPrice);
            itemName = mp.title;
          }
        } else if (item.productId) {
          const [product] = await db3.select().from(products).where(eq6(products.id, String(item.productId))).limit(1);
          if (product) {
            itemPrice = parseFloat(product.basePrice);
            itemName = product.name;
          }
        }
        const qty = item.quantity || 1;
        const itemDiscount = item.itemDiscountPercent ? parseFloat(item.itemDiscountPercent) / 100 : 0;
        const discountedPrice = itemPrice * (1 - itemDiscount) * qty;
        totalRetailPrice += discountedPrice;
        itemDetails.push({
          itemId: item.id,
          name: itemName,
          unitPrice: itemPrice,
          quantity: qty,
          discount: itemDiscount * 100,
          subtotal: discountedPrice
        });
      }
      let bundlePrice = totalRetailPrice;
      let savings = 0;
      if (bundle.pricingType === "fixed_price" && bundle.fixedPrice) {
        bundlePrice = parseFloat(bundle.fixedPrice);
        savings = totalRetailPrice - bundlePrice;
      } else if (bundle.pricingType === "discount_percent" && bundle.discountPercent) {
        const discount = parseFloat(bundle.discountPercent) / 100;
        bundlePrice = totalRetailPrice * (1 - discount);
        savings = totalRetailPrice - bundlePrice;
      } else if (bundle.pricingType === "discount_amount" && bundle.discountAmount) {
        bundlePrice = totalRetailPrice - parseFloat(bundle.discountAmount);
        savings = parseFloat(bundle.discountAmount);
      }
      res.json({
        bundleId: bundle.id,
        bundleName: bundle.name,
        originalPrice: totalRetailPrice,
        bundlePrice: Math.max(0, bundlePrice),
        savings: Math.max(0, savings),
        savingsPercent: totalRetailPrice > 0 ? savings / totalRetailPrice * 100 : 0,
        items: itemDetails
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  const { bulkPublisher: bulkPublisher2 } = await Promise.resolve().then(() => (init_bulk_publisher(), bulk_publisher_exports));
  app3.post("/api/admin/orchestration/bulk-publish", isAdmin, async (req, res) => {
    try {
      const { productIds, channelTypes } = req.body;
      if (!productIds?.length || !channelTypes?.length) {
        return res.status(400).json({ error: "productIds and channelTypes arrays required" });
      }
      const jobId = await bulkPublisher2.createJob({ productIds, channelTypes });
      res.json({ jobId, message: "Bulk publish job started" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/bulk-publish/:jobId", isAdmin, async (req, res) => {
    try {
      const job = bulkPublisher2.getJob(req.params.jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/orchestration/bulk-publish-jobs", isAdmin, async (req, res) => {
    try {
      const jobs = bulkPublisher2.getAllJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  function generateGiftCode() {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "GIFT";
    for (let i = 0; i < 3; i++) {
      code += "-";
      for (let j = 0; j < 4; j++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
      }
    }
    return code;
  }
  app3.get("/api/gifts/packages", async (req, res) => {
    try {
      const packages = await storage.getActiveGiftPackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/gifts/packages/:id", async (req, res) => {
    try {
      const pkg = await storage.getGiftPackage(req.params.id);
      if (!pkg) return res.status(404).json({ error: "Gift package not found" });
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/gifts/purchase", async (req, res) => {
    try {
      const { giftPackageId, buyerEmail, buyerName, personalMessage, recipientEmail } = req.body;
      const pkg = await storage.getGiftPackage(giftPackageId);
      if (!pkg) return res.status(404).json({ error: "Gift package not found" });
      if (!pkg.isActive) return res.status(400).json({ error: "Gift package is not available" });
      const buyerUserId = req.user?.claims?.sub || null;
      const expiresAt = /* @__PURE__ */ new Date();
      expiresAt.setDate(expiresAt.getDate() + (pkg.redemptionValidDays || 365));
      const giftCode = await storage.createGiftCode({
        code: generateGiftCode(),
        giftPackageId,
        buyerUserId,
        buyerEmail,
        buyerName,
        personalMessage: pkg.includePersonalMessage ? personalMessage : null,
        expiresAt,
        status: "active",
        lastEmailedTo: recipientEmail || null,
        lastEmailedAt: recipientEmail ? /* @__PURE__ */ new Date() : null
      });
      res.json({
        success: true,
        giftCode: giftCode.code,
        expiresAt: giftCode.expiresAt,
        packageName: pkg.name
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/gifts/redeem/:code", async (req, res) => {
    try {
      const giftCode = await storage.getGiftCodeByCode(req.params.code.toUpperCase());
      if (!giftCode) {
        return res.status(404).json({ error: "Gift code not found" });
      }
      if (giftCode.status === "redeemed") {
        return res.status(400).json({ error: "This gift has already been redeemed" });
      }
      if (giftCode.status === "expired" || /* @__PURE__ */ new Date() > new Date(giftCode.expiresAt)) {
        return res.status(400).json({ error: "This gift code has expired" });
      }
      if (giftCode.status === "cancelled") {
        return res.status(400).json({ error: "This gift code has been cancelled" });
      }
      const pkg = await storage.getGiftPackage(giftCode.giftPackageId);
      if (!pkg) {
        return res.status(500).json({ error: "Gift package not found" });
      }
      let productDetails = null;
      if (pkg.masterProductId) {
        const product = await storage.getMasterProduct(pkg.masterProductId);
        if (product) {
          const designVersions = await storage.getDesignVersions(product.id);
          productDetails = {
            id: product.id,
            title: product.title,
            imageUrl: designVersions[0]?.renderedPngUrl || null,
            // Colors/sizes are determined at checkout based on provider
            availableColors: [],
            availableSizes: []
          };
        }
      }
      res.json({
        giftCodeId: giftCode.id,
        packageName: pkg.name,
        packageDescription: pkg.description,
        giftType: pkg.giftType,
        personalMessage: giftCode.personalMessage,
        buyerName: giftCode.buyerName,
        expiresAt: giftCode.expiresAt,
        allowColorChoice: pkg.allowColorChoice,
        allowSizeChoice: pkg.allowSizeChoice,
        allowQrCustomization: pkg.allowQrCustomization,
        product: productDetails,
        dynamicsTier: pkg.dynamicsTier,
        dynamicsMonths: pkg.dynamicsMonths
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/gifts/redeem/:code", async (req, res) => {
    try {
      const giftCode = await storage.getGiftCodeByCode(req.params.code.toUpperCase());
      if (!giftCode) {
        return res.status(404).json({ error: "Gift code not found" });
      }
      if (giftCode.status !== "active") {
        return res.status(400).json({ error: `Gift code is ${giftCode.status}` });
      }
      if (/* @__PURE__ */ new Date() > new Date(giftCode.expiresAt)) {
        await storage.updateGiftCode(giftCode.id, { status: "expired" });
        return res.status(400).json({ error: "This gift code has expired" });
      }
      const { recipientEmail, recipientName, selectedColor, selectedSize, qrContent, qrStyle, shippingAddress } = req.body;
      const recipientUserId = req.user?.claims?.sub || null;
      const redemption = await storage.createGiftRedemption({
        giftCodeId: giftCode.id,
        recipientUserId,
        recipientEmail,
        recipientName,
        selectedColor,
        selectedSize,
        qrContent,
        qrStyle,
        shippingAddress,
        fulfillmentStatus: "pending"
      });
      await storage.updateGiftCode(giftCode.id, { status: "redeemed" });
      res.json({
        success: true,
        redemptionId: redemption.id,
        message: "Gift redeemed successfully! Your order is being processed."
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/gifts/packages", isAdmin, async (req, res) => {
    try {
      const packages = await storage.getAllGiftPackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/gifts/packages", isAdmin, async (req, res) => {
    try {
      const pkg = await storage.createGiftPackage(req.body);
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/gifts/packages/:id", isAdmin, async (req, res) => {
    try {
      const pkg = await storage.updateGiftPackage(req.params.id, req.body);
      if (!pkg) return res.status(404).json({ error: "Gift package not found" });
      res.json(pkg);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/gifts/packages/:id", isAdmin, async (req, res) => {
    try {
      await storage.deleteGiftPackage(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/gifts/codes", isAdmin, async (req, res) => {
    try {
      if (db3) {
        const { giftCodes: giftCodes2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
        const { desc: desc4 } = await import("drizzle-orm");
        const codes = await db3.select().from(giftCodes2).orderBy(desc4(giftCodes2.createdAt)).limit(100);
        res.json(codes);
      } else {
        res.json([]);
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/gifts/redemptions", isAdmin, async (req, res) => {
    try {
      if (db3) {
        const { giftRedemptions: giftRedemptions2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
        const { desc: desc4 } = await import("drizzle-orm");
        const redemptions = await db3.select().from(giftRedemptions2).orderBy(desc4(giftRedemptions2.redeemedAt)).limit(100);
        res.json(redemptions);
      } else {
        res.json([]);
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/gifts/redemptions/:id", isAdmin, async (req, res) => {
    try {
      const redemption = await storage.updateGiftRedemption(req.params.id, req.body);
      if (!redemption) return res.status(404).json({ error: "Redemption not found" });
      res.json(redemption);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/partner-stores", isAdmin, async (req, res) => {
    try {
      const stores = await storage.getPartnerStores();
      res.json(stores);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/partner-stores/:id", isAdmin, async (req, res) => {
    try {
      const store = await storage.getPartnerStore(req.params.id);
      if (!store) return res.status(404).json({ error: "Partner store not found" });
      res.json(store);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/partner-stores", isAdmin, async (req, res) => {
    try {
      const dataWithApiKey = {
        ...req.body,
        apiKey: req.body.apiKey || `qrg_${crypto.randomUUID().replace(/-/g, "")}`
      };
      const validated = insertPartnerStoreSchema.parse(dataWithApiKey);
      const existingStores = await storage.getPartnerStores();
      const normalizedName = validated.name?.toLowerCase().trim();
      const isDuplicate = existingStores.some(
        (s) => s.name?.toLowerCase().trim() === normalizedName && s.isInternal === validated.isInternal
      );
      if (isDuplicate) {
        return res.status(409).json({
          error: `A ${validated.isInternal ? "internal" : "partner"} store with the name "${validated.name}" already exists`
        });
      }
      const store = await storage.createPartnerStore(validated);
      res.json(store);
    } catch (error) {
      if (error instanceof z2.ZodError) {
        console.error("[Partner Store Validation Error]", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ error: "Validation error", details: error.errors });
      }
      console.error("[Partner Store Create Error]", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/partner-stores/:id", isAdmin, async (req, res) => {
    try {
      const store = await storage.updatePartnerStore(req.params.id, req.body);
      if (!store) return res.status(404).json({ error: "Partner store not found" });
      res.json(store);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/partner-stores/:id", isAdmin, async (req, res) => {
    try {
      await storage.deletePartnerStore(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/partner-stores/:id/regenerate-key", isAdmin, async (req, res) => {
    try {
      const newApiKey = `qrg_${crypto.randomUUID().replace(/-/g, "")}`;
      const store = await storage.updatePartnerStore(req.params.id, { apiKey: newApiKey });
      if (!store) return res.status(404).json({ error: "Partner store not found" });
      res.json({ apiKey: newApiKey });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/partner-stores/:id/products", isAdmin, async (req, res) => {
    try {
      const storeProducts = await storage.getPartnerStoreProducts(req.params.id);
      res.json(storeProducts);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/email-templates", isAdmin, async (req, res) => {
    try {
      const templates = await storage.getEmailTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/email-templates/:id", isAdmin, async (req, res) => {
    try {
      const template = await storage.getEmailTemplate(req.params.id);
      if (!template) return res.status(404).json({ error: "Template not found" });
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/email-templates", isAdmin, async (req, res) => {
    try {
      const parsed = insertEmailTemplateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.errors });
      }
      const template = await storage.createEmailTemplate(parsed.data);
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.patch("/api/admin/email-templates/:id", isAdmin, async (req, res) => {
    try {
      const parsed = insertEmailTemplateSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.errors });
      }
      const template = await storage.updateEmailTemplate(req.params.id, parsed.data);
      if (!template) return res.status(404).json({ error: "Template not found" });
      res.json(template);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/email-templates/:id", isAdmin, async (req, res) => {
    try {
      await storage.deleteEmailTemplate(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.get("/api/admin/email-logs", isAdmin, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 100;
      const logs = await storage.getEmailLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  function getProxyUrl(storagePath) {
    if (!storagePath) return null;
    return `/api/background-files/${encodeURIComponent(storagePath)}`;
  }
  app3.get("/api/admin/background-assets", isAdmin, async (req, res) => {
    try {
      const assetType = req.query.type;
      const { backgroundAssets: backgroundAssets2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      let query = db3.select().from(backgroundAssets2).where(eq6(backgroundAssets2.isActive, true));
      if (assetType && (assetType === "source" || assetType === "cropped")) {
        query = db3.select().from(backgroundAssets2).where(and6(eq6(backgroundAssets2.isActive, true), eq6(backgroundAssets2.assetType, assetType)));
      }
      const assets = await query.orderBy(backgroundAssets2.createdAt);
      const assetsWithProxy = assets.map((asset) => ({
        ...asset,
        proxyUrl: getProxyUrl(asset.storagePath)
      }));
      res.json(assetsWithProxy);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  app3.post("/api/admin/background-assets", isAdmin, async (req, res) => {
    try {
      const { name, assetType, imageData, mimeType, sourceAssetId, cropData, tags, fromZip } = req.body;
      if (!name || !assetType || !imageData) {
        return res.status(400).json({ error: "Missing required fields: name, assetType, imageData" });
      }
      if (assetType !== "source" && assetType !== "cropped") {
        return res.status(400).json({ error: "assetType must be 'source' or 'cropped'" });
      }
      let folderPath;
      if (assetType === "cropped") {
        folderPath = "library/backgrounds/cropped";
      } else if (fromZip) {
        folderPath = "library/backgrounds/raw/zip";
      } else {
        folderPath = "library/backgrounds/raw";
      }
      const fileName = `${Date.now()}-${name.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
      const uploadResult = await uploadImageFromBuffer(
        Buffer.from(imageData, "base64"),
        fileName,
        mimeType || "image/png",
        folderPath
      );
      const { backgroundAssets: backgroundAssets2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      const [asset] = await db3.insert(backgroundAssets2).values({
        name,
        assetType,
        imageUrl: uploadResult.publicUrl,
        storagePath: uploadResult.storageUrl,
        sourceAssetId: sourceAssetId || null,
        mimeType: mimeType || "image/png",
        cropData: cropData || null,
        tags: tags || null,
        isActive: true
      }).returning();
      res.json({
        ...asset,
        proxyUrl: getProxyUrl(asset.storagePath)
      });
    } catch (error) {
      console.error("Error uploading background asset:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app3.delete("/api/admin/background-assets/:id", isAdmin, async (req, res) => {
    try {
      const { backgroundAssets: backgroundAssets2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      await db3.update(backgroundAssets2).set({ isActive: false }).where(eq6(backgroundAssets2.id, req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  startCronJobs();
  const httpServer = createServer(app3);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs2 from "fs";
import path3 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path2 from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      ),
      await import("@replit/vite-plugin-dev-banner").then(
        (m) => m.devBanner()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path2.resolve(import.meta.dirname, "client", "src"),
      "@shared": path2.resolve(import.meta.dirname, "shared"),
      "@assets": path2.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path2.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path2.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app3, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app3.use(vite.middlewares);
  app3.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path3.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs2.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app3) {
  const distPath = path3.resolve(import.meta.dirname, "public");
  if (!fs2.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app3.use(express.static(distPath));
  app3.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}

// server/index.ts
init_stripeClient();
import { runMigrations } from "stripe-replit-sync";

// server/webhookHandlers.ts
init_stripeClient();
var WebhookHandlers = class {
  static async processWebhook(payload, signature) {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "STRIPE WEBHOOK ERROR: Payload must be a Buffer. Received type: " + typeof payload + ". This usually means express.json() parsed the body before reaching this handler. FIX: Ensure webhook route is registered BEFORE app.use(express.json())."
      );
    }
    const sync = await getStripeSync();
    await sync.processWebhook(payload, signature);
  }
};

// server/webhooks/index.ts
import { Router } from "express";
import crypto4 from "crypto";
var webhookRouter = Router();
var handlers = /* @__PURE__ */ new Map();
function verifyPrintifySignature(body, signature, secret) {
  if (!signature || !secret) return false;
  try {
    const expected = crypto4.createHmac("sha256", secret).update(body).digest("hex");
    if (signature.length !== expected.length) return false;
    return crypto4.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  } catch {
    return false;
  }
}
function verifyPrintfulSignature(body, signature, secret) {
  if (!signature || !secret) return false;
  try {
    const expected = crypto4.createHmac("sha256", secret).update(body).digest("base64");
    return signature === expected;
  } catch {
    return false;
  }
}
function verifyEtsySignature(body, signature, secret) {
  if (!signature || !secret) return false;
  try {
    const expected = crypto4.createHmac("sha256", secret).update(body).digest("hex");
    return signature === `sha256=${expected}`;
  } catch {
    return false;
  }
}
function verifyStripeSignature(body, signature, secret) {
  if (!signature || !secret) return false;
  try {
    const elements = signature.split(",");
    const timestampPart = elements.find((e) => e.startsWith("t="));
    const sigPart = elements.find((e) => e.startsWith("v1="));
    if (!timestampPart || !sigPart) return false;
    const timestamp2 = timestampPart.slice(2);
    const sig = sigPart.slice(3);
    const payload = `${timestamp2}.${body}`;
    const expected = crypto4.createHmac("sha256", secret).update(payload).digest("hex");
    if (sig.length !== expected.length) return false;
    return crypto4.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}
function parseProviderEventType(provider, payload) {
  switch (provider) {
    case "printify":
      const printifyEvent = payload.event;
      if (printifyEvent?.includes("order:created")) return "order.created";
      if (printifyEvent?.includes("order:shipped")) return "order.shipped";
      if (printifyEvent?.includes("order:delivered")) return "order.delivered";
      if (printifyEvent?.includes("order:cancelled")) return "order.cancelled";
      if (printifyEvent?.includes("product:")) return "product.updated";
      break;
    case "printful":
      const printfulType = payload.type;
      if (printfulType === "package_shipped") return "order.shipped";
      if (printfulType === "order_created") return "order.created";
      if (printfulType === "order_canceled") return "order.cancelled";
      if (printfulType === "product_synced") return "product.updated";
      if (printfulType === "stock_updated") return "stock.low";
      break;
    case "etsy":
      const etsyType = payload.type;
      if (etsyType === "shop.receipt.new") return "order.created";
      if (etsyType === "shop.receipt.shipped") return "order.shipped";
      break;
    case "ebay":
      const ebayMetadata = payload.metadata;
      const ebayTopic = ebayMetadata?.topic;
      if (ebayTopic?.includes("MARKETPLACE_ORDER")) return "order.created";
      break;
    case "amazon":
      const amazonType = payload.notificationType;
      if (amazonType === "ORDER_CHANGE") return "order.created";
      break;
    case "stripe":
      const stripeType = payload.type;
      if (stripeType === "checkout.session.completed") return "order.created";
      if (stripeType === "payment_intent.succeeded") return "order.created";
      break;
  }
  return "provider.error";
}
function getRawBody(req) {
  const raw = req.rawBody;
  if (Buffer.isBuffer(raw)) {
    return raw.toString("utf8");
  }
  if (typeof raw === "string") {
    return raw;
  }
  return JSON.stringify(req.body);
}
webhookRouter.post("/printify", async (req, res) => {
  try {
    const rawBody = getRawBody(req);
    const signature = req.headers["x-printify-signature"];
    const secret = process.env.PRINTIFY_WEBHOOK_SECRET || "";
    const verified = verifyPrintifySignature(rawBody, signature, secret);
    if (secret && !verified) {
      console.warn(`[Webhook] Printify signature verification failed`);
      return res.status(401).json({ error: "Invalid signature" });
    }
    const event = {
      id: crypto4.randomUUID(),
      provider: "printify",
      type: parseProviderEventType("printify", req.body),
      timestamp: /* @__PURE__ */ new Date(),
      payload: req.body,
      rawBody,
      verified
    };
    const handler = handlers.get("printify");
    if (handler) {
      await handler.handle(event);
    }
    console.log(`[Webhook] Printify event: ${event.type}, verified: ${verified}`);
    res.status(200).json({ received: true, eventId: event.id });
  } catch (error) {
    console.error("[Webhook] Printify error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});
webhookRouter.post("/printful", async (req, res) => {
  try {
    const rawBody = getRawBody(req);
    const signature = req.headers["x-printful-signature"];
    const secret = process.env.PRINTFUL_WEBHOOK_SECRET || "";
    const verified = verifyPrintfulSignature(rawBody, signature, secret);
    if (secret && !verified) {
      console.warn(`[Webhook] Printful signature verification failed`);
      return res.status(401).json({ error: "Invalid signature" });
    }
    const event = {
      id: crypto4.randomUUID(),
      provider: "printful",
      type: parseProviderEventType("printful", req.body),
      timestamp: /* @__PURE__ */ new Date(),
      payload: req.body,
      rawBody,
      verified
    };
    const handler = handlers.get("printful");
    if (handler) {
      await handler.handle(event);
    }
    console.log(`[Webhook] Printful event: ${event.type}, verified: ${verified}`);
    res.status(200).json({ received: true, eventId: event.id });
  } catch (error) {
    console.error("[Webhook] Printful error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});
webhookRouter.post("/etsy", async (req, res) => {
  try {
    const rawBody = getRawBody(req);
    const signature = req.headers["x-etsy-signature"];
    const secret = process.env.ETSY_WEBHOOK_SECRET || "";
    const verified = verifyEtsySignature(rawBody, signature, secret);
    if (secret && !verified) {
      console.warn(`[Webhook] Etsy signature verification failed`);
      return res.status(401).json({ error: "Invalid signature" });
    }
    const event = {
      id: crypto4.randomUUID(),
      provider: "etsy",
      type: parseProviderEventType("etsy", req.body),
      timestamp: /* @__PURE__ */ new Date(),
      payload: req.body,
      rawBody,
      verified
    };
    const handler = handlers.get("etsy");
    if (handler) {
      await handler.handle(event);
    }
    console.log(`[Webhook] Etsy event: ${event.type}, verified: ${verified}`);
    res.status(200).json({ received: true, eventId: event.id });
  } catch (error) {
    console.error("[Webhook] Etsy error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});
webhookRouter.post("/ebay", async (req, res) => {
  try {
    const rawBody = getRawBody(req);
    const challengeCode = req.query.challenge_code;
    if (challengeCode) {
      const verificationToken = process.env.EBAY_VERIFICATION_TOKEN || "";
      const endpoint = `${process.env.REPLIT_DOMAINS?.split(",")[0] ? `https://${process.env.REPLIT_DOMAINS.split(",")[0]}` : ""}/webhooks/ebay`;
      const hash = crypto4.createHash("sha256").update(challengeCode + verificationToken + endpoint).digest("hex");
      return res.status(200).json({ challengeResponse: hash });
    }
    const event = {
      id: crypto4.randomUUID(),
      provider: "ebay",
      type: parseProviderEventType("ebay", req.body),
      timestamp: /* @__PURE__ */ new Date(),
      payload: req.body,
      rawBody,
      verified: true
      // eBay verification happens via challenge-response
    };
    const handler = handlers.get("ebay");
    if (handler) {
      await handler.handle(event);
    }
    console.log(`[Webhook] eBay event: ${event.type}`);
    res.status(200).json({ received: true, eventId: event.id });
  } catch (error) {
    console.error("[Webhook] eBay error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});
webhookRouter.post("/amazon", async (req, res) => {
  try {
    const rawBody = getRawBody(req);
    const event = {
      id: crypto4.randomUUID(),
      provider: "amazon",
      type: parseProviderEventType("amazon", req.body),
      timestamp: /* @__PURE__ */ new Date(),
      payload: req.body,
      rawBody,
      verified: true
      // Amazon verification would be via AWS signature
    };
    const handler = handlers.get("amazon");
    if (handler) {
      await handler.handle(event);
    }
    console.log(`[Webhook] Amazon event: ${event.type}`);
    res.status(200).json({ received: true, eventId: event.id });
  } catch (error) {
    console.error("[Webhook] Amazon error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});
webhookRouter.post("/stripe", async (req, res) => {
  try {
    const rawBody = getRawBody(req);
    const signature = req.headers["stripe-signature"];
    const secret = process.env.STRIPE_WEBHOOK_SECRET || "";
    const verified = verifyStripeSignature(rawBody, signature, secret);
    if (secret && !verified) {
      console.warn(`[Webhook] Stripe signature verification failed`);
      return res.status(401).json({ error: "Invalid signature" });
    }
    const event = {
      id: crypto4.randomUUID(),
      provider: "stripe",
      type: parseProviderEventType("stripe", req.body),
      timestamp: /* @__PURE__ */ new Date(),
      payload: req.body,
      rawBody,
      verified
    };
    const handler = handlers.get("stripe");
    if (handler) {
      await handler.handle(event);
    }
    console.log(`[Webhook] Stripe event: ${event.type}, verified: ${verified}`);
    res.status(200).json({ received: true, eventId: event.id });
  } catch (error) {
    console.error("[Webhook] Stripe error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});
webhookRouter.get("/health", (_req, res) => {
  res.status(200).json({
    status: "ok",
    registeredHandlers: Array.from(handlers.keys()),
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});

// server/index.ts
init_storage();
var __filename = fileURLToPath(import.meta.url);
var __dirname = path4.dirname(__filename);
var app2 = express2();
app2.use("/assets", express2.static(path4.resolve(__dirname, "..", "attached_assets")));
async function initStripe() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.log("DATABASE_URL not found, skipping Stripe initialization");
    return;
  }
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  if (!hostname) {
    console.log("Stripe connector not configured, skipping Stripe initialization");
    console.log("(This is fine for testing - Stripe can be set up later)");
    return;
  }
  try {
    console.log("Initializing Stripe schema...");
    await runMigrations({ databaseUrl, schema: "stripe" });
    console.log("Stripe schema ready");
    const stripeSync2 = await getStripeSync();
    console.log("Setting up managed webhook...");
    const domains = process.env.REPLIT_DOMAINS;
    if (domains) {
      const webhookBaseUrl = `https://${domains.split(",")[0]}`;
      const result = await stripeSync2.findOrCreateManagedWebhook(
        `${webhookBaseUrl}/api/stripe/webhook`
      );
      if (result?.webhook?.url) {
        console.log(`Webhook configured: ${result.webhook.url}`);
      } else {
        console.log("Webhook setup completed");
      }
    } else {
      console.log("REPLIT_DOMAINS not set, skipping webhook setup");
    }
    console.log("Syncing Stripe data...");
    stripeSync2.syncBackfill().then(() => console.log("Stripe data synced")).catch((err) => console.error("Error syncing Stripe data:", err));
  } catch (error) {
    console.log("Stripe not fully configured, skipping:", error.message || error);
    console.log("(Payment features will be unavailable until Stripe is configured)");
  }
}
app2.post(
  "/api/stripe/webhook",
  express2.raw({ type: "application/json" }),
  async (req, res) => {
    const signature = req.headers["stripe-signature"];
    if (!signature) {
      return res.status(400).json({ error: "Missing stripe-signature" });
    }
    try {
      const sig = Array.isArray(signature) ? signature[0] : signature;
      if (!Buffer.isBuffer(req.body)) {
        console.error("STRIPE WEBHOOK ERROR: req.body is not a Buffer");
        return res.status(500).json({ error: "Webhook processing error" });
      }
      await WebhookHandlers.processWebhook(req.body, sig);
      res.status(200).json({ received: true });
    } catch (error) {
      console.error("Webhook error:", error.message);
      res.status(400).json({ error: "Webhook processing error" });
    }
  }
);
app2.use(express2.json({
  limit: "50mb",
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app2.use(express2.urlencoded({ extended: false }));
app2.use("/webhooks", webhookRouter);
var generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  max: 500,
  message: { error: "Too many requests, please try again later" },
  standardHeaders: true,
  legacyHeaders: false
});
var strictLimiter = rateLimit({
  windowMs: 15 * 60 * 1e3,
  max: 20,
  message: { error: "Too many requests, please try again later" },
  standardHeaders: true,
  legacyHeaders: false
});
var uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1e3,
  max: 30,
  message: { error: "Upload limit reached, please try again later" },
  standardHeaders: true,
  legacyHeaders: false
});
var mockupJobLimiter = rateLimit({
  windowMs: 60 * 60 * 1e3,
  max: 10,
  message: { error: "Mockup generation limit reached, please try again later" },
  standardHeaders: true,
  legacyHeaders: false
});
app2.use("/api/checkout", strictLimiter);
app2.use("/api/orders", generalLimiter);
app2.use("/api/images/upload", uploadLimiter);
app2.use("/api/qr/generate", generalLimiter);
app2.use("/api/mockup-jobs/batch", mockupJobLimiter);
app2.use("/api/", generalLimiter);
app2.use((req, res, next) => {
  const start = Date.now();
  const path5 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path5.startsWith("/api")) {
      let logLine = `${req.method} ${path5} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const storageMode = getStorageMode();
  if (storageMode !== "postgres-only") {
    log(`Initializing storage in ${storageMode} mode...`);
    await initializeWrappedStorage();
  }
  await initStripe();
  const server = await registerRoutes(app2);
  app2.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app2.get("env") === "development") {
    await setupVite(app2, server);
  } else {
    serveStatic(app2);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, async () => {
    log(`serving on port ${port}`);
    try {
      const { mockupJobQueue: mockupJobQueue2 } = await Promise.resolve().then(() => (init_mockup_job_queue(), mockup_job_queue_exports));
      mockupJobQueue2.startWorker();
      log("Mockup job queue worker started");
    } catch (err) {
      console.error("Failed to start mockup job queue worker:", err);
    }
  });
})();
