import { Request, Response } from 'express';
  import express from 'express';
  import { db } from '../core';
  import { freezePacketPricing, createCanonicalOrder, writePayoutAttribution } from '../services/order-service';
import { sendActivationEmail } from '../services/email';
import { MEMBER_PACKETS_COLLECTION } from '../constants';
import Stripe from 'stripe';

  export function register(app: express.Express): void {

app.post('/public/packet-checkout', async (req: Request, res: Response): Promise<void> => {
  try {
    const { packetId, selectedShirtSize, referrerId: rawReferrerId } = req.body;
    if (!packetId) { res.status(400).json({ error: "packetId is required" }); return; }

    let referrerId = '';
    if (rawReferrerId) {
      const referrerDoc = await db.collection('users').doc(rawReferrerId).get();
      if (referrerDoc.exists) { referrerId = rawReferrerId; }
      else { console.warn(`[PacketCheckout] Invalid referrerId '${rawReferrerId}' — not a real user, ignoring`); }
    }

    const packetDoc = await db.collection(MEMBER_PACKETS_COLLECTION).doc(packetId).get();
    if (!packetDoc.exists) { res.status(404).json({ error: "Product not found" }); return; }
    const packet = packetDoc.data()!;
    if (packet.status !== 'published' && packet.status !== 'active') {
      res.status(400).json({ error: "Product is no longer available" }); return;
    }

    const size = selectedShirtSize || packet.selectedShirtSize || 'M';
    const { totalPrice: serverTotal } = await freezePacketPricing({ packet, selectedSize: size });

    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!stripeKey) { res.status(503).json({ error: "Payment not configured" }); return; }
    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });

    const productTitle = packet.title || 'QR Gear Custom Product';
    const productImage = packet.itemImage || packet.socialPacket?.itemImage || null;
    const packetBaseUrl = process.env.FIREBASE_HOSTING_URL || 'https://qrgear-c1ffd.web.app';

    // Resolve creator's Connect account for automatic 25% transfer
    const creatorMemberId = packet.memberId || '';
    let connectAccountId = '';
    let connectTransferApplied = false;
    if (creatorMemberId) {
      try {
        const profileDoc = await db.collection('member_profiles').doc(creatorMemberId).get();
        const profile = profileDoc.data() || {};
        if (profile.stripeConnectAccountId && profile.stripePayoutsEnabled === true) {
          connectAccountId = profile.stripeConnectAccountId;
        }
      } catch (profileErr: any) {
        console.warn('[PacketCheckout] Non-fatal: Could not fetch creator profile for Connect:', profileErr.message);
      }
    }

    const totalCents = Math.round(serverTotal * 100);
    const entityShareCents = Math.floor(totalCents * 0.25);

    // Build session with optional destination transfer
    const sessionParams: any = {
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: productTitle,
            description: `Size: ${size}`,
            images: productImage ? [productImage.startsWith('http') ? productImage : `${packetBaseUrl}${productImage}`] : [],
          },
          unit_amount: totalCents,
        },
        quantity: 1,
      }],
      mode: 'payment',
      shipping_address_collection: {
        allowed_countries: ['US', 'CA', 'GB', 'AU', 'DE', 'FR', 'ES', 'IT', 'NL', 'BE'],
      },
      success_url: `${packetBaseUrl}/p/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${packetBaseUrl}/p/${packetId}`,
      metadata: {
        packetId,
        selectedShirtSize: size,
        referrerId: referrerId || '',
        source: 'packet_share',
        memberId: creatorMemberId,
        serverTotal: serverTotal.toString(),
        connectAccountId: connectAccountId || '',
        connectTransferApplied: connectAccountId ? 'true' : 'false',
      },
      customer_creation: 'if_required',
    };

    if (connectAccountId && entityShareCents > 0) {
      sessionParams.payment_intent_data = {
        transfer_data: {
          destination: connectAccountId,
          amount: entityShareCents,
        },
      };
      connectTransferApplied = true;
      console.log(`[PacketCheckout] Connect transfer: ${entityShareCents}¢ → ${connectAccountId}`);
    }

    const session = await stripe.checkout.sessions.create(sessionParams);

    console.log(`[PacketCheckout] Created session ${session.id} for packet ${packetId}, total: $${serverTotal}`);
    res.json({ url: session.url, sessionId: session.id, total: serverTotal });
  } catch (error: any) {
    console.error('[PacketCheckout] Error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

app.get('/public/packet-checkout/verify/:sessionId', async (req: Request, res: Response): Promise<void> => {
  try {
    const { sessionId } = req.params;
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!stripeKey) { res.status(503).json({ error: "Payment not configured" }); return; }
    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });

    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if (session.payment_status !== 'paid') {
      res.status(400).json({ error: "Payment not completed", status: session.payment_status }); return;
    }

    const packetId = session.metadata?.packetId;
    const referrerId = session.metadata?.referrerId;
    const selectedSize = session.metadata?.selectedShirtSize || 'M';
    const creatorMemberId = session.metadata?.memberId || '';
    const serverTotal = parseFloat(session.metadata?.serverTotal || '0');

    if (!packetId) { res.status(400).json({ error: "No packet linked to this session" }); return; }

    const existingOrderQuery = await db.collection('orders_public')
      .where('stripeSessionId', '==', sessionId).limit(1).get();
    if (!existingOrderQuery.empty) {
      const existingOrder = existingOrderQuery.docs[0].data();
      res.json({ success: true, alreadyProcessed: true, order: { id: existingOrderQuery.docs[0].id, ...existingOrder } });
      return;
    }

    const packetDoc = await db.collection(MEMBER_PACKETS_COLLECTION).doc(packetId).get();
    const packet = packetDoc.exists ? packetDoc.data()! : {};

    const buyerEmail = (session.customer_details as any)?.email || '';
    const buyerName = (session.customer_details as any)?.name || '';
    const shippingAddress = (session as any).shipping_details?.address || null;

    const totalAmount = serverTotal || ((session as any).amount_total! / 100);

    const { orderId, claimCode, alreadyExisted, orderData } = await createCanonicalOrder({
      source: 'packet_share',
      stripeSessionId: sessionId,
      stripePaymentIntentId: session.payment_intent as string,
      buyerEmail,
      buyerName,
      shippingAddress,
      totalAmount,
      packetId,
      packet,
      selectedSize,
      referrerId: referrerId || '',
      creatorMemberId,
    });

    if (!alreadyExisted) {
      const productCost = packet.pricingSnapshot?.printifyCostBase || packet.pricingSnapshot?.totalCostBase || 0;
      const connectAccountIdMeta = session.metadata?.connectAccountId || '';
      const connectTransferAppliedMeta = session.metadata?.connectTransferApplied === 'true';

      await writePayoutAttribution({
        source: 'packet_share',
        orderId,
        orderTotal: totalAmount,
        productCost,
        creatorMemberId,
        referrerId: referrerId || undefined,
        buyerEmail: buyerEmail || undefined,
        packetId,
        connectTransferApplied: connectTransferAppliedMeta,
        connectAccountId: connectAccountIdMeta || undefined,
      });

      // Send activation email with claim code
      if (buyerEmail && claimCode) {
        sendActivationEmail({
          customerEmail: buyerEmail,
          customerName: buyerName || 'Customer',
          activationCode: claimCode,
          productName: packet.title || packet.productTitle || 'QR Gear Product',
          previewImageUrl: packet.itemImage || packet.mockupUrl || null,
          orderId,
        }).catch((err: any) => console.error('[Checkout] Activation email error (non-fatal):', err));
      }
    }

    res.json({
      success: true,
      alreadyProcessed: alreadyExisted,
      order: { id: orderId, ...orderData },
      claimCode,
    });
  } catch (error: any) {
    console.error('[PacketCheckout Verify] Error:', error.message);
    res.status(500).json({ error: error.message });
  }
});


  }
  