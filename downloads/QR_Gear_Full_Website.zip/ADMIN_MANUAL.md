# QR Gear Admin Manual

## Getting Started

Access the admin panel by navigating to `/admin` in your browser or clicking "Admin" in the navigation menu.

---

## Managing Categories

Categories help organize your products and pre-designed collections. Users can filter products by category on the homepage.

### Viewing Categories

When you open the admin panel, you'll see a table showing all your categories with:
- **Icon** - Visual identifier for the category
- **Name** - The category display name
- **Description** - Brief description (visible on larger screens)
- **Status** - Toggle switch showing if category is active/visible
- **Actions** - Edit and delete buttons

### Adding Default Categories

If starting fresh with no categories:
1. Click the **"Seed Defaults"** button
2. This adds six starter categories: Religious, Political, Sports, Business, Entertainment, Custom

### Creating a New Category

1. Click the **"Add Category"** button (top right)
2. Fill in the form:
   - **Name** (required) - Display name for the category
   - **Description** - Brief explanation of what belongs in this category
   - **Icon** - Click one of the icon buttons to select a visual icon
   - **Active** - Toggle on/off to control visibility
3. Click **"Create"** to save

### Editing a Category

1. Find the category in the table
2. Click the **pencil icon** in the Actions column
3. Update any fields in the form
4. Click **"Update"** to save changes

### Deleting a Category

1. Find the category in the table
2. Click the **trash icon** in the Actions column
3. Confirm deletion in the popup dialog
4. Click **"Delete"** to permanently remove

**Warning:** Deleting a category cannot be undone. Products linked to this category may need to be reassigned.

### Toggling Category Visibility

- Use the **toggle switch** in the Status column to quickly show/hide a category
- When OFF (inactive): Category won't appear in filters on the storefront
- When ON (active): Category is visible to customers

---

## Category Icons

Choose from these available icons:
- **Church** - Religious/faith-based items
- **Flag** - Political/patriotic items
- **Trophy** - Sports/athletic items
- **Briefcase** - Business/professional items
- **Music** - Entertainment/media items
- **Palette** - Custom/creative items
- **Tag** - General/uncategorized items

---

## Tips

1. **Start with defaults** - Use "Seed Defaults" to get started quickly, then customize
2. **Keep it simple** - 5-8 categories is usually enough for good organization
3. **Use descriptive names** - Clear category names help customers find products
4. **Hide, don't delete** - If unsure, toggle a category inactive instead of deleting
5. **Refresh if needed** - Click the "Refresh" button to reload categories from the database

---

## Troubleshooting

**Categories not loading?**
- Check your internet connection
- Click the "Refresh" button
- Verify Firebase credentials are configured correctly

**Can't create categories?**
- Ensure Firebase Firestore is in test mode or has proper security rules
- Check browser console for error messages

**Categories not showing on storefront?**
- Verify the category is toggled to "Active"
- Refresh the homepage

---

## Printify Integration

QR Gear is connected to Printify for print-on-demand fulfillment.

### Connected Shop
- **Shop Name:** QRGear
- **Shop ID:** 19642701 (stored as PRINTIFY_SHOP_ID)

### Available Products

Products are synced from Printify's catalog. Current products include:

| Product | Category | Blueprint ID | Made in USA |
|---------|----------|--------------|-------------|
| Unisex Jersey T-Shirt (Bella+Canvas) | Apparel | 12 | Yes |
| Heavy Cotton T-Shirt (Gildan) | Apparel | 6 | Yes |
| Trucker Cap (OTTO Cap) | Headwear | 1128 | Yes |
| Dad Hat with Leather Patch | Headwear | 1221 | Yes |
| Ceramic Mug 11oz | Drinkware | 68 | Yes |
| Ceramic Mug 15oz | Drinkware | 425 | Yes |
| Canvas Tote Bag | Bags | 467 | Yes |
| Drawstring Bag | Bags | 414 | Yes |

### USA Flag Badge

Products marked as "Made in USA" display an American flag badge on product cards.

---

## Multi-Provider Orchestration System

The orchestration system lets you manage products across multiple print providers and marketplaces from one place.

### Accessing Orchestration

Navigate to `/admin/orchestration` or click "Orchestration" in the admin menu.

### Dashboard Overview

The dashboard shows:
- **Provider Health** - Real-time status of all print providers (Printify, Printful)
- **Channel Status** - Connection status for each marketplace (Etsy, eBay, Amazon)
- **Recent Orders** - Unified view of orders from all channels
- **Publishing Queue** - Products waiting to be published

### Managing Master Products

Master products are your central product definitions that get published to multiple channels.

**Creating a Master Product:**
1. Go to the Products tab
2. Tap "New Product"
3. Fill in product details (name, description, base price)
4. Upload or generate your QR artwork
5. Select which variants to offer (sizes, colors)
6. Save the master product

**Publishing to Channels:**
1. Select a master product
2. Tap "Publish"
3. Choose which channels to publish to
4. Review channel-specific pricing (auto-calculated with fees)
5. Confirm to publish

### Bulk Publishing

Publish multiple products at once:
1. Go to the Bulk Publish tab
2. Select products using checkboxes
3. Choose target channels
4. Tap "Publish Selected"
5. Monitor progress in the queue

### Provider Health Monitor

View real-time status of print providers:
- **Green** - Provider operational, fast shipping
- **Yellow** - Minor delays or issues
- **Red** - Provider down or major problems

The system automatically routes orders to healthy providers.

### Auto-Routing

Orders are automatically routed to the best provider based on:
- Provider availability
- Shipping speed
- Production cost
- Customer location

### Profit Calculator

View profit margins for each channel:
1. Select a product
2. Open the Profit tab
3. See breakdown of costs, fees, and margins per channel
4. Get recommended pricing suggestions

### Auto-Repricing

Set rules to automatically adjust prices:
1. Go to Repricing Rules
2. Create a new rule
3. Set conditions (cost changes, competition, margins)
4. Set actions (price adjustments)
5. Enable the rule

---

## Gift Mode

Gift Mode lets customers purchase gift packages that recipients can redeem and customize.

### Accessing Gift Management

Navigate to `/admin/gifts` or click "Gifts" in the admin menu.

### Managing Gift Packages

**Creating a Gift Package:**
1. Go to the Packages tab
2. Tap "Create Package"
3. Fill in details:
   - **Name** - Display name (e.g., "Custom T-Shirt Gift")
   - **Description** - What's included
   - **Type** - Product gift or QR Dynamics subscription
   - **Price** - Amount the purchaser pays
   - **Expiration Days** - How long codes remain valid (default 365)
4. For product gifts, select available customization options
5. For subscriptions, choose tier and duration
6. Toggle "Active" to make available
7. Tap "Create"

**Editing a Package:**
1. Find the package in the table
2. Tap the pencil icon
3. Update details
4. Tap "Update"

### Viewing Gift Codes

The Codes tab shows all generated gift codes:
- **Code** - The unique gift code (format: GIFT-XXXX-XXXX-XXXX)
- **Package** - Which package it's for
- **Status** - Active, Redeemed, Expired, or Cancelled
- **Purchaser** - Who bought the gift
- **Created** - When the code was generated

Tap the copy icon to copy a code to share with the recipient.

### Managing Redemptions

The Redemptions tab shows all redeemed gifts:
- **Code** - The gift code that was used
- **Recipient** - Who redeemed it
- **Customizations** - Their chosen options (size, color, etc.)
- **Fulfillment Status** - Pending, Processing, Shipped, or Delivered

**Updating Fulfillment Status:**
1. Find the redemption in the table
2. Use the dropdown in the Actions column
3. Select the new status
4. Status updates automatically

### Gift Purchase Flow (Customer Side)

1. Customer visits `/gifts`
2. Browses available gift packages
3. Selects a package
4. Enters recipient info and personal message
5. Completes payment
6. Receives the gift code to share

### Gift Redemption Flow (Recipient Side)

1. Recipient visits `/redeem`
2. Enters their gift code
3. Sees the gift details and personal message
4. Customizes their product (size, color, QR content)
5. Enters shipping address
6. Confirms redemption
7. Order is created for fulfillment

---

## Unified Order Dashboard

View and manage orders from all channels in one place.

### Accessing Orders

Navigate to `/admin/orders` or click "Orders" in the admin menu.

### Order List

Shows all orders with:
- **Order ID** - Unique identifier
- **Channel** - Where the order came from (Etsy, eBay, Amazon, Direct)
- **Customer** - Buyer name
- **Items** - Products ordered
- **Total** - Order amount
- **Status** - Current fulfillment status
- **Provider** - Which print provider is handling it

### Filtering Orders

Use filters to find specific orders:
- By channel
- By status
- By date range
- By provider

### Order Details

Tap an order to see:
- Full customer information
- Shipping address
- Line items with customizations
- Production status from provider
- Tracking information (when available)

---

## QR Analytics

Track how your QR codes are being scanned.

### Viewing Analytics

Navigate to `/admin/analytics` or click "Analytics" in the admin menu.

### Available Metrics

- **Total Scans** - All-time scan count
- **Scans Today** - Today's activity
- **Top Products** - Most scanned QR codes
- **Scan Locations** - Geographic distribution
- **Scan Timeline** - Activity over time

---

## Tips for Mobile Use

The admin panel is designed for touch screens:
- All buttons are large (48px minimum) for easy tapping
- Tables scroll horizontally on narrow screens
- Forms use large input fields
- Dialogs are sized for mobile screens

---

## Email Notifications

QR Gear sends automated transactional emails to customers.

### Email Types

1. **Order Confirmation** - Sent automatically when checkout completes
   - Includes order details, items, prices, and shipping address
   - Sent to the customer's email from Stripe checkout

2. **Shipping Notification** - Sent when tracking info is available
   - Includes tracking number, carrier, and tracking link
   - Auto-sent when syncing order status from Printify (if tracking is new)

### Email API Endpoints (Admin Only)

**Resend Order Confirmation:**
```
POST /admin/orders/:id/resend-confirmation
```
Manually resend the order confirmation email.

**Send Shipping Notification:**
```
POST /admin/orders/:id/send-shipping-email
```
Manually send shipping notification (requires tracking number on order).

### Configuration

Email requires `QR_RESEND_API_KEY` environment variable set in Firebase Cloud Functions.

To configure:
1. Create a Resend account at resend.com
2. Add and verify your sender domain (e.g., qrgear.com)
3. Get your API key from Resend dashboard
4. Add to Cloud Functions via Google Cloud Console:
   - Go to https://console.cloud.google.com/functions
   - Select the `api` function
   - Click Edit → Runtime environment variables
   - Add `QR_RESEND_API_KEY` with your Resend API key

### Email Sender

Emails are sent from: `QR Gear <noreply@qrgear.com>`

Note: You must verify ownership of qrgear.com domain in Resend before emails will send successfully.

---

## Transactional Email

The existing Resend service sends order confirmations, shipping notices, and activation emails.
Use **System → Email** for order/shipping templates (`email_templates`) and send logs (`email_logs`).
Saved templates use the existing trigger and template-variable schema. With no saved template,
the built-in email is used; a disabled template stops the email.

`sent` means the provider accepted the message, not confirmed inbox delivery. `failed` records
the send error. Order controls allow an explicit resend. There is no separate email queue or
background retry worker. Automatic sends use provider idempotency keys; manual resends use a new key.

---

## Public Wizard Checkout & Post-Sale Flow

The Public Wizard (`/build` and `/creator`) lets visitors build custom QR products without an account and purchase them through guest checkout.

### How It Works — Step by Step

**Building Phase:**
1. Visitor arrives at `/build` (or `/creator`) and selects a product
2. System creates a temporary packet in Firestore to track their build
3. As they go through each step (color, size, QR type, placements, text), the packet is updated
4. At the preview step, real Printful mockups are generated showing the actual product
5. Visitor sees a cost summary and member conversion pitch ("Turn This Into Income")

**Checkout Phase:**
6. Visitor clicks "Add to Cart" — no account required
7. System creates a Stripe checkout session from the temp packet data
8. Price is re-calculated server-side from product data (never trusts client-side price)
9. Stripe collects payment and buyer's email on the checkout page
10. On successful payment, temp packet converts to a permanent product packet

**Post-Sale Phase:**
11. A unique **claim code** (e.g. `QR-7X4M-9K2P`) is generated and stored on the order
12. Confirmation email is sent with the claim code
13. Buyer sees a two-path confirmation screen:
    - **"Become a Member"**: Track shipping, keep custom graphic permanently, turn design into income, manage QR destination
    - **"No thanks"**: Clean goodbye with order number, claim code info, and scan instructions
14. If buyer doesn't become a member, their custom graphic is retained for 30 days as incentive

**Item Registration (When Product Arrives):**
15. Buyer receives their physical product (e.g. shirt) and scans the QR code
16. System prompts them to enter their **claim code** to register the item
17. This creates a `buyer_instance` record in QR Dynamics, linking the physical product to their account
18. Without the claim code, nobody can register someone else's item
19. Buyer can now control where the QR points, see scan analytics, etc.

### Admin Notes
- Temp packets have a 24-hour expiration if not purchased
- Claim codes are visible on order records in the admin panel
- The pricing validation step ensures no price manipulation by the buyer
- Expired temp packets are automatically cleaned up

---

## Marketplaces

Sell your products on external platforms like Etsy, eBay, and Amazon.

### Accessing Marketplaces
Navigate to **Admin > Marketplaces** or visit `/admin/marketplaces`.

### Connecting a Marketplace
1. Click **Add Marketplace**
2. Enter a store name (e.g., "My Etsy Shop")
3. Select the platform (Etsy, eBay, or Amazon)
4. Click **Create Marketplace Store**

### Configuring a Marketplace
After creating a marketplace store, click the gear icon to configure:
- **Shop Name**: Your shop name on that platform
- **Shop / Seller ID**: The marketplace-assigned ID
- **Marketplace Fee %**: Used to calculate listing prices that maintain your target margin
- **Auto-Sync Inventory**: Toggle automatic inventory sync with the marketplace

### Managing Listings
Expand a marketplace store to see assigned products. From here you can:
- View listing status (Draft, Listed, Syncing, Error, Delisted)
- Push products to the marketplace
- View the listing on the marketplace (external link)
- Sync all listings

### Store Types Overview
The platform uses four store types:
- **Internal**: QR Gear's own storefront (USA 250, etc.)
- **Marketplace**: Etsy, eBay, Amazon (you sell, they display)
- **Partner**: External sites embedding QR Gear UX
- **Member**: Individual member stores via wizard

---

## Known Issues (as of April 19, 2026)

### Product Builder Stuck on "Starting…"

**What you see:** When you select a shirt (or any product) in the Products builder, the sticky bar at the top shows a spinning "Starting…" badge that never changes to "In progress." The Save Draft button never appears.

**Why it happens:** Two separate root causes were identified and partially fixed:

1. **Missing Firestore index** — The query that looks up or creates a build session requires a composite index on the `buildSessions` collection. That index was missing, causing a silent 500 error every time a product was selected. The index has been added to `firestore.indexes.json` and deployed to production. The server-side query was also rewritten to avoid depending on that index so it works even before the index finishes building.

2. **Background Cost Sync blocking the server** — On startup (and every hour), the server runs a Printify cost sync that makes hundreds of sequential API calls. While this is running, the Express server is heavily occupied and often cannot respond to the build session creation request in time. This is the likely cause of the issue still occurring after the index fix.

**What still needs to be fixed (for Ghost):**

The Cost Sync job (`[Cron] Starting Printify catalog sync...`) needs to be moved off the main Express server thread. Options:
- Move it to a Firebase Cloud Functions scheduled trigger (e.g., `pubsub.schedule`) so it runs independently and does not block the dev or production server
- Or convert it to a true background worker using a job queue so it does not starve incoming HTTP requests
- As a minimum short-term fix: add a concurrency limiter so the cost sync runs no more than 1-2 Printify API calls at a time with a delay between them, preventing it from monopolizing the event loop

**Files relevant to this bug:**
- `server/routes/admin-build-sessions.routes.ts` — build session creation endpoint (query already fixed)
- `firestore.indexes.json` — composite index for `buildSessions` already added
- `server/lib/cron.ts` (or equivalent) — where the Printify cost sync job is scheduled
- `client/src/features/adminProducts/builder/modules/ProductsModule.tsx` line 616 — where the frontend calls `POST /api/admin/build-sessions/from-master`

**Workaround for now:** Wait until the cost sync finishes (it runs for several minutes on startup). You can tell it is done when the server logs stop printing `[Cost Sync]` lines. After that, re-select your product and the builder should initialize correctly.

### Email Page Crash: "d.map is not a function"

**What you see:** Navigating to the Email section in admin shows "We hit a snag. The app encountered an error and logged it for recovery." with the error `d.map is not a function`.

**Why it happens:** The dev server and Cloud Functions return the email data in different shapes:
- Dev server returns a plain array: `[...]`
- Cloud Functions return a wrapped object: `{ templates: [...] }` or `{ logs: [...] }`

The frontend assumed a plain array and called `.map()` directly on whichever response it got. When it received the wrapped object from Cloud Functions, `.map()` crashed.

**Fix applied:** `client/src/pages/admin-email-templates.tsx` — the query now checks whether the response is a plain array or a wrapped object and handles both formats correctly. The email page should load without crashing after this fix is deployed.

**Root cause for Ghost:** The Cloud Functions routes in `functions/src/routes/am-crud.ts` (lines 129–164) wrap their responses in `{ templates }` and `{ logs }` objects, while the equivalent dev server routes in `server/routes/misc/partner-stores-email.routes.ts` return plain arrays. These should be made consistent — the Cloud Functions should return plain arrays to match the dev server.

### Orchestration Page Crash: "x.map is not a function" — FIXED

**What the problem was:** Navigating to the Orchestration section crashed with `.map is not a function`. The Cloud Functions routes for `/admin/orchestration/master-products` and `/admin/orchestration/channel-configs` were returning wrapped objects (`{ products: [...] }`, `{ configs: [...] }`) while the dev server returned plain arrays.

**Full fix applied (both layers):**
- `functions/src/routes/am-crud.ts` lines 295 and 332 — changed to return plain arrays, matching the dev server. This is the root cause fix.
- `client/src/pages/admin-orchestration.tsx`, `orchestration-bundles-tab.tsx`, and `admin-gifts.tsx` — defensive unwrapping added on the frontend as a belt-and-suspenders guard.

---

### API Authentication Refactor: Central Fetch Utilities — COMPLETED

**What changed:** All member-facing and admin-facing API calls across the frontend have been migrated from a scattered pattern (direct `fetch()` + manual `getAuthHeaders()` + hardcoded base URL) to two centralized utilities.

**Before (old pattern — now removed from admin and member files):**
```ts
const { apiBase, getAuthHeaders } = useAdminAuth();
const headers = await getAuthHeaders();
const res = await fetch(`${apiBase}/some-route`, { headers });
```

**After (new pattern):**
```ts
import { adminFetch } from "@/lib/adminFetch";
const data = await adminFetch("/some-route", { json: payload });

import { memberFetch } from "@/lib/memberFetch";
const data = await memberFetch(`/${userId}/channels`);
```

**Files migrated:**
- `client/src/lib/adminFetch.ts` — new utility, prepends `/api/admin`, auto-injects admin auth
- `client/src/lib/memberFetch.ts` — new utility, prepends `/api/members`, auto-injects member auth
- All admin feature files (`adminProducts`, `adminStores`, `adminOrders`, etc.)
- All member feature files: `wizard-context-actions.ts`, `WizardContext.tsx`, `MembersPage.tsx`, `SocialHubView.tsx`, `SocialHubSections.tsx`, `member-channels-view.tsx`, `member-index-view.tsx`, `MemberIndexView.tsx`, `PayoutsView.tsx`, `wizard-context-navigation.ts`, `SuperSimpleWizard.tsx`
- Shared wizard components: `VideoSourcePicker.tsx`, `BackgroundLibraryPicker.tsx`, `wizardSteps/ChannelStep.tsx`

**Legitimate exceptions** — these three cases intentionally keep using `getAuthHeaders()` directly:
- `PayoutsView.tsx` — calls `/api/connect/...` (Stripe Connect), a different route prefix with no dedicated utility
- `member-channels-view.tsx` — calls `/api/member/packets` (singular route), separate from `/api/members/` (plural)
- `wizard-context-actions.ts` XHR video upload — uses `XMLHttpRequest` for upload progress tracking, which requires headers on the XHR object directly

**Impact:** No user-visible change. Auth behavior is identical. All API calls now fail loudly with a descriptive error instead of silently returning empty data on auth failure.

---

## Need Help?

Contact support if you encounter issues not covered in this manual.
