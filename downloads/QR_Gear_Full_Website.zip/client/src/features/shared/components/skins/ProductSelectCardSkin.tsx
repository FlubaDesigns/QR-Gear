import type { PrintTextColorOverride } from '@shared/printTextColor';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { formatBlankId } from "@shared/blankKeys";
import type { CanonicalProductSelectItem } from "@shared/adapters/catalog.adapter";
import { useMemo, useState, useEffect, useCallback } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import UsaFlag from "@/components/UsaFlag";
import {
  Check,
  Factory,
  Package,
  Palette,
  Ruler,
  Eye,
  Pencil,
  Save,
  Loader2,
  Trash2,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  Images,
  X,
  CheckSquare,
  Square,
} from "lucide-react";

// Keep the shared catalog adapter as the single UI field contract.
export type ProductSelectItem = CanonicalProductSelectItem;

export type TierValue = "good" | "better" | "best" | null;

export interface ProductSelectCardSkinProps {
  item: ProductSelectItem;
  isSelected: boolean;
  onSelect: (id: string, item: ProductSelectItem) => void;
  tier?: TierValue;
  onTierChange?: (id: string, tier: TierValue) => void;
  showTierControls?: boolean;
  onDescriptionSave?: (id: string, description: string, restore?: boolean) => Promise<void>;
  descriptionSaving?: boolean;
  editableDescription?: boolean;
  onTitleSave?: (id: string, title: string) => Promise<void>;
  titleSaving?: boolean;
  editableTitle?: boolean;
  textEditScope?: string;
  priceLabel?: string;
  selectLabel?: React.ReactNode;
  selectedLabel?: React.ReactNode;
  disableWhenSelected?: boolean;
  selectDisabled?: boolean;
  selectDisabledTitle?: string;
  onImageDelete?: (id: string, imageUrl: string) => Promise<void>;
  onImageRestore?: (id: string) => Promise<void>;
  onImagesBulkSave?: (id: string, images: string[]) => Promise<void>;
  masterCatalogImages?: string[];
  fulfillmentProvider?: string;
  mockupImageUrl?: string | null;
  editableColors?: boolean;
  savedColors?: Array<{name: string; hex: string}>;
  onColorsSave?: (id: string, colors: Array<{name: string; hex: string}>) => Promise<void>;
  colorsSaving?: boolean;
  onTextColorSave?: (id: string, colorName: string, mode: PrintTextColorOverride) => Promise<void>;
  textColorSaving?: boolean;
}

function PreviewModal({
  item,
  open,
  onOpenChange,
  onSelect,
  defaultColorEntry,
  onDescriptionSave,
  descriptionSaving,
  editableDescription,
  onTitleSave,
  titleSaving,
  editableTitle,
  textEditScope,
  onImageDelete,
  onImageRestore,
  onImagesBulkSave,
  masterCatalogImages,
  tier,
  onTierChange,
  showTierControls,
  mockupImageUrl,
  editableColors,
  savedColors,
  onColorsSave,
  colorsSaving,
  onTextColorSave, textColorSaving,
  actionLabel,
  actionDisabled,
  priceLabel,
  providerLabel,
}: {
  actionLabel: React.ReactNode;
  actionDisabled: boolean;
  priceLabel?: string;
  providerLabel?: string;
  item: ProductSelectItem;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: () => void;
  defaultColorEntry: { name: string; hex?: string } | null;
  onDescriptionSave?: (id: string, description: string, restore?: boolean) => Promise<void>;
  descriptionSaving?: boolean;
  editableDescription?: boolean;
  onTitleSave?: (id: string, title: string) => Promise<void>;
  titleSaving?: boolean;
  editableTitle?: boolean;
  textEditScope?: string;
  mockupImageUrl?: string | null;
  onImageDelete?: (id: string, imageUrl: string) => Promise<void>;
  onImageRestore?: (id: string) => Promise<void>;
  onImagesBulkSave?: (id: string, images: string[]) => Promise<void>;
  masterCatalogImages?: string[];
  tier?: TierValue;
  onTierChange?: (id: string, tier: TierValue) => void;
  showTierControls?: boolean;
  editableColors?: boolean;
  savedColors?: Array<{name: string; hex: string}>;
  onColorsSave?: (id: string, colors: Array<{name: string; hex: string}>) => Promise<void>;
  colorsSaving?: boolean;
  onTextColorSave?: (id: string, colorName: string, mode: PrintTextColorOverride) => Promise<void>;
  textColorSaving?: boolean;
}) {
  const isMobile = useIsMobile();
  const [editingDesc, setEditingDesc] = useState(false);
  const [draftDesc, setDraftDesc] = useState(item.description || "");
  const [confirmResetDesc, setConfirmResetDesc] = useState(false);
  const [editingTitle, setEditingTitle] = useState(false);
  const [draftTitle, setDraftTitle] = useState(item.name || "");
  const [confirmResetTitle, setConfirmResetTitle] = useState(false);
  const [selectedColorNames, setSelectedColorNames] = useState<Set<string>>(
    () => new Set(savedColors ? savedColors.map(c => c.name) : item.availableColors.map(c => c.name))
  );
  useEffect(() => {
    setSelectedColorNames(new Set(savedColors ? savedColors.map(c => c.name) : item.availableColors.map(c => c.name)));
  }, [savedColors, item.availableColors]);

  const masterImages = useMemo(() => {
    const imgs = item.images ?? (item.primaryImageUrl ? [item.primaryImageUrl] : []);
    return imgs;
  }, [item.images, item.primaryImageUrl]);

  const [localImages, setLocalImages] = useState<string[]>(masterImages);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Prepend the mockup as the very first image when available.
  // localImages always stays as the editable product images only — mockup is display-only.
  const displayImages = useMemo(
    () => (mockupImageUrl ? [mockupImageUrl, ...localImages] : localImages),
    [mockupImageUrl, localImages]
  );
  const isMockupIndex = mockupImageUrl ? currentIndex === 0 : false;
  const currentImage = displayImages[currentIndex] ?? null;
  const [deletingImageUrl, setDeletingImageUrl] = useState<string | null>(null);

  useEffect(() => {
    setLocalImages(masterImages);
    setCurrentIndex(0);
  }, [item.id, masterImages.join(",")]);

  const handlePrev = () => setCurrentIndex(i => Math.max(0, i - 1));
  const handleNext = () => setCurrentIndex(i => Math.min(displayImages.length - 1, i + 1));

  const handleDeleteImage = async (imgUrl: string) => {
    if (!onImageDelete || deletingImageUrl) return;
    setDeletingImageUrl(imgUrl);
    const newImages = localImages.filter(u => u !== imgUrl);
    setLocalImages(newImages);
    if (currentIndex >= newImages.length && newImages.length > 0) {
      setCurrentIndex(newImages.length - 1);
    }
    try {
      await onImageDelete(item.id, imgUrl);
    } catch {
      setLocalImages(localImages);
    } finally {
      setDeletingImageUrl(null);
    }
  };

  const [savingText, setSavingText] = useState(false);
  const [textSaveError, setTextSaveError] = useState<string | null>(null);
  const saveText = async (field: "title" | "description", value: string, restore = false) => {
    const save = field === "title" ? onTitleSave : onDescriptionSave;
    if (!save || savingText) return;
    setSavingText(true);
    setTextSaveError(null);
    try {
      if (field === "description") await onDescriptionSave!(item.id, value, restore);
      else await onTitleSave!(item.id, value);
      if (field === "title") { setEditingTitle(false); setConfirmResetTitle(false); }
      else { setEditingDesc(false); setConfirmResetDesc(false); }
    } catch {
      setTextSaveError("Could not save. Your edits are still here.");
    } finally {
      setSavingText(false);
    }
  };
  const handleSaveDesc = () => saveText("description", draftDesc);
  const handleSaveTitle = () => saveText("title", draftTitle);

  const [restoringImages, setRestoringImages] = useState(false);
  const imagesAreModified = masterCatalogImages !== undefined
    && localImages.join(",") !== masterCatalogImages.join(",");

  const handleRestoreImages = async () => {
    if (!onImageRestore || restoringImages) return;
    setRestoringImages(true);
    try {
      await onImageRestore(item.id);
      if (masterCatalogImages) {
        setLocalImages(masterCatalogImages);
        setCurrentIndex(0);
      }
    } catch {
      // The save callback reports the error; keep the current selection.
    } finally {
      setRestoringImages(false);
    }
  };

  // ── Bulk select mode ──────────────────────────────────────────────────────
  const [bulkMode, setBulkMode] = useState(false);
  const [selectedForDeletion, setSelectedForDeletion] = useState<Set<string>>(new Set());
  const [bulkSaving, setBulkSaving] = useState(false);

  const enterBulkMode = useCallback(() => {
    setSelectedForDeletion(new Set());
    setBulkMode(true);
  }, []);

  const exitBulkMode = useCallback(() => {
    setBulkMode(false);
    setSelectedForDeletion(new Set());
  }, []);

  const toggleBulkImage = useCallback((url: string) => {
    setSelectedForDeletion(prev => {
      const next = new Set(prev);
      if (next.has(url)) next.delete(url); else next.add(url);
      return next;
    });
  }, []);

  const selectAllForDeletion = useCallback(() => {
    setSelectedForDeletion(new Set(localImages));
  }, [localImages]);

  const clearBulkSelection = useCallback(() => {
    setSelectedForDeletion(new Set());
  }, []);

  const confirmBulkDelete = useCallback(async () => {
    if (!onImagesBulkSave || bulkSaving || selectedForDeletion.size === 0) return;
    const keptImages = localImages.filter(img => !selectedForDeletion.has(img));
    setBulkSaving(true);
    try {
      await onImagesBulkSave(item.id, keptImages);
      setLocalImages(keptImages);
      setCurrentIndex(0);
      exitBulkMode();
    } catch {
      // The save callback reports the error; retain the selection for retry.
    } finally {
      setBulkSaving(false);
    }
  }, [onImagesBulkSave, bulkSaving, selectedForDeletion, localImages, item.id, exitBulkMode]);

  // Enter = confirm bulk delete, Escape = exit bulk mode
  useEffect(() => {
    if (!bulkMode) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && selectedForDeletion.size > 0) confirmBulkDelete();
      else if (e.key === 'Escape') exitBulkMode();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [bulkMode, selectedForDeletion.size, confirmBulkDelete, exitBulkMode]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="[&_button]:min-h-12 [&_button]:min-w-12 [&>button]:left-4 [&>button]:right-auto [&>button]:flex [&>button]:items-center [&>button]:justify-center [&>button]:bg-background fixed left-2 right-2 top-2 bottom-2 w-auto max-w-none max-h-none translate-x-0 translate-y-0 p-0 overflow-hidden sm:left-[50%] sm:right-auto sm:top-[50%] sm:bottom-auto sm:w-[95vw] sm:max-w-lg sm:max-h-[90vh] sm:translate-x-[-50%] sm:translate-y-[-50%]"
        data-testid={`modal-preview-${item.id}`}
      >
        <VisuallyHidden>
          <DialogTitle>{item.name}</DialogTitle>
        </VisuallyHidden>

        <div className="h-full sm:max-h-[90vh] overflow-y-auto">
          <div className="relative">
            {/* Main image gallery */}
            <div
              className={`relative bg-muted flex items-center justify-center overflow-hidden ${
                isMobile ? "min-h-[220px] max-h-[45vh]" : "aspect-square"
              }`}
            >
              {currentImage ? (
                <img
                  key={currentImage}
                  src={currentImage}
                  alt={`${item.name} ${currentIndex + 1} of ${displayImages.length}`}
                  loading="lazy"
                  decoding="async"
                  className={`max-w-full max-h-full object-contain ${isMobile ? "p-2" : "p-3"}`}
                  data-testid={`img-preview-large-${item.id}`}
                />
              ) : (
                <Package className="h-24 w-24 text-muted-foreground" />
              )}

              {/* Mockup label — shown when viewing the generated mockup image */}
              {isMockupIndex && (
                <div className="absolute top-3 right-3">
                  <Badge className="bg-primary/90 text-primary-foreground text-xs backdrop-blur-sm shadow-sm">
                    Mockup
                  </Badge>
                </div>
              )}

              {/* Prev / Next navigation — desktop only, overlaid on image */}
              {!isMobile && displayImages.length > 1 && (
                <>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute left-1 top-1/2 -translate-y-1/2 bg-black/40 text-white disabled:opacity-30"
                    onClick={handlePrev}
                    aria-label="Previous image"
                    disabled={currentIndex === 0}
                    data-testid={`button-img-prev-${item.id}`}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute right-1 top-1/2 -translate-y-1/2 bg-black/40 text-white disabled:opacity-30"
                    onClick={handleNext}
                    aria-label="Next image"
                    disabled={currentIndex === displayImages.length - 1}
                    data-testid={`button-img-next-${item.id}`}
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </>
              )}

              {/* Counter — desktop only inside image */}
              {!isMobile && displayImages.length > 1 && (
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/50 text-white text-xs px-2 py-0.5 rounded-full pointer-events-none">
                  {currentIndex + 1} / {displayImages.length}
                </div>
              )}

              {item.madeInUSA && (
                <div className="absolute bottom-3 right-3">
                  <Badge
                    variant="secondary"
                    className="gap-1 bg-background/90 backdrop-blur-sm text-xs shadow-sm"
                  >
                    <UsaFlag className="w-3 h-2" /> USA
                  </Badge>
                </div>
              )}
            </div>

            {/* Mobile prev/next row — below the image, easy one-thumb reach */}
            {isMobile && displayImages.length > 1 && (
              <div className="flex items-center justify-between px-4 py-2 bg-muted/30 border-b">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={handlePrev}
                    aria-label="Previous image"
                  disabled={currentIndex === 0}
                  data-testid={`button-img-prev-${item.id}`}
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
                <span className="text-xs text-muted-foreground">
                  {currentIndex + 1} / {displayImages.length}
                </span>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={handleNext}
                    aria-label="Next image"
                  disabled={currentIndex === displayImages.length - 1}
                  data-testid={`button-img-next-${item.id}`}
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            )}

            {/* Image action row — delete + restore, always below the image for easy access */}
            {(onImageDelete || onImageRestore) && (
              <div className="flex items-center justify-between gap-2 px-3 py-2 bg-muted/20 border-b">
                <div className="flex-1">
                  {onImageRestore && imagesAreModified && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="gap-1.5 text-muted-foreground"
                      onClick={handleRestoreImages}
                      disabled={restoringImages}
                      data-testid={`button-restore-images-${item.id}`}
                    >
                      {restoringImages
                        ? <Loader2 className="h-4 w-4 animate-spin" />
                        : <RotateCcw className="h-4 w-4" />
                      }
                      Restore all
                    </Button>
                  )}
                </div>
                {/* Delete is disabled on the mockup — it's not a catalog image */}
                {onImageDelete && currentImage && !isMockupIndex && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="gap-1.5 text-destructive/80"
                    onClick={() => handleDeleteImage(currentImage)}
                    disabled={!!deletingImageUrl}
                    data-testid={`button-delete-img-${item.id}`}
                  >
                    {deletingImageUrl === currentImage
                      ? <Loader2 className="h-4 w-4 animate-spin" />
                      : <Trash2 className="h-4 w-4" />
                    }
                    Remove this image
                  </Button>
                )}
              </div>
            )}

            {/* Thumbnail strip — horizontal scrollable rail */}
            {displayImages.length > 1 && (
              <div className="bg-muted/50 px-3 py-2 border-t" data-testid={`gallery-strip-${item.id}`}>
                <div className="flex gap-2 overflow-x-auto overflow-y-hidden whitespace-nowrap touch-pan-x snap-x snap-mandatory pb-1">
                  {displayImages.map((imgUrl, idx) => {
                    const isMockupThumb = mockupImageUrl ? idx === 0 : false;
                    return (
                      <button
                        key={imgUrl}
                        type="button"
                        onClick={() => setCurrentIndex(idx)}
                        className={`relative snap-start flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 transition-colors ${
                          idx === currentIndex ? "border-primary" : "border-transparent"
                        }`}
                        data-testid={`button-thumb-${item.id}-${idx}`}
                      >
                        <img
                          src={imgUrl}
                          alt={isMockupThumb ? "Mockup" : `Thumbnail ${idx + 1}`}
                          className="w-full h-full object-contain bg-background p-0.5"
                        />
                        {isMockupThumb && (
                          <span className="absolute bottom-0 left-0 right-0 text-center text-[9px] font-semibold bg-primary/80 text-primary-foreground leading-tight py-0.5">
                            Mockup
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Image count indicator + bulk select entry point */}
            {onImageDelete && (
              <div className="flex items-center justify-between gap-2 px-3 py-1.5 bg-muted/30 text-xs text-muted-foreground border-t">
                <div className="flex items-center gap-1.5 min-w-0">
                  <Images className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">
                    {localImages.length > 0
                      ? `${localImages.length} image${localImages.length !== 1 ? "s" : ""} forwarded to members`
                      : "No images — use Restore all to reset"
                    }
                  </span>
                </div>
                {onImagesBulkSave && localImages.length > 1 && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-6 text-xs px-2 flex-shrink-0"
                    onClick={enterBulkMode}
                    data-testid={`button-bulk-select-${item.id}`}
                  >
                    <CheckSquare className="w-3 h-3 mr-1" />
                    Select
                  </Button>
                )}
              </div>
            )}

            {/* ── Bulk select grid ── */}
            {bulkMode && (
              <div className="border-t bg-background" data-testid={`bulk-select-panel-${item.id}`}>
                {/* Header row */}
                <div className="flex items-center justify-between gap-2 px-3 py-2 border-b bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs gap-1"
                      onClick={selectedForDeletion.size === localImages.length ? clearBulkSelection : selectAllForDeletion}
                      data-testid={`button-select-all-${item.id}`}
                    >
                      {selectedForDeletion.size === localImages.length
                        ? <><Square className="w-3.5 h-3.5" /> Deselect all</>
                        : <><CheckSquare className="w-3.5 h-3.5" /> Select all</>
                      }
                    </Button>
                    {selectedForDeletion.size > 0 && (
                      <span className="text-xs text-destructive font-medium">
                        {selectedForDeletion.size} will be removed
                      </span>
                    )}
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 text-xs"
                    onClick={exitBulkMode}
                    data-testid={`button-bulk-cancel-${item.id}`}
                  >
                    Cancel
                  </Button>
                </div>

                {/* Image grid */}
                <div className="grid grid-cols-3 gap-1.5 p-2 max-h-[40vh] overflow-y-auto">
                  {localImages.map((imgUrl, idx) => {
                    const marked = selectedForDeletion.has(imgUrl);
                    return (
                      <button
                        key={imgUrl}
                        type="button"
                        onClick={() => toggleBulkImage(imgUrl)}
                        className={`relative aspect-square rounded-md overflow-hidden border-2 transition-colors ${
                          marked ? "border-destructive" : "border-transparent"
                        }`}
                        data-testid={`bulk-img-${item.id}-${idx}`}
                      >
                        <img
                          src={imgUrl}
                          alt={`Image ${idx + 1}`}
                          className="w-full h-full object-contain bg-muted p-0.5"
                        />
                        {/* Overlay for selected (to-be-deleted) images */}
                        {marked && (
                          <div className="absolute inset-0 bg-destructive/30 flex items-center justify-center">
                            <div className="bg-destructive rounded-full p-0.5">
                              <X className="w-3.5 h-3.5 text-destructive-foreground" />
                            </div>
                          </div>
                        )}
                        {/* Keep indicator for unselected */}
                        {!marked && (
                          <div className="absolute top-1 right-1">
                            <div className="bg-background/80 rounded-full p-0.5">
                              <Check className="w-3 h-3 text-green-500" />
                            </div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Confirm delete footer */}
                <div className="flex items-center gap-2 px-3 py-2 border-t bg-muted/20">
                  <p className="text-xs text-muted-foreground flex-1">
                    {selectedForDeletion.size === 0
                      ? "Select images above to remove them"
                      : `${localImages.length - selectedForDeletion.size} image${localImages.length - selectedForDeletion.size !== 1 ? "s" : ""} will be kept`
                    }
                  </p>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="gap-1.5"
                    onClick={confirmBulkDelete}
                    disabled={selectedForDeletion.size === 0 || bulkSaving}
                    data-testid={`button-bulk-confirm-${item.id}`}
                  >
                    {bulkSaving
                      ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      : <Trash2 className="w-3.5 h-3.5" />
                    }
                    Delete {selectedForDeletion.size > 0 ? selectedForDeletion.size : ""} selected
                  </Button>
                </div>
              </div>
            )}

            <div className="p-4 space-y-4">
              {textEditScope && (editableTitle || editableDescription) && (
                <p className="text-sm font-medium" data-testid={`text-edit-scope-${item.id}`}>{textEditScope}</p>
              )}
              {textSaveError && <p role="alert" className="text-sm text-destructive">{textSaveError}</p>}
              <div className="space-y-2">
                {editableTitle && onTitleSave ? (
                  <div data-testid={`title-edit-area-${item.id}`}>
                    {editingTitle ? (
                      <div className="space-y-2">
                        <Input
                          value={draftTitle}
                          onChange={(e) => setDraftTitle(e.target.value)}
                          className="text-base font-semibold"
                          placeholder="Enter a custom title..."
                          data-testid={`input-title-${item.id}`}
                        />
                        {item.providerTitle && item.providerTitle !== draftTitle && (
                          confirmResetTitle ? (
                            <div className="flex items-center gap-2 text-xs" data-testid={`confirm-reset-title-${item.id}`}>
                              <span className="text-muted-foreground">Reset to original — are you sure?</span>
                              <button
                                type="button"
                                className="text-red-400 hover:text-red-300 underline font-medium"
                                disabled={savingText || titleSaving}
                                onClick={() => saveText("title", "")}
                                data-testid={`button-confirm-yes-reset-title-${item.id}`}
                              >
                                Yes, reset
                              </button>
                              <button
                                type="button"
                                className="text-muted-foreground hover:text-foreground underline"
                                onClick={() => setConfirmResetTitle(false)}
                                data-testid={`button-confirm-cancel-reset-title-${item.id}`}
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              className="text-xs text-blue-400 hover:text-blue-300 underline"
                              onClick={() => setConfirmResetTitle(true)}
                              data-testid={`button-reset-to-provider-title-${item.id}`}
                            >
                              Reset to original title
                            </button>
                          )
                        )}
                        <div className="flex gap-2">
                          <Button onClick={handleSaveTitle} disabled={savingText || titleSaving} data-testid={`button-save-title-${item.id}`}>
                            Save title
                          </Button>
                          <Button variant="outline" disabled={savingText} onClick={() => { setEditingTitle(false); setConfirmResetTitle(false); setDraftTitle(item.name || ""); }}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="group w-full text-left cursor-pointer rounded-md border border-dashed border-muted-foreground/30 p-3"
                        onClick={() => { setDraftTitle(item.name || ""); setEditingTitle(true); }}
                        data-testid={`button-edit-title-${item.id}`}
                      >
                        <div className="flex items-start gap-2">
                          <Pencil className="w-3.5 h-3.5 mt-1 text-muted-foreground shrink-0" />
                          <h3 className="font-semibold text-lg leading-tight" data-testid={`text-preview-name-${item.id}`}>
                            {item.name}
                          </h3>
                        </div>
                        {item.adminCatalogTitle && (
                          <span className="ml-6 text-xs text-blue-400">Custom title</span>
                        )}
                      </button>
                    )}
                  </div>
                ) : (
                  <h3 className="font-semibold text-lg leading-tight" data-testid={`text-preview-name-${item.id}`}>
                    {item.name}
                  </h3>
                )}

                <div className="flex items-center gap-3 flex-wrap">
                  {item.price != null && (
                    <span className="text-2xl font-bold" data-testid={`text-preview-price-${item.id}`}>
                      {priceLabel && <span className="text-sm font-normal mr-2">{priceLabel}</span>}${item.price.toFixed(2)}
                    </span>
                  )}
                  {item.cost != null && (
                    <span className="text-sm text-muted-foreground">
                      Cost: ${item.cost.toFixed(2)}
                    </span>
                  )}
                  {item.price != null && item.cost != null && (
                    <Badge variant="secondary" className="bg-green-500/15 text-green-600 text-sm">
                      +${(item.price - item.cost).toFixed(2)} profit
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {providerLabel && <Badge variant="outline">{providerLabel}</Badge>}
                  {defaultColorEntry && (
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <span className="flex items-center gap-1.5">
                        <span
                          className="inline-block w-3 h-3 rounded-full border border-border"
                          style={{ backgroundColor: defaultColorEntry.hex || "#888" }}
                        />
                        <span>{defaultColorEntry.name}</span>
                      </span>
                    </span>
                  )}
                </div>

                {(item.manufacturer || item.model) && (
                  <div className="flex items-center gap-2 flex-wrap text-sm text-muted-foreground">
                    <span className="flex items-center gap-1.5">
                      <Factory className="w-4 h-4" />
                      <span>{[item.manufacturer, item.model].filter(Boolean).join(' ')}</span>
                    </span>
                  </div>
                )}

                {editableDescription && onDescriptionSave ? (
                  <div className="space-y-2" data-testid={`desc-edit-area-${item.id}`}>
                    {editingDesc ? (
                      <>
                        <Textarea
                          value={draftDesc}
                          onChange={(e) => setDraftDesc(e.target.value)}
                          className="text-sm min-h-[80px]"
                          placeholder="Enter a custom description for this product..."
                          data-testid={`textarea-desc-${item.id}`}
                        />
                        {(item.providerDescription || item.providerDescriptionRaw) && (item.providerDescription || item.providerDescriptionRaw) !== draftDesc && (
                          confirmResetDesc ? (
                            <div className="flex items-center gap-2 text-xs" data-testid={`confirm-reset-desc-${item.id}`}>
                              <span className="text-muted-foreground">Reset to original — are you sure?</span>
                              <button
                                type="button"
                                className="text-red-400 hover:text-red-300 underline font-medium"
                                disabled={savingText || descriptionSaving}
                                onClick={() => saveText("description", "", true)}
                                data-testid={`button-confirm-yes-reset-desc-${item.id}`}
                              >
                                Yes, reset
                              </button>
                              <button
                                type="button"
                                className="text-muted-foreground hover:text-foreground underline"
                                onClick={() => setConfirmResetDesc(false)}
                                data-testid={`button-confirm-cancel-reset-desc-${item.id}`}
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              className="text-xs text-blue-400 hover:text-blue-300 underline"
                              onClick={() => setConfirmResetDesc(true)}
                              data-testid={`button-reset-to-provider-${item.id}`}
                            >
                              Reset to original description
                            </button>
                          )
                        )}
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={handleSaveDesc}
                            disabled={descriptionSaving || savingText}
                            data-testid={`button-save-desc-${item.id}`}
                          >
                            {descriptionSaving ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Save className="w-4 h-4" />
                            )}
                            Save description
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={savingText}
                            onClick={() => { setConfirmResetDesc(false); setEditingDesc(false); setDraftDesc(item.description || ""); }}
                            data-testid={`button-cancel-desc-${item.id}`}
                          >
                            Cancel
                          </Button>
                        </div>
                      </>
                    ) : (
                      <button
                        type="button"
                        className="group w-full text-left cursor-pointer rounded-md border border-dashed border-muted-foreground/30 p-3"
                        onClick={() => { setDraftDesc(item.description || item.providerDescription || ""); setEditingDesc(true); }}
                        data-testid={`button-edit-desc-${item.id}`}
                      >
                        <div className="flex items-start gap-2">
                          <Pencil className="w-3.5 h-3.5 mt-0.5 text-muted-foreground shrink-0" />
                          {item.description ? (
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          ) : (
                            <p className="text-sm text-muted-foreground italic">Tap to add a custom description...</p>
                          )}
                        </div>
                      </button>
                    )}
                  </div>
                ) : (
                  item.description && <p className="text-sm text-muted-foreground">{item.description}</p>
                )}
              </div>

              {(item.availableColors.length > 0 || item.availableSizes.length > 0) && (
                <div className="space-y-3">
                  {item.availableColors.length > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Palette className="w-3.5 h-3.5" />
                        <span>{item.availableColors.length} colors</span>
                      </div>
                      <div className={`flex flex-wrap gap-1.5 ${isMobile ? "max-h-[52px] overflow-hidden" : ""}`}>
                        {item.availableColors.map((c, i) => (
                          <div
                            key={i}
                            className="w-5 h-5 rounded-full border border-border flex-shrink-0"
                            style={{ backgroundColor: c.hex || "#888" }}
                            title={c.name}
                            data-testid={`preview-swatch-${item.id}-${i}`}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {item.availableSizes.length > 0 && (
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Ruler className="w-3.5 h-3.5" />
                        <span>{item.availableSizes.length} sizes</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {item.availableSizes.map((s, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {s}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {showTierControls && onTierChange && (
                <div className="space-y-1.5" data-testid={`tier-controls-modal-${item.id}`}>
                  <p className="text-xs text-muted-foreground font-medium">Quality Tier</p>
                  <div className="flex gap-2">
                    {(["good", "better", "best"] as const).map((t) => (
                      <Button
                        key={t}
                        size="sm"
                        variant={tier === t ? "default" : "outline"}
                        className={`flex-1 text-xs ${tier === t ? TIER_COLORS[t] : ""}`}
                        onClick={() => onTierChange(item.id, tier === t ? null : t)}
                        data-testid={`button-modal-tier-${t}-${item.id}`}
                      >
                        {TIER_LABELS[t]}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {onTextColorSave && item.availableColors.length > 0 && <details className="space-y-3">
                <summary className="min-h-12 cursor-pointer py-3 text-sm font-medium">Automatic print text by product color</summary>
                <p className="text-xs text-muted-foreground">Applies to new Automatic text builds of this blank in every catalog and site. Existing approved artwork stays saved.</p>
                {item.availableColors.map(c => <label key={c.name} className="flex flex-col gap-1 text-sm">
                  <span>{c.name}</span>
                  <select aria-label={`Automatic text for ${c.name}`} value={c.textColorMode ?? 'auto'} disabled={textColorSaving}
                    className="w-full min-h-12 rounded-md border bg-background px-3"
                    onChange={event => { void onTextColorSave(item.id, c.name, event.target.value as PrintTextColorOverride).catch(() => { /* Controller reports the failed save. */ }); }}>
                    <option value="auto">Automatic</option><option value="light">Light text (white)</option><option value="dark">Dark text (black)</option>
                  </select>
                  {c.contrastHex === null && (c.textColorMode ?? 'auto') === 'auto' && <span className="text-xs text-destructive">Color value unavailable. Choose Light text or Dark text.</span>}
                </label>)}
              </details>}

              {editableColors && onColorsSave && item.availableColors.length > 0 && (
                <div className="space-y-2" data-testid={`color-controls-modal-${item.id}`}>
                  <p className="text-xs text-muted-foreground font-medium">
                    Curated Colors ({selectedColorNames.size} of {item.availableColors.length} shown in wizard)
                  </p>
                  <div className="flex flex-wrap gap-x-3 gap-y-2 max-h-40 overflow-y-auto pr-1">
                    {item.availableColors.map((c, i) => (
                      <label key={i} className="flex items-center gap-1.5 cursor-pointer min-w-[120px]">
                        <input
                          type="checkbox"
                          className="rounded"
                          checked={selectedColorNames.has(c.name)}
                          onChange={e => {
                            const next = new Set(selectedColorNames);
                            if (e.target.checked) next.add(c.name); else next.delete(c.name);
                            setSelectedColorNames(next);
                          }}
                          data-testid={`checkbox-color-${item.id}-${i}`}
                        />
                        <div
                          className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                          style={{ backgroundColor: c.hex || '#888' }}
                        />
                        <span className="text-xs truncate">{c.name}</span>
                      </label>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={colorsSaving}
                      onClick={() => {
                        const selected = item.availableColors
                          .filter(c => selectedColorNames.has(c.name))
                          .map(c => ({ name: c.name, hex: c.hex || '' }));
                        void onColorsSave(item.id, selected).catch(() => { /* Owner mutation reports save errors. */ });
                      }}
                      data-testid={`button-save-colors-${item.id}`}
                    >
                      {colorsSaving ? 'Saving…' : 'Save Color Selection'}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedColorNames(new Set(item.availableColors.map(c => c.name)))}
                      data-testid={`button-reset-colors-${item.id}`}
                    >
                      Select All
                    </Button>
                  </div>
                </div>
              )}

              <Button
                className="w-full min-h-12 text-base"
                onClick={() => {
                  onSelect();
                  onOpenChange(false);
                }}
                disabled={actionDisabled}
                data-testid={`button-modal-select-${item.id}`}
              >
                {actionLabel}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

const TIER_COLORS: Record<string, string> = {
  good: "bg-blue-600 text-white",
  better: "bg-amber-500 text-white",
  best: "bg-emerald-600 text-white",
};

const TIER_LABELS: Record<string, string> = {
  good: "Good",
  better: "Better",
  best: "Best",
};

export function ProductSelectCardSkin({ item, isSelected, onSelect, tier, onTierChange, showTierControls, onDescriptionSave, descriptionSaving, editableDescription, onTitleSave, titleSaving, editableTitle, textEditScope, priceLabel, selectLabel, selectedLabel, disableWhenSelected, selectDisabled, selectDisabledTitle, onImageDelete, onImageRestore, onImagesBulkSave, masterCatalogImages, fulfillmentProvider, mockupImageUrl, editableColors, savedColors, onColorsSave, colorsSaving, onTextColorSave, textColorSaving }: ProductSelectCardSkinProps) {
  const providerLabel = fulfillmentProvider === "both" ? "Printify + Printful"
    : fulfillmentProvider === "printful" ? "Printful" : fulfillmentProvider === "printify" ? "Printify" : fulfillmentProvider;
  const actionLabel = isSelected ? (selectedLabel ?? "Selected") : (selectLabel ?? "Select product");
  const actionDisabled = (isSelected && !!disableWhenSelected) || !!selectDisabled;
  const titleParts = item.name.split(" | ");
  const splitTitle = titleParts.length === 2 && !!item.manufacturer && titleParts[1].toLowerCase().includes(item.manufacturer.toLowerCase());
  const cardTitle = splitTitle ? titleParts[1] : item.name;
  const cardSubtitle = splitTitle ? titleParts[0] : null;
  const [previewOpen, setPreviewOpen] = useState(false);
  const [imageToRemove, setImageToRemove] = useState<string | null>(null);
  const [imageRemovalError, setImageRemovalError] = useState<string | null>(null);
  const [cardImageIndex, setCardImageIndex] = useState(0);
  const [deletingCardImage, setDeletingCardImage] = useState(false);

  // All images available for the card thumbnail slider
  const cardImages = useMemo(() => {
    const imgs = item.images ?? (item.primaryImageUrl ? [item.primaryImageUrl] : []);
    return imgs;
  }, [item.images, item.primaryImageUrl]);

  // Reset index when product changes
  useEffect(() => {
    setCardImageIndex(0);
  }, [item.id]);

  const clampedIndex = Math.min(cardImageIndex, Math.max(0, cardImages.length - 1));
  const currentCardImage = cardImages[clampedIndex] ?? null;

  const handleCardPrev = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setCardImageIndex(i => Math.max(0, i - 1));
  }, []);

  const handleCardNext = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setCardImageIndex(i => Math.min(cardImages.length - 1, i + 1));
  }, [cardImages.length]);

  const handleCardImageDelete = async () => {
    if (!onImageDelete || deletingCardImage || !imageToRemove) return;
    setDeletingCardImage(true);
    setImageRemovalError(null);
    try {
      await onImageDelete(item.id, imageToRemove);
      setCardImageIndex(i => Math.max(0, i - 1));
      setImageToRemove(null);
    } catch {
      setImageRemovalError("Could not remove the image. Please try again.");
    } finally {
      setDeletingCardImage(false);
    }
  };

  const defaultColorEntry = useMemo(() => {
    if (item.defaultColor) {
      return (
        item.availableColors.find(
          (c) => c.name.toLowerCase() === item.defaultColor!.toLowerCase()
        ) || null
      );
    }
    return item.availableColors[0] || null;
  }, [item.availableColors, item.defaultColor]);

  return (
    <>
      <Card
        className={`overflow-hidden transition-all ${isSelected ? "ring-2 ring-primary ring-offset-2" : ""}`}
        data-testid={`select-card-${item.id}`}
      >
        {/* ── Main image area with nav arrows ── */}
        <div
          className="relative w-full aspect-square max-h-[320px] flex items-center justify-center rounded-t-xl bg-muted cursor-pointer overflow-hidden"
          onClick={() => setPreviewOpen(true)}
          data-testid={`img-tap-${item.id}`}
        >
          {isSelected && (
            <div
              className="absolute top-0 left-0 right-0 z-10 bg-primary text-primary-foreground text-[11px] font-semibold text-center py-1"
              data-testid={`banner-selected-${item.id}`}
            >
              SELECTED
            </div>
          )}

          {currentCardImage ? (
            <img
              key={currentCardImage}
              src={currentCardImage}
              alt={item.name}
              loading="lazy"
              decoding="async"
              className="w-full h-full object-contain p-3"
              data-testid={`img-product-${item.id}`}
            />
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <Package className="h-12 w-12" />
            </div>
          )}

          {/* Prev / Next arrows — only when multiple images */}
          {cardImages.length > 1 && (
            <>
              <button
                type="button"
                onClick={handleCardPrev}
                disabled={clampedIndex === 0}
                className="absolute left-1 top-1/2 -translate-y-1/2 z-20 rounded-full bg-background/80 backdrop-blur-sm min-w-12 min-h-12 flex items-center justify-center shadow disabled:opacity-30"
                aria-label="Previous image"
                data-testid={`button-card-prev-${item.id}`}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleCardNext}
                disabled={clampedIndex === cardImages.length - 1}
                className="absolute right-1 top-1/2 -translate-y-1/2 z-20 rounded-full bg-background/80 backdrop-blur-sm min-w-12 min-h-12 flex items-center justify-center shadow disabled:opacity-30"
                aria-label="Next image"
                data-testid={`button-card-next-${item.id}`}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </>
          )}

          {/* Delete current image — only in catalog mode with permission */}
          {onImageDelete && currentCardImage && cardImages.length > 0 && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); setImageRemovalError(null); setImageToRemove(currentCardImage); }}
              disabled={deletingCardImage}
              className="absolute top-1 right-1 z-20 min-h-12 min-w-12 flex items-center justify-center rounded-full bg-background/80 backdrop-blur-sm shadow text-destructive"
              title="Remove this image from catalog"
              aria-label="Remove this image from catalog"
              data-testid={`button-card-delete-img-${item.id}`}
            >
              {deletingCardImage
                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                : <Trash2 className="w-3.5 h-3.5" />
              }
            </button>
          )}

          {item.madeInUSA && (
            <div className="absolute top-2 left-2">
              <Badge variant="secondary" className="gap-1 bg-background/90 backdrop-blur-sm text-xs shadow-sm">
                <UsaFlag className="w-3 h-2" />
                USA
              </Badge>
            </div>
          )}

          {tier && (
            <div className="absolute bottom-2 left-2">
              <Badge className={`text-xs shadow-sm ${TIER_COLORS[tier]}`} data-testid={`badge-tier-${item.id}`}>
                {TIER_LABELS[tier]}
              </Badge>
            </div>
          )}

        </div>

        {/* ── Thumbnail strip ── */}
        {cardImages.length > 1 && (
          <div className="flex gap-1 px-2 pt-1.5 pb-0 overflow-x-auto" data-testid={`thumbnails-${item.id}`}>
            {cardImages.map((img, idx) => (
              <button
                key={img}
                type="button"
                onClick={(e) => { e.stopPropagation(); setCardImageIndex(idx); }}
                className={`flex-shrink-0 w-14 h-14 rounded border-2 overflow-hidden transition-colors ${
                  idx === clampedIndex ? "border-primary" : "border-transparent"
                }`}
                data-testid={`thumbnail-${item.id}-${idx}`}
              >
                <img
                  src={img}
                  alt={`${item.name} thumbnail ${idx + 1}`}
                  className="w-full h-full object-contain bg-muted"
                />
              </button>
            ))}
          </div>
        )}

        <CardContent className="p-3 space-y-2">
          <h3
            className="font-sans font-semibold text-base leading-snug"
            data-testid={`text-name-${item.id}`}
          >
            {cardTitle}
          </h3>
          {cardSubtitle && <p className="text-sm text-muted-foreground">{cardSubtitle}</p>}

          <p
            className="text-[10px] text-muted-foreground/60 font-mono"
            data-testid={`text-id-${item.id}`}
          >
            {formatBlankId(item.id, item.qrgBlankId)}
          </p>

          {!splitTitle && (item.manufacturer || item.model) && (
            <p className="text-xs text-muted-foreground truncate" data-testid={`text-make-model-${item.id}`}>
              {[item.manufacturer, item.model].filter(Boolean).join(' ')}
            </p>
          )}

          <div className="flex items-center justify-between gap-1 flex-wrap">
            {fulfillmentProvider && (
              <Badge
                variant="outline"
                className="text-[10px] bg-background/80"
                data-testid={`badge-provider-card-${item.id}`}
              >
                {providerLabel}
              </Badge>
            )}
            {item.price != null && (
              <span className="text-sm font-bold ml-auto" data-testid={`text-price-${item.id}`}>
                {priceLabel && <span className="font-normal mr-1">{priceLabel}</span>}${item.price.toFixed(2)}
              </span>
            )}
          </div>

          {(item.availableColors.length > 0 || item.availableSizes.length > 0) && (
            <p className="text-xs text-muted-foreground">
              {[item.availableColors.length > 0 ? `${item.availableColors.length} colors` : null,
                item.availableSizes.length > 0 ? `${item.availableSizes.length} sizes` : null].filter(Boolean).join(" · ")}
            </p>
          )}

          <Button
            variant={isSelected ? "secondary" : "default"}
            className="w-full min-h-12 text-base"
            onClick={(e) => { e.stopPropagation(); onSelect(item.id, item); }}
            disabled={actionDisabled}
            title={selectDisabled ? selectDisabledTitle : undefined}
            data-testid={`button-select-${item.id}`}
          >
            {actionLabel}
          </Button>

        </CardContent>
      </Card>

      <AlertDialog open={imageToRemove !== null} onOpenChange={(open) => { if (!open && !deletingCardImage) setImageToRemove(null); }}>
        <AlertDialogContent className="w-[calc(100%-2rem)] rounded-lg" data-testid={`confirm-image-removal-${item.id}`}>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this image?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this image from {item.name}? The product will stay in the catalog.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {imageToRemove && <img src={imageToRemove} alt="Image to remove" className="h-32 w-full object-contain" />}
          {imageRemovalError && <p role="alert" className="text-sm text-destructive">{imageRemovalError}</p>}
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel className="min-h-12 text-base" disabled={deletingCardImage} data-testid={`button-cancel-remove-image-${item.id}`}>Cancel</AlertDialogCancel>
            <AlertDialogAction className="min-h-12 text-base bg-destructive text-destructive-foreground hover:bg-destructive/90" disabled={deletingCardImage}
              onClick={(e) => { e.preventDefault(); void handleCardImageDelete(); }} data-testid={`button-confirm-remove-image-${item.id}`}>
              {deletingCardImage ? "Removing…" : "Yes, remove image"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <PreviewModal
        actionLabel={actionLabel}
        actionDisabled={actionDisabled}
        priceLabel={priceLabel}
        providerLabel={providerLabel}
        item={item}
        open={previewOpen}
        onOpenChange={setPreviewOpen}
        onSelect={() => onSelect(item.id, item)}
        defaultColorEntry={defaultColorEntry}
        onDescriptionSave={onDescriptionSave}
        descriptionSaving={descriptionSaving}
        editableDescription={editableDescription}
        onTitleSave={onTitleSave}
        titleSaving={titleSaving}
        editableTitle={editableTitle}
        textEditScope={textEditScope}
        onImageDelete={onImageDelete}
        onImageRestore={onImageRestore}
        onImagesBulkSave={onImagesBulkSave}
        masterCatalogImages={masterCatalogImages}
        tier={tier}
        onTierChange={onTierChange}
        showTierControls={showTierControls}
        mockupImageUrl={mockupImageUrl}
        editableColors={editableColors}
        savedColors={savedColors}
        onColorsSave={onColorsSave}
        colorsSaving={colorsSaving}
        onTextColorSave={onTextColorSave} textColorSaving={textColorSaving}
      />
    </>
  );
}
