import { Loader2 } from "lucide-react";
import { usePrintTextPreview } from '../PrintTextColorControl';
import { useProductGraphicPreview } from "@/hooks/useProductGraphicPreview";
import type { TextStyle, RenderOptions } from "@/features/shared/graphics/productGraphicRenderer";

interface TextOverlay {
  text: string;
  enabled: boolean;
  fontFamily: string;
  fontSize: string;
  fontWeight?: string;
  color: string;
  colorMode?: import('@shared/printTextColor').PrintTextColorMode;
  warpPreset?: string;
  letterSpacing?: number;
  strokeColor?: string;
  strokeWidth?: number;
  verticalOffset?: number;
  horizontalOffset?: number;
  mode?: "text" | "image";
  imageUrl?: string;
  imageScale?: number;
}

export interface GraphicPreviewViewProps {
  renderOptions?: RenderOptions;
  backgroundColor?: string;
  backgroundImage?: string;
  headerStyle?: TextOverlay;
  footerStyle?: TextOverlay;
  showQRCode?: boolean;
  aspectRatio?: "square" | "portrait";
  className?: string;
  qrContent?: string;
  placement?: string;
  qrPositionX?: number;
  qrPositionY?: number;
  qrSizePercent?: number;
  areaImageUrl?: string;
  areaImageMode?: "behind-qr";
  areaImageOffsetX?: number;
  areaImageOffsetY?: number;
  areaImageScale?: number;
  subBottomStyle?: {
    enabled?: boolean;
    text?: string;
    color?: string;
    fontSize?: string;
    fontFamily?: string;
    fontWeight?: string;
    letterSpacing?: number;
  };
  graphicLayoutMode?: "zone" | "freeform";
}

function toTextStyle(overlay?: TextOverlay): TextStyle | null {
  if (!overlay || !overlay.enabled) return null;
  const isImage = overlay.mode === "image" && overlay.imageUrl;
  if (!isImage && !overlay.text) return null;
  return {
    text: overlay.text,
    enabled: overlay.enabled,
    fontFamily: overlay.fontFamily || "Arial",
    fontSize: overlay.fontSize || "18px",
    fontWeight: overlay.fontWeight,
    color: overlay.color || "#000000",
    colorMode: overlay.colorMode,
    letterSpacing: overlay.letterSpacing,
    strokeColor: overlay.strokeColor,
    strokeWidth: overlay.strokeWidth,
    verticalOffset: overlay.verticalOffset,
    horizontalOffset: overlay.horizontalOffset,
    mode: overlay.mode,
    imageUrl: overlay.imageUrl,
    imageScale: overlay.imageScale,
  };
}

export function GraphicPreviewView({
  renderOptions,
  backgroundColor = "#1a1a2e",
  backgroundImage,
  headerStyle,
  footerStyle,
  showQRCode = true,
  aspectRatio = "square",
  className = "",
  qrContent,
  placement,
  qrPositionX,
  qrPositionY,
  qrSizePercent,
  areaImageUrl,
  areaImageMode,
  areaImageOffsetX,
  areaImageOffsetY,
  areaImageScale,
  subBottomStyle,
  graphicLayoutMode,
}: GraphicPreviewViewProps) {
  const { background } = usePrintTextPreview(null, backgroundColor);
  backgroundColor = background?.hex || backgroundColor;
  const aspectClass =
    aspectRatio === "portrait" ? "aspect-[2/3]" : "aspect-square";

  const dimensions = renderOptions?.providerLayout?.dimensions;
  const { dataUrl, isLoading, error } = useProductGraphicPreview({
    renderOptions,
    qrContent: qrContent || "https://qrgear.app",
    qrColor: "black",
    headerStyle: toTextStyle(headerStyle),
    footerStyle: toTextStyle(footerStyle),
    backgroundColor,
    transparent: false,
    placement,
    qrPositionX: graphicLayoutMode === "zone" ? 50 : qrPositionX,
    qrPositionY: graphicLayoutMode === "zone" ? 50 : qrPositionY,
    qrSizePercent,
    areaImageUrl,
    areaImageMode,
    areaImageOffsetX,
    areaImageOffsetY,
    areaImageScale,
    subBottomStyle,
    graphicLayoutMode,
    enabled: showQRCode || !!(headerStyle?.enabled || footerStyle?.enabled) || !!areaImageUrl || subBottomStyle?.enabled,
    debounceMs: 300,
  });

  return (
    <div
      className={`relative w-full max-w-[280px] sm:max-w-[200px] mx-auto ${aspectClass} rounded-lg overflow-hidden border-2 border-border shadow-lg ${className}`}
      style={{
        ...(backgroundImage ? { background: `url(${backgroundImage}) center/cover` } : { backgroundColor }),
        ...(dimensions ? { aspectRatio: `${dimensions.widthPx} / ${dimensions.heightPx}` } : {}),
      }}
      data-testid="graphic-preview-view"
    >
      {error ? <p role="alert" className="p-3 text-sm text-destructive">{error}</p> : isLoading && !dataUrl ? (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        </div>
      ) : dataUrl ? (
        <img
          src={dataUrl}
          alt="Product graphic preview"
          className="w-full h-full object-contain"
          data-testid="img-graphic-preview"
        />
      ) : (
        <div
          className="w-full h-full"
          style={{ backgroundColor: backgroundColor || "#1a1a2e" }}
        />
      )}
      {isLoading && dataUrl && (
        <div className="absolute top-1 right-1">
          <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
        </div>
      )}
    </div>
  );
}
