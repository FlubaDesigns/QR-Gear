import { resolveDisplayText } from "@shared/descriptionLayers";
import { masterBlankImages, resolveCatalogImages } from "@shared/productImages";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Layers,
  Search,
  Filter,
  Flag,
  Globe,
  BookOpen,
  Plus,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ScrollVerticalView } from "@/features/shared/components/views/ScrollVerticalView";
import { CustomDropdown } from "@/components/ui/custom-dropdown";
import {
  ProductSelectCardSkin,
  type ProductSelectItem,
} from "@/features/shared/components/skins/ProductSelectCardSkin";
import { useBuilderContext } from "../BuilderContext";
import { useProductsContext } from "../../ProductsContext";
import type { CatalogProduct, GenderFilter, CatalogCategory } from "../types";
import type { ScrollViewItem } from "@/features/shared/components/views/index";
import { getLookupBlankKey, getProductSnapshotKey, isQRGBlankId } from "@shared/blankKeys";
import { catalogToSelectItem } from "@shared/adapters/catalog.adapter";
import type { AdminCatalog } from "@shared/catalogs";
import { BlankPickerModal } from "./BlankPickerModal";

// Shelf creation is dormant until the owner chooses to enable it.
const SHELF_CREATION_ENABLED = false;

type LocationFilter = "all" | "usa" | "other";
type DataMode = "all" | "catalog" | "joint";

function detectGender(title: string): "mens" | "womens" | "unisex" {
  const lowerTitle = title.toLowerCase();
  if (lowerTitle.includes("unisex")) return "unisex";
  if (
    lowerTitle.includes("women's") ||
    lowerTitle.includes("womens") ||
    lowerTitle.includes("women ") ||
    lowerTitle.startsWith("women") ||
    lowerTitle.includes("female") ||
    lowerTitle.includes("ladies") ||
    lowerTitle.includes("lady") ||
    lowerTitle.includes("girl's") ||
    lowerTitle.includes("girls")
  ) {
    return "womens";
  }
  if (
    lowerTitle.includes("men's") ||
    lowerTitle.includes("mens") ||
    lowerTitle.includes("men ") ||
    lowerTitle.startsWith("men") ||
    lowerTitle.includes("male") ||
    lowerTitle.includes("guys") ||
    lowerTitle.includes("boy's") ||
    lowerTitle.includes("boys")
  ) {
    return "mens";
  }
  return "unisex";
}

interface CatalogCategoryResponse {
  name: string;
  items: CatalogProduct[];
  count: number;
}

// QRG super-category labels per S-digit (QRG.md §3) — display-only
const SUPER_CATEGORY_LABELS: Record<string, string> = {
  "1": "Apparel",
  "2": "Houseware",
  "3": "Print & Display",
  "4": "Accessories",
  "5": "Pet Products",
  "6": "Holiday & Seasonal",
};

// Strip qrg_ prefix and return the 5-digit STNNN string.
// digits[0] = S (super-category), digits.slice(0,2) = ST (subcategory).
function getQrgDigits(docId: string | undefined): string {
  if (!docId) return "";
  const m = docId.match(/^qrg_([1-6][1-9]\d{3})$/);
  return m ? m[1] : "";
}

// True when the item is stocked by the given provider.
// printful: must have printfulProductId.
// printify: must have both printifyBlueprintId and printifyProviderId.
function providerStocksProduct(item: any, prov: string): boolean {
  if (prov === "printful") return !!item.printfulProductId;
  if (prov === "printify") return !!item.printifyBlueprintId && !!item.printifyProviderId;
  return false;
}

export function ProductsModule() {
  const { state, setCategory, setOriginFilter, setGenderFilter, selectProduct, setProductDescription, setProductTitle, setActiveSession, setActivePacketId, setSelectedCatalogId, loadFromWorkingState } = useBuilderContext();
  const { selectedProviders, setSelectedProviders } = useProductsContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  const provider = selectedProviders[0] || "";
  const selectedCatalogId = state.selectedCatalogId;

  const [search, setSearch] = useState("");
  // Display selections are projections of the same state used by filtering and saves.
  const locationFilter = state.originFilter.showUSA
    ? (state.originFilter.showOther ? "all" : "usa")
    : (state.originFilter.showOther ? "other" : "none");
  const dataMode: DataMode = !selectedCatalogId || selectedCatalogId === "all"
    ? "all" : selectedCatalogId === "joint" ? "joint" : "catalog";
  const [pickerOpen, setPickerOpen] = useState(false);
  const [moreFiltersOpen, setMoreFiltersOpen] = useState(false);
  const [openShelfIds, setOpenShelfIds] = useState<Set<string>>(new Set());
  const toggleShelf = useCallback((id: string) => {
    setOpenShelfIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);
  const [addingShelf, setAddingShelf] = useState(false);
  const [newShelfName, setNewShelfName] = useState("");
  const [savingShelf, setSavingShelf] = useState(false);
  const [qrgSuperCategory, setQrgSuperCategory] = useState<string | null>(null);
  const [qrgSubCategory, setQrgSubCategory] = useState<string | null>(null);

  useEffect(() => {
    if (selectedCatalogId && selectedCatalogId !== "all") {
      setQrgSuperCategory(null);
      setQrgSubCategory(null);
    }
  }, [selectedCatalogId]);

  const { data: adminCatalogsData, error: catalogsError, refetch: reloadCatalogs } = useQuery<{ catalogs: AdminCatalog[] }>({
    queryKey: ["/api/admin/catalogs"],
  });
  const adminCatalogs = adminCatalogsData?.catalogs || [];

  const { data: shelfGroups = [] } = useQuery<Array<{ id: string; name: string; sortOrder: number }>>({
    queryKey: ["/api/admin/shelf-groups"],
    enabled: SHELF_CREATION_ENABLED,
  });

  // Derived early so it is available inside the buildShelfItems queryFn closure below.
  const activeCatalogEarly = selectedCatalogId && selectedCatalogId !== "all" && selectedCatalogId !== "joint"
    ? (adminCatalogsData?.catalogs || []).find(c => c.id === selectedCatalogId) || null
    : null;
  const catalogBlankIds = activeCatalogEarly?.blankIds || [];

  // build-shelf query — kept for shelfItemByCanonicalId (optional shelfItemId in build sessions).
  // Not used as the primary source for catalogModeProducts (see below).
  const { data: buildShelfItems = [] } = useQuery<Array<{ id: string; shelfKey: string; catalogId: string; groupIds: string[]; catalog: CatalogProduct }>>({
    queryKey: ["/api/admin/build-shelf", selectedCatalogId],
    queryFn: async () => {
      const url = selectedCatalogId && selectedCatalogId !== "all" && selectedCatalogId !== "joint"
        ? `/api/admin/build-shelf?catalogId=${encodeURIComponent(selectedCatalogId)}`
        : "/api/admin/build-shelf?mode=global";
      const r = await apiRequest("GET", url);
      if (!r.ok) throw new Error(`build-shelf fetch failed: ${r.status}`);
      const items: Array<{ id: string; shelfKey: string; catalogId: string; groupIds: string[]; catalog: CatalogProduct }> = await r.json();

      // If the shelf has no items yet (blanks were added via BlankPickerModal
      // which only writes catalogs.blankIds, not admin_build_shelf), fall back
      // to resolving those blankIds directly from master_catalog.
      if (items.length === 0 && catalogBlankIds.length > 0) {
        console.log(`[ProductsModule] build-shelf empty for catalog ${selectedCatalogId}, falling back to master catalog for ${catalogBlankIds.length} blankIds`);
        try {
          const masterRes = await apiRequest("GET", "/api/master-catalog");
          if (!masterRes.ok) return items;
          const masterData: Array<{ name: string; items: any[] }> = await masterRes.json();
          const blankIdSet = new Set(catalogBlankIds);
          const fallback: Array<{ id: string; shelfKey: string; catalogId: string; groupIds: string[]; catalog: CatalogProduct }> = [];
          const seen = new Set<string>();
          for (const cat of masterData) {
            for (const item of (cat.items || [])) {
              const docId: string | undefined = item.docId;
              if (docId && blankIdSet.has(docId) && !seen.has(docId)) {
                seen.add(docId);
                fallback.push({
                  id: `fallback:${docId}`,
                  shelfKey: docId,
                  catalogId: selectedCatalogId!,
                  groupIds: [],
                  catalog: item as CatalogProduct,
                });
              }
            }
          }
          console.log(`[ProductsModule] Fallback resolved ${fallback.length} items from master catalog`);
          return fallback;
        } catch (fallbackErr: any) {
          console.error("[ProductsModule] Master catalog fallback failed:", fallbackErr.message);
        }
      }

      return items;
    },
    enabled: dataMode === "catalog",
  });

  // Full master catalog data — used as the authoritative source for catalog-mode products.
  // Same approach as useAdminBlanksController (which works in production): read catalog.blankIds
  // then look up each blank in master_catalog. This avoids depending on admin_build_shelf
  // (which blanks added via BlankPickerModal never write to).
  const { data: masterCatalogFull = [], isLoading: loadingCatalogProducts, error: masterError, refetch: reloadMaster } = useQuery<Array<{ name: string; items: CatalogProduct[]; count: number }>>({
    queryKey: ["/api/master-catalog"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/master-catalog");
      const d = await res.json();
      if (!Array.isArray(d)) throw new Error("Master catalog response is invalid.");
      return d;
    },
    enabled: dataMode === "catalog" || dataMode === "all",
    staleTime: 60000,
  });

  const activeCatalog = selectedCatalogId !== "all"
    ? adminCatalogs.find(c => c.id === selectedCatalogId) || null
    : null;

  const shelfKeyToGroupIds = useMemo(() => {
    const map = new Map<string, string[]>();
    for (const item of buildShelfItems) {
      map.set(item.shelfKey, item.groupIds || []);
    }
    return map;
  }, [buildShelfItems]);

  // Fast lookup from any canonical product key → shelf item (used for shelfItemId in build sessions)
  const shelfItemByCanonicalId = useMemo(() => {
    const map = new Map<string, { id: string; shelfKey: string; catalogId: string }>();
    for (const item of buildShelfItems) {
      const catDocId = (item.catalog as any).docId as string | undefined;
      if (catDocId) map.set(catDocId, item);
      map.set(item.shelfKey, item);
      const numId = String((item.catalog as any).id || "");
      if (numId) map.set(numId, item);
    }
    return map;
  }, [buildShelfItems]);

  // O(1) membership check — used in selectItemMap to resolve the canonical blankKey
  // without going through catalogKeyMap (which is keyed by numeric provider ID and
  // loses precision when two qrg_STNNN entries share the same blueprint number).
  const activeCatalogBlankIdSet = useMemo(
    () => new Set<string>(activeCatalog?.blankIds || []),
    [activeCatalog],
  );


  const handleCatalogChange = useCallback((catalogId: string) => {
    setSelectedCatalogId(catalogId);
    if (catalogId !== "all") selectProduct(null);
  }, [selectProduct, setSelectedCatalogId]);

  // catalogModeProducts — derived from master_catalog filtered by catalog.blankIds.
  // Mirrors the approach used by useAdminBlanksController (the working "add blanks" path):
  // catalog.blankIds are qrg_STNNN keys; master_catalog items carry docId + qrgCategory.
  // This bypasses admin_build_shelf entirely, which blanks added via BlankPickerModal
  // never write to (they only write to catalogs.blankIds).
  const { catalogModeProducts, catalogKeyMap } = useMemo(() => {
    if (!activeCatalog || masterCatalogFull.length === 0) {
      return { catalogModeProducts: [] as CatalogProduct[], catalogKeyMap: new Map<string, string>() };
    }
    const blankIdSet = new Set<string>(activeCatalog.blankIds || []);
    const products: CatalogProduct[] = [];
    const keyMap = new Map<string, string>();
    const seen = new Set<string>();
    for (const cat of masterCatalogFull) {
      for (const item of (cat.items || [])) {
        const docId = (item as any).docId as string | undefined;
        const numId = String((item as any).id || "");
        const canonicalId = docId || numId;
        if (seen.has(canonicalId)) continue;
        if ((docId && blankIdSet.has(docId)) || blankIdSet.has(numId)) {
          seen.add(canonicalId);
          const withCategory = { ...item, qrgCategory: (item as any).qrgCategory || cat.name || null } as CatalogProduct;
          products.push(withCategory);
          if (numId) keyMap.set(numId, docId || numId);
          if (docId) keyMap.set(docId, docId);
        }
      }
    }
    return { catalogModeProducts: products, catalogKeyMap: keyMap };
  }, [activeCatalog, masterCatalogFull]);

  useEffect(() => {
    if (dataMode !== "catalog" || catalogModeProducts.length === 0) return;
    const categoryKeys = Array.from(
      new Set(catalogModeProducts.map((p: any) => p.qrgCategory || "Other"))
    );
    setOpenShelfIds(new Set(categoryKeys.map(key => `qrg-shelf-${key}`)));
  }, [dataMode, selectedCatalogId, catalogModeProducts]);

  const { data: jointCatalogProducts = [], isLoading: loadingJointProducts, error: jointError, refetch: reloadJoint } = useQuery<CatalogProduct[]>({
    queryKey: ["joint-catalog-products"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/master-catalog/joint");
      const data = (await res.json()) as CatalogCategoryResponse[];
      const items: CatalogProduct[] = [];
      const seen = new Set<string>();
      for (const cat of data) {
        for (const item of (cat.items || [])) {
          const key = getLookupBlankKey(item);
          if (!seen.has(key)) {
            seen.add(key);
            items.push({ ...item, qrgCategory: item.qrgCategory ?? cat.name ?? null });
          }
        }
      }
      return items;
    },
    enabled: dataMode === "joint",
    staleTime: 60000,
  });

  const applyLocationFilter = useCallback((loc: LocationFilter) => {
    if (loc === "all") setOriginFilter({ showUSA: true, showOther: true });
    else if (loc === "usa") setOriginFilter({ showUSA: true, showOther: false });
    else setOriginFilter({ showUSA: false, showOther: true });
  }, [setOriginFilter]);

  const prevProviderRef = useRef(provider);
  const internalProviderSwitch = useRef(false);
  useEffect(() => {
    if (prevProviderRef.current !== provider) {
      if (internalProviderSwitch.current) {
        internalProviderSwitch.current = false;
      }
      prevProviderRef.current = provider;
    }
  }, [provider]);

  const loadingCategories = loadingCatalogProducts;
  const categories: CatalogCategory[] = masterCatalogFull.map(cat => ({
    name: cat.name, itemCount: cat.count || cat.items?.length || 0,
  }));

  // QRG super-category / subcategory navigator data — derived from masterCatalogFull filtered by provider.
  // superCategoryCode (S-digit) → Map of subCategoryCode (ST-digits) → { categoryName, count }
  const qrgNavigatorData = useMemo(() => {
    if (dataMode !== "all" || masterCatalogFull.length === 0) return null;
    const superMap = new Map<string, Map<string, { categoryName: string; count: number }>>();
    for (const cat of masterCatalogFull) {
      for (const rawItem of (cat.items || [])) {
        const item = rawItem as any;
        if (!providerStocksProduct(item, provider)) continue;
        const digits = getQrgDigits(item.docId);
        if (digits.length < 2) continue;
        const superCode = digits[0];
        const subCode = digits.slice(0, 2);
        if (!superMap.has(superCode)) superMap.set(superCode, new Map());
        const subMap = superMap.get(superCode)!;
        const entry = subMap.get(subCode);
        if (!entry) subMap.set(subCode, { categoryName: cat.name, count: 1 });
        else entry.count++;
      }
    }
    return superMap;
  }, [masterCatalogFull, provider, dataMode]);

  const sortedCategories = useMemo(() => {
    if (dataMode === "catalog" && activeCatalog) {
      const counts = new Map<string, number>();
      for (const p of catalogModeProducts) {
        const catName = p.qrgCategory || null;
        if (catName) counts.set(catName, (counts.get(catName) ?? 0) + 1);
      }
      return Array.from(counts.entries())
        .map(([name, itemCount]) => ({ name, itemCount }))
        .filter(c => c.itemCount > 0 && c.name && c.name.trim() !== "")
        .sort((a, b) => {
          if (a.name === "T-Shirts & Tops") return -1;
          if (b.name === "T-Shirts & Tops") return 1;
          return a.name.localeCompare(b.name);
        });
    }
    if (dataMode === "joint") {
      const counts = new Map<string, number>();
      for (const p of jointCatalogProducts) {
        const catName = p.qrgCategory || null;
        if (catName) counts.set(catName, (counts.get(catName) ?? 0) + 1);
      }
      return Array.from(counts.entries())
        .map(([name, itemCount]) => ({ name, itemCount }))
        .filter(c => c.itemCount > 0 && c.name && c.name.trim() !== "")
        .sort((a, b) => {
          if (a.name === "T-Shirts & Tops") return -1;
          if (b.name === "T-Shirts & Tops") return 1;
          return a.name.localeCompare(b.name);
        });
    }
    return [...categories]
      .filter(c => c.itemCount > 0 && c.name && c.name.trim() !== "")
      .sort((a, b) => {
        if (a.name === "T-Shirts & Tops") return -1;
        if (b.name === "T-Shirts & Tops") return 1;
        return a.name.localeCompare(b.name);
      });
  }, [categories, dataMode, activeCatalog, catalogModeProducts, jointCatalogProducts]);

  const categoryOptions = sortedCategories.map(cat => ({
    value: cat.name,
    label: `${cat.name} (${cat.itemCount})`,
    icon: <Layers className="h-4 w-4 flex-shrink-0" />,
  }));

  const categoryData = masterCatalogFull.find(cat => cat.name === state.category) || null;
  const isLoading = loadingCatalogProducts;
  const error = masterError;

  const products = categoryData?.items || [];

  const productsWithGender = useMemo(() =>
    products.map(p => ({ ...p, gender: detectGender(p.title) })),
    [products]
  );

  const filteredProducts = useMemo(() => {
    return productsWithGender.filter(p => {
      const passesOrigin = (state.originFilter.showUSA && p.madeInUSA) ||
                           (state.originFilter.showOther && !p.madeInUSA);
      const passesGender = state.genderFilter === "all" || p.gender === state.genderFilter;
      const passesSearch = !search || p.title.toLowerCase().includes(search.toLowerCase());
      // When browsing via the QRG subcategory navigator, gate by current provider
      const passesProvider = !qrgSubCategory || providerStocksProduct(p as any, provider);
      return passesOrigin && passesGender && passesSearch && passesProvider;
    });
  }, [productsWithGender, state.originFilter, state.genderFilter, search, qrgSubCategory, provider]);

  const usaCount = products.filter(p => p.madeInUSA).length;
  const otherCount = products.filter(p => !p.madeInUSA).length;

  const originFilteredProducts = useMemo(() => {
    return productsWithGender.filter(p =>
      (state.originFilter.showUSA && p.madeInUSA) ||
      (state.originFilter.showOther && !p.madeInUSA)
    );
  }, [productsWithGender, state.originFilter]);

  const genderCounts = useMemo(() => ({
    all: originFilteredProducts.length,
    mens: originFilteredProducts.filter(p => p.gender === "mens").length,
    womens: originFilteredProducts.filter(p => p.gender === "womens").length,
    unisex: originFilteredProducts.filter(p => p.gender === "unisex").length,
  }), [originFilteredProducts]);

  const selectedProductId = state.selectedProduct ? getProductSnapshotKey(state.selectedProduct) : null;

  const activeProducts = dataMode === "catalog" ? catalogModeProducts : dataMode === "joint" ? jointCatalogProducts : filteredProducts;

  const selectItemMap = useMemo(() => {
    const map = new Map<string, { selectItem: ProductSelectItem; catalog: CatalogProduct & { gender: string }; blankKey: string }>();
    const seen = new Set<string>();
    activeProducts.forEach(p => {
      // Canonical identity: qrg_STNNN docId takes priority over numeric provider id
      const canonicalId = (p as any).docId || String(p.id);
      // Skip duplicates — enforce one card per canonical ID
      if (seen.has(canonicalId)) return;
      seen.add(canonicalId);
      const withGender = { ...p, gender: detectGender(p.title) };
      // Canonical blank key resolution — priority order:
      //   1. p.docId (qrg_STNNN) when it is directly present in the catalog's blankIds.
      //      This is the only correct path for QRG-classified blanks: two distinct qrg_STNNN
      //      entries that share a provider blueprint numeric ID must each resolve to their own
      //      docId, not whatever the catalogKeyMap last wrote for that shared numeric ID.
      //   2. catalogKeyMap lookup by numeric provider ID — legacy/unclassified blanks only.
      //   3. Fallback to docId or provider-shaped key.
      const docId = (p as any).docId as string | undefined;
      const blankKey = (docId && activeCatalogBlankIdSet.has(docId))
        ? docId
        : (catalogKeyMap.get(String(p.id))
            ?? docId
            ?? (p.fulfillmentProvider === "printful" ? `pf:${p.id}` : String(p.id)));
      // Load catalog-level admin overrides so cards always show the admin's version
      const adminDesc = activeCatalog?.blankDescriptions?.[blankKey] ?? null;
      const adminTitle = activeCatalog?.blankTitles?.[blankKey] ?? null;
      const adminImages = activeCatalog?.blankImages?.[blankKey] ?? null;
      map.set(canonicalId, { selectItem: catalogToSelectItem(p, adminDesc, adminTitle, adminImages, activeCatalog?.blankColors?.[blankKey]), catalog: withGender, blankKey });
    });
    return map;
  }, [activeProducts, activeCatalog, catalogKeyMap, activeCatalogBlankIdSet]);

  const handleDescriptionSave = useCallback(async (id: string, description: string) => {
    const entry = selectItemMap.get(id);
    if (!entry) return;

    if (activeCatalog) {
      try {
        await apiRequest("PUT", `/api/admin/catalogs/${activeCatalog.id}/blank-description`, { blankId: entry.blankKey, description: description.trim() });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
        toast({ title: "Description saved to catalog" });
      } catch (error) {
        toast({ title: "Could not save description", variant: "destructive" });
        throw error;
      }
    } else if (selectedProductId === id) {
      setProductDescription(description.trim() || null, 'manual');
      toast({ title: "Product description saved" });
    }
  }, [selectItemMap, selectedProductId, setProductDescription, activeCatalog, queryClient, toast]);

  const handleTitleSave = useCallback(async (id: string, title: string) => {
    const entry = selectItemMap.get(id);
    if (!entry) return;

    if (activeCatalog) {
      try {
        await apiRequest("PUT", `/api/admin/catalogs/${activeCatalog.id}/blank-title`, { blankId: entry.blankKey, title: title.trim() });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
        toast({ title: "Title saved to catalog" });
      } catch (error) {
        toast({ title: "Could not save title", variant: "destructive" });
        throw error;
      }
    } else if (selectedProductId === id) {
      setProductTitle(title.trim() || null, 'manual');
      toast({ title: "Product title saved" });
    }
  }, [selectItemMap, selectedProductId, setProductTitle, activeCatalog, queryClient, toast]);

  const handleImageDelete = useCallback(async (id: string, imageUrl: string) => {
    if (!activeCatalog) return;
    const entry = selectItemMap.get(id);
    if (!entry) return;
    const blankKey = entry.blankKey;
    const currentImages = entry.selectItem.images || [];
    const newImages = currentImages.filter(img => img !== imageUrl);
    // Optimistic update
    queryClient.setQueryData(["/api/admin/catalogs"], (old: any) => {
      if (!old?.catalogs) return old;
      return {
        ...old,
        catalogs: old.catalogs.map((cat: any) => {
          if (cat.id !== activeCatalog.id) return cat;
          return { ...cat, blankImages: { ...(cat.blankImages || {}), [blankKey]: newImages } };
        }),
      };
    });
    try {
      await apiRequest("PUT", `/api/admin/catalogs/${activeCatalog.id}/blank-images`, { blankId: blankKey, images: newImages });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: `Image removed — ${newImages.length} remaining for members` });
    } catch (err: any) {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: "Could not save image change", description: err?.message || "Unknown error", variant: "destructive" });
      throw err;
    }
  }, [activeCatalog, selectItemMap, queryClient, toast]);

  const handleImagesBulkSave = useCallback(async (id: string, images: string[]) => {
    if (!activeCatalog) return;
    const entry = selectItemMap.get(id);
    if (!entry) return;
    const blankKey = entry.blankKey;
    queryClient.setQueryData(["/api/admin/catalogs"], (old: any) => {
      if (!old?.catalogs) return old;
      return {
        ...old,
        catalogs: old.catalogs.map((cat: any) => {
          if (cat.id !== activeCatalog.id) return cat;
          return { ...cat, blankImages: { ...(cat.blankImages || {}), [blankKey]: images } };
        }),
      };
    });
    try {
      await apiRequest("PUT", `/api/admin/catalogs/${activeCatalog.id}/blank-images`, { blankId: blankKey, images });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: `Images updated — ${images.length} forwarded to members` });
    } catch (err: any) {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: "Could not save images", description: err?.message || "Unknown error", variant: "destructive" });
      throw err;
    }
  }, [activeCatalog, selectItemMap, queryClient, toast]);

  const handleTierChange = useCallback(async (id: string, tier: string | null) => {
    if (!activeCatalog) return;
    const entry = selectItemMap.get(id);
    if (!entry) return;
    const blankKey = entry.blankKey;
    queryClient.setQueryData(["/api/admin/catalogs"], (old: any) => {
      if (!old?.catalogs) return old;
      return {
        ...old,
        catalogs: old.catalogs.map((cat: any) => {
          if (cat.id !== activeCatalog.id) return cat;
          const blankTiers = { ...(cat.blankTiers || {}) };
          if (tier) blankTiers[blankKey] = tier;
          else delete blankTiers[blankKey];
          return { ...cat, blankTiers };
        }),
      };
    });
    try {
      await apiRequest("PUT", `/api/admin/catalogs/${activeCatalog.id}/blank-tier`, { blankId: blankKey, tier: tier || null });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
    } catch (err: any) {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: "Could not save tier", description: err?.message || "Unknown error", variant: "destructive" });
    }
  }, [activeCatalog, selectItemMap, queryClient, toast]);

  const handleAddShelf = useCallback(async () => {
    if (!SHELF_CREATION_ENABLED) return;
    const name = newShelfName.trim();
    if (!name) return;
    setSavingShelf(true);
    try {
      const maxOrder = shelfGroups.reduce((m, g) => Math.max(m, g.sortOrder ?? 0), 0);
      await apiRequest("POST", "/api/admin/shelf-groups", { name, sortOrder: maxOrder + 1 });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/shelf-groups"] });
      toast({ title: `"${name}" shelf added` });
      setNewShelfName("");
      setAddingShelf(false);
    } catch (err: any) {
      toast({ title: "Could not add shelf", description: err?.message || "Unknown error", variant: "destructive" });
    } finally {
      setSavingShelf(false);
    }
  }, [newShelfName, shelfGroups, queryClient, toast]);

  const handleImageRestore = useCallback(async (id: string) => {
    if (!activeCatalog) return;
    const entry = selectItemMap.get(id);
    if (!entry) return;
    const blankKey = entry.blankKey;
    queryClient.setQueryData(["/api/admin/catalogs"], (old: any) => {
      if (!old?.catalogs) return old;
      return {
        ...old,
        catalogs: old.catalogs.map((cat: any) => {
          if (cat.id !== activeCatalog.id) return cat;
          const blankImages = { ...(cat.blankImages || {}) };
          delete blankImages[blankKey];
          return { ...cat, blankImages };
        }),
      };
    });
    try {
      await apiRequest("PUT", `/api/admin/catalogs/${activeCatalog.id}/blank-images`, { blankId: blankKey, images: [], restore: true });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: "Images restored from master catalog" });
    } catch (err: any) {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/catalogs"] });
      toast({ title: "Could not restore images", description: err?.message || "Unknown error", variant: "destructive" });
      throw err;
    }
  }, [activeCatalog, selectItemMap, queryClient, toast]);

  const scrollItems: ScrollViewItem[] = useMemo(() =>
    activeProducts.map(p => ({
      id: (p as any).docId || String(p.id),
      imageUrl: p.imageUrl || "",
      title: p.title,
      subtitle: p.brand,
      minPrice: p.minPrice,
      maxPrice: p.maxPrice,
      colorCount: p.colorCount,
      madeInUSA: p.madeInUSA,
      hasMockupMapping: p.hasMockupMapping,
    })),
    [activeProducts]
  );

  const handleCardSelect = useCallback((id: string, _item: ProductSelectItem) => {
    const entry = selectItemMap.get(id);
    if (!entry) return;

    const sourceMasterId = entry.catalog.docId;
    if (!sourceMasterId || !isQRGBlankId(sourceMasterId)) {
      toast({ title: "Choose a classified blank", description: "Assign this blank its QRG identity in Admin Blanks before building.", variant: "destructive" });
      return;
    }
    const catalogProduct = entry.catalog as any;
    const selectedProvider = providerStocksProduct(catalogProduct, provider)
      ? provider
      : catalogProduct.fulfillmentProvider || provider;
    if (selectedProvider !== provider) {
      internalProviderSwitch.current = true;
    }

    // Keep master title/description intact. Catalog copy-forward uses the owned
    // fields below; card display overrides are not provider truth.
    const curatedProduct = {
      ...entry.catalog,
      catalogId: activeCatalog?.id ?? null,
      fulfillmentProvider: selectedProvider,
      images: entry.selectItem.images ?? [],
      imageUrl: entry.selectItem.primaryImageUrl,
      availableColors: entry.selectItem.availableColors,
      availableSizes: entry.selectItem.availableSizes,
    } as typeof entry.catalog;
    const isCurrentSelection = selectProduct(curatedProduct);

    // Card selection is the explicit copy-forward action per Progressive Truth.
    // If the catalog has an override for this blank, upgrade the packet-owned fields
    // from 'provider' seed (set in selectProduct) to 'catalog' level. Either way the
    // packet owns its copy from this point — upstream changes after selection do not
    // affect it unless the admin explicitly edits the field.
    const adminDesc = activeCatalog?.blankDescriptions?.[entry.blankKey] ?? null;
    const adminTitle = activeCatalog?.blankTitles?.[entry.blankKey] ?? null;
    if (adminDesc) setProductDescription(adminDesc, 'catalog');
    if (adminTitle) setProductTitle(adminTitle, 'catalog');

    // Start/resume the existing draft path using the canonical QRG blank ID.
    // P6: resolve shelf item to pass its Firestore ID for catalog-scope validation on the backend
    const shelfItem = shelfItemByCanonicalId.get(id) ?? shelfItemByCanonicalId.get(entry.blankKey) ?? null;
    apiRequest("POST", "/api/admin/build-sessions/from-master", {
      sourceMasterId,
      forceNew: state.forceNewSession,
      catalogId: activeCatalog?.id || null,
      blankKey: entry.blankKey || null,
      shelfItemId: shelfItem?.id || null,
    })
      .then(r => r.json())
      .then(data => {
        if (!isCurrentSelection()) return;
        if (!data.sessionId) {
          console.error("[ProductsModule] from-master returned no sessionId:", data);
          selectProduct(null);
          toast({ title: "Could not start build session", description: data.error || "Please try selecting the product again.", variant: "destructive" });
          return;
        }
        const status = (data.session?.status || 'working') as 'working' | 'artifact_ready' | 'committed';
        setActiveSession(data.sessionId, status, data.session?.committedInstanceId || null, data.session?.draftName || null);

        if (data.isExisting && data.session?.working && Object.keys(data.session.working).length > 0) {
          loadFromWorkingState(data.session.working, curatedProduct);
          const draftName = data.session.draftName || curatedProduct.title || "your draft";
          toast({ title: "Draft resumed", description: `Picked up where you left off on "${draftName}".` });
          console.log(`[ProductsModule] Working state restored for session ${data.sessionId}`);
        } else {
          console.log(`[ProductsModule] Build session ${data.isExisting ? 'resumed (no working state)' : 'started'}: ${data.sessionId} (${status})`);
        }
        // Restore the packet ID so CreateGraphicsModule can re-display the packet result
        const existingPacketId: string | null = data.session?.generated?.packetId || null;
        setActivePacketId(existingPacketId);
        if (existingPacketId) {
          console.log(`[ProductsModule] Restored activePacketId: ${existingPacketId}`);
        }


      })
      .catch(err => {
        if (!isCurrentSelection()) return;
        console.error("[ProductsModule] Failed to start build session:", err.message || err);
        selectProduct(null);
        toast({ title: "Could not start build session", description: "Please try selecting the product again.", variant: "destructive" });
      });
  }, [selectItemMap, selectProduct, state.forceNewSession, provider, setSelectedProviders, activeCatalog, setProductDescription, setProductTitle, setActiveSession, setActivePacketId, loadFromWorkingState, toast, shelfItemByCanonicalId]);

  const renderProductCard = useCallback(
    (scrollItem: ScrollViewItem) => {
      const entry = selectItemMap.get(String(scrollItem.id));
      if (!entry) return null;
      const cardId = String(scrollItem.id);
      const rawProduct = entry.catalog as any;
      const rawImages = masterBlankImages(rawProduct);
      const blankKey = entry.blankKey;
      const itemTier = (activeCatalog?.blankTiers?.[blankKey] ?? null) as "good" | "better" | "best" | null;
      return (
        <ProductSelectCardSkin
          item={!activeCatalog && selectedProductId === cardId ? {
            ...entry.selectItem,
            name: resolveDisplayText({ packetValue: state.adminCatalogTitle, providerValue: entry.selectItem.providerTitle }).value,
            description: resolveDisplayText({ packetValue: state.productDescription, providerValue: entry.selectItem.providerDescription }).value,
          } : entry.selectItem}
          textEditScope={activeCatalog ? `Catalog: ${activeCatalog.name}` : "Product"}
          isSelected={selectedProductId === cardId}
          onSelect={handleCardSelect}
          priceLabel="Our cost"
          selectLabel="Use this blank"
          selectedLabel="Selected"
          disableWhenSelected
          editableDescription={!!activeCatalog || selectedProductId === cardId}
          onDescriptionSave={handleDescriptionSave}
          editableTitle={!!activeCatalog || selectedProductId === cardId}
          onTitleSave={handleTitleSave}
          onImageDelete={activeCatalog ? handleImageDelete : undefined}
          onImageRestore={activeCatalog ? handleImageRestore : undefined}
          onImagesBulkSave={activeCatalog ? handleImagesBulkSave : undefined}
          masterCatalogImages={rawImages}
          fulfillmentProvider={rawProduct.fulfillmentProvider as string | undefined}
          tier={itemTier}
          onTierChange={activeCatalog ? handleTierChange : undefined}
          showTierControls={!!activeCatalog}
          mockupImageUrl={selectedProductId === cardId ? (state.loadedGraphic?.compositeUrl ?? null) : null}
        />
      );
    },
    [selectItemMap, selectedProductId, handleCardSelect, handleDescriptionSave, handleTitleSave, activeCatalog, handleImageDelete, handleImageRestore, handleTierChange, state.loadedGraphic, state.adminCatalogTitle, state.productDescription, handleImagesBulkSave]
  );

  if (!provider) return (
    <p className="text-sm text-muted-foreground" data-testid="choose-product-provider">
      Choose a fulfillment provider above to browse products.
    </p>
  );

  const catalogLoadError = catalogsError || (dataMode === "joint" ? jointError : masterError);
  if (catalogLoadError) return (
    <div role="alert" className="space-y-3 rounded-md border border-destructive p-4">
      <p>Could not load products. Your saved catalog has not been cleared.</p>
      <Button className="h-12" onClick={() => { void reloadCatalogs(); void reloadMaster(); if (dataMode === "joint") void reloadJoint(); }}>Retry</Button>
    </div>
  );

  return (
    <>
    <div className="space-y-4">
      <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md" data-testid="active-provider-indicator">
        <span className="text-xs text-muted-foreground">Browsing:</span>
        <span className="text-sm font-medium capitalize">{provider}</span>
      </div>

      <div data-testid="module-catalog-select">
        <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
          <div className="flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm font-medium">Product Source</p>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setPickerOpen(true)}
            disabled={!activeCatalog}
            title={activeCatalog ? undefined : "Choose a catalog to add blanks"}
            data-testid="button-open-blank-picker"
          >
            <Plus className="h-3.5 w-3.5 mr-1" />
            Add Blank
          </Button>
        </div>
        <select
          value={selectedCatalogId}
          onChange={e => handleCatalogChange(e.target.value)}
          className="w-full text-sm bg-background border rounded-md px-3 py-2"
          data-testid="select-catalog"
        >
          <option value="all">All Products (by category)</option>
          <option value="joint">⭐ Joint Catalog (master + admin descriptions)</option>
          {adminCatalogs.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name} ({cat.blankIds?.length || 0} blanks)</option>
          ))}
        </select>
      </div>

      {dataMode === "catalog" && activeCatalog && (
        <>
          {loadingCatalogProducts ? (
            <div className="flex gap-3 overflow-hidden">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="flex-shrink-0 w-[calc(50vw-3rem)] max-w-[180px] aspect-[9/16] rounded-lg" />
              ))}
            </div>
          ) : catalogModeProducts.length === 0 ? (
            <div className="p-6 text-center space-y-2 border rounded-md bg-muted/20">
              <p className="text-sm text-muted-foreground">
                No products found in this catalog.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {(() => {
                // Auto-group by qrgCategory derived from the QRG STNNN schema.
                // Use the master catalog category order for consistent sort order.
                const categoryOrder = sortedCategories.map(c => c.name);
                const sectionMap = new Map<string, CatalogProduct[]>();
                for (const p of catalogModeProducts) {
                  const cat = (p as any).qrgCategory || "Other";
                  if (!sectionMap.has(cat)) sectionMap.set(cat, []);
                  sectionMap.get(cat)!.push(p);
                }
                // Sort sections: known categories in API order first, then "Other" last
                const sectionKeys = Array.from(sectionMap.keys()).sort((a, b) => {
                  if (a === "Other") return 1;
                  if (b === "Other") return -1;
                  const ai = categoryOrder.indexOf(a);
                  const bi = categoryOrder.indexOf(b);
                  if (ai === -1 && bi === -1) return a.localeCompare(b);
                  if (ai === -1) return 1;
                  if (bi === -1) return -1;
                  return ai - bi;
                });

                const sections: JSX.Element[] = [];
                for (const shelfKey of sectionKeys) {
                  const groupProducts = sectionMap.get(shelfKey)!;
                  const shelfId = `qrg-shelf-${shelfKey}`;
                  const isOpen = openShelfIds.has(shelfId);
                  const groupScrollItems = groupProducts.map(p => ({
                    id: (p as any).docId || String(p.id),
                    imageUrl: p.imageUrl || "",
                    title: p.title,
                    subtitle: p.brand,
                    minPrice: p.minPrice,
                    maxPrice: p.maxPrice,
                    colorCount: p.colorCount,
                    madeInUSA: p.madeInUSA,
                    hasMockupMapping: p.hasMockupMapping,
                  }));
                  sections.push(
                    <div key={shelfId} className="border rounded-md overflow-hidden">
                      <button
                        type="button"
                        className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium bg-muted/30 hover-elevate"
                        onClick={() => toggleShelf(shelfId)}
                        data-testid={`shelf-group-${shelfId}`}
                      >
                        <span>
                          {shelfKey}{" "}
                          <span className="text-muted-foreground font-normal">({groupProducts.length})</span>
                        </span>
                        {isOpen ? <ChevronUp className="h-4 w-4 flex-shrink-0" /> : <ChevronDown className="h-4 w-4 flex-shrink-0" />}
                      </button>
                      {isOpen && (
                        <ScrollVerticalView
                          items={groupScrollItems}
                          renderItem={(item) => renderProductCard(item as ScrollViewItem)}
                          height={isMobile ? undefined : "calc(100vh - 280px)"}
                          emptyMessage=""
                        />
                      )}
                    </div>
                  );
                }

                return sections.length > 0 ? sections : (
                  <ScrollVerticalView
                    items={scrollItems}
                    renderItem={(item) => renderProductCard(item as ScrollViewItem)}
                    height={isMobile ? undefined : "calc(100vh - 160px)"}
                    emptyMessage="No products in this catalog."
                    footer={
                      <p className="text-sm text-muted-foreground text-center mt-3 font-medium">
                        {scrollItems.length} products available
                      </p>
                    }
                  />
                );
              })()}

              {addingShelf ? (
                <div className="flex items-center gap-2 pt-1" data-testid="add-shelf-form">
                  <Input
                    autoFocus
                    placeholder="Shelf name…"
                    value={newShelfName}
                    onChange={e => setNewShelfName(e.target.value)}
                    onKeyDown={async e => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        await handleAddShelf();
                      } else if (e.key === "Escape") {
                        setAddingShelf(false);
                        setNewShelfName("");
                      }
                    }}
                    className="flex-1"
                    data-testid="input-new-shelf-name"
                  />
                  <Button
                    size="sm"
                    onClick={handleAddShelf}
                    disabled={savingShelf || !newShelfName.trim()}
                    data-testid="button-save-shelf"
                  >
                    {savingShelf ? "Saving…" : "Save"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => { setAddingShelf(false); setNewShelfName(""); }}
                    data-testid="button-cancel-shelf"
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full"
                  onClick={() => setAddingShelf(true)}
                  disabled={!SHELF_CREATION_ENABLED}
                  title={SHELF_CREATION_ENABLED ? undefined : "Shelf creation is dormant"}
                  data-testid="button-add-shelf"
                >
                  <Plus className="h-3.5 w-3.5 mr-1" />
                  Add Shelf
                </Button>
              )}
            </div>
          )}
        </>
      )}

      {dataMode === "joint" && (
        <>
          <div className="flex items-center gap-2 py-1">
            <span className="text-xs font-medium text-amber-600 dark:text-amber-400">
              Joint Catalog — {loadingJointProducts ? "loading…" : `${jointCatalogProducts.length} products with verified descriptions`}
            </span>
          </div>
          {loadingJointProducts ? (
            <div className="flex gap-3 overflow-hidden">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="flex-shrink-0 w-[calc(50vw-3rem)] max-w-[180px] aspect-[9/16] rounded-lg" />
              ))}
            </div>
          ) : jointCatalogProducts.length === 0 ? (
            <div className="p-6 text-center space-y-2 border rounded-md bg-muted/20">
              <p className="text-sm text-muted-foreground">
                No products have both a master description and an admin description yet. Add admin descriptions to products in a catalog first.
              </p>
            </div>
          ) : (
            <ScrollVerticalView
              items={scrollItems}
              renderItem={(item) => renderProductCard(item as ScrollViewItem)}
              height={isMobile ? undefined : "calc(100vh - 160px)"}
              emptyMessage="No products in joint catalog."
              footer={
                <p className="text-sm text-muted-foreground text-center mt-3 font-medium">
                  {scrollItems.length} verified products
                </p>
              }
            />
          )}
        </>
      )}

      {dataMode === "all" && (
        <>
          <div data-testid="module-category">
            <div className="flex items-center gap-2 mb-2">
              <Layers className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm font-medium">Browse Catalog</p>
            </div>

            {loadingCatalogProducts && qrgNavigatorData === null ? (
              <div className="flex gap-1 flex-wrap">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-7 w-20 rounded-md" />
                ))}
              </div>
            ) : qrgNavigatorData && qrgNavigatorData.size > 0 ? (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1" data-testid="qrg-super-category-nav">
                  {Array.from(qrgNavigatorData.entries())
                    .sort(([a], [b]) => a.localeCompare(b))
                    .map(([superCode, subMap]) => {
                      const totalCount = Array.from(subMap.values()).reduce((n, s) => n + s.count, 0);
                      const isActive = qrgSuperCategory === superCode;
                      return (
                        <button
                          key={superCode}
                          type="button"
                          className={[
                            "text-xs px-2.5 py-1.5 rounded-md border transition-colors",
                            isActive
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-muted/40 border-border hover-elevate",
                          ].join(" ")}
                          onClick={() => {
                            if (qrgSuperCategory === superCode) {
                              setQrgSuperCategory(null);
                              setQrgSubCategory(null);
                              setCategory(null);
                            } else {
                              setQrgSuperCategory(superCode);
                              setQrgSubCategory(null);
                              setCategory(null);
                            }
                          }}
                          data-testid={`qrg-super-category-${superCode}`}
                        >
                          {SUPER_CATEGORY_LABELS[superCode] ?? superCode}
                          <span className="ml-1 opacity-60">({totalCount})</span>
                        </button>
                      );
                    })}
                </div>

                {qrgSuperCategory && qrgNavigatorData.get(qrgSuperCategory) && (
                  <div className="flex flex-wrap gap-1 pl-2 border-l border-border" data-testid="qrg-sub-category-nav">
                    {Array.from(qrgNavigatorData.get(qrgSuperCategory)!.entries())
                      .sort(([a], [b]) => a.localeCompare(b))
                      .map(([subCode, { categoryName, count }]) => {
                        const isActive = qrgSubCategory === subCode;
                        return (
                          <button
                            key={subCode}
                            type="button"
                            className={[
                              "text-xs px-2.5 py-1.5 rounded-md border transition-colors",
                              isActive
                                ? "bg-primary text-primary-foreground border-primary"
                                : "bg-muted/40 border-border hover-elevate",
                            ].join(" ")}
                            onClick={() => {
                              if (qrgSubCategory === subCode) {
                                setQrgSubCategory(null);
                                setCategory(null);
                              } else {
                                setQrgSubCategory(subCode);
                                setCategory(categoryName);
                              }
                            }}
                            data-testid={`qrg-sub-category-${subCode}`}
                          >
                            {categoryName}
                            <span className="ml-1 opacity-60">({count})</span>
                          </button>
                        );
                      })}
                  </div>
                )}

                {qrgSuperCategory && !qrgNavigatorData.get(qrgSuperCategory)?.size && (
                  <p className="text-xs text-muted-foreground pl-2">
                    No subcategories available via {provider} for this category.
                  </p>
                )}
              </div>
            ) : (
              !loadingCatalogProducts && (
                <p className="text-xs text-muted-foreground">
                  No catalog data available via {provider}.
                </p>
              )
            )}
          </div>

          {!qrgSuperCategory && !loadingCatalogProducts && (
            <p className="text-xs text-muted-foreground" data-testid="hint-select-super-category">
              Select a category above to browse by product type.
            </p>
          )}

          {qrgSuperCategory && !qrgSubCategory && (
            <p className="text-xs text-muted-foreground" data-testid="hint-select-sub-category">
              Select a subcategory to see products.
            </p>
          )}

          {qrgSubCategory && state.category && (
            <>
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-8"
                  data-testid="input-search"
                />
              </div>

              <div>
                <button
                  type="button"
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setMoreFiltersOpen(o => !o)}
                  data-testid="button-toggle-more-filters"
                >
                  <Filter className="h-3 w-3" />
                  {moreFiltersOpen ? "Hide filters" : "More filters"}
                  {(locationFilter !== "all" || state.genderFilter !== "all") && (
                    <span className="ml-1 inline-flex items-center justify-center w-4 h-4 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">
                      {(locationFilter !== "all" ? 1 : 0) + (state.genderFilter !== "all" ? 1 : 0)}
                    </span>
                  )}
                  {moreFiltersOpen ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                </button>

                {moreFiltersOpen && (
                  <div className="mt-2 space-y-2 pl-1" data-testid="more-filters-panel">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs text-muted-foreground w-14">Location</span>
                      <Badge
                        variant={locationFilter === "all" ? "default" : "outline"}
                        className="cursor-pointer text-xs"
                        onClick={() => applyLocationFilter("all")}
                        data-testid="filter-location-all"
                      >
                        <Globe className="w-3 h-3 mr-1" /> All ({products.length})
                      </Badge>
                      <Badge
                        variant={locationFilter === "usa" ? "default" : "outline"}
                        className="cursor-pointer text-xs"
                        onClick={() => applyLocationFilter("usa")}
                        data-testid="filter-location-usa"
                      >
                        <Flag className="w-3 h-3 mr-1" /> USA ({usaCount})
                      </Badge>
                      <Badge
                        variant={locationFilter === "other" ? "default" : "outline"}
                        className="cursor-pointer text-xs"
                        onClick={() => applyLocationFilter("other")}
                        data-testid="filter-location-other"
                      >
                        Other ({otherCount})
                      </Badge>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs text-muted-foreground w-14">Gender</span>
                      {(["all", "mens", "womens", "unisex"] as const).map((g) => (
                        <Badge
                          key={g}
                          variant={state.genderFilter === g ? "default" : "outline"}
                          className="cursor-pointer text-xs capitalize"
                          onClick={() => setGenderFilter(g)}
                          data-testid={`filter-gender-${g}`}
                        >
                          {g === "all" ? "All" : g === "mens" ? "Men" : g === "womens" ? "Women" : "Unisex"} ({genderCounts[g]})
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {error ? (
                <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-md space-y-2">
                  <p className="text-sm text-destructive">
                    {error instanceof Error ? error.message : "Failed to load products"}
                  </p>
                </div>
              ) : isLoading ? (
                <div className="flex gap-3 overflow-hidden">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="flex-shrink-0 w-[calc(50vw-3rem)] max-w-[180px] aspect-[9/16] rounded-lg" />
                  ))}
                </div>
              ) : (
                <ScrollVerticalView
                  items={scrollItems}
                  renderItem={(item) => renderProductCard(item as ScrollViewItem)}
                  height={isMobile ? undefined : "calc(100vh - 160px)"}
                  emptyMessage="No products match the current filters."
                  footer={
                    <p className="text-sm text-muted-foreground text-center mt-3 font-medium">
                      {scrollItems.length} products available
                    </p>
                  }
                />
              )}
            </>
          )}
        </>
      )}

      {state.selectedProduct && (
        <p className="text-xs text-muted-foreground px-1" data-testid="selected-product-hint">
          Product selected — choose your QR type below.
        </p>
      )}
    </div>

    {pickerOpen && activeCatalog && (
      <BlankPickerModal key={activeCatalog.id} targetCatalogId={activeCatalog.id} open={pickerOpen} onOpenChange={setPickerOpen} />
    )}
    </>
  );
}
