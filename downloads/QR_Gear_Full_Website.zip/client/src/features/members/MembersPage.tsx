import { MemberDynamics } from './MemberDynamics';
import { useState, useEffect, useRef, Component, lazy, Suspense, type ErrorInfo, type ReactNode } from "react";
import { useMemberRuntimeState } from './useMemberRuntimeState';
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  User, QrCode, Loader2, Layers, DollarSign, Share2,
  Wand2, Zap, Sparkles, BarChart3, Banknote, AlertCircle, RefreshCw
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import SEO from "@/components/SEO";
import { MemberAuthProvider } from "@/features/members/MemberAuthContext";
import { MembersProvider } from "@/features/members/MembersContext";
import {
  type ViewMode, type WizardTier,
} from "@/features/shared/components/wizardSteps";
import { memberFetch } from "@/lib/memberFetch";
import { WizardProvider, useWizardContext } from "./WizardContext";
import { MemberIndexView } from "./member-index-view";
import { ChannelsView } from "./member-channels-view";
import { PayoutsView } from "./PayoutsView";

const SuperSimpleWizard = lazy(() => import("./SuperSimpleWizard").then(m => ({ default: m.SuperSimpleWizard })));
const SimpleWizard = lazy(() => import("./SimpleWizard").then(m => ({ default: m.SimpleWizard })));
const AdvancedWizard = lazy(() => import("./AdvancedWizard").then(m => ({ default: m.AdvancedWizard })));
const StudioMode = lazy(() => import("./StudioMode").then(m => ({ default: m.StudioMode })));
const SocialHubView = lazy(() => import("./SocialHubView").then(m => ({ default: m.SocialHubView })));

function LazyFallback() {
  return (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
    </div>
  );
}

interface EarningsSummary {
  total: number;
  pending: number;
  paid: number;
  profitShare: number;
}

function EarningsView({ memberId }: { memberId: string }) {
  const { data: earningsData, isLoading } = useQuery<{ earnings: any[], summary: EarningsSummary }>({
    queryKey: ['/api/members', memberId, 'earnings'],
    queryFn: async () => {
      if (!memberId) return { earnings: [], summary: { total: 0, pending: 0, paid: 0, profitShare: 0.25 } };
      return memberFetch<any>(`/${memberId}/earnings`);
    },
    enabled: !!memberId
  });

  const summary = earningsData?.summary || { total: 0, pending: 0, paid: 0, profitShare: 0.25 };
  const earnings = earningsData?.earnings || [];

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <DollarSign className="w-5 h-5" />
          Earnings Dashboard
        </CardTitle>
      </CardHeader>
      <CardContent className="row">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full" />
          </div>
        ) : (
          <>
            <div className="layout__auto mb-6">
              <div className="py-4 text-center">
                  <p className="text-sm text-slate-400">Total Earnings</p>
                  <p className="text-2xl font-bold text-green-400">${summary.total.toFixed(2)}</p>
                </div>
              <div className="py-4 text-center">
                  <p className="text-sm text-slate-400">Pending</p>
                  <p className="text-2xl font-bold text-yellow-400">${summary.pending.toFixed(2)}</p>
                </div>
              <div className="py-4 text-center">
                  <p className="text-sm text-slate-400">Profit Share</p>
                  <p className="text-2xl font-bold text-blue-400">{(summary.profitShare * 100).toFixed(0)}%</p>
                </div>
            </div>
            
            {earnings.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <BarChart3 className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="mb-2">No sales yet</p>
                <p className="text-sm">Share your products to start earning {(summary.profitShare * 100).toFixed(0)}% profit</p>
              </div>
            ) : (
              <div className="space-y-2">
                <h3 className="text-white font-medium mb-3">Recent Earnings</h3>
                {earnings.slice(0, 5).map((earning: any) => (
                  <div key={earning.id} className="flex justify-between items-center p-3 bg-slate-700/50 rounded-lg">
                    <div>
                      <p className="text-white text-sm">{earning.productName || 'Product Sale'}</p>
                      <p className="text-xs text-slate-400">{new Date(earning.createdAt).toLocaleDateString()}</p>
                    </div>
                    <Badge variant={earning.status === 'paid' ? 'default' : 'secondary'}>
                      ${earning.amount?.toFixed(2) || '0.00'}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}


function useTempPacketClaim({
  userId,
  onboardingComplete,
  onClaim,
  onSuccess,
  onError,
}: {
  userId: string;
  onboardingComplete: boolean;
  onClaim: (cfg: any) => void;
  onSuccess: () => void;
  onError: (msg?: string) => void;
}) {
  const claimedRef = useRef(false);
  const params = new URLSearchParams(window.location.search);
  const tempPacketId = params.get('tempPacketId') || localStorage.getItem('pending_temp_packet_id');

  useEffect(() => {
    if (!onboardingComplete || !tempPacketId || !userId || claimedRef.current) return;
    claimedRef.current = true;
    localStorage.removeItem('pending_temp_packet_id');
    (async () => {
      try {
        const { auth } = await import('@/lib/firebase');
        const token = await auth.currentUser?.getIdToken();
        const res = await fetch(`/api/members/${userId}/claim-temp-packet`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
          body: JSON.stringify({ tempPacketId }),
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          const msg = (errData as any).error;
          onError(msg);
          return;
        }
        const data = await res.json();
        if (data.success && data.packetConfig) {
          onClaim(data.packetConfig);
          onSuccess();
        }
      } catch (err) {
        console.warn('[Member] Failed to claim temp packet:', err);
        onError();
      }
    })();
  }, [onboardingComplete, tempPacketId, userId]);
}

function MembersShell() {
  const { isLoading: authLoading } = useAuth();

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
      </div>
    );
  }

  return (
    <WizardProvider>
      <MembersController />
    </WizardProvider>
  );
}

function MembersController() {
  const {
    user,
    viewMode, setViewMode,
    wizardTier, setWizardTier, startNewBuild,
    publishCount,
    showUnlockPrompt, setShowUnlockPrompt,
    setSelectedColor, setQrType, setSelectedPlacements, setGraphicSize,
  } = useWizardContext();
  const [, setLocation] = useLocation();
  const [initialChannelId, setInitialChannelId] = useState<string | null>(null);
  const { toast } = useToast();

  const { isLoading, isAuthenticated, userId, onboardingComplete, profileError, refreshProfile } = useMemberRuntimeState();

  useEffect(() => {
    if (profileError) return;
    if (!isLoading && isAuthenticated && userId && !onboardingComplete) {
      const params = window.location.search;
      setLocation(`/member${params}`);
    }
  }, [isLoading, isAuthenticated, userId, onboardingComplete, profileError, setLocation]);

  useTempPacketClaim({
    userId,
    onboardingComplete,
    onClaim: (cfg: any) => {
      if (cfg.selectedColor) setSelectedColor(cfg.selectedColor);
      if (cfg.qrType) setQrType(cfg.qrType);
      if (cfg.selectedPlacements?.length) setSelectedPlacements(cfg.selectedPlacements);
      if (cfg.graphicSize) setGraphicSize(cfg.graphicSize);
      setWizardTier('super-simple');
      setViewMode('wizard');
    },
    onSuccess: () => {
      toast({ title: 'Your work was saved!', description: 'Pick up right where you left off.' });
    },
    onError: (msg?: string) => {
      toast({
        title: "Couldn't recover your work",
        description: msg || 'Your session may have expired. Try creating again.',
        variant: 'destructive',
      });
    },
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setWizardTier('super-simple');
      setViewMode('wizard');
    }
  }, [isLoading, isAuthenticated]);

  if (isAuthenticated && profileError) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%)' }}>
        <Card className="bg-slate-800/80 border-red-500/30 max-w-sm w-full">
          <CardContent className="p-8 text-center space-y-4">
            <AlertCircle className="w-10 h-10 mx-auto text-red-400" />
            <h2 className="text-lg font-semibold text-white">Couldn't load your profile</h2>
            <p className="text-slate-400 text-sm">
              There was a problem connecting to your account. Check your connection and try again.
            </p>
            <Button
              onClick={refreshProfile}
              className="w-full"
              data-testid="button-retry-profile"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isAuthenticated && (isLoading || !onboardingComplete)) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%)' }}>
        <Loader2 className="h-8 w-8 animate-spin text-blue-400" />
      </div>
    );
  }

  return (
    <div className="row">
      <SEO title="Member Area" description="Build and sell your products" />
      
      <div className="row">
        {viewMode !== 'wizard' && isAuthenticated && (
        <div className="flex gap-2 flex-wrap mb-4">
              <Button
                variant={viewMode === 'index' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('index')}
                data-testid="tab-home"
                className={viewMode === 'index' ? 'bg-slate-600 text-white' : 'text-white/70 hover:text-white hover:bg-white/10'}
              >
                <User className="w-4 h-4 mr-1" />
                Home
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => startNewBuild('super-simple')}
                data-testid="tab-super-simple"
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <Sparkles className="w-4 h-4 mr-1" />
                Super Simple
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => startNewBuild('simple')}
                data-testid="tab-simple"
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <Wand2 className="w-4 h-4 mr-1" />
                Quick Create
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => startNewBuild('advanced')}
                data-testid="tab-advanced"
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <Layers className="w-4 h-4 mr-1" />
                Advanced
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => startNewBuild('studio')}
                data-testid="tab-studio"
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <Zap className="w-4 h-4 mr-1" />
                Studio
              </Button>
              <Button
                variant={viewMode === 'channels' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('channels')}
                data-testid="tab-channels"
                className={viewMode === 'channels' ? 'bg-blue-600 text-white' : 'text-white/70 hover:text-white hover:bg-white/10'}
              >
                <Layers className="w-4 h-4 mr-1" />
                Channels
              </Button>
              <Button
                variant={viewMode === 'collections' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('collections')}
                data-testid="tab-collections"
                className={viewMode === 'collections' ? 'bg-blue-600 text-white' : 'text-white/70 hover:text-white hover:bg-white/10'}
              >
                <QrCode className="w-4 h-4 mr-1" />
                QR Dynamics
              </Button>
              <Button
                variant={viewMode === 'earnings' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('earnings')}
                data-testid="tab-earnings"
                className={viewMode === 'earnings' ? 'bg-blue-600 text-white' : 'text-white/70 hover:text-white hover:bg-white/10'}
              >
                <DollarSign className="w-4 h-4 mr-1" />
                Earnings
              </Button>
              <Button
                variant={viewMode === 'payouts' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('payouts')}
                data-testid="tab-payouts"
                className={viewMode === 'payouts' ? 'bg-emerald-600 text-white' : 'text-white/70 hover:text-white hover:bg-white/10'}
              >
                <Banknote className="w-4 h-4 mr-1" />
                Payouts
              </Button>
              <Button
                variant={viewMode === 'social' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('social')}
                data-testid="tab-social"
                className={viewMode === 'social' ? 'bg-pink-600 text-white' : 'text-white/70 hover:text-white hover:bg-white/10'}
              >
                <Share2 className="w-4 h-4 mr-1" />
                Social Hub
              </Button>
        </div>
        )}

        {showUnlockPrompt === 'advanced' && (
          <div className="glass-card p-4 mb-6 flex flex-wrap items-center justify-between gap-4 border-blue-500/50 bg-blue-900/20">
            <div className="flex items-center gap-3">
              <Layers className="w-6 h-6 text-blue-400" />
              <div>
                <p className="text-white font-medium">Advanced Mode Unlocked!</p>
                <p className="text-white/70 text-sm">Great job on your first creation! You now have access to Advanced mode with more options.</p>
              </div>
            </div>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={() => setShowUnlockPrompt(null)}
              className="text-white/70 hover:text-white"
              data-testid="dismiss-unlock-prompt"
            >
              Got it
            </Button>
          </div>
        )}

        {showUnlockPrompt === 'studio' && (
          <div className="glass-card p-4 mb-6 flex flex-wrap items-center justify-between gap-4 border-amber-500/50 bg-amber-900/20">
            <div className="flex items-center gap-3">
              <Zap className="w-6 h-6 text-amber-400" />
              <div>
                <p className="text-white font-medium">Studio Mode Unlocked!</p>
                <p className="text-white/70 text-sm">You're a pro now! Studio mode gives you full control with quick publishing.</p>
              </div>
            </div>
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={() => setShowUnlockPrompt(null)}
              className="text-white/70 hover:text-white"
              data-testid="dismiss-unlock-prompt"
            >
              Got it
            </Button>
          </div>
        )}

        {viewMode === 'wizard' && wizardTier === 'simple' && (
          <Suspense fallback={<LazyFallback />}>
            <SimpleWizard />
          </Suspense>
        )}

        {viewMode === 'wizard' && wizardTier === 'advanced' && (
          <Suspense fallback={<LazyFallback />}>
            <AdvancedWizard />
          </Suspense>
        )}

        {viewMode === 'wizard' && wizardTier === 'studio' && (
          <Suspense fallback={<LazyFallback />}>
            <StudioMode />
          </Suspense>
        )}

        {viewMode === 'wizard' && wizardTier === 'super-simple' && (
          <Suspense fallback={<LazyFallback />}>
            <SuperSimpleWizard />
          </Suspense>
        )}

        {viewMode === 'index' && !isAuthenticated && (
          <div className="flex flex-col items-center justify-center py-16 px-4">
            <Card className="bg-slate-800/80 border-slate-700 max-w-md w-full">
              <CardContent className="p-8 text-center space-y-4">
                <QrCode className="w-12 h-12 mx-auto text-emerald-400" />
                <h2 className="text-xl font-bold text-white">You need an account to continue</h2>
                <p className="text-slate-400 text-sm">
                  An account lets us save your creations, generate your product mockups, and give you a personal dashboard to manage everything. It only takes a few seconds.
                </p>
                <p className="text-slate-500 text-xs">
                  Head back to the creator — you'll be asked to sign up right before your mockup is generated.
                </p>
                <div className="flex flex-col gap-3 pt-2">
                  <Button
                    onClick={() => { setWizardTier('super-simple'); setViewMode('wizard'); }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white"
                    data-testid="button-back-to-wizard"
                  >
                    <Wand2 className="w-4 h-4 mr-2" />
                    Back to Creator
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {viewMode === 'index' && isAuthenticated && (
          <MemberIndexView 
            memberId={user?.id || ''} 
            onNavigate={(view, channelId) => {
              if (view === 'channels' && channelId) {
                setInitialChannelId(channelId);
              } else {
                setInitialChannelId(null);
              }
              setViewMode(view);
            }}
            onStartWizard={startNewBuild}
            publishCount={publishCount}
          />
        )}

        {viewMode === 'channels' && (
          <ChannelsView memberId={user?.id || ''} initialChannelId={initialChannelId} />
        )}

        {viewMode === 'collections' && (
          <MemberDynamics memberId={user?.id || ''} />
        )}

        {viewMode === 'earnings' && (
          <EarningsView memberId={user?.id || ''} />
        )}

        {viewMode === 'payouts' && (
          <PayoutsView memberId={user?.id || ''} />
        )}

        {viewMode === 'social' && (
          <Suspense fallback={<LazyFallback />}>
            <SocialHubView memberId={user?.id || ''} />
          </Suspense>
        )}

        <div className="mt-6 text-center text-white/50 text-sm">
          Logged in as: {user?.email || "Unknown"}
        </div>
      </div>
    </div>
  );
}

class MembersErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null; errorInfo: string }> {
  state = { error: null as Error | null, errorInfo: '' };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) {
    this.setState({ errorInfo: info.componentStack || '' });
    console.error('[MembersPage crash]', error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center p-6" style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%)' }}>
          <Card className="bg-slate-800/80 border-red-500/50 max-w-lg">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-xl font-bold text-white">Something went wrong</h2>
              <p className="text-red-300 text-sm font-mono break-all">{this.state.error.message}</p>
              <pre className="text-xs text-slate-400 max-h-40 overflow-auto whitespace-pre-wrap">{this.state.errorInfo}</pre>
              <Button onClick={() => { this.setState({ error: null, errorInfo: '' }); window.location.reload(); }} data-testid="button-reload-members">
                Reload Page
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function MembersApp() {
  return (
    <MembersErrorBoundary>
      <MemberAuthProvider apiBase="/api/members">
        <MembersProvider>
          <MembersShell />
        </MembersProvider>
      </MemberAuthProvider>
    </MembersErrorBoundary>
  );
}
