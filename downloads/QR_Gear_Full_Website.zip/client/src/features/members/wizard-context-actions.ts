import { publishMemberBuild } from '@/lib/memberBuild';
import {
  generateQRCodeUrl,
  normalizeWizardProduct,
  wizardProductToPacketBoundProduct,
  getDefaultPacketTitle,
  getDefaultPacketDescription,
  getAuthHeaders,
} from "@/features/shared/components/wizardSteps";
import type { AllowedProduct } from "@/features/shared/components/wizardSteps";
import { memberFetch } from "@/lib/memberFetch";

export function executeGeneratePreviewQrCode(ctx: any): string {
  const previewUrl = `${window.location.origin}/preview/${Date.now()}`;
  const qrApiUrl = generateQRCodeUrl(previewUrl, 200);
  ctx.setQrGraphic(qrApiUrl);
  ctx.setProductGraphic(qrApiUrl);
  return qrApiUrl;
}

export async function executeCreatePacketForProduct(ctx: any, product: AllowedProduct): Promise<string | null> {
  try {
    console.log('[Wizard] Creating packet for product:', {
      blueprintId: product.blueprintId,
      printProviderId: product.printProviderId,
      title: product.title,
      memberEarnings: product.memberEarnings,
      retailPrice: product.retailPrice,
      baseCost: product.baseCost,
    });

    const placeholderQrUrl = generateQRCodeUrl('placeholder', 200);

    const packetPayload = {
      memberId: ctx.user?.id,
      kind: 'qr_basic',
      background: { url: placeholderQrUrl },
      boundProduct: {
        ...wizardProductToPacketBoundProduct(normalizeWizardProduct(product, 'member')),
      },
      metadata: {},
      source: { entryPoint: 'simple-wizard' },
      status: 'building',
    };

    try {
      const data = await memberFetch<any>(`/${ctx.user?.id}/packets`, {
        method: 'POST',
        json: packetPayload,
      });
      console.log('[Wizard] Created packet on product select:', data.packetId);
      ctx.setCurrentPacketId(data.packetId);
      return data.packetId;
    } catch (packetErr) {
      console.error('[Wizard] Packet creation failed:', packetErr);
    }
  } catch (error) {
    console.error('[Wizard] Failed to create packet:', error);
  }
  return null;
}

export async function executeUpdatePacket(ctx: any, updates: Record<string, any>): Promise<boolean> {
  if (!ctx.currentPacketId || !ctx.user?.id) {
    console.warn('[Wizard] No packet or user to update');
    return false;
  }
  try {
    await memberFetch(`/${ctx.user.id}/packets/${ctx.currentPacketId}`, {
      method: 'PATCH',
      json: updates,
    });
    console.log('[Wizard] Updated packet:', ctx.currentPacketId, Object.keys(updates));
    return true;
  } catch (error) {
    console.error('[Wizard] Failed to update packet:', error);
    return false;
  }
}

export async function executeSimplePublish(ctx: any): Promise<boolean> {
  if (!ctx.user?.id) {
    ctx.setShowSignInToPublish(true);
    return false;
  }
  if (!ctx.selectedChannel) {
    ctx.toast({ title: 'Select a channel', description: 'Go to My Channels and select or create one first.', variant: 'destructive' });
    return false;
  }

  ctx.setIsPublishing(true);
  let resolvedVideoUrl = ctx.playVideoUrl;
  try {
    let resolvedChannelId = ctx.selectedChannel.id;
    if (ctx.selectedChannel.id === 'temp-channel') {
      const channelData = await memberFetch<any>(`/${ctx.user.id}/channels`, {
        method: 'POST',
        json: { name: ctx.selectedChannel.name || 'My Products' },
      });
      resolvedChannelId = channelData.id || channelData.channelId;
      ctx.setSelectedChannel({ id: resolvedChannelId, name: ctx.selectedChannel.name || 'My Products' });
    }

    if (ctx.pendingVideoFile && ctx.playVideoUrl?.startsWith('blob:')) {
      const formData = new FormData();
      formData.append('file', ctx.pendingVideoFile);
      formData.append('storeType', 'member');
      const uploadData = await memberFetch<any>(`/${ctx.user.id}/videos/upload`, {
        method: 'POST',
        body: formData,
      });
      if (uploadData?.url) {
        resolvedVideoUrl = uploadData.url;
        ctx.setPlayVideoUrl(resolvedVideoUrl);
      }
      ctx.setPendingVideoFile(null);
    }

    const packetData: Record<string, any> = {
      packetType: ctx.qrType,
      title: ctx.simpleTitle,
      description: ctx.simpleDescription,
      channelId: resolvedChannelId,
      storeId: ctx.user.id,
      status: 'published',
      boundProduct: ctx.selectedProductType
        ? wizardProductToPacketBoundProduct(normalizeWizardProduct(ctx.selectedProductType, 'member'))
        : null,
      selectedColor: ctx.selectedColor || null,
      selectedShirtSize: ctx.selectedShirtSize || null,
      selectedPlacements: ctx.selectedPlacements.length > 0 ? ctx.selectedPlacements : null,
      perPlacementConfigs: Object.keys(ctx.perPlacementConfigs).length > 0 ? ctx.perPlacementConfigs : null,
      perPlacementSizes: Object.keys(ctx.perPlacementSizes).length > 0 ? ctx.perPlacementSizes : null,
      graphicSize: ctx.graphicSize || null,
      textLayoutChoice: ctx.textLayoutChoice || null,
      headerText: ctx.headerStyle.enabled ? ctx.headerStyle.text : null,
      footerText: ctx.footerStyle.enabled ? ctx.footerStyle.text : null,
      headerStyle: ctx.headerStyle.enabled ? ctx.headerStyle : null,
      footerStyle: ctx.footerStyle.enabled ? ctx.footerStyle : null,
      qrType: ctx.qrType || null,
      qrDestination: ctx.qrDestination || null,
      qrGraphic: ctx.qrGraphic || null,
      productGraphic: ctx.productGraphic || null,
      background: ctx.urlGraphic || null,
      originalUrlGraphic: ctx.originalUrlGraphic || null,
      videoUrl: ctx.qrType === 'qr-play' ? (resolvedVideoUrl || ctx.videoUrl) : null,
      qrBasicInputType: ['qr-basic', 'qr-plus'].includes(ctx.qrType) ? (ctx.qrBasicInputType || null) : null,
      qrBasicContent: ['qr-basic', 'qr-plus'].includes(ctx.qrType) ? (ctx.qrBasicContent || null) : null,
      qrBasicMockup: ctx.qrType === 'qr-basic' ? (ctx.qrBasicMockup || null) : null,
      qrBasicSaveChoice: ctx.qrType === 'qr-basic' ? (ctx.qrBasicSaveChoice || null) : null,
      qrPlusMockup: ctx.qrType === 'qr-plus' ? (ctx.qrPlusMockup || null) : null,
      qrPlusSaveChoice: ctx.qrType === 'qr-plus' ? (ctx.qrPlusSaveChoice || null) : null,
      qrCanvasMockup: ctx.qrType === 'qr-canvas' ? (ctx.qrCanvasMockup || null) : null,
      qrPlayMockup: ctx.qrType === 'qr-play' ? (ctx.qrPlayMockup || null) : null,
      composeMockup: ctx.qrType === 'qr-compose' ? (ctx.composeMockup || null) : null,
      composeItems: ctx.qrType === 'qr-compose' ? ctx.composeItems : null,
      composeMode: ctx.qrType === 'qr-compose' ? (ctx.composeMode || 'auto-rotate') : null,
      composeHostingTerm: ctx.qrType === 'qr-compose' ? (ctx.composeHostingTerm || null) : null,
      qrPositionX: ctx.qrPositionX,
      qrPositionY: ctx.qrPositionY,
      qrSizePercent: ctx.qrSizePercent,
      areaImageUrl: ctx.areaImageUrl || null,
      areaImageMode: ctx.areaImageMode,
      source: { entryPoint: 'simple-wizard' },
      itemImage: ctx.qrType === 'qr-canvas' ? (ctx.qrCanvasMockup || ctx.productGraphic || null)
        : ctx.qrType === 'qr-basic' ? (ctx.qrBasicMockup || ctx.productGraphic || null)
        : ctx.qrType === 'qr-plus' ? (ctx.qrPlusMockup || ctx.productGraphic || null)
        : ctx.qrType === 'qr-play' ? (ctx.qrPlayMockup || ctx.productGraphic || null)
        : ctx.qrType === 'qr-compose' ? (ctx.composeMockup || ctx.productGraphic || null)
        : (ctx.productGraphic || null),
    };

    console.log('[UnifiedPublish] Publishing packet:', {
      existingPacketId: ctx.currentPacketId,
      qrType: ctx.qrType,
      blueprintId: ctx.selectedProductType?.blueprintId,
      color: ctx.selectedColor,
      placements: ctx.selectedPlacements,
      graphicSize: ctx.graphicSize,
      textLayout: ctx.textLayoutChoice,
      earnings: ctx.runningEarnings,
    });

    let result: any;

    packetData.existingPacketId = ctx.currentPacketId;
    packetData.graphicLayoutMode = ctx.graphicLayoutMode;
    result = await publishMemberBuild(ctx.user.id, packetData);

    const packetId = result.id || result.packetId || ctx.currentPacketId || null;
    ctx.setPublishedBuild(result);
    ctx.setPublishedPacketId(packetId);
    ctx.setCurrentPacketId(packetId);
    ctx.incrementPublishCount();
    ctx.api.invalidateMembers();

    if (ctx.qrType === 'qr-compose') {
      ctx.setComposeInstanceId(result.composeInstanceId || null);
      ctx.setSimpleStep('compose-confirm');
    } else if (ctx.qrType === 'qr-play') {
      ctx.setSimpleStep('play-save-choice');
    } else if (ctx.qrType === 'qr-canvas') {
      ctx.setPublishedQrGraphicUrl(result.qrGraphic || null);
      ctx.setPublishedProductGraphicUrl(result.productGraphic || null);
      try {
        const assetsToSave: { url: string; assetType: string; name: string }[] = [];
        if (result.productGraphic) {
          assetsToSave.push({ url: result.productGraphic, assetType: 'graphic', name: `${ctx.simpleTitle || 'Canvas'} - Product Graphic` });
        }
        if (ctx.urlGraphic) {
          assetsToSave.push({ url: ctx.urlGraphic, assetType: 'background', name: `${ctx.simpleTitle || 'Canvas'} - Landing Page` });
        }
        if (result.qrGraphic) {
          assetsToSave.push({ url: result.qrGraphic, assetType: 'graphic', name: `${ctx.simpleTitle || 'Canvas'} - QR Code` });
        }
        for (const asset of assetsToSave) {
          try {
            await memberFetch(`/${ctx.user.id}/library`, {
              method: 'POST',
              json: {
                publicUrl: asset.url,
                storageUrl: asset.url,
                assetType: asset.assetType,
                mediaType: 'image',
                name: asset.name,
                fileName: asset.name.replace(/[^a-zA-Z0-9]/g, '_') + '.png'
              },
            });
          } catch (err) {
            console.error('[Canvas Auto-Save] Failed:', asset.assetType, err);
            ctx.toast({ title: 'Auto-save warning', description: `Could not auto-save ${asset.assetType} to your library.`, variant: 'destructive' });
          }
        }
      } catch (saveErr) {
        console.error('[Canvas Auto-Save] Error:', saveErr);
        ctx.toast({ title: 'Auto-save warning', description: 'Could not auto-save assets to your library.', variant: 'destructive' });
      }
      ctx.setSimpleStep('canvas-confirm');
    } else if (ctx.qrType === 'qr-basic') {
    } else if (ctx.qrType === 'qr-plus') {
    } else {
      ctx.setSimpleStep('channel');
      ctx.setViewMode('index');
      ctx.setCurrentPacketId(null);
      ctx.setSimpleTitle('');
      ctx.setSimpleDescription('');
      ctx.setQrType('');
      ctx.setContentRightsConfirmed(false);
      ctx.setUrlGraphic('');
      ctx.setProductGraphic('');
    }
    return true;
  } catch (error) {
    console.error('Simple publish error:', error);
    ctx.toast({ title: 'Publish failed', description: error instanceof Error ? error.message : 'Failed to publish. Please try again.', variant: 'destructive' });
    return false;
  } finally {
    ctx.setIsPublishing(false);
  }
}

export async function executeSaveCanvasToLibrary(ctx: any): Promise<boolean> {
  if (!ctx.user?.id) return false;

  ctx.setIsCanvasSaving(true);
  try {
    const assetsToSave: { url: string; assetType: string; name: string }[] = [];

    if ((ctx.canvasSaveChoice === 'item' || ctx.canvasSaveChoice === 'all') && ctx.publishedProductGraphicUrl) {
      assetsToSave.push({
        url: ctx.publishedProductGraphicUrl,
        assetType: 'graphic',
        name: `${ctx.simpleTitle || 'Canvas'} - Product Graphic`
      });
    }

    if ((ctx.canvasSaveChoice === 'landing' || ctx.canvasSaveChoice === 'all') && ctx.urlGraphic) {
      assetsToSave.push({
        url: ctx.urlGraphic,
        assetType: 'background',
        name: `${ctx.simpleTitle || 'Canvas'} - Landing Page`
      });
    }

    if (ctx.canvasSaveChoice === 'all' && ctx.publishedQrGraphicUrl) {
      assetsToSave.push({
        url: ctx.publishedQrGraphicUrl,
        assetType: 'graphic',
        name: `${ctx.simpleTitle || 'Canvas'} - QR Code`
      });
    }

    for (const asset of assetsToSave) {
      try {
        await memberFetch(`/${ctx.user.id}/library`, {
          method: 'POST',
          json: {
            publicUrl: asset.url,
            storageUrl: asset.url,
            assetType: asset.assetType,
            mediaType: 'image',
            name: asset.name,
            fileName: asset.name.replace(/[^a-zA-Z0-9]/g, '_') + '.png'
          },
        });
        console.log('[Canvas Save] Saved to library:', asset.assetType, asset.name);
      } catch (err) {
        console.error('[Canvas Save] Failed to save:', asset.assetType, err);
        ctx.toast({ title: 'Library save warning', description: `Could not save ${asset.assetType} to your library.`, variant: 'destructive' });
      }
    }

    return true;
  } finally {
    ctx.setIsCanvasSaving(false);
  }
}

export async function executeVideoFileUpload(ctx: any, file: File): Promise<void> {
  const MAX_SIZE = 50 * 1024 * 1024;
  const MIN_SIZE = 10 * 1024;
  if (file.size > MAX_SIZE) {
    ctx.setVideoUploadError(`File is too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Maximum size is 50MB. For larger videos, use the "Paste URL" option instead.`);
    return;
  }
  if (file.size < MIN_SIZE) {
    ctx.setVideoUploadError('This file is too small to be a valid video. Please select the actual video file from your camera roll.');
    return;
  }

  const rejectedExtensions = /\.(ts|m3u8|m3u)$/i;
  if (rejectedExtensions.test(file.name)) {
    ctx.setVideoUploadError('This file type (.ts stream) is not supported. Please select an MP4 or MOV video from your camera roll instead.');
    return;
  }

  if (file.type === 'video/mp2t' || file.type === 'video/mp2ts' || file.type === 'video/MP2T') {
    ctx.setVideoUploadError('Transport stream (.ts) files are not supported. Please select an MP4 or MOV video from your camera roll instead.');
    return;
  }

  const allowedTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/3gpp', 'video/3gpp2', 'video/x-m4v', 'video/x-matroska'];
  const isVideo = file.type.startsWith('video/') || /\.(mp4|mov|webm|m4v|3gp)$/i.test(file.name);
  if (!isVideo && !allowedTypes.includes(file.type)) {
    ctx.setVideoUploadError('Please upload a video file (MP4, MOV, WebM, M4V, or 3GP).');
    return;
  }

  ctx.setVideoUploadError(null);
  ctx.setVideoUploadSuccess(false);

  if (!ctx.user?.id) {
    try {
      ctx.setIsUploadingVideo(true);
      ctx.setVideoUploadProgress(0);
      const blobUrl = URL.createObjectURL(file);
      ctx.setPendingVideoFile(file);
      ctx.setVideoUploadProgress(100);
      ctx.setPlayVideoUrl(blobUrl);
      ctx.setVideoUploadSuccess(true);
    } catch (err) {
      ctx.setVideoUploadError('Failed to load video. Please try again.');
    } finally {
      ctx.setIsUploadingVideo(false);
    }
    return;
  }

  ctx.setIsUploadingVideo(true);
  ctx.setVideoUploadProgress(0);

  try {
    const memberId = ctx.user.id;
    const authHeaders = await getAuthHeaders();

    const formData = new FormData();
    formData.append('file', file);
    formData.append('storeType', 'member');

    const result = await new Promise<{ url: string }>((resolve, reject) => {
      const xhr = new XMLHttpRequest();

      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const pct = Math.round((e.loaded / e.total) * 100);
          ctx.setVideoUploadProgress(pct);
        }
      });

      xhr.addEventListener('load', () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const data = JSON.parse(xhr.responseText);
            resolve(data);
          } catch {
            reject(new Error('Invalid server response'));
          }
        } else {
          let msg = 'Upload failed';
          try {
            const errData = JSON.parse(xhr.responseText);
            msg = errData.error || msg;
          } catch {}
          reject(new Error(msg));
        }
      });

      xhr.addEventListener('error', () => {
        reject(new Error('Network error - check your connection and try again'));
      });

      xhr.addEventListener('abort', () => {
        reject(new Error('Upload was cancelled'));
      });

      xhr.open('POST', `/api/members/${memberId}/media`);
      const authHeader = (authHeaders as any)['Authorization'];
      if (authHeader) {
        xhr.setRequestHeader('Authorization', authHeader);
      }
      xhr.send(formData);
    });

    ctx.setPlayVideoUrl(result.url);
    ctx.setVideoUrl(result.url);
    ctx.setVideoUploadSuccess(true);
    console.log('[QR Play] Video uploaded successfully:', result.url);

    try {
      await memberFetch(`/${memberId}/library/upload`, {
        method: 'POST',
        json: {
          assetType: 'video',
          name: `${ctx.simpleTitle || 'QR Play'} - Video`,
          imageData: 'data:text/plain;base64,' + btoa(result.url),
          mimeType: 'text/plain',
          originalName: `video-url-${Date.now()}.txt`,
        },
      });
      console.log('[QR Play] Video auto-saved to member library');
    } catch (libErr) {
      console.warn('[QR Play] Auto-save to library failed (non-blocking):', libErr);
    }
  } catch (error: any) {
    console.error('[QR Play] Video upload error:', error);
    ctx.setVideoUploadError(error?.message || 'Failed to upload video. Please try again.');
    ctx.setVideoUploadSuccess(false);
  } finally {
    ctx.setIsUploadingVideo(false);
  }
}

export async function executeSavePlayToLibrary(ctx: any): Promise<void> {
  if (!ctx.user?.id || ctx.playSaveChoice === 'skip') return;

  ctx.setIsPlaySaving(true);
  try {
    if (ctx.playVideoUrl && !ctx.playVideoUrl.startsWith('/api/member-files/')) {
      await memberFetch(`/${ctx.user.id}/library/upload`, {
        method: 'POST',
        json: {
          assetType: 'video',
          name: `${ctx.simpleTitle || 'QR Play'} - Video`,
          imageData: 'data:text/plain;base64,' + btoa(ctx.playVideoUrl),
          mimeType: 'text/plain',
          originalName: `video-url-${Date.now()}.txt`,
        },
      }).catch(() => {});
    }
  } catch (error) {
    console.error('[QR Play] Save to library error:', error);
  } finally {
    ctx.setIsPlaySaving(false);
  }
}

export async function executeFetchPublishedCanvasPlayItems(ctx: any): Promise<void> {
  if (!ctx.user?.id) return;
  ctx.setIsLoadingPublishedItems(true);
  try {
    const data = await memberFetch<any>(`/${ctx.user.id}/published-items?types=qr-canvas,qr-play`);
    ctx.setPublishedCanvasPlayItems(data.items || []);
  } catch (error) {
    console.error('[QR Compose] Error fetching published items:', error);
  } finally {
    ctx.setIsLoadingPublishedItems(false);
  }
}

export async function executeGenerateProductMockup(
  ctx: any,
  type: string,
  setMockup: (url: string) => void,
): Promise<void> {
  try {
    const previewUrl = `${window.location.origin}/preview/${Date.now()}`;
    const qrApiUrl = generateQRCodeUrl(previewUrl, 200);
    ctx.setQrGraphic(qrApiUrl);
    console.log(`[${type}] Generated qrGraphic:`, qrApiUrl);

    console.log(`[${type}] Generating productGraphic with textLayoutChoice:`, ctx.textLayoutChoice);
    const productGraphicResult = await ctx.api.generateProductGraphic({
      qrUrl: previewUrl,
      headerStyle: ctx.headerStyle,
      footerStyle: ctx.footerStyle,
      textLayoutChoice: ctx.textLayoutChoice,
      qrColor: 'black',
    });

    let artworkForMockup = qrApiUrl;
    if (productGraphicResult.success && productGraphicResult.productGraphic) {
      ctx.setProductGraphic(productGraphicResult.productGraphic);
      artworkForMockup = productGraphicResult.productGraphic;
      console.log(`[${type}] Generated productGraphic (composite), length:`, productGraphicResult.productGraphic.length);
    } else {
      console.warn(`[${type}] productGraphic generation failed, using qrGraphic as fallback`);
      ctx.setProductGraphic(qrApiUrl);
    }

    const isPrintful = ctx.selectedProductType?.fulfillmentProvider === 'printful';
    if (ctx.selectedProductType?.blueprintId && (ctx.selectedProductType?.printProviderId || isPrintful) && ctx.selectedColor) {
      const effectiveQrSize = (ctx.graphicSize === 'small' || ctx.graphicSize === 'medium' || ctx.graphicSize === 'large') ? ctx.graphicSize : 'medium';
      console.log(`[${type}] Generating mockup with graphicSize:`, ctx.graphicSize, '→ effectiveQrSize:', effectiveQrSize, 'provider:', isPrintful ? 'printful' : 'printify');

      const mockupResult = await ctx.api.generateMockup({
        canonicalBlankKey: ctx.selectedProductType?.canonicalBlankKey,
        blueprintId: ctx.selectedProductType.blueprintId,
        printProviderId: ctx.selectedProductType.printProviderId || 99,
        colorName: ctx.selectedColor,
        artworkUrl: artworkForMockup,
        placement: 'front',
        qrSize: effectiveQrSize,
        fulfillmentProvider: isPrintful ? 'printful' : 'printify',
      });

      const bestUrl = mockupResult.lifestyleMockupUrl || mockupResult.mockupUrl;
      if (mockupResult.success && bestUrl) {
        console.log(`[${type}] SUCCESS - Setting mockup to:`, bestUrl);
        setMockup(bestUrl);
      } else {
        console.warn(`[${type}] FAILED - Using QR fallback. Error:`, mockupResult.error);
        setMockup(qrApiUrl);
      }
    } else {
      console.warn(`[${type}] Missing product info for mockup`);
      setMockup(qrApiUrl);
    }
  } catch (error) {
    console.error(`[${type}] Error generating mockup:`, error);
    const fallbackUrl = generateQRCodeUrl('placeholder', 200);
    setMockup(fallbackUrl);
  }
}

export async function executeHandleProductSelect(ctx: any, product: AllowedProduct): Promise<void> {
  ctx.setSelectedProductType(product);
  if (!ctx.simpleTitle) {
    ctx.setSimpleTitle(getDefaultPacketTitle(product.title));
  }
  if (!ctx.simpleDescription) {
    ctx.setSimpleDescription(getDefaultPacketDescription(product.title));
  }
  const packetId = await executeCreatePacketForProduct(ctx, product);
  if (!packetId) {
    ctx.toast({ title: 'Packet creation failed', description: 'Could not initialize your product. Please try again.', variant: 'destructive' });
  }

  if (!product.placements || product.placements.length === 0) {
    const prov = product.fulfillmentProvider;
    if (!prov || !product.canonicalBlankKey) throw new Error('Reload the QRG member catalog.');
    const params = new URLSearchParams({ provider: prov });
    if (prov === 'printify') {
      if (product.blueprintId) params.set('blueprintId', String(product.blueprintId));
      if (product.printProviderId) params.set('printProviderId', String(product.printProviderId));
    } else {
      params.set('productId', String(product.blueprintId));
    }
    fetch(`/api/members/product-options/${encodeURIComponent(product.canonicalBlankKey)}`)
      .then(r => r.json())
      .then(data => {
        if (data.placements && data.placements.length > 0) {
          ctx.setSelectedProductType((prev: any) => prev ? { ...prev, placements: data.placements } : prev);
        }
      })
      .catch(err => console.warn('[WizardContext] Failed to fetch placements:', err));
  }
}

export async function executeHandlePublish(ctx: any): Promise<void> {
  if (!ctx.selectedProductType) {
    ctx.toast({ title: 'Select a QRG product', description: 'Choose a product from the member catalog before publishing.', variant: 'destructive' });
    return;
  }
  await executeSimplePublish(ctx);
}
