import { APPAREL_SIZE_ORDER } from '@shared/storefrontTypes';
import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  DollarSign, Percent, Layers, Type, Clock, Save, Loader2, Check, Tag,
  Truck,
} from "lucide-react";
import AdminShell from "@/components/AdminShell";
import AdminSectionSubNav from "@/components/admin/AdminSectionSubNav";
import { SELL_SUBNAV } from "@/components/admin/adminNavConfig";
import AdminSectionCard from "@/components/admin/AdminSectionCard";
import StickyActionBar from "@/components/admin/StickyActionBar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { CouponsSection } from "./admin-pricing-coupons";

import { pricingSettingsSchema, type PricingSettings } from '@shared/schema-orders';
type HostingTier = PricingSettings['hostingTiers'][number];
type BrandLabelPricing = PricingSettings['brandLabelPricing'];

export default function AdminPricing() {
  const { toast } = useToast();

  const { data: settings, isLoading, error: loadError, refetch } = useQuery<PricingSettings>({
    queryKey: ["/api/admin/pricing-settings"],
  });

  const [sizeUpcharges, setSizeUpcharges] = useState<Record<string, number>>({});
  const [markupPercent, setMarkupPercent] = useState<string>("");
  const [markupFixed, setMarkupFixed] = useState<string>("");
  const [additionalPlacementCost, setAdditionalPlacementCost] = useState<string>("");
  const [textLineUpcharge, setTextLineUpcharge] = useState<string>("");
  const [centerGraphicUpcharge, setCenterGraphicUpcharge] = useState<string>("");
  const [memberProfitShare, setMemberProfitShare] = useState<string>("");
  const [builtInShippingCost, setBuiltInShippingCost] = useState<string>("");
  const [hostingTiers, setHostingTiers] = useState<HostingTier[]>([]);
  const [brandLabelPricing, setBrandLabelPricing] = useState<BrandLabelPricing>({} as BrandLabelPricing);
  const [preferredLabelPosition, setPreferredLabelPosition] = useState<'outside' | 'inside'>('outside');
  const [initialized, setInitialized] = useState(false);
  const [markupPreview, setMarkupPreview] = useState<any>(null);
  useEffect(() => { setMarkupPreview(null); }, [markupPercent, markupFixed]);

  useEffect(() => {
    if (settings && !initialized) {
    setSizeUpcharges(settings.sizeUpcharges || {});
    setMarkupPercent(String(settings.markupPercent ?? ''));
    setMarkupFixed(String(settings.markupFixed ?? ''));
    setAdditionalPlacementCost(String(settings.additionalPlacementCost ?? ''));
    setTextLineUpcharge(String(settings.textLineUpcharge ?? ''));
    setCenterGraphicUpcharge(String(settings.centerGraphicUpcharge ?? ''));
    setMemberProfitShare(settings.memberProfitShare == null ? '' : String(settings.memberProfitShare * 100));
    setBuiltInShippingCost(String(settings.builtInShippingCost ?? ''));
    setHostingTiers(settings.hostingTiers || []);
    if (settings.brandLabelPricing) {
      setBrandLabelPricing(settings.brandLabelPricing);
    }
    if (settings.preferredLabelPosition) {
      setPreferredLabelPosition(settings.preferredLabelPosition);
    }
    setInitialized(true);
    }
  }, [settings, initialized]);

  const saveMutation = useMutation({
    mutationFn: async (data: PricingSettings) => {
      const res = await apiRequest("POST", "/api/admin/pricing-settings", data);
      return res.json();
    },
    onSuccess: () => {
      setMarkupPreview(null);
      toast({ title: "Settings Saved", description: "Pricing configuration updated successfully." });
      queryClient.invalidateQueries({ queryKey: ["/api/pricing-settings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/pricing-settings"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleSave = () => {
    const parsed = pricingSettingsSchema.safeParse({
      sizeUpcharges,
      markupPercent: parseFloat(markupPercent),
      markupFixed: parseFloat(markupFixed),
      additionalPlacementCost: parseFloat(additionalPlacementCost),
      textLineUpcharge: parseFloat(textLineUpcharge),
      centerGraphicUpcharge: parseFloat(centerGraphicUpcharge),
      memberProfitShare: parseFloat(memberProfitShare) / 100,
      builtInShippingCost: parseFloat(builtInShippingCost),
      hostingTiers,
      brandLabelPricing,
      preferredLabelPosition,
    });
    if (!parsed.success) { toast({ title: 'Check pricing fields', description: parsed.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; '), variant: 'destructive' }); return; }
    saveMutation.mutate(parsed.data);
  };

  const syncPricingMutation = useMutation({
    mutationFn: async (previewToken?: string) => {
      const res = await apiRequest("POST", "/api/admin/pricing-settings/sync", previewToken ? { previewToken } : {});
      return res.json();
    },
    onSuccess: (data) => {
      setMarkupPreview(data.dryRun ? data : null);
      if (!data.dryRun) {
        void queryClient.invalidateQueries();
        toast({ title: "Saved pricing applied", description: `Updated ${data.productsUpdated} catalog products and their linked packets.` });
      }
    },
    onError: (error: Error) => {
      setMarkupPreview(null);
      toast({ title: "Pricing was not applied", description: error.message, variant: "destructive" });
    },
  });
  const draftPricing = { sizeUpcharges, markupPercent: Number(markupPercent), markupFixed: Number(markupFixed),
    additionalPlacementCost: Number(additionalPlacementCost), textLineUpcharge: Number(textLineUpcharge),
    centerGraphicUpcharge: Number(centerGraphicUpcharge), memberProfitShare: Number(memberProfitShare) / 100,
    builtInShippingCost: Number(builtInShippingCost), hostingTiers, brandLabelPricing, preferredLabelPosition };
  const blankAmount = [markupPercent, markupFixed, additionalPlacementCost, textLineUpcharge, centerGraphicUpcharge, memberProfitShare, builtInShippingCost].some(v => !v.trim());
  const parsedSaved = pricingSettingsSchema.safeParse(settings);
  const parsedDraft = pricingSettingsSchema.safeParse(draftPricing);
  const draftKey = JSON.stringify(draftPricing);
  const unsavedMarkup = blankAmount || !parsedSaved.success || !parsedDraft.success || JSON.stringify(parsedSaved.data) !== JSON.stringify(parsedDraft.data);
  useEffect(() => { setMarkupPreview(null); }, [draftKey]);

  const updateTierPrice = (code: string, price: string) => {
    setHostingTiers(tiers =>
      tiers.map(t => t.code === code ? { ...t, price: price === '' ? NaN : Number(price) } : t)
    );
  };

  return (
    <AdminShell
      title="Pricing Configuration"
      icon={DollarSign}
      backHref="/admin/products"
      backLabel="Back to Products"
      sectionNav={<AdminSectionSubNav items={SELL_SUBNAV} />}
      actions={
        <Button
          variant="outline"
          onClick={handleSave}
          disabled={saveMutation.isPending || isLoading || !!loadError || !initialized}
          data-testid="button-save-pricing-header"
          className="qr-touch-48"
        >
          {saveMutation.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin sm:mr-2" />
          ) : (
            <Save className="h-4 w-4 sm:mr-2" />
          )}
          <span className="hidden sm:inline">
            {saveMutation.isSuccess ? "Saved" : "Save Pricing"}
          </span>
        </Button>
      }
    >
      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      )}
      {loadError && <div role="alert" className="p-4 text-destructive">Pricing could not be loaded: {loadError.message} <Button variant="outline" onClick={() => refetch()}>Retry</Button></div>}
      {!isLoading && !loadError && initialized && (
      <><div className="grid gap-4">
        <AdminSectionCard
          title="Markup Settings"
          icon={Percent}
          description="Configure how much markup is added to the base production cost"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="markup-percent">Markup Percentage (%)</Label>
              <Input
                id="markup-percent"
                type="number"
                min="0"
                max="100"
                value={markupPercent}
                onChange={(e) => setMarkupPercent(e.target.value)}
                placeholder="25"
                className="min-h-[48px] text-lg"
                inputMode="decimal"
                data-testid="input-markup-percent"
              />
              <p className="text-xs text-muted-foreground">Applied to total cost before fixed markup</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="markup-fixed">Fixed Markup ($)</Label>
              <Input
                id="markup-fixed"
                type="number"
                min="0"
                step="0.01"
                value={markupFixed}
                onChange={(e) => setMarkupFixed(e.target.value)}
                placeholder="0.00"
                className="min-h-[48px] text-lg"
                inputMode="decimal"
                data-testid="input-markup-fixed"
              />
              <p className="text-xs text-muted-foreground">Added after percentage markup</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t space-y-3">
            <Button variant="outline" className="min-h-[44px]" onClick={() => syncPricingMutation.mutate(undefined)}
              disabled={syncPricingMutation.isPending || saveMutation.isPending || unsavedMarkup}
              data-testid="button-sync-pricing">
              {syncPricingMutation.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Check className="h-4 w-4 mr-2" />}
              Preview Saved Pricing
            </Button>
            <p className="text-xs text-muted-foreground">
              {unsavedMarkup ? 'Save your pricing changes before previewing. ' : ''}
              Recalculates saved products from their QRG provider costs, print content, hosting, labels and shipping, then applies your markup. Restores missing inside brand labels with the existing label artwork and verified print area. External marketplace prices are not published by this action.
            </p>
            {markupPreview && <div data-testid="markup-preview" className="space-y-3">
              <p>Saved markup: {markupPreview.markupPercent}% + ${markupPreview.markupFixed.toFixed(2)}.
                {' '}{markupPreview.productsToUpdate} products would be updated; {markupPreview.blocked.length} need attention.</p>
              <div className="overflow-auto max-h-80">
                <table className="w-full text-sm"><thead><tr><th className="text-left">Product</th><th>Current price</th><th>Updated price</th></tr></thead>
                  <tbody>{markupPreview.products.map((p: any) => <tr key={p.id}><td>{p.title}{p.restoreInsideLabel && <span className="block text-xs text-muted-foreground">Restore inside label</span>}</td><td className="text-center">${p.currentPrice.toFixed(2)}</td><td className="text-center">${p.customerPrice.toFixed(2)}</td></tr>)}</tbody>
                </table>
              </div>
              {markupPreview.blocked.length > 0 && <div role="alert" className="text-destructive text-sm">
                <p>No prices will change until these products are repaired:</p>
                <ul>{markupPreview.blocked.map((p: any) => <li key={p.id}>{p.title}: {p.reason}</li>)}</ul>
              </div>}
              <Button onClick={() => syncPricingMutation.mutate(markupPreview.previewToken)}
                disabled={syncPricingMutation.isPending || unsavedMarkup || markupPreview.blocked.length > 0 || markupPreview.productsToUpdate === 0}
                data-testid="button-apply-markup">Apply Previewed Pricing</Button>
            </div>}
          </div>
        </AdminSectionCard>

        <AdminSectionCard
          title="Placement Costs"
          icon={Layers}
          description="Cost for additional print placements beyond the first"
        >
          <div className="space-y-2">
            <Label htmlFor="placement-cost">Additional Placement Cost ($)</Label>
            <Input
              id="placement-cost"
              type="number"
              min="0"
              step="0.01"
              value={additionalPlacementCost}
              onChange={(e) => setAdditionalPlacementCost(e.target.value)}
              placeholder="4.00"
              className="min-h-[48px] text-lg max-w-xs"
              inputMode="decimal"
              data-testid="input-placement-cost"
            />
            <p className="text-xs text-muted-foreground">
              First placement is included in base cost. Each additional placement adds this amount.
            </p>
          </div>
        </AdminSectionCard>

        <AdminSectionCard
          title="Content Upcharges"
          icon={Type}
          description="Additional cost for custom header/footer content and center graphics"
        >
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="text-upcharge">Header / Footer Upcharge ($)</Label>
              <Input
                id="text-upcharge"
                type="number"
                min="0"
                step="0.01"
                value={textLineUpcharge}
                onChange={(e) => setTextLineUpcharge(e.target.value)}
                placeholder="2.00"
                className="min-h-[48px] text-lg max-w-xs"
                inputMode="decimal"
                data-testid="input-text-upcharge"
              />
              <p className="text-xs text-muted-foreground">
                Charged per zone (header or footer) — applies to both text and uploaded images
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="center-graphic-upcharge">Center Graphic Upcharge ($)</Label>
              <Input
                id="center-graphic-upcharge"
                type="number"
                min="0"
                step="0.01"
                value={centerGraphicUpcharge}
                onChange={(e) => setCenterGraphicUpcharge(e.target.value)}
                placeholder="5.00"
                className="min-h-[48px] text-lg max-w-xs"
                inputMode="decimal"
                data-testid="input-center-graphic-upcharge"
              />
              <p className="text-xs text-muted-foreground">
                Charged when a full graphic image is uploaded to the center area (behind or replacing the QR code)
              </p>
            </div>
          </div>
        </AdminSectionCard>

        <AdminSectionCard title="Size Price Increases" icon={DollarSign} description="Added to the base product price for the selected size. Blank means this size is not configured.">
          <div className="grid grid-cols-3 gap-4">
            {APPAREL_SIZE_ORDER.map(size => (
              <div key={size} className="space-y-2">
                <Label htmlFor={`size-price-${size}`}>{size} ($)</Label>
                <Input id={`size-price-${size}`} type="number" min="0" step="0.01"
                  value={sizeUpcharges[size] ?? ''}
                  onChange={e => setSizeUpcharges(current => { const next = { ...current }; if (e.target.value === '') delete next[size]; else next[size] = Number(e.target.value); return next; })} />
              </div>
            ))}
          </div>
        </AdminSectionCard>

        <AdminSectionCard
          title="Built-In Shipping Cost"
          icon={Truck}
          description="Shipping cost baked into the product price — customers see 'Free Shipping'"
        >
          <div className="space-y-2">
            <Label htmlFor="built-in-shipping">Shipping Cost ($)</Label>
            <Input
              id="built-in-shipping"
              type="number"
              min="0"
              step="0.01"
              value={builtInShippingCost}
              onChange={(e) => setBuiltInShippingCost(e.target.value)}
              placeholder="4.95"
              className="min-h-[48px] text-lg max-w-xs"
              inputMode="decimal"
              data-testid="input-built-in-shipping"
            />
            <p className="text-xs text-muted-foreground">
              This amount is added to the base cost before markup. Customers will never see this — they see "Free Shipping" at checkout.
            </p>
          </div>
        </AdminSectionCard>

        <AdminSectionCard
          title="Brand Label Pricing"
          icon={Tag}
          description="Your brand, front and center — custom labels make every product truly yours"
        >
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-semibold mb-3">Printify Labels</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="printify-inside">Inside Label ($)</Label>
                  <Input
                    id="printify-inside"
                    type="number"
                    min="0"
                    step="0.01"
                    value={Number.isFinite(brandLabelPricing.printifyInside) ? brandLabelPricing.printifyInside : ''}
                    onChange={(e) => setBrandLabelPricing(prev => ({ ...prev, printifyInside: e.target.value === '' ? NaN : Number(e.target.value) }))}
                    placeholder="0.55"
                    className="min-h-[48px] text-lg"
                    inputMode="decimal"
                    data-testid="input-printify-inside-label"
                  />
                  <p className="text-xs text-muted-foreground">Replaces manufacturer tag inside neck</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="printify-outside">Outside Label ($)</Label>
                  <Input
                    id="printify-outside"
                    type="number"
                    min="0"
                    step="0.01"
                    value={Number.isFinite(brandLabelPricing.printifyOutside) ? brandLabelPricing.printifyOutside : ''}
                    onChange={(e) => setBrandLabelPricing(prev => ({ ...prev, printifyOutside: e.target.value === '' ? NaN : Number(e.target.value) }))}
                    placeholder="0.55"
                    className="min-h-[48px] text-lg"
                    inputMode="decimal"
                    data-testid="input-printify-outside-label"
                  />
                  <p className="text-xs text-muted-foreground">Printed on outside back of neck</p>
                </div>
              </div>
            </div>
            <div className="border-t pt-4">
              <h3 className="text-sm font-semibold mb-3">Printful Labels</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="printful-inside">Inside Label ($)</Label>
                  <Input
                    id="printful-inside"
                    type="number"
                    min="0"
                    step="0.01"
                    value={Number.isFinite(brandLabelPricing.printfulInside) ? brandLabelPricing.printfulInside : ''}
                    onChange={(e) => setBrandLabelPricing(prev => ({ ...prev, printfulInside: e.target.value === '' ? NaN : Number(e.target.value) }))}
                    placeholder="0.99"
                    className="min-h-[48px] text-lg"
                    inputMode="decimal"
                    data-testid="input-printful-inside-label"
                  />
                  <p className="text-xs text-muted-foreground">Replaces manufacturer tag inside neck</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="printful-outside">Outside Label ($)</Label>
                  <Input
                    id="printful-outside"
                    type="number"
                    min="0"
                    step="0.01"
                    value={Number.isFinite(brandLabelPricing.printfulOutside) ? brandLabelPricing.printfulOutside : ''}
                    onChange={(e) => setBrandLabelPricing(prev => ({ ...prev, printfulOutside: e.target.value === '' ? NaN : Number(e.target.value) }))}
                    placeholder="2.49"
                    className="min-h-[48px] text-lg"
                    inputMode="decimal"
                    data-testid="input-printful-outside-label"
                  />
                  <p className="text-xs text-muted-foreground">Printed on outside back of neck</p>
                </div>
              </div>
            </div>
            <div className="border-t pt-4">
              <h3 className="text-sm font-semibold mb-3">Default Tag Placement</h3>
              <div className="flex items-center gap-3 min-h-[44px]">
                <Switch
                  id="label-position"
                  checked={preferredLabelPosition === 'inside'}
                  onCheckedChange={(checked) => setPreferredLabelPosition(checked ? 'inside' : 'outside')}
                  data-testid="switch-label-position"
                />
                <Label htmlFor="label-position" className="text-sm cursor-pointer">
                  {preferredLabelPosition === 'outside'
                    ? 'Outside Neck — printed on the back of the collar (visible to others)'
                    : 'Inside Neck — replaces the manufacturer tag (hidden inside collar)'}
                </Label>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                This saved preference does not replace the required inside brand label. The inside label is always retained, its provider-specific cost is included, and its artwork travels to fulfillment. An outside label is charged only when that placement is selected in the product build.
              </p>
            </div>
            <div className="bg-muted/50 rounded-md p-3 text-xs text-muted-foreground space-y-1">
              <p>Inside labels replace the manufacturer tag inside the collar. Outside labels are printed on the back of the collar, visible to others.</p>
              <p>Label costs use the fulfillment provider saved on each product.</p>
            </div>
          </div>
        </AdminSectionCard>

        <AdminSectionCard
          title="Member Profit Share"
          icon={Percent}
          description="Percentage of profit that members earn when their products sell"
        >
          <div className="space-y-2">
            <Label htmlFor="member-profit-share">Member Share (%)</Label>
            <Input
              id="member-profit-share"
              type="number"
              min="0"
              max="100"
              step="1"
              value={memberProfitShare}
              onChange={(e) => setMemberProfitShare(e.target.value)}
              placeholder="25"
              className="min-h-[48px] text-lg max-w-xs"
              inputMode="decimal"
              data-testid="input-member-profit-share"
            />
            <p className="text-xs text-muted-foreground">
              Members earn this % of profit (price - cost) on each sale. Zero disables the share.
            </p>
          </div>
        </AdminSectionCard>

        <AdminSectionCard
          title="Hosting Tiers"
          icon={Clock}
          description="Pricing for QR landing page hosting (applies to Canvas/Play/Dynamics modes)"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {hostingTiers.map((tier) => (
              <div key={tier.code} className="space-y-2">
                <Label htmlFor={`tier-${tier.code}`}>{tier.name}</Label>
                <Input
                  id={`tier-${tier.code}`}
                  type="number"
                  min="0"
                  step="0.01"
                  value={Number.isFinite(tier.price) ? tier.price : ''}
                  onChange={(e) => updateTierPrice(tier.code, e.target.value)}
                  className="min-h-[48px] text-lg"
                  inputMode="decimal"
                  data-testid={`input-tier-${tier.code}`}
                />
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            Hosting fee is added for QR Canvas, QR Play, and QR Dynamics products
          </p>
        </AdminSectionCard>

        <CouponsSection />

        <AdminSectionCard title="Pricing Formula">
          <div className="font-mono text-sm space-y-1">
            <p>Base Cost = Production + Placements + Header/Footer + Center Graphic + Hosting + Brand Label + Shipping</p>
            <p>Customer Price = Base x (1 + {markupPercent || 0}%) + ${markupFixed || 0}</p>
            <p className="text-muted-foreground">Shipping is baked into the price — customers see "Free Shipping"</p>
          </div>
        </AdminSectionCard>


        {pricingSettingsSchema.safeParse(settings).success && (
        <AdminSectionCard
          title="Example Price Breakdown"
          icon={DollarSign}
        >
          <p className="text-sm text-muted-foreground mb-4">
            Example: $15 base product, 1 extra placement, 1 header/footer zone, 1 center graphic, 1-year hosting, inside brand label, built-in shipping
          </p>

          <div className="flex gap-2 mb-4 flex-wrap">
            <span className="text-xs font-medium text-muted-foreground">Example using:</span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300 font-medium">
              Printify inside: ${(brandLabelPricing.printifyInside?.toFixed(2) ?? 'Not set')}
            </span>
            <span className="text-xs px-2 py-0.5 rounded-md bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 font-medium">
              Printful inside: ${(brandLabelPricing.printfulInside?.toFixed(2) ?? 'Not set')}
            </span>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex justify-between gap-2 p-2 bg-muted rounded-md border">
              <span className="text-foreground">Base Product Cost:</span>
              <span className="font-bold text-foreground">$15.00</span>
            </div>
            <div className="flex justify-between gap-2 p-2 bg-muted rounded-md border">
              <span className="text-foreground">Extra Placement (1 x ${additionalPlacementCost || 0}):</span>
              <span className="font-medium text-foreground">+${parseFloat(additionalPlacementCost || "0").toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-2 p-2 bg-muted rounded-md border">
              <span className="text-foreground">Header/Footer Zone (1 x ${textLineUpcharge || 0}):</span>
              <span className="font-medium text-foreground">+${parseFloat(textLineUpcharge || "0").toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-2 p-2 bg-muted rounded-md border">
              <span className="text-foreground">Center Graphic (1 x ${centerGraphicUpcharge || 0}):</span>
              <span className="font-medium text-foreground">+${parseFloat(centerGraphicUpcharge || "0").toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-2 p-2 bg-muted rounded-md border">
              <span className="text-foreground">Hosting ({hostingTiers[0]?.name || "1 Year"}):</span>
              <span className="font-medium text-foreground">+${(hostingTiers[0]?.price ?? 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between gap-2 p-2 bg-amber-50 dark:bg-amber-950 rounded-md border border-amber-200 dark:border-amber-800">
              <span className="text-amber-900 dark:text-amber-200">Brand Label (inside):</span>
              <span className="font-medium text-amber-900 dark:text-amber-200">+${(brandLabelPricing.printifyInside?.toFixed(2) ?? 'Not set')}</span>
            </div>
            <div className="flex justify-between gap-2 p-2 bg-emerald-50 dark:bg-emerald-950 rounded-md border border-emerald-200 dark:border-emerald-800">
              <span className="text-emerald-900 dark:text-emerald-200">Built-In Shipping:</span>
              <span className="font-medium text-emerald-900 dark:text-emerald-200">+${parseFloat(builtInShippingCost || "0").toFixed(2)}</span>
            </div>

            <div className="border-t pt-2 mt-2">
              {(() => {
                const labelCost = brandLabelPricing.printifyInside;
                const shippingCost = parseFloat(builtInShippingCost || "0");
                const subtotal = 15 + parseFloat(additionalPlacementCost || "0") + parseFloat(textLineUpcharge || "0") + parseFloat(centerGraphicUpcharge || "0") + (hostingTiers[0]?.price ?? 0) + labelCost + shippingCost;
                const markupAmount = (subtotal * (parseFloat(markupPercent || "0") / 100)) + parseFloat(markupFixed || "0");
                const customerPrice = subtotal + markupAmount;
                return (
                  <>
                    <div className="flex justify-between gap-2 p-2 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800">
                      <span className="font-medium text-blue-900 dark:text-blue-200">Subtotal:</span>
                      <span className="font-bold text-blue-900 dark:text-blue-200">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between gap-2 p-2 bg-muted rounded-md border mt-2">
                      <span className="text-foreground">Your Markup ({markupPercent || 0}% + ${markupFixed || 0}):</span>
                      <span className="font-medium text-foreground">+${markupAmount.toFixed(2)}</span>
                    </div>
                    <div className="border-t-2 pt-2 mt-2">
                      <div className="flex justify-between gap-2 p-3 bg-green-100 dark:bg-green-950 rounded-md border-2 border-green-300 dark:border-green-700">
                        <span className="font-bold text-lg text-green-900 dark:text-green-300">Customer Price:</span>
                        <span className="font-bold text-lg text-green-700 dark:text-green-400">
                          ${customerPrice.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </AdminSectionCard>
        )}
      </div>

      <StickyActionBar>
        <button
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="qr-btn qr-btn--primary qr-btn--touch disabled:opacity-50"
          data-testid="button-save"
        >
          {saveMutation.isPending ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : saveMutation.isSuccess ? (
            <Check className="h-5 w-5" />
          ) : (
            <Save className="h-5 w-5" />
          )}
          Save Pricing
        </button>
      </StickyActionBar>
      </>)}
    </AdminShell>
  );
}
