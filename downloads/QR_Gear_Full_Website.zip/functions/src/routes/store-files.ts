import { catalogProductOptions, CatalogSelectionError } from '../services/catalog-sale-variants';
import { resolveSaleItem } from '../services/order-fulfillment';
import { publicProductText } from '../../../shared/descriptionLayers';
import { packetMockupSourceId, buildPacketMockupRequest } from '../../../shared/builderSnapshot';
import { buildPacketImageOrder, resolveProductImages, packetLeadColor } from "../../../shared/productImages";
import { Request, Response, NextFunction } from 'express';
  import express from 'express';
  import { admin, db, storage, docToObject, docsToArray, stripUndef, sanitizeStyleForFirestore, generateNanoId, escapeHtml, generateGiftCode, FulfillmentProvider, PrintMethod, normalizePlacement, normalizePlacements, toProviderPlacement, isEmbroideryPlacement, groupPlacementsByLocation, detectPrintMethod, QR_GEAR_BRANDED_TAG_URL, LABEL_PLACEMENTS_PRINTFUL, isValidHexColor, isColorDark, PRINTIFY_TO_INTERNAL, PRINTFUL_TO_INTERNAL, INTERNAL_TO_PRINTFUL, INTERNAL_TO_PRINTFUL_DTF } from '../core';
import { verifyAuth, requireAuth, requireAdmin, verifyMemberAuthCF, ADMIN_USER_IDS } from '../middleware';
import { printfulClient } from '../services/printful';
  import { printifyClient, getPrintifyApiKey, getPrintifyShopId, submitOrderToPrintify, checkPrintifyOrderStatus, PRINTIFY_API_BASE } from '../services/printify';
  import { generateSignedUrl, addSignedUrlsToAssets, downloadAndStoreImage } from '../services/storage-helpers';
  import { calculateAuthoritativePrice, getAuthoritativePrice, getSizeUpcharges, getCatalogInstancePrice } from '../services/pricing';
  import { generateMockupFromPrintful, processMockupResult, getPrintfulProductId, toPublicUrl, DEFAULT_BLUEPRINT_MAPPINGS } from '../services/mockup-generator';
  import type { MockupRequest, MockupResult } from '../services/mockup-generator';
  import { getPrintfulApiKey, getPrintfulApiKeyAsync, getPrintfulStoreId, PRINTFUL_API_BASE } from '../services/printful';
  import type { PrintfulMockupTask, PrintfulVariant } from '../services/printful';
  import { getResendClient, QR_GEAR_FROM_EMAIL } from '../services/email';
  import { cfGenerateCompositeImage, cfGeneratePrintifyComposite, cfUploadBufferToStorage, cfGetPreviewFontSize, cfWrapText, CF_PLACEMENT_DIMENSIONS, CF_FONT_MAP, CF_PREVIEW_CONTAINER_WIDTH, CF_PREVIEW_WIDTH, CF_PREVIEW_QR_SIZE, getCanvas, getQRCode } from '../services/composite-image';
import { isAvailableProductVariant, buildStructuredOptions, deriveCardMode, sortProductSizes, sizeUpcharge } from '../../../shared/storefrontTypes';

/**
 * Convert a productPackets.mockupsByColor nested structure into the flat frontend format.
 *
 * Stored format in Firestore:
 *   { [colorKey]: { [placementKey]: { [sizeKey]: url, lifestyle: url } } }
 *
 * Returned format for the frontend:
 *   { [colorKey]: { lifestyle?, front?, angles?: string[] } }
 *
 * Also returns an ordered `mockupImages` array built from the first (default) color:
 *   [front, lifestyle, ...other placements]
 * and the `defaultColor` key so the API can advertise which color is pre-selected.
 */
function extractPacketMockups(pkt: Record<string, any>): {
  mockupsByColor: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null;
  mockupImages: string[];
  defaultColor: string | null;
} {
  const raw = pkt.mockupsByColor;

  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { mockupsByColor: null, mockupImages: buildPacketImageOrder(pkt), defaultColor: null };
  }

  const result: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> = {};

  for (const [colorKey, placementsRaw] of Object.entries(raw)) {
    if (!placementsRaw || typeof placementsRaw !== 'object') continue;
    const placements = placementsRaw as Record<string, any>;
    const colorEntry: { lifestyle?: string; front?: string; angles: string[] } = { angles: [] };

    for (const [placementKey, sizeDataRaw] of Object.entries(placements)) {
      if (!sizeDataRaw || typeof sizeDataRaw !== 'object') continue;
      const sizeData = sizeDataRaw as Record<string, any>;

      if (sizeData.lifestyle && !colorEntry.lifestyle) {
        colorEntry.lifestyle = sizeData.lifestyle;
      }

      const mockupUrl = Object.entries(sizeData)
        .filter(([k]) => k !== 'lifestyle')
        .map(([, v]) => v as string)
        .find((v) => typeof v === 'string' && v.startsWith('http'));

      if (mockupUrl) {
        const isFront = ['front', 'front-center', 'chest', 'front_center'].includes(placementKey);
        if (isFront && !colorEntry.front) {
          colorEntry.front = mockupUrl;
        } else if (!isFront) {
          colorEntry.angles.push(mockupUrl);
        }
      }
    }

    if (colorEntry.lifestyle || colorEntry.front || colorEntry.angles.length > 0) {
      result[colorKey] = colorEntry;
    }
  }

  if (Object.keys(result).length === 0) {
    return { mockupsByColor: null, mockupImages: buildPacketImageOrder(pkt), defaultColor: null };
  }

  const savedLeadColor = packetLeadColor(pkt);
  const defaultColor = savedLeadColor && result[savedLeadColor] ? savedLeadColor : Object.keys(result)[0];
  const first = result[defaultColor];
  const mockupImages: string[] = [];
  if (first.front) mockupImages.push(first.front);
  if (first.lifestyle) mockupImages.push(first.lifestyle);
  (first.angles || []).forEach((u) => mockupImages.push(u));

  return { mockupsByColor: result, mockupImages: buildPacketImageOrder(pkt, mockupImages), defaultColor };
}

/**
 * Handle the simpler 2-level format used in the `packets` collection:
 *   { colorKey: { front?: string; lifestyle?: string; angles?: string[] } }
 *
 * `extractPacketMockups` handles the 3-level productPackets format.
 * This handles the 2-level member/wizard packet format.
 */
function tryFlatMockupsByColor(
  raw: Record<string, any>,
): Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null {
  const result: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> = {};
  for (const [colorKey, val] of Object.entries(raw)) {
    if (!val || typeof val !== 'object' || Array.isArray(val)) continue;
    if (typeof val.front === 'string' || typeof val.lifestyle === 'string') {
      result[colorKey] = {
        ...(val.lifestyle ? { lifestyle: val.lifestyle as string } : {}),
        ...(val.front ? { front: val.front as string } : {}),
        ...(Array.isArray(val.angles)
          ? { angles: (val.angles as any[]).filter((u) => typeof u === 'string') }
          : {}),
      };
    }
  }
  return Object.keys(result).length > 0 ? result : null;
}

  export function register(app: express.Express): void {
  // ============ BATCH: STORE/LIBRARY FILE ROUTES ============

app.get('/store/product/:linkId', async (req: Request, res: Response): Promise<void> => {
  try {
    const { linkId } = req.params;

    // ── Primary: admin_catalog_instances ────────────────────────────────────
    const instanceDoc = await db.collection('admin_catalog_instances').doc(linkId).get();
    if (instanceDoc.exists) {
      console.log('[Store API] Product detail: serving from admin_catalog_instances', linkId);
      const d = instanceDoc.data()!;
      const resolved = d.resolved || {};

      let price: number | null = resolved.pricing?.customerPrice ?? null;
      let packetMockupUrl: string | null = null;
      let packetMockupsByColor: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null = null;
      let packetMockupImages: string[] = [];
      let packetDefaultColor: string | null = null;
      let packetQrProductType: string | null = null;
      let packetLandingPageSnapshotUrl: string | null = null;
      let packetCompositeUrl: string | null = null;
      let packetQrOnlyUrl: string | null = null;
      let packetPlayMediaUrl: string | null = null;
      let productOptions = await catalogProductOptions(db, d, null);

      if (d.currentPacketId) {
        try {
          const pDoc = await db.collection('productPackets').doc(d.currentPacketId).get();
          if (pDoc.exists) {
            const pkt = pDoc.data()!;
            productOptions = await catalogProductOptions(db, d, pkt);
            const extracted = extractPacketMockups(pkt);
            packetMockupsByColor = extracted.mockupsByColor;
            packetMockupImages = extracted.mockupImages;
            packetDefaultColor = extracted.defaultColor;
            packetQrProductType = pkt.qrProductState?.replace(/_/g, '-') || null;
            packetMockupUrl = pkt.priorityMockupUrl || pkt.compositeUrl || pkt.landingPageSnapshotUrl || pkt.productGraphicUrl || null;
            packetLandingPageSnapshotUrl = pkt.landingPageSnapshotUrl || null;
            packetCompositeUrl = pkt.compositeUrl || pkt.productGraphicUrl || null;
            packetQrOnlyUrl = pkt.qrOnlyUrl || null;
            packetPlayMediaUrl = pkt.playMediaUrl || null;
            if (price === null && pkt.pricing?.customerPrice) price = pkt.pricing.customerPrice;
          }
        } catch (e: any) {
          console.error('[Store API] Failed to read productPacket for', d.currentPacketId, e.message);
        }
      }

      const toStrArr = (arr: any[]): string[] =>
        (arr || []).map((v: any) => (typeof v === 'string' ? v : v?.name || v?.label || String(v))).filter(Boolean);

      const allImages = resolveProductImages({
        mockups: packetMockupImages,
      });

      const bColors = productOptions.availableColors;
      const bSizes = productOptions.availableSizes;

      res.json({
        id: instanceDoc.id,
        name: publicProductText(resolved.title || 'Untitled'),
        description: publicProductText(resolved.description || ''),
        category: resolved.category || '',
        productLine: resolved.productLine || '',
        imageUrl: allImages[0] || null,
        images: allImages,
        packetImageUrl: packetMockupUrl,
        landingPageSnapshotUrl: packetLandingPageSnapshotUrl,
        compositeUrl: packetCompositeUrl,
        qrCodeUrl: packetQrOnlyUrl,
        playMediaUrl: packetPlayMediaUrl,
        qrProductType: packetQrProductType,
        price: price !== null ? Math.round(price * 100) / 100 : null,
        ...productOptions,
        sizeUpcharges: await getSizeUpcharges(),
        availableColors: bColors,
        availablePlacements: [],
        defaultColor: packetDefaultColor,
        mockupsByColor: packetMockupsByColor,
        selectedGraphicSize: null,
        storeId: d.storeId || null,
        storeName: d.storeName || null,
        channel: d.channelId || null,
        collection: d.collectionName || null,
        packetId: d.currentPacketId || null,
        qrgBaseCode: resolved.qrgBaseCode || resolved.qrgPacketCode || null,
        options: buildStructuredOptions(bColors, bSizes),
        cardMode: deriveCardMode(bColors, bSizes),
        media: { images: allImages, mockupPriority: true, heroStrategy: 'mockupFirst' },
      });
      return;
    }

    // ── Legacy fallback: storeProductLinks ──────────────────────────────────
    console.log('[Store API] Product detail: falling back to storeProductLinks for', linkId);
    const linkDoc = await db.collection('storeProductLinks').doc(linkId).get();
    if (linkDoc.exists) {
      const link = linkDoc.data()!;

      let price: number | null = null;
      let productOptions = await catalogProductOptions(db, link, null);
      let availablePlacements: string[] = [];
      let description = '';
      let category = '';
      let productLine = '';
      let packetImageUrl: string | null = null;
      let packetPlacementMockupUrls: Record<string, string> = {};
      let packetMockupsByColorA: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null = null;

      if (link.packetId) {
        const packetDoc = await db.collection('packets').doc(link.packetId).get();
        if (packetDoc.exists) {
          const packet = packetDoc.data()!;
          productOptions = await catalogProductOptions(db, link, packet);
          packetImageUrl = packet.priorityMockupUrl || packet.landingPageSnapshotUrl || packet.productGraphicUrl || null;
          if (packet.placementMockupUrls && typeof packet.placementMockupUrls === 'object') {
            packetPlacementMockupUrls = packet.placementMockupUrls as Record<string, string>;
          }
          const rawMockups = packet.mockupsByColor;
          if (rawMockups && typeof rawMockups === 'object' && !Array.isArray(rawMockups)) {
            const extracted3 = extractPacketMockups(packet);
            packetMockupsByColorA = extracted3.mockupsByColor ?? tryFlatMockupsByColor(rawMockups as Record<string, any>);
          }
          const productId = packet.productId;
          if (productId) {
            price = await getAuthoritativePrice(productId);
            const productDoc = await db.collection('products').doc(productId).get();
            if (productDoc.exists) {
              const product = productDoc.data()!;
              availablePlacements = product.availablePlacements || [];
              description = product.description || '';
              category = product.category || '';
              productLine = product.productLine || '';
            }
          }
          if (price === null && packet.pricingSnapshot?.totalPrice) {
            price = parseFloat(packet.pricingSnapshot.totalPrice);
          }
        }
      }

      if (price === null && link.pricing) {
        price = parseFloat(link.pricing.customerPrice || link.pricing.totalPrice || link.pricing.retailPrice || '0');
      }

      const lifestyleUrl: string | null = link.lifestyleMockupUrl || null;
      const flatMockupUrl: string | null = link.mockupUrl || packetImageUrl || null;

      const mergedPlacementUrls: Record<string, string> = {
        ...packetPlacementMockupUrls,
        ...(link.placementMockupUrls && typeof link.placementMockupUrls === 'object'
          ? (link.placementMockupUrls as Record<string, string>)
          : {}),
      };
      const EXTRA_PLACEMENT_ORDER = ['back', 'left_sleeve', 'right_sleeve'];

      const mockupImages: string[] = [];
      if (lifestyleUrl) mockupImages.push(lifestyleUrl);
      if (flatMockupUrl && flatMockupUrl !== lifestyleUrl) mockupImages.push(flatMockupUrl);
      EXTRA_PLACEMENT_ORDER.forEach(p => {
        const u = mergedPlacementUrls[p];
        if (u && !mockupImages.includes(u)) mockupImages.push(u);
      });
      const qrArtUrl = link.compositeUrl || link.qrOnlyUrl || null;
      if (qrArtUrl && !mockupImages.includes(qrArtUrl)) mockupImages.push(qrArtUrl);

      if (!packetMockupsByColorA) {
        const synColorKey = link.defaultColor || null;
        const synAngles = EXTRA_PLACEMENT_ORDER.map((p) => mergedPlacementUrls[p]).filter(Boolean) as string[];
        if (synColorKey && (flatMockupUrl || lifestyleUrl || synAngles.length > 0)) {
          packetMockupsByColorA = {
            [synColorKey]: {
              ...(lifestyleUrl ? { lifestyle: lifestyleUrl } : {}),
              ...(flatMockupUrl ? { front: flatMockupUrl } : {}),
              ...(synAngles.length > 0 ? { angles: synAngles } : {}),
            },
          };
        }
      }

      const allImages = resolveProductImages({ mockups: mockupImages });

      const { availableColors, availableSizes } = productOptions;
      res.json({
        id: linkDoc.id,
        name: publicProductText(link.productName || 'Untitled Product'),
        description: publicProductText(description),
        category,
        productLine,
        imageUrl: allImages[0] || null,
        images: allImages,
        packetImageUrl,
        qrCodeUrl: link.qrOnlyUrl || null,
        qrProductType: link.qrProductState || 'qr-basics',
        price: price !== null ? Math.round(price * 100) / 100 : null,
        ...productOptions,
        availableSizes: sortProductSizes(availableSizes),
        sizeUpcharges: await getSizeUpcharges(),
        availableColors,
        availablePlacements,
        defaultColor: link.defaultColor || null,
        mockupsByColor: packetMockupsByColorA,
        selectedGraphicSize: link.selectedGraphicSize || null,
        storeId: link.storeId || null,
        storeName: link.storeName || null,
        channel: link.channel || null,
        collection: link.collection || null,
        packetId: link.packetId || null,
        options: buildStructuredOptions(availableColors, availableSizes),
        cardMode: deriveCardMode(availableColors, availableSizes),
        media: { images: allImages, mockupPriority: true, heroStrategy: 'mockupFirst' },
      });
      return;
    }

    res.status(404).json({ error: "Product not found" });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

app.post('/store/product/:linkId/add-to-cart', async (req: Request, res: Response): Promise<void> => {
  try {
    const { linkId } = req.params;
    const { selectedColor, selectedSize, quantity = 1 } = req.body;

    // ── Primary: admin_catalog_instances ──────────────────────────────────
    const instanceDoc = await db.collection('admin_catalog_instances').doc(linkId).get();
    if (instanceDoc.exists) {
      const item = await resolveSaleItem({ quantity, customization: { productId: linkId, productColor: selectedColor, productSize: selectedSize } });
      const d = instanceDoc.data()!;
      const images = d.resolved?.images || [];
      const image = images[0];
      const packet = (await db.collection('productPackets').doc(item.packetId).get()).data();
      const artworkUrl = packet?.compositeUrl || packet?.landingPageSnapshotUrl || packet?.productGraphicUrl || null;
      res.json({
        productId: linkId, linkId, price: Number(item.price),
        name: publicProductText(item.productTitle),
        imageUrl: artworkUrl || (typeof image === 'string' ? image : image?.url || null),
        selectedColor: item.customization.productColor,
        selectedSize: item.customization.productSize,
        quantity: item.quantity,
        customization: item.customization,
      });
      return;
    }

    // ── Legacy fallback: storeProductLinks ────────────────────────────────
    console.warn('[Store API] add-to-cart: falling back to legacy storeProductLinks for', linkId);
    const linkDoc = await db.collection('storeProductLinks').doc(linkId).get();
    if (linkDoc.exists) {
      const link = linkDoc.data()!;

      const savedPacket = link.packetId ? (await db.collection('packets').doc(link.packetId).get()).data() : null;
      const options = await catalogProductOptions(db, link, savedPacket);
      if (!isAvailableProductVariant(options.availableVariants, selectedColor, selectedSize)) throw new CatalogSelectionError(options.optionsError || 'Choose an available QRG color and size.');
      let price: number | null = null;
      let productId: string | null = null;

      if (link.packetId) {
        const packetDoc = await db.collection('packets').doc(link.packetId).get();
        if (packetDoc.exists) {
          const packet = packetDoc.data()!;
          productId = packet.productId || null;
          if (productId) price = await getAuthoritativePrice(productId);
          if (price === null && packet.pricingSnapshot?.totalPrice) {
            price = parseFloat(packet.pricingSnapshot.totalPrice);
          }
        }
      }

      if (price === null && link.pricing) {
        price = parseFloat(link.pricing.customerPrice || link.pricing.totalPrice || link.pricing.retailPrice || '0');
      }

      if (price === null || price <= 0) {
        res.status(400).json({ error: "Price could not be determined for this product" });
        return;
      }

      res.json({
        productId: productId || linkId,
        linkId,
        price: Math.round((price + sizeUpcharge(selectedSize, await getSizeUpcharges())) * 100) / 100,
        name: publicProductText(link.productName || 'Untitled Product'),
        imageUrl: link.mockupUrl || link.compositeUrl || link.qrOnlyUrl || null,
        selectedColor: selectedColor || link.defaultColor || null,
        selectedSize: selectedSize || null,
        quantity,
        isLegacy: true,
      });
      return;
    }

    res.status(404).json({ error: "Product not found" });
  } catch (e: any) { res.status(e instanceof CatalogSelectionError ? 400 : 500).json({ error: e.message }); }
});

app.get('/store/:storeType/:storeName', async (req: Request, res: Response): Promise<void> => {
  try {
    const { storeType, storeName } = req.params;
    const segment = req.query.segment as string | undefined;
    const channel = req.query.channel as string | undefined;
    const collection = req.query.collection as string | undefined;

    if (storeType === 'channel') {
      const channelDoc = await db.collection('storeChannels').doc(storeName).get();
      if (!channelDoc.exists) {
        res.status(404).json({ error: "Channel not found" });
        return;
      }
      const channelData = channelDoc.data() || {};
      const storeId = channelData.storeId;

      let storeData: any = { id: storeId, name: storeId };
      if (storeId) {
        const storeDoc = await db.collection('stores').doc(storeId).get();
        if (storeDoc.exists) {
          storeData = { id: storeDoc.id, ...storeDoc.data() };
        }
      }

      const instancesSnap = await db.collection('admin_catalog_instances')
        .where('storeId', '==', storeId)
        .where('channelId', '==', storeName)
        .get();

      const getFirstImageUrl = (images: any[]): string | null => {
        if (!images?.length) return null;
        const img = images[0];
        if (typeof img === 'string') return img;
        return img?.url || null;
      };

      const products = await Promise.all(
        instancesSnap.docs
          .filter((doc: any) => {
            const d = doc.data();
            // Exclude soft-deleted / hidden / draft instances from the public store
            if (d.isVisible === false || d.status === 'deleted' || d.status === 'archived') return false;
            if (!segment) return true;
            return d.collectionName === segment;
          })
          .map(async (doc: any) => {
            const d = doc.data();
            const resolved = d.resolved || {};
            const pricing = resolved.pricing || null;
            let price: number | null = pricing?.customerPrice ?? null;
            // Lifestyle/person image from the Printify catalog — this is always first
            const imageUrl = getFirstImageUrl(resolved.images || []);
            // QR graphic mockup from the packet — shown as secondary image
            let packetImageUrl: string | null = null;
            let pktMockupsByColor1: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null = null;
            let pktMockupImages1: string[] = [];
            let pktDefaultColor1: string | null = null;
            let pktQrProductType1: string | null = null;
            let productOptions = await catalogProductOptions(db, d, null);

            if (d.currentPacketId) {
              try {
                const pDoc = await db.collection('productPackets').doc(d.currentPacketId).get();
                if (pDoc.exists) {
                  const pkt = pDoc.data()!;
                  productOptions = await catalogProductOptions(db, d, pkt);
                  const extracted = extractPacketMockups(pkt);
                  pktMockupsByColor1 = extracted.mockupsByColor;
                  pktMockupImages1 = extracted.mockupImages;
                  pktDefaultColor1 = extracted.defaultColor;
                  pktQrProductType1 = pkt.qrProductState?.replace(/_/g, '-') || null;
                  packetImageUrl = pkt.priorityMockupUrl || pkt.compositeUrl || pkt.landingPageSnapshotUrl || pkt.productGraphicUrl || null;
                  if (price === null && pkt.pricing?.customerPrice) price = pkt.pricing.customerPrice;
                }
              } catch (e: any) {
                console.error('[Store API] Listing1: failed to read productPacket', d.currentPacketId, e.message);
              }
            }

            const toStringArray = (arr: any[]): string[] =>
              (arr || []).map((v: any) => (typeof v === 'string' ? v : v?.name || v?.label || String(v))).filter(Boolean);
            const rawColors = d.enabledColors || resolved.colors || [];
            const rawSizes = d.enabledSizes || resolved.sizes || [];

            const allImages = resolveProductImages({
              mockups: pktMockupImages1,
            });

            const l1Colors = productOptions.availableColors;
            const l1Sizes = productOptions.availableSizes;
            return {
              id: doc.id,
              name: publicProductText(resolved.title || 'Untitled'),
              imageUrl: allImages[0] || null,
              images: allImages,
              packetImageUrl,
              segment: d.collectionName || null,
              isFeatured: false,
              isSeasonalPromo: false,
              templateVariant: null,
              qrProductType: pktQrProductType1,
              qrCodeUrl: null,
              selectedColors: l1Colors,
              ...productOptions,
              availableSizes: l1Sizes,
              defaultColor: pktDefaultColor1,
              mockupsByColor: pktMockupsByColor1,
              price: price !== null ? Math.round(price * 100) / 100 : null,
              createdAt: d.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
              options: buildStructuredOptions(l1Colors, l1Sizes),
              cardMode: deriveCardMode(l1Colors, l1Sizes),
              media: { images: allImages, mockupPriority: true, heroStrategy: 'mockupFirst' },
            };
          })
      );

      console.log(`[Public Store] Channel "${storeName}" in store "${storeId}": ${products.length} catalog instances`);
      res.json({
        storeType: storeData.roleType || 'internal',
        storeName: channelData.name || storeName,
        segment: segment || null,
        products,
      });
      return;
    }

    const snap = await db.collection('stores').where('roleType', '==', storeType).limit(10).get();
    if (snap.empty) { res.status(404).json({ error: "Store not found" }); return; }

    let matchedStore: any = null;
    for (const doc of snap.docs) {
      const data = doc.data();
      const storeSlug = (data.name || '').toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      const storeSlugCompact = storeSlug.replace(/-/g, '');
      if (doc.id === storeName || storeSlug === storeName || storeSlugCompact === storeName) {
        matchedStore = { id: doc.id, ...data };
        break;
      }
    }
    // Channel-first fallback: if store not found by name, resolve it via the channel doc
    if (!matchedStore && channel) {
      const fallbackChan = await db.collection('storeChannels').doc(channel).get();
      if (fallbackChan.exists) {
        const fcData = fallbackChan.data() || {};
        if (fcData.storeId) {
          const storeDoc = await db.collection('stores').doc(fcData.storeId).get();
          if (storeDoc.exists) matchedStore = { id: storeDoc.id, ...storeDoc.data() };
        }
      }
    }
    if (!matchedStore) { res.status(404).json({ error: "Store not found" }); return; }

    // ---- Channel-scoped query: /api/store/internal/qr-gear?channel=usa-250[&collection=monuments] ----
    if (channel) {
      const channelDoc = await db.collection('storeChannels').doc(channel).get();
      if (!channelDoc.exists || (channelDoc.data() || {}).storeId !== matchedStore.id) {
        res.status(404).json({ error: 'Channel not found in this store' });
        return;
      }
      const channelData = channelDoc.data() || {};

      const instancesSnap = await db.collection('admin_catalog_instances')
        .where('storeId', '==', matchedStore.id)
        .where('channelId', '==', channel)
        .get();

      const getFirstImgUrl = (images: any[]): string | null => {
        if (!images?.length) return null;
        const img = images[0];
        return typeof img === 'string' ? img : (img?.url || null);
      };
      const toStrArr = (arr: any[]): string[] =>
        (arr || []).map((v: any) => typeof v === 'string' ? v : v?.name || v?.label || String(v)).filter(Boolean);

      // Normalize to slug for comparison so "Armed Forces" matches URL param "armed-forces"
      const toSlug = (s: string) => s.toLowerCase().replace(/[\s_]+/g, '-');
      const collectionSlug = collection ? toSlug(collection) : null;

      const channelProducts = await Promise.all(
        instancesSnap.docs
          .filter((doc: any) => {
            const d = doc.data();
            // Exclude soft-deleted / hidden / draft instances from the public store
            if (d.isVisible === false || d.status === 'deleted' || d.status === 'archived') return false;
            if (!collection) return true;
            const name: string = d.collectionName || '';
            return name === collection || toSlug(name) === collectionSlug;
          })
          .map(async (doc: any) => {
            const d = doc.data();
            const resolved = d.resolved || {};
            let price: number | null = resolved.pricing?.customerPrice ?? null;
            const imageUrl = getFirstImgUrl(resolved.images || []);
            let packetImageUrl: string | null = null;
            let pktMockupsByColor2: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null = null;
            let pktMockupImages2: string[] = [];
            let pktDefaultColor2: string | null = null;
            let pktQrProductType2: string | null = null;
            let productOptions = await catalogProductOptions(db, d, null);

            if (d.currentPacketId) {
              try {
                const pDoc = await db.collection('productPackets').doc(d.currentPacketId).get();
                if (pDoc.exists) {
                  const pkt = pDoc.data()!;
                  productOptions = await catalogProductOptions(db, d, pkt);
                  const extracted = extractPacketMockups(pkt);
                  pktMockupsByColor2 = extracted.mockupsByColor;
                  pktMockupImages2 = extracted.mockupImages;
                  pktDefaultColor2 = extracted.defaultColor;
                  pktQrProductType2 = pkt.qrProductState?.replace(/_/g, '-') || null;
                  packetImageUrl = pkt.priorityMockupUrl || pkt.compositeUrl || pkt.landingPageSnapshotUrl || pkt.productGraphicUrl || null;
                  if (price === null && pkt.pricing?.customerPrice) price = pkt.pricing.customerPrice;
                }
              } catch (e: any) {
                console.error('[Store API] Listing2: failed to read productPacket', d.currentPacketId, e.message);
              }
            }

            const allImagesCh = resolveProductImages({
              mockups: pktMockupImages2,
            });

            const l2Colors = productOptions.availableColors;
            const l2Sizes = productOptions.availableSizes;
            return {
              id: doc.id,
              name: publicProductText(resolved.title || 'Untitled'),
              imageUrl: allImagesCh[0] || null,
              images: allImagesCh,
              packetImageUrl,
              segment: d.collectionName || null,
              isFeatured: false,
              isSeasonalPromo: false,
              templateVariant: null,
              qrProductType: pktQrProductType2,
              qrCodeUrl: null,
              selectedColors: l2Colors,
              ...productOptions,
              availableSizes: l2Sizes,
              defaultColor: pktDefaultColor2,
              mockupsByColor: pktMockupsByColor2,
              price: price !== null ? Math.round(price * 100) / 100 : null,
              createdAt: d.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
              options: buildStructuredOptions(l2Colors, l2Sizes),
              cardMode: deriveCardMode(l2Colors, l2Sizes),
              media: { images: allImagesCh, mockupPriority: true, heroStrategy: 'mockupFirst' },
            };
          })
      );

      console.log(`[Public Store] Channel "${channel}" in "${matchedStore.name}": ${channelProducts.length} instances${collection ? ` / collection: ${collection}` : ''}`);
      res.json({
        storeType: matchedStore.roleType || storeType,
        storeName: matchedStore.name || storeName,
        channelId: channel,
        channelName: channelData.name || channel,
        collection: collection || null,
        segment: null,
        products: channelProducts,
      });
      return;
    }
    // ---- End channel-scoped query ----

    const channelsSnap = await db.collection('storeChannels').where('storeId', '==', matchedStore.id).get();
    const channels = channelsSnap.docs.map((d: any) => ({ id: d.id, ...d.data() }));

    const getFirstImgUrl2 = (images: any[]): string | null => {
      if (!images?.length) return null;
      const img = images[0];
      return typeof img === 'string' ? img : (img?.url || null);
    };
    const toStrArr2 = (arr: any[]): string[] =>
      (arr || []).map((v: any) => typeof v === 'string' ? v : v?.name || v?.label || String(v)).filter(Boolean);

    const storeInstancesSnap = await db.collection('admin_catalog_instances')
      .where('storeId', '==', matchedStore.id)
      .get();

    const products = await Promise.all(
      storeInstancesSnap.docs
        .filter((doc: any) => {
          const d = doc.data();
          // Exclude soft-deleted / hidden / draft instances from the public store
          if (d.isVisible === false || d.status === 'deleted' || d.status === 'archived') return false;
          return !segment || d.collectionName === segment;
        })
        .map(async (doc: any) => {
          const d = doc.data();
          const resolved = d.resolved || {};
          let price: number | null = resolved.pricing?.customerPrice ?? null;
          const imageUrl = getFirstImgUrl2(resolved.images || []);
          let packetImageUrl: string | null = null;

          let pktMockupsByColor3: Record<string, { lifestyle?: string; front?: string; angles?: string[] }> | null = null;
          let pktMockupImages3: string[] = [];
          let pktDefaultColor3: string | null = null;
            let pktQrProductType3: string | null = null;
            let productOptions = await catalogProductOptions(db, d, null);

          if (d.currentPacketId) {
            try {
              const pDoc = await db.collection('productPackets').doc(d.currentPacketId).get();
              if (pDoc.exists) {
                const pkt = pDoc.data()!;
                  productOptions = await catalogProductOptions(db, d, pkt);
                const extracted = extractPacketMockups(pkt);
                pktMockupsByColor3 = extracted.mockupsByColor;
                pktMockupImages3 = extracted.mockupImages;
                pktDefaultColor3 = extracted.defaultColor;
                  pktQrProductType3 = pkt.qrProductState?.replace(/_/g, '-') || null;
                packetImageUrl = pkt.priorityMockupUrl || pkt.compositeUrl || pkt.landingPageSnapshotUrl || pkt.productGraphicUrl || null;
                if (price === null && pkt.pricing?.customerPrice) price = pkt.pricing.customerPrice;
              }
            } catch (e: any) {
              console.error('[Store API] Listing3: failed to read productPacket', d.currentPacketId, e.message);
            }
          }

          const allImagesSt = resolveProductImages({
            mockups: pktMockupImages3,
          });

          const l3Colors = productOptions.availableColors;
          const l3Sizes = productOptions.availableSizes;
          return {
            id: doc.id,
            name: publicProductText(resolved.title || 'Untitled'),
            imageUrl: allImagesSt[0] || null,
            images: allImagesSt,
            packetImageUrl,
            segment: d.collectionName || null,
            isFeatured: false,
            isSeasonalPromo: false,
            templateVariant: null,
            qrProductType: pktQrProductType3,
            qrCodeUrl: null,
            selectedColors: l3Colors,
            ...productOptions,
            availableSizes: l3Sizes,
            defaultColor: pktDefaultColor3,
            mockupsByColor: pktMockupsByColor3,
            price: price !== null ? Math.round(price * 100) / 100 : null,
            createdAt: d.createdAt?.toDate?.()?.toISOString() || new Date().toISOString(),
            options: buildStructuredOptions(l3Colors, l3Sizes),
            cardMode: deriveCardMode(l3Colors, l3Sizes),
            media: { images: allImagesSt, mockupPriority: true, heroStrategy: 'mockupFirst' },
          };
        })
    );

    console.log(`[Public Store] Store "${matchedStore.name}" (${storeType}): ${products.length} catalog instances, ${channels.length} channels`);
    res.json({
      storeType,
      storeName: matchedStore.name,
      segment: segment || null,
      channels,
      products,
    });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});

// ============ BATCH: FILE SERVING ROUTES ============

app.get('/library-files/:file', async (req: Request, res: Response): Promise<void> => {
  try {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const fileName = String(req.params.file || '').trim();
    if (!fileName) { res.status(400).json({ error: 'Missing filename' }); return; }
    const bucket = admin.storage().bucket();
    const roots = ['library/backgrounds/raw', 'library/backgrounds/cropped', 'library/backgrounds/raw/zip', 'library/backgrounds/zip', 'library/templates', 'library/designs', 'custom-designs', 'library/images'];
    for (const root of roots) {
      const file = bucket.file(`${root}/${fileName}`);
      const [exists] = await file.exists();
      if (exists) {
        const [metadata] = await file.getMetadata();
        res.set('Content-Type', metadata.contentType || 'application/octet-stream');
        res.set('Cache-Control', 'public, max-age=3600');
        const stream = file.createReadStream();
        stream.pipe(res);
        return;
      }
    }
    const imgSnap = await admin.firestore().collection('admin_images').where('isActive', '==', true).get();
    for (const doc of imgSnap.docs) {
      const sUrl = doc.data().storageUrl || '';
      if (sUrl && sUrl.split('/').pop() === fileName) {
        const file = bucket.file(sUrl);
        const [exists] = await file.exists();
        if (exists) {
          const [metadata] = await file.getMetadata();
          res.set('Content-Type', metadata.contentType || 'application/octet-stream');
          res.set('Cache-Control', 'public, max-age=3600');
          file.createReadStream().pipe(res);
          return;
        }
      }
    }
    res.status(404).json({ error: 'File not found' });
  } catch (e: any) { if (!res.headersSent) res.status(500).json({ error: e.message }); }
});

app.get('/files/:file', async (req: Request, res: Response): Promise<void> => {
  try {
    const fileName = String(req.params.file || '').trim();
    if (!fileName) { res.status(400).json({ error: 'Missing filename' }); return; }
    const bucket = admin.storage().bucket();
    const file = bucket.file(`custom-designs/${fileName}`);
    const [exists] = await file.exists();
    if (!exists) { res.status(404).json({ error: 'File not found' }); return; }
    const [metadata] = await file.getMetadata();
    res.set('Content-Type', metadata.contentType || 'application/octet-stream');
    res.set('Cache-Control', 'public, max-age=31536000');
    file.createReadStream().pipe(res);
  } catch (e: any) { if (!res.headersSent) res.status(500).json({ error: e.message }); }
});

app.get('/media-files/:filename', async (req: Request, res: Response): Promise<void> => {
  try {
    const fileName = req.params.filename;
    const bucket = admin.storage().bucket();
    const file = bucket.file(`uploads/${fileName}`);
    const [exists] = await file.exists();
    if (!exists) { res.status(404).json({ error: 'Media file not found' }); return; }
    const [metadata] = await file.getMetadata();
    res.set('Content-Type', metadata.contentType || 'application/octet-stream');
    res.set('Cache-Control', 'public, max-age=31536000');
    file.createReadStream().pipe(res);
  } catch (e: any) { if (!res.headersSent) res.status(500).json({ error: e.message }); }
});

// ── POST /store/product/:linkId/mockup-for-color ────────────────────────────
// Public endpoint. Checks packet mockupsByColor cache first. On miss, generates
// via Printful and writes back to the packet so the next hit is instant.
app.post('/store/product/:linkId/mockup-for-color', async (req: Request, res: Response): Promise<void> => {
  try {
    const { linkId } = req.params;
    const { colorName } = req.body;

    if (typeof colorName !== 'string' || !colorName.trim()) { res.status(400).json({ error: 'colorName is required' }); return; }

    // Normalize helper — matches buildProductGallery's normalizeColorName
    const norm = (s: string) =>
      s.replace(/^Solid\s+/i, '').toLowerCase().trim().replace(/\s+/g, '-');
    const targetNorm = norm(colorName);

    // ── Load packet from admin_catalog_instances ──────────────────────────
    let packetId: string | null = null;
    let packetData: Record<string, any> | null = null;
    let instanceData: Record<string, any> | null = null;

    const instanceDoc = await db.collection('admin_catalog_instances').doc(linkId).get();
    if (instanceDoc.exists) {
      instanceData = instanceDoc.data()!;
      packetId = instanceData.currentPacketId || null;
      if (packetId) {
        const pDoc = await db.collection('productPackets').doc(packetId).get();
        if (pDoc.exists) packetData = pDoc.data()!;
      }
    }

    // ── Cache check — 3-level format (colorKey → placement → size → url) ──
    if (packetData?.mockupsByColor && typeof packetData.mockupsByColor === 'object') {
      const raw = packetData.mockupsByColor as Record<string, any>;
      for (const [colorKey, placementsRaw] of Object.entries(raw)) {
        if (norm(colorKey) !== targetNorm) continue;
        // Dig into placements → sizes for a URL
        if (placementsRaw && typeof placementsRaw === 'object') {
          let frontUrl: string | null = null;
          let lifestyleUrl: string | null = null;
          for (const [, sizeDataRaw] of Object.entries(placementsRaw as Record<string, any>)) {
            if (!sizeDataRaw || typeof sizeDataRaw !== 'object') continue;
            const sizeData = sizeDataRaw as Record<string, any>;
            if (sizeData.lifestyle && !lifestyleUrl) lifestyleUrl = sizeData.lifestyle;
            const hit = Object.entries(sizeData)
              .filter(([k]) => k !== 'lifestyle')
              .map(([, v]) => v as string)
              .find((v) => typeof v === 'string' && v.startsWith('http'));
            if (hit && !frontUrl) frontUrl = hit;
          }
          if (frontUrl || lifestyleUrl) {
            res.json({ success: true, fromCache: true, colorName, mockupUrl: frontUrl, lifestyleMockupUrl: lifestyleUrl });
            return;
          }
        }
        // Flat 2-level format fallback
        if ((placementsRaw as any)?.front || (placementsRaw as any)?.lifestyle) {
          const flat = placementsRaw as any;
          res.json({ success: true, fromCache: true, colorName, mockupUrl: flat.front || null, lifestyleMockupUrl: flat.lifestyle || null });
          return;
        }
      }
    }

    // ── Cache miss — generate ─────────────────────────────────────────────
    if (!packetData) {
      res.json({ success: false, error: 'No packet data for this product', colorName });
      return;
    }

    const enabledColors = (instanceData?.enabledColors || instanceData?.resolved?.colors || [])
      .map((value: any) => typeof value === 'string' ? value : value?.name || value?.label);
    if (!enabledColors.includes(colorName)) {
      res.status(400).json({ success: false, error: 'Color is not enabled for this product', colorName });
      return;
    }
    const sourceMasterId = packetMockupSourceId(packetData);
    const masterDoc = await db.collection('master_catalog').doc(sourceMasterId).get();
    if (!masterDoc.exists) throw new Error('QRG blank not found');
    const request = buildPacketMockupRequest(packetData, masterDoc.data()!, 'front', colorName);
    const result = await generateMockupFromPrintful(request);
    if (!result.mockupUrl) throw new Error('Printful returned no color mockup');

    // ── Save back to packet (3-level format) ──────────────────────────────
    if (result.mockupUrl && packetId) {
      try {
        const colorKey = norm(colorName);
        const update: Record<string, any> = {
          [`mockupsByColor.${colorKey}.front.medium`]: result.mockupUrl,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        };
        if (result.lifestyleMockupUrl) {
          update[`mockupsByColor.${colorKey}.front.lifestyle`] = result.lifestyleMockupUrl;
        }
        await db.collection('productPackets').doc(packetId).update(update);
        console.log(`[StoreColorMockup] Saved ${colorName} mockup to packet ${packetId}`);
      } catch (saveErr: any) {
        console.warn(`[StoreColorMockup] Save failed: ${saveErr.message}`);
      }
    }

    res.json({
      success: true,
      fromCache: false,
      colorName,
      mockupUrl: result.mockupUrl || null,
      lifestyleMockupUrl: result.lifestyleMockupUrl || null,
    });
  } catch (e: any) {
    console.error('[StoreColorMockup] Error:', e.message);
    res.status(502).json({ success: false, error: e.message, colorName: req.body?.colorName });
  }
});


  }
  // build-marker: catalogFirst-gallery-fix
