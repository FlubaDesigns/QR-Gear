import { listCatalogInstances } from "../services/catalog-list";
import { updateCatalogInstance } from '../services/catalog-instance-update';
import { buildPacketImageOrder } from "../../../shared/productImages";
/**
 * Admin Catalog Instances — Production Routes
 *
 * Architecture:
 *   provider sync → master_catalog (canonical, read-only from here)
 *   master_catalog → admin_catalog_instances (admin-editable derived copy)
 *   instances → productPackets / templates / graphics (attached artifacts, not the product)
 *
 * NON-NEGOTIABLE:
 * - Master catalog is NEVER mutated here
 * - Admin instances are NEVER mutated by member routes
 * - resolveInstance() is the only place that computes resolved state
 * - Every packet carries full lineage back to master
 */

import express from 'express';
import { db, admin, stripUndef } from '../core';
import { requireAdmin } from '../middleware';
import { resolveInstance, mergeImagesByUrl } from '../services/instance-resolver';
import { allocateQrgInstance } from '../services/qrg-instance-allocator';

const ADMIN_INSTANCES  = 'admin_catalog_instances';
const MASTER_CATALOG   = 'master_catalog';
const PACKETS          = 'productPackets';

function toSerializable(doc: FirebaseFirestore.DocumentSnapshot): Record<string, any> {
  const data = doc.data() as any;
  return {
    id: doc.id,
    ...data,
    createdAt: data.createdAt?.toDate?.() ?? null,
    updatedAt: data.updatedAt?.toDate?.() ?? null,
    assignedAt: data.assignedAt?.toDate?.() ?? null,
  };
}

export function register(app: express.Express): void {

  // ── GET /admin/catalog-instances ────────────────────────────────────────────
  // Filters by storeId in Firestore (indexed), then applies channelId /
  // collectionName in memory so legacy instances (committed before folder-path
  // CF update, channelId=null) still surface instead of silently disappearing.
  app.get('/admin/catalog-instances', requireAdmin, async (req: any, res: any) => {
    try { res.json(await listCatalogInstances(db, req.query)); }
    catch (error: any) { res.status(500).json({ error: error.message }); }
  });

  // ── GET /admin/catalog-instances/by-packet/:packetId ────────────────────────
  // Look up the single instance whose currentPacketId matches, plus the store's
  // roleType so the frontend can auto-select Role → Store → Channel.
  app.get('/admin/catalog-instances/by-packet/:packetId', requireAdmin, async (req: any, res: any): Promise<void> => {
    try {
      const { packetId } = req.params;
      const snap = await db.collection(ADMIN_INSTANCES)
        .where('currentPacketId', '==', packetId)
        .limit(1).get();

      if (snap.empty) {
        res.status(404).json({ error: `No instance found for packetId ${packetId}` });
        return;
      }

      const instance = toSerializable(snap.docs[0]);

      // Fetch the store doc to get roleType
      let storeRoleType: string | null = null;
      if (instance.storeId) {
        const storeDoc = await db.collection('stores').doc(instance.storeId).get();
        if (storeDoc.exists) {
          storeRoleType = (storeDoc.data() as any)?.roleType ?? null;
        }
      }

      res.json({ success: true, instance, storeRoleType });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // ── GET /admin/catalog-instances/:id ────────────────────────────────────────
  app.get('/admin/catalog-instances/:id', requireAdmin, async (req: any, res: any): Promise<void> => {
    try {
      const doc = await db.collection(ADMIN_INSTANCES).doc(req.params.id).get();
      if (!doc.exists) { res.status(404).json({ error: 'Instance not found' }); return; }
      res.json({ success: true, instance: toSerializable(doc) });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // ── POST /admin/catalog-instances/from-master ────────────────────────────────
  // Clone a master catalog item into a new admin instance.
  // Master doc is NEVER touched.
  app.post('/admin/catalog-instances/from-master', requireAdmin, async (req: any, res: any): Promise<void> => {
    try {
      const { sourceMasterId, catalogId } = req.body;
      if (!sourceMasterId) { res.status(400).json({ error: 'sourceMasterId is required' }); return; }
      if (!catalogId)      { res.status(400).json({ error: 'catalogId is required' }); return; }

      const masterDoc = await db.collection(MASTER_CATALOG).doc(sourceMasterId).get();
      if (!masterDoc.exists) {
        res.status(404).json({ error: `Master catalog item not found: ${sourceMasterId}` });
        return;
      }
      const master = masterDoc.data() as any;
      const now = admin.firestore.FieldValue.serverTimestamp();

      // Normalize images into ImageRecord[] at creation time
      const normalizedImages = mergeImagesByUrl(master.images ?? [], []);

      // Normalize master colors to strings — master_catalog stores {name, hex} objects
      const normalizedColors = (master.colors ?? [])
        .map((c: any) => (typeof c === 'string' ? c : (c?.name ?? c?.hex ?? '')))
        .filter(Boolean) as string[];

      // Preserve name→hex mapping so the UI can render accurate color swatches
      const colorMap: Record<string, string> = {};
      for (const c of (master.colors ?? [])) {
        if (typeof c === 'object' && c?.name && c?.hex) colorMap[c.name] = c.hex;
      }

      const baseSnapshot = {
        title:               master.title              ?? '',
        description:         master.description        ?? null,
        images:              normalizedImages,
        brand:               master.brand              ?? null,
        colors:              normalizedColors,
        sizes:               master.sizes              ?? [],
        category:            master.category           ?? null,
        originCountry:       master.originCountry      ?? null,
        minPrice:            master.minPrice           ?? null,
        maxPrice:            master.maxPrice           ?? null,
        printifyBlueprintId: master.printifyBlueprintId ?? null,
        printfulProductId:   master.printfulProductId  ?? null,
      };

      const overrides = {};
      const resolved  = resolveInstance(baseSnapshot, overrides);

      // ── Allocate QRG identity (context = 'I' for Internal/admin instance) ──
      const rawBlankId: string | null = master.qrgBlankId || null;
      if (!rawBlankId || !/^[1-6][1-9][0-9]{3}$/.test(rawBlankId)) {
        res.status(400).json({ error: `Master ${sourceMasterId} has no valid qrgBlankId — cannot create instance without QRG identity` });
        return;
      }

      const qrgIdentity = await allocateQrgInstance({ qrgBlankId: rawBlankId, context: 'I' });

      const instanceData = {
        instanceType:        'admin' as const,
        sourceMasterId,
        catalogId,
        ownerAdminId:        req.user?.uid ?? null,
        assignedAt:          now,
        baseSnapshot,
        overrides,
        resolved,
        colorMap:            Object.keys(colorMap).length > 0 ? colorMap : null,
        // QRG identity — canonical schema: QRG-[STNNN]-[C]-[NNNNNN]
        qrgBlankId:          qrgIdentity.qrgBlankId,
        qrgContext:          qrgIdentity.qrgContext,
        instanceNumber:      qrgIdentity.instanceNumber,
        qrgBaseCode:         qrgIdentity.qrgBaseCode,
        variantCode:         qrgIdentity.variantCode,
        qrgFullCode:         qrgIdentity.qrgFullCode,
        currentPacketId:     null,
        currentTemplateId:   null,
        currentGraphicSetId: null,
        status:              'draft' as const,
        version:             1,
        createdAt:           now,
        updatedAt:           now,
        createdBy:           req.user?.uid ?? 'system',
        updatedBy:           req.user?.uid ?? 'system',
      };

      const ref = await db.collection(ADMIN_INSTANCES).add(instanceData);
      console.log(`[AdminInstances] Created ${ref.id} (${qrgIdentity.qrgBaseCode}) from master ${sourceMasterId}`);
      res.json({ success: true, instanceId: ref.id, sourceMasterId, qrgBaseCode: qrgIdentity.qrgBaseCode });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // ── PATCH /admin/catalog-instances/:id ──────────────────────────────────────
  // Save admin overrides. resolveInstance is recomputed. Master is NEVER touched.
  // Also accepts top-level listing controls: enabledColors, enabledSizes,
  // customerPrice, and folderUpdate (for moving an instance to a different folder).
  app.patch('/admin/catalog-instances/:id', requireAdmin, async (req: any, res: any) => {
    try { res.json(await updateCatalogInstance(db, req.params.id, req.body, admin.firestore.FieldValue.serverTimestamp(), req.user?.uid || 'system')); }
    catch (error: any) { res.status(400).json({ error: error.message }); }
  });

  // ── DELETE /admin/catalog-instances/:id ─────────────────────────────────────
  // Soft-deletes so the public store immediately hides the item without losing data.

  // ── POST /admin/catalog-instances/:id/requeue-mockups ───────────────────────
  // Re-queue mockup generation for an existing instance's packet.
  // Use this to fix instances that were created before the mockupsByColor
  // write-back fix, or when colors are added/changed on an existing instance.
  app.post('/admin/catalog-instances/:id/requeue-mockups', requireAdmin, async (req: any, res: any): Promise<void> => {
    try {
      const { id } = req.params;
      const { colors: requestedColors } = req.body; // optional: specific colors to re-queue

      const instanceDoc = await db.collection(ADMIN_INSTANCES).doc(id).get();
      if (!instanceDoc.exists) { res.status(404).json({ error: 'Instance not found' }); return; }

      const instance = instanceDoc.data() as any;
      if (!instance.currentPacketId) {
        res.status(400).json({ error: 'Instance has no linked packet. Generate and save the product in the builder first.' });
        return;
      }

      const packetDoc = await db.collection(PACKETS).doc(instance.currentPacketId).get();
      if (!packetDoc.exists) { res.status(404).json({ error: 'Packet not found' }); return; }

      const packet = packetDoc.data() as any;
      const artworkUrl: string | null = packet.artworkUrl || packet.compositeUrl || packet.productGraphicUrl || null;
      if (!artworkUrl) {
        res.status(400).json({ error: 'Packet has no artworkUrl. Upload artwork to the packet before generating mockups.' });
        return;
      }

      const blueprintId: number | null = packet.blueprintId || instance.baseSnapshot?.printifyBlueprintId || null;
      if (!blueprintId) {
        res.status(400).json({ error: 'Packet has no blueprintId. Link a blueprint before generating mockups.' });
        return;
      }

      const printProviderId: number = packet.printProviderId || 39;
      const fulfillmentProvider: string = packet.fulfillmentProvider || 'printify';

      // Resolve color list: caller override → packet colors → instance enabledColors → resolved colors
      const rawColors: any[] = packet.colors || packet.enabledColors || instance.enabledColors || instance.resolved?.colors || [];
      const allColors: Array<{ name: string; hex: string }> = rawColors.map((c: any) =>
        typeof c === 'string' ? { name: c, hex: '#000000' } : { name: c.name || c.label || String(c), hex: c.hex || c.color || '#000000' }
      ).filter((c: any) => c.name);

      const colorsToQueue = requestedColors?.length
        ? allColors.filter(c => requestedColors.includes(c.name))
        : allColors;

      if (colorsToQueue.length === 0) {
        res.status(400).json({ error: 'No colors found to generate mockups for.' });
        return;
      }

      const productIdForMockups = `packet_${instance.currentPacketId}`;
      const placements = ['front'];
      const qrSizes = ['small', 'medium', 'large'];
      const now = admin.firestore.FieldValue.serverTimestamp();
      const batch = db.batch();
      let jobsQueued = 0;

      for (const color of colorsToQueue) {
        for (const placement of placements) {
          for (const qrSize of qrSizes) {
            const jobRef = db.collection('mockup_jobs').doc();
            batch.set(jobRef, {
              productId: productIdForMockups,
              colorName: color.name,
              colorHex: color.hex,
              qrSize,
              placement,
              jobData: {
                blueprintId,
                printProviderId,
                artworkUrl,
                artworkVariant: 'black',
                fulfillmentProvider,
              },
              status: 'pending',
              priority: jobsQueued,
              attempts: 0,
              maxAttempts: 5,
              createdAt: now,
              updatedAt: now,
            });
            jobsQueued++;
          }
        }
      }
      await batch.commit();
      console.log(`[AdminInstances] Queued ${jobsQueued} mockup jobs for instance ${id} / packet ${instance.currentPacketId}`);

      res.json({
        success: true,
        instanceId: id,
        packetId: instance.currentPacketId,
        jobsQueued,
        colors: colorsToQueue.map(c => c.name),
        message: `Queued ${jobsQueued} mockup jobs for ${colorsToQueue.length} color(s). Jobs will process in the background.`,
      });
    } catch (e: any) { res.status(500).json({ error: e.message }); }
  });

  // ── POST /admin/catalog-instances/backfill-all-images ───────────────────────
  // Must be registered BEFORE /:id routes so Express doesn't treat "backfill-all-images" as an id.
  // Iterates every admin_catalog_instance that has a currentPacketId, reads the linked
  // packet, and rebuilds resolved.images in canonical order. Idempotent — safe to run repeatedly.
  app.post('/admin/catalog-instances/backfill-all-images', requireAdmin, async (req: any, res: any): Promise<void> => {
    try {
      const snap = await db.collection(ADMIN_INSTANCES)
        .where('currentPacketId', '!=', null)
        .limit(300)
        .get();

      let updated = 0;
      let skipped = 0;
      const errors: string[] = [];

      for (const doc of snap.docs) {
        try {
          const instance = doc.data() as any;
          const packetId = instance.currentPacketId;
          if (!packetId) { skipped++; continue; }

          const packetDoc = await db.collection(PACKETS).doc(packetId).get();
          if (!packetDoc.exists) { skipped++; continue; }

          const pkt = packetDoc.data() as any;
          const images = buildPacketImageOrder(pkt);
          if (images.length === 0) { skipped++; continue; }

          const qrgBaseCode: string | null = pkt.qrgBaseCode || pkt.qrgPacketCode || null;
          const update: Record<string, any> = {
            'resolved.images': images,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          };
          if (qrgBaseCode) update['resolved.qrgBaseCode'] = qrgBaseCode;

          await doc.ref.update(update);
          updated++;
        } catch (e: any) {
          errors.push(`${doc.id}: ${e.message}`);
        }
      }

      console.log(`[AdminInstances] backfill-all-images: updated=${updated} skipped=${skipped} errors=${errors.length}`);
      res.json({ success: true, total: snap.size, updated, skipped, ...(errors.length ? { errors } : {}) });
    } catch (e: any) {
      console.error('[AdminInstances] backfill-all-images error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });

  // ── POST /admin/catalog-instances/:id/rebuild-images ────────────────────────
  // Reads the linked packet and rebuilds resolved.images in canonical order:
  //   generated product images → artwork/proof (no catalog-photo fallback)
  // Also syncs resolved.qrgId from the packet. Safe to call any time after a packet
  // is created; the storefront gallery will reflect the update immediately.
  app.post('/admin/catalog-instances/:id/rebuild-images', requireAdmin, async (req: any, res: any): Promise<void> => {
    try {
      const { id } = req.params;

      const instanceDoc = await db.collection(ADMIN_INSTANCES).doc(id).get();
      if (!instanceDoc.exists) { res.status(404).json({ error: 'Instance not found' }); return; }

      const instance = instanceDoc.data() as any;
      if (!instance.currentPacketId) {
        res.status(400).json({ error: 'Instance has no linked packet' });
        return;
      }

      const packetDoc = await db.collection(PACKETS).doc(instance.currentPacketId).get();
      if (!packetDoc.exists) { res.status(404).json({ error: 'Packet not found' }); return; }

      const pkt = packetDoc.data() as any;
      const images = buildPacketImageOrder(pkt);
      const qrgBaseCode: string | null = pkt.qrgBaseCode || pkt.qrgPacketCode || null;

      const update: Record<string, any> = {
        'resolved.images': images,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      };
      if (qrgBaseCode) update['resolved.qrgBaseCode'] = qrgBaseCode;

      await db.collection(ADMIN_INSTANCES).doc(id).update(update);

      console.log(`[AdminInstances] rebuild-images: instance=${id} imageCount=${images.length}`);
      res.json({ success: true, instanceId: id, imageCount: images.length, qrgBaseCode });
    } catch (e: any) {
      console.error('[AdminInstances] rebuild-images error:', e.message);
      res.status(500).json({ error: e.message });
    }
  });
}
