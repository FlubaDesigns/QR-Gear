import { advanceCatalogSync, catalogSyncProgress, catalogFieldsChanged } from '../services/catalog-sync';
import { syncMasterCatalog } from '../services/master-catalog';
import { Request, Response, NextFunction } from 'express';
  import express from 'express';
  import { admin, db, storage, docToObject, docsToArray, stripUndef, sanitizeStyleForFirestore, generateNanoId, escapeHtml, generateGiftCode, FulfillmentProvider, PrintMethod, normalizePlacement, normalizePlacements, toProviderPlacement, isEmbroideryPlacement, groupPlacementsByLocation, detectPrintMethod, QR_GEAR_BRANDED_TAG_URL, LABEL_PLACEMENTS_PRINTFUL, isValidHexColor, isColorDark, PRINTIFY_TO_INTERNAL, PRINTFUL_TO_INTERNAL, INTERNAL_TO_PRINTFUL, INTERNAL_TO_PRINTFUL_DTF, normalizePrintfulCategory } from '../core';
import { STORE_PRODUCT_LINKS_COLLECTION } from '../constants';
import { verifyAuth, requireAuth, requireAdmin, verifyMemberAuthCF, ADMIN_USER_IDS } from '../middleware';
import { printfulClient } from '../services/printful';
  import { printifyClient, getPrintifyApiKey, getPrintifyShopId, submitOrderToPrintify, checkPrintifyOrderStatus, PRINTIFY_API_BASE } from '../services/printify';
  import { generateSignedUrl, addSignedUrlsToAssets, downloadAndStoreImage } from '../services/storage-helpers';
  import { calculateAuthoritativePrice, getAuthoritativePrice } from '../services/pricing';
  import { generateMockupFromPrintful, processMockupResult, getPrintfulProductId, toPublicUrl, DEFAULT_BLUEPRINT_MAPPINGS } from '../services/mockup-generator';
  import type { MockupRequest, MockupResult } from '../services/mockup-generator';
  import { getPrintfulApiKey, getPrintfulApiKeyAsync, getPrintfulStoreId, PRINTFUL_API_BASE } from '../services/printful';
  import type { PrintfulMockupTask, PrintfulVariant } from '../services/printful';
  import { getResendClient, QR_GEAR_FROM_EMAIL } from '../services/email';
  import { cfGenerateCompositeImage, cfGeneratePrintifyComposite, cfUploadBufferToStorage, cfGetPreviewFontSize, cfWrapText, CF_PLACEMENT_DIMENSIONS, CF_FONT_MAP, CF_PREVIEW_CONTAINER_WIDTH, CF_PREVIEW_WIDTH, CF_PREVIEW_QR_SIZE, getCanvas, getQRCode } from '../services/composite-image';


import { registerPpCatalogBrowseRoutes } from './pp-catalog-browse';

/** Normalize both current summaries and historical Printify errorMessage summaries. */
function serializeSync(id: string, data: any): any {
  let summary = data.summary ?? (data.status === 'completed' ? data.errorMessage : null);
  if (typeof summary === 'string') {
    try { summary = JSON.parse(summary); }
    catch { console.warn('[Catalog Sync] Invalid saved summary for', id); summary = null; }
  }
  const iso = (value: any) => value?.toDate?.()?.toISOString() ?? (typeof value === 'string' ? value : null);
  const startedAt = iso(data.startedAt);
  if (data.protocol === 'request-v1') return catalogSyncProgress(id, data);
  const expired = data.status === 'running' && startedAt && Date.now() - Date.parse(startedAt) >= 30 * 60 * 1000;
  return { ...data, status: expired ? 'failed' : data.status, id, syncId: id, summary: summary ?? null,
    errorMessage: expired ? 'The last supplier sync did not record completion within 30 minutes. Run Smart Sync to retry.' : data.status === 'failed' ? data.errorMessage : null,
    startedAt, completedAt: iso(data.completedAt) };
}

  export function register(app: express.Express): void {
  registerPpCatalogBrowseRoutes(app);
// ============ PRODUCTS PAGE: STORE-PRODUCT-LINKS CRUD ============

app.get('/admin/store-product-links', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const linksSnapshot = await db.collection(STORE_PRODUCT_LINKS_COLLECTION).orderBy("createdAt", "desc").limit(100).get();
    const links = linksSnapshot.docs.map(doc => ({
      id: doc.id, ...doc.data(),
      createdAt: doc.data().createdAt?.toDate?.()?.toISOString() || null,
      updatedAt: doc.data().updatedAt?.toDate?.()?.toISOString() || null,
    }));
    console.log(`[Store Links] Listed ${links.length} total links`);
    res.json({ success: true, links, count: links.length });
  } catch (error: any) {
    console.error("[Store Links] Error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/admin/store-product-links', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      storeId, storeName, channel, collection, packetId, templateId, graphicsId,
      qrContent, productName, compositeUrl, qrOnlyUrl, pricing,
      enabledColors, enabledSizes, selectedGraphicSize, defaultColor,
      qrProductState, landingPageUrl, mockupUrl, assemblyId: bodyAssemblyId
    } = req.body;
    if (!storeId || !channel) { res.status(400).json({ error: "storeId and channel are required" }); return; }
    if (!packetId && !templateId && !graphicsId) { res.status(400).json({ error: "At least one of packetId, templateId, or graphicsId is required" }); return; }

    // ── Assembly guard: packet must be linked to an assembly before store assignment ──
    let resolvedAssemblyId: string | null = bodyAssemblyId || null;
    if (packetId) {
      const packetDoc = await db.collection('productPackets').doc(packetId).get();
      if (!packetDoc.exists) { res.status(404).json({ error: `Packet ${packetId} not found` }); return; }
      const packetData = packetDoc.data() as any;
      resolvedAssemblyId = packetData.assemblyId || bodyAssemblyId || null;
      if (!resolvedAssemblyId) {
        res.status(400).json({ error: "Cannot assign to store — packet is missing an assembly. Complete the QRG → BLD → GRF chain in the Library first." });
        return;
      }
    }
    // ── end assembly guard ────────────────────────────────────────────────────────────

    const now = admin.firestore.FieldValue.serverTimestamp();
    const linkData: Record<string, any> = {
      storeId, storeName: storeName || "", channel, collection: collection || null,
      packetId: packetId || null, templateId: templateId || null, graphicsId: graphicsId || null,
      qrContent: qrContent || null, productName: productName || null,
      compositeUrl: compositeUrl || null, qrOnlyUrl: qrOnlyUrl || null, pricing: pricing || null,
      enabledColors: enabledColors || [], enabledSizes: enabledSizes || [],
      selectedGraphicSize: selectedGraphicSize || null, defaultColor: defaultColor || null,
      qrProductState: qrProductState || null, landingPageUrl: landingPageUrl || null,
      mockupUrl: mockupUrl || null, assemblyId: resolvedAssemblyId, createdAt: now, updatedAt: now,
    };
    const linkRef = await db.collection(STORE_PRODUCT_LINKS_COLLECTION).add(linkData);
    console.log(`[Store Links] Created link: ${linkRef.id} for store ${storeId} / channel ${channel}`);
    res.json({ success: true, linkId: linkRef.id, message: `Product linked to ${storeName || storeId} / ${channel}` });
  } catch (error: any) {
    console.error("[Store Links] Error creating link:", error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/admin/stores/:storeId/channels/:channelId/products', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { storeId, channelId } = req.params;
    if (!storeId || !channelId) { res.status(400).json({ error: "storeId and channelId are required" }); return; }
    const linksSnapshot = await db.collection(STORE_PRODUCT_LINKS_COLLECTION)
      .where("storeId", "==", storeId).where("channel", "==", channelId).get();
    const products = linksSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id, linkId: doc.id, packetId: data.packetId || null,
        templateId: data.templateId || null, name: data.productName || "Untitled Product",
        imageUrl: data.compositeUrl || data.qrOnlyUrl || null, mockupUrl: data.mockupUrl || null,
        qrContent: data.qrContent || null, pricing: data.pricing || null,
        enabledColors: data.enabledColors || [], enabledSizes: data.enabledSizes || [],
        selectedGraphicSize: data.selectedGraphicSize || null, defaultColor: data.defaultColor || null,
        collection: data.collection || null, qrProductState: data.qrProductState || null,
        landingPageUrl: data.landingPageUrl || null,
        createdAt: data.createdAt?.toDate?.()?.toISOString() || null,
      };
    });
    console.log(`[Store Links] Found ${products.length} products for ${storeId}/${channelId}`);
    res.json(products);
  } catch (error: any) {
    console.error("[Store Links] Error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.patch('/admin/store-product-links/:linkId', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { linkId } = req.params;
    const updates = req.body;
    if (!linkId) { res.status(400).json({ error: "linkId is required" }); return; }
    const docRef = db.collection(STORE_PRODUCT_LINKS_COLLECTION).doc(linkId);
    const doc = await docRef.get();
    if (!doc.exists) { res.status(404).json({ error: "Link not found" }); return; }
    await docRef.update({ ...stripUndef(updates), updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    console.log(`[Store Links PATCH] Updated link ${linkId}:`, Object.keys(updates));
    res.json({ success: true, linkId, message: "Link updated" });
  } catch (error: any) {
    console.error("[Store Links PATCH] Error:", error);
    res.status(500).json({ error: error.message });
  }
});

app.delete('/admin/store-product-links/:linkId', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { linkId } = req.params;
    if (!linkId) { res.status(400).json({ error: "linkId is required" }); return; }
    const docRef = db.collection(STORE_PRODUCT_LINKS_COLLECTION).doc(linkId);
    const doc = await docRef.get();
    if (!doc.exists) { res.status(404).json({ error: "Link not found" }); return; }
    await docRef.delete();
    console.log(`[Store Links DELETE] Deleted link ${linkId}`);
    res.json({ success: true, linkId, message: "Link deleted" });
  } catch (error: any) {
    console.error("[Store Links DELETE] Error:", error);
    res.status(500).json({ error: error.message });
  }
});

// ============ PRODUCTS PAGE: CATALOG SYNC ============

app.get('/admin/catalog/sync-status', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const syncId = req.query.syncId as string;
    if (syncId) {
      const syncDoc = await db.collection("catalogSyncs").doc(syncId).get();
      if (!syncDoc.exists) { res.status(404).json({ error: "Sync not found" }); return; }
      res.json(serializeSync(syncDoc.id, syncDoc.data()));
      return;
    }
    const provider = req.query.provider as string | undefined;
    if (provider && provider !== 'printify' && provider !== 'printful') {
      res.status(400).json({ error: 'provider must be printify or printful' }); return;
    }
    let query: FirebaseFirestore.Query = db.collection("catalogSyncs");
    if (provider) query = query.where('syncType', '==', provider === 'printify' ? 'smart' : 'printful');
    // Equality-only history reads work before a composite index finishes deploying.
    // Sort the complete provider history, not a truncated page of arbitrary jobs.
    const latestSnapshot = await query.get();
    if (latestSnapshot.empty) { res.json({ status: 'none', message: 'No sync has been run yet' }); return; }
    const history = latestSnapshot.docs.map(doc => serializeSync(doc.id, doc.data()));
    history.sort((a, b) => (Date.parse(b.startedAt || '') || 0) - (Date.parse(a.startedAt || '') || 0) || a.id.localeCompare(b.id));
    res.json(history[0]);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

for (const provider of ['printify', 'printful'] as const) {
  app.post(provider === 'printful' ? '/admin/catalog/sync-printful' : '/admin/catalog/sync', requireAdmin, async (req: Request, res: Response): Promise<void> => {
    try {
      if (provider === 'printify' && !printifyClient.isConfigured) { res.status(503).json({ error: 'Printify API not configured' }); return; }
      const progress = await advanceCatalogSync(db, provider, req.body, {
        list: () => provider === 'printful' ? printfulClient.getCatalogProducts() : printifyClient.getCatalogBlueprints(),
        rebuild: () => syncMasterCatalog(),
        syncProduct: async product => {
          const pid = product.id;
          if (provider === 'printify') {
            const ref = db.collection('printify_blueprints').doc(String(pid));
            const existing = (await ref.get()).data();
            const details = await printifyClient.getBlueprintDetails(pid);
            const data = { id: pid, title: product.title, description: product.description || null,
              richDescription: details.description || null, brand: product.brand || null, model: product.model || null,
              images: product.images || null, primaryImageUrl: product.images?.[0] || null };
            if (!catalogFieldsChanged(existing, data)) return 'skipped';
            await ref.set({ ...data, lastSyncedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
            return existing ? 'updated' : 'added';
          }
          const detail = await printfulClient.getProduct(pid);
          if (!Array.isArray(detail?.variants)) throw new Error(`Printful returned invalid variants for ${pid}`);
          const variants = detail.variants;
          const prices = variants.map(v => Number(v.price)).filter(p => Number.isFinite(p) && p > 0);
          if (!prices.length) throw new Error(`Printful product ${pid} has no valid prices`);
          const ref = db.collection('printful_products').doc(String(pid));
          const legacyRef = db.collection('printfulCatalog').doc(String(pid));
          const [existingDoc, legacyDoc, existingVariants] = await Promise.all([ref.get(), legacyRef.get(), db.collection('printful_variants').where('productId', '==', pid).get()]);
          const existing = existingDoc.data();
          const byId = new Map(existingVariants.docs.map(d => [d.id, d.data()]));
          const data = { id: pid, title: product.title, type: product.type || null, brand: product.brand || null,
            model: product.model || null, image: product.image || null, variantCount: variants.length,
            category: normalizePrintfulCategory(product.type || '', product.title || ''), description: product.description || null,
            availableSizes: Array.from(new Set(variants.map(v => v.size).filter(Boolean))),
            availableColors: Array.from(new Map(variants.filter(v => v.color).map(v => [v.color, { name: v.color, hex: v.color_code || null }])).values()),
            isAvailable: true, minPrice: Math.min(...prices).toFixed(2), maxPrice: Math.max(...prices).toFixed(2) };
          const changedVariants = variants.map(v => ({ ...v, productId: pid, colorCode: v.color_code || null }))
            .filter(v => catalogFieldsChanged(byId.get(String(v.id)), v));
          // Unchanged variant rows are not rewritten by Smart Sync.
          for (let offset = 0; offset < changedVariants.length; offset += 400) {
            const batch = db.batch();
            for (const v of changedVariants.slice(offset, offset + 400)) batch.set(db.collection('printful_variants').doc(String(v.id)), v, { merge: true });
            await batch.commit();
          }
          const changed = catalogFieldsChanged(existing, data), legacyChanged = catalogFieldsChanged(legacyDoc.data(), data);
          if (changed || legacyChanged) {
            const batch = db.batch(), saved = { ...data, lastSyncedAt: admin.firestore.FieldValue.serverTimestamp() };
            if (changed) batch.set(ref, saved, { merge: true });
            if (legacyChanged) batch.set(legacyRef, saved, { merge: true });
            await batch.commit();
          }
          return !existing ? 'added' : changed || legacyChanged || changedVariants.length ? 'updated' : 'skipped';
        },
      });
      res.json(progress);
    } catch (e: any) {
      console.error('[Catalog Sync] Request failed:', e.message);
      res.status(e.status || 500).json({ error: e.message });
    }
  });
}

app.get('/admin/catalog/printful', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const search = (req.query.search as string || '').toLowerCase();
    const snapshot = await db.collection('printfulCatalog').get();
    let products: any[] = [];
    snapshot.forEach(doc => products.push({ docId: doc.id, ...doc.data() }));
    if (search) {
      products = products.filter(p =>
        (p.title || '').toLowerCase().includes(search) ||
        (p.brand || '').toLowerCase().includes(search) ||
        (p.model || '').toLowerCase().includes(search) ||
        (p.category || '').toLowerCase().includes(search)
      );
    }
    res.json(products);
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/catalog/printful/:productId', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const productId = parseInt(req.params.productId);
    if (!printfulClient.isConfigured) { res.status(503).json({ error: "Printful API not configured" }); return; }
    const productData = await printfulClient.getProduct(productId);
    const printfileData = await printfulClient.getPrintfiles(productId).catch(() => null);
    const placements = printfileData?.available_placements ? Object.keys(printfileData.available_placements) : [];
    const colors = new Set<string>();
    const sizes = new Set<string>();
    if (productData?.variants) {
      for (const v of productData.variants) {
        if (v.color) colors.add(v.color);
        if (v.size) sizes.add(v.size);
      }
    }
    res.json({
      ...productData.product,
      variants: productData.variants,
      placements,
      colors: Array.from(colors),
      sizes: Array.from(sizes),
    });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/catalog/printful-mapping', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { printifyBlueprintId, printfulProductId, notes } = req.body;
    if (!printifyBlueprintId || !printfulProductId) {
      res.status(400).json({ error: "printifyBlueprintId and printfulProductId required" }); return;
    }
    const existingSnap = await db.collection('printify_printful_mapping')
      .where('printifyBlueprintId', '==', printifyBlueprintId)
      .where('isActive', '==', true).limit(1).get();
    if (!existingSnap.empty) {
      await existingSnap.docs[0].ref.update({ isActive: false, deactivatedAt: admin.firestore.FieldValue.serverTimestamp() });
    }
    const mappingRef = await db.collection('printify_printful_mapping').add({
      printifyBlueprintId, printfulProductId, isActive: true,
      notes: notes || null, createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    res.json({ success: true, mappingId: mappingRef.id, message: `Mapped Printify #${printifyBlueprintId} → Printful #${printfulProductId}` });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/catalog/printful-mappings', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const snap = await db.collection('printify_printful_mapping').where('isActive', '==', true).get();
    const mappings: any[] = [];
    snap.forEach(doc => mappings.push({ id: doc.id, ...doc.data() }));
    const hardcoded = Object.entries(DEFAULT_BLUEPRINT_MAPPINGS).map(([bpId, pfId]) => ({
      printifyBlueprintId: parseInt(bpId), printfulProductId: pfId, source: 'hardcoded'
    }));
    res.json({ firestoreMappings: mappings, hardcodedMappings: hardcoded });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

// ============ PRODUCTS PAGE: CATALOG PLACEMENTS ============

app.get('/admin/catalog/placements', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const provider = req.query.provider as string;
    const blueprintId = req.query.blueprintId ? parseInt(req.query.blueprintId as string) : null;
    const printProviderId = req.query.printProviderId ? parseInt(req.query.printProviderId as string) : null;
    const productId = req.query.productId ? parseInt(req.query.productId as string) : null;

    if (provider === 'printify') {
      if (!blueprintId) { res.status(400).json({ error: "blueprintId required for Printify" }); return; }
      if (!printifyClient.isConfigured) { res.status(503).json({ error: "Printify API not configured" }); return; }

      let resolvedProviderId = printProviderId;

      if (!resolvedProviderId) {
        try {
          const provSnapshot = await db.collection('printify_providers').get();
          const matching = provSnapshot.docs
            .map(d => d.data())
            .filter(d => (d.blueprintId ?? d.blueprint_id) === blueprintId);
          if (matching.length > 0) {
            const best = matching.reduce((prev, cur) => {
              const prevColors = Array.isArray(prev.availableColors) ? prev.availableColors.length : 0;
              const curColors = Array.isArray(cur.availableColors) ? cur.availableColors.length : 0;
              return curColors > prevColors ? cur : prev;
            });
            resolvedProviderId = best.providerId ?? best.provider_id ?? null;
          }
        } catch (lookupErr: any) {
          console.warn(`[Placements] Provider DB lookup failed for blueprint ${blueprintId}:`, lookupErr.message);
        }
      }

      if (!resolvedProviderId) {
        try {
          const liveProviders = await printifyClient.getPrintProviders(blueprintId);
          if (liveProviders && liveProviders.length > 0) {
            const usaFirst = liveProviders.find((p: any) => p.location?.country === 'US' || p.location?.country === 'USA');
            resolvedProviderId = (usaFirst || liveProviders[0]).id;
          }
        } catch (provErr: any) {
          console.warn(`[Placements] Live provider fetch failed for blueprint ${blueprintId}:`, provErr.message);
        }
      }

      if (!resolvedProviderId) {
        res.status(400).json({ error: "No print provider found for this blueprint. Try syncing the catalog first." });
        return;
      }

      try {
        const variantData = await printifyClient.getVariants(blueprintId, resolvedProviderId);
        const placementSet = new Set<string>();
        if (variantData?.variants) {
          for (const v of variantData.variants) {
            if (v.placeholders) {
              for (const ph of v.placeholders) { placementSet.add(ph.position || ph.placeholder); }
            }
          }
        }
        if (placementSet.size === 0) placementSet.add('front');
        const normalized = normalizePlacements('printify', Array.from(placementSet));
        const mapped = normalized.map(p => ({
          id: p, type: p, title: p.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()), additionalPrice: 0,
        }));
        res.json({ placements: mapped, source: 'printify-api' });
      } catch (err: any) {
        res.json({ placements: [{ id: 'front', type: 'front', title: 'Front', additionalPrice: 0 }], source: 'default-fallback' });
      }
      return;
    }

    if (provider === 'printful') {
      if (!productId) { res.status(400).json({ error: "productId required for Printful" }); return; }
      const printfileInfo = await printfulClient.getPrintfiles(productId);
      const rawPlacements = printfileInfo?.available_placements ? Object.keys(printfileInfo.available_placements) : [];
      const printPlacements = rawPlacements.filter(p => !isEmbroideryPlacement(p));
      const grouped = groupPlacementsByLocation('printful', printPlacements);
      const mapped = grouped.map(g => ({
        id: g.internal, type: g.internal,
        title: g.internal.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()),
        additionalPrice: 0,
        methods: g.methods.map(m => ({ method: m.method, providerName: m.providerName })),
      }));
      res.json({ placements: mapped, source: 'printful-api' });
      return;
    }

    res.status(400).json({ error: "provider must be 'printify' or 'printful'" });
  } catch (error: any) {
    console.error("Placement fetch error:", error.message);
    res.status(500).json({ error: error.message });
  }
});

}
