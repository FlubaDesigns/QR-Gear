import {readHostingTiers,changeHostingTier} from '../services/hosting-tiers';
import { HealthMonitorService } from '../services/health-monitor';
import { registerFontRoutes } from '../services/font-settings';
import { projectTemplateDisplay } from '../../../shared/templateDisplay';
import { Request, Response, NextFunction } from 'express';
  import express from 'express';
  import { admin, db, storage, docToObject, docsToArray, stripUndef, sanitizeStyleForFirestore, generateNanoId, escapeHtml, generateGiftCode, FulfillmentProvider, PrintMethod, normalizePlacement, normalizePlacements, toProviderPlacement, isEmbroideryPlacement, groupPlacementsByLocation, detectPrintMethod, QR_GEAR_BRANDED_TAG_URL, LABEL_PLACEMENTS_PRINTFUL, isValidHexColor, isColorDark, PRINTIFY_TO_INTERNAL, PRINTFUL_TO_INTERNAL, INTERNAL_TO_PRINTFUL, INTERNAL_TO_PRINTFUL_DTF } from '../core';
import { PLATFORM_STORE_ID } from '../constants';
import { verifyAuth, requireAuth, requireAdmin, verifyMemberAuthCF, ADMIN_USER_IDS } from '../middleware';
import { printfulClient, updatePrintfulKeyCache } from '../services/printful';
  import { printifyClient, getPrintifyApiKey, getPrintifyShopId, submitOrderToPrintify, checkPrintifyOrderStatus, PRINTIFY_API_BASE } from '../services/printify';
  import { generateSignedUrl, addSignedUrlsToAssets, downloadAndStoreImage } from '../services/storage-helpers';
  import { calculateAuthoritativePrice, getAuthoritativePrice } from '../services/pricing';
  import { generateMockupFromPrintful, processMockupResult, getPrintfulProductId, toPublicUrl, DEFAULT_BLUEPRINT_MAPPINGS } from '../services/mockup-generator';
  import type { MockupRequest, MockupResult } from '../services/mockup-generator';
  import { getPrintfulApiKey, getPrintfulApiKeyAsync, getPrintfulStoreId, PRINTFUL_API_BASE } from '../services/printful';
  import type { PrintfulMockupTask, PrintfulVariant } from '../services/printful';
  import { getResendClient, QR_GEAR_FROM_EMAIL } from '../services/email';
  import { cfGenerateCompositeImage, cfGeneratePrintifyComposite, cfUploadBufferToStorage, cfGetPreviewFontSize, cfWrapText, CF_PLACEMENT_DIMENSIONS, CF_FONT_MAP, CF_PREVIEW_CONTAINER_WIDTH, CF_PREVIEW_WIDTH, CF_PREVIEW_QR_SIZE, getCanvas, getQRCode } from '../services/composite-image';


  export function register(app: express.Express): void {
for(const path of ['/hosting-tiers','/admin/hosting-tiers']) app.get(path,...(path.startsWith('/admin')?[requireAdmin]:[]),async(_req:Request,res:Response)=>{
  try{res.json(await readHostingTiers(db));}catch(e:any){res.status(409).json({error:'Save valid hosting tiers in Admin Pricing first.'});}
});
for(const method of ['post','put','delete'] as const) app[method](method==='post'?'/admin/hosting-tiers':'/admin/hosting-tiers/:id',requireAdmin,async(req:Request,res:Response)=>{
  try{res.json({success:true,tiers:await changeHostingTier(db,method.toUpperCase(),req.params.id,req.body)});}catch(e:any){res.status(e.status||400).json({error:e.message});}
});
app.post('/admin/hosting-tiers/seed',requireAdmin,(_req:Request,res:Response)=>{res.status(409).json({error:'Hosting tiers are controlled in Admin Pricing. No code defaults were applied.'});});
// ============ BATCH: MISC ADMIN ROUTES ============


app.get('/admin/graphic-sets', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('graphic_sets').orderBy('createdAt', 'desc').get();
    const sets = snapshot.docs.map((d: any) => ({ id: d.id, ...d.data() }));
    res.json({ sets });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/graphic-sets/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const doc = await db.collection('graphic_sets').doc(req.params.id).get();
    if (!doc.exists) { res.status(404).json({ error: "Not found" }); return; }
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/graphic-sets', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const docRef = await db.collection('graphic_sets').add({ ...req.body, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    res.json({ id: docRef.id, success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.put('/admin/graphic-sets/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('graphic_sets').doc(req.params.id).update({ ...req.body, updatedAt: new Date().toISOString() });
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.delete('/admin/graphic-sets/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('graphic_sets').doc(req.params.id).delete();
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/pricing/quote', async (req: Request, res: Response): Promise<void> => {
  try {
    const pricingDoc = await db.collection('testSettings').doc('pricing').get();
    const settings = pricingDoc.exists ? pricingDoc.data() : {};
    res.json({ settings });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/pricing/quote', async (req: Request, res: Response): Promise<void> => {
  try {
    const { blueprintId, quantity = 1 } = req.body;
    const pricingDoc = await db.collection('testSettings').doc('pricing').get();
    const settings = pricingDoc.exists ? pricingDoc.data() : {};
    const markupPercent = settings?.markupPercent ?? 25;
    const markupFixed = settings?.markupFixed ?? 0;
    let baseCost = 0;
    if (blueprintId) {
      const productSnap = await db.collection('products').where('blueprintId', '==', blueprintId).limit(1).get();
      if (!productSnap.empty) {
        const product = productSnap.docs[0].data();
        baseCost = product.baseCost || 0;
      }
    }
    const unitPrice = Math.ceil((baseCost * (1 + markupPercent / 100) + markupFixed) * 100) / 100;
    const total = unitPrice * quantity;
    res.json({ baseCost, unitPrice, quantity, total, markupPercent, markupFixed });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/catalog/cost-sync-status', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const doc = await db.collection('system').doc('cost-sync-status').get();
    res.json(doc.exists ? doc.data() : { status: 'never_run' });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/catalog/sync-history', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('catalog_sync_history').orderBy('startedAt', 'desc').limit(20).get();
    const history = snapshot.docs.map((d: any) => ({ id: d.id, ...d.data() }));
    res.json({ history });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});











app.get('/admin/templates', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('productTemplates').orderBy('createdAt', 'desc').get();
    let withPreview = 0, withFallbackTitle = 0, noPacket = 0;

    const templates = snapshot.docs.map((d: any) => {
      const data = d.data();

      // ── Packet reconstruction ────────────────────────────────────────────────
      // Build the packet object whenever ANY packet-relevant field is present.
      // Previously this was gated on (packetId || qrContent || artworkUrl) which
      // silently dropped valid templates that only had e.g. thumbnailUrl or
      // priorityMockupUrl.  The picker threshold is much lower than the build
      // threshold — we just need enough to show a usable card.
      const hasPacketData = !!(
        data.packetId || data.qrContent || data.artworkUrl ||
        data.thumbnailUrl || data.priorityMockupUrl || data.compositeUrl ||
        data.blueprintId || data.placementConfig
      );

      const packet = hasPacketData ? {
        id: data.packetId || null,
        qrContent: data.qrContent || null,
        productName: data.productName || data.name || null,
        compositeUrl: data.compositeUrl || data.artworkUrl || null,
        priorityMockupUrl: data.priorityMockupUrl || null,
        blueprintId: data.blueprintId || null,
        printProviderId: data.printProviderId || null,
        fulfillmentProvider: data.fulfillmentProvider || 'printify',
        placements: data.placements || (data.placementConfig ? Object.keys(data.placementConfig) : []),
        placementConfig: data.placementConfig || {},
        placementSizes: data.placementSizes || {},
        placementMethods: data.placementMethods || {},
        defaultColor: data.defaultColor || null,
        defaultColorHex: data.defaultColorHex || null,
        landingPageTitle: data.landingPageTitle || data.name || null,
        landingPageDescription: data.landingPageDescription || data.description || null,
        headerText: data.headerText || null,
        footerText: data.footerText || null,
        headerStyle: data.headerStyle || null,
        footerStyle: data.footerStyle || null,
        subBottomEnabled: data.subBottomEnabled || false,
        subBottomText: data.subBottomText || '',
        subBottomFontFamily: data.subBottomFontFamily || 'Arial',
        subBottomFontSize: data.subBottomFontSize || '14',
        subBottomFontWeight: data.subBottomFontWeight || '400',
        subBottomColor: data.subBottomColor || '#666666',
        backgroundUrl: data.backgroundUrl || null,
        qrProductState: data.qrProductState || 'qr_canvas',
        areaImageUrl: data.areaImageUrl || null,
        areaImageMode: data.areaImageMode || 'behind-qr',
        areaImageOffsetX: data.areaImageOffsetX ?? 50,
        areaImageOffsetY: data.areaImageOffsetY ?? 50,
        areaImageScale: data.areaImageScale ?? 100,
        graphicLayoutMode: data.graphicLayoutMode || 'zone',
        qrSizePercent: data.qrSizePercent ?? 75,
        qrPositionX: data.qrPositionX ?? 50,
        qrPositionY: data.qrPositionY ?? 50,
      } : null;

      if (!packet) noPacket++;

      const preview = projectTemplateDisplay({ ...data, packet });
      if (preview.previewImageUrl) withPreview++;
      if (!data.productName && !data.name) withFallbackTitle++;

      return {
        id: d.id,
        ...data,
        packetId: data.packetId || null,
        packet,
        ...preview,
      };
    });

    console.log(`[/admin/templates] returned ${templates.length} templates | withPreview=${withPreview} | fallbackTitle=${withFallbackTitle} | noPacket=${noPacket}`);
    res.json({ templates });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/templates', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const docRef = await db.collection('productTemplates').add({ ...req.body, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    res.json({ id: docRef.id, success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.put('/admin/templates/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('productTemplates').doc(req.params.id).update({ ...req.body, updatedAt: new Date().toISOString() });
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.delete('/admin/templates/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('productTemplates').doc(req.params.id).delete();
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/template-categories', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('template_categories').orderBy('sortOrder', 'asc').get();
    const categories = snapshot.docs.map((d: any) => ({ id: d.id, ...d.data() }));
    res.json({ categories });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/template-categories', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const docRef = await db.collection('template_categories').add({ ...req.body, createdAt: new Date().toISOString() });
    res.json({ id: docRef.id, success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.put('/admin/template-categories/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('template_categories').doc(req.params.id).update({ ...req.body, updatedAt: new Date().toISOString() });
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.delete('/admin/template-categories/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('template_categories').doc(req.params.id).delete();
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/library-files/member/:userId/:mediaType/:filename', async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, mediaType, filename } = req.params;
    const decodedFilename = decodeURIComponent(filename);
    const storagePath = `library/member/${userId}/${mediaType}/${decodedFilename}`;
    const bucket = storage.bucket();
    const file = bucket.file(storagePath);
    const [exists] = await file.exists();
    if (!exists) { res.status(404).json({ error: "File not found" }); return; }
    const [metadata] = await file.getMetadata();
    res.setHeader('Content-Type', metadata.contentType || 'application/octet-stream');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    const stream = file.createReadStream();
    stream.pipe(res);
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});


app.post('/admin/upload', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { imageData, fileName, mimeType, folder = 'admin-uploads' } = req.body;
    if (!imageData) { res.status(400).json({ error: "No imageData provided" }); return; }
    const base64Data = imageData.replace(/^data:[^;]+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    const result = await cfUploadBufferToStorage(buffer, mimeType || 'image/png', folder);
    res.json({ success: true, url: result.publicUrl, storagePath: result.storagePath });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/upload-media', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { imageData, fileName, mimeType, folder = 'admin-media' } = req.body;
    if (!imageData) { res.status(400).json({ error: "No imageData provided" }); return; }
    const base64Data = imageData.replace(/^data:[^;]+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    const result = await cfUploadBufferToStorage(buffer, mimeType || 'image/png', folder);
    res.json({ success: true, url: result.publicUrl, storagePath: result.storagePath });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});



// ============ BATCH SYNC: REMAINING MISSING ROUTES ============

// --- Dynamic Pages ---

app.get('/dynamic-pages', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = (req as any).user?.uid;
    const snapshot = await db.collection('dynamic_pages').where('userId', '==', userId).orderBy('createdAt', 'desc').get();
    const pages = snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() }));
    res.json(pages);
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/dynamic-pages/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const doc = await db.collection('dynamic_pages').doc(req.params.id).get();
    if (!doc.exists) { res.status(404).json({ error: 'Dynamic page not found' }); return; }
    const page = { id: doc.id, ...doc.data() };
    const assetsSnapshot = await db.collection('dynamic_page_assets').where('pageId', '==', req.params.id).get();
    const assets = assetsSnapshot.docs.map((d: any) => ({ id: d.id, ...d.data() }));
    res.json({ ...page, assets });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/dynamic-pages', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = (req as any).user?.uid;
    const { title, description, hostingTierId } = req.body;
    const slug = `dp-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 8)}`;
    const pageData = { userId, slug, title: title || 'Untitled', description: description || '', hostingTierId: hostingTierId || null, activeAssetId: null, isActive: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const docRef = await db.collection('dynamic_pages').add(pageData);
    res.json({ id: docRef.id, ...pageData });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/dynamic-pages/create', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = (req as any).user?.uid;
    const { title, description, hostingTierId } = req.body;
    const slug = `dp-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 8)}`;
    const pageData = { userId, slug, title: title || 'Untitled', description: description || '', hostingTierId: hostingTierId || null, activeAssetId: null, isActive: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const docRef = await db.collection('dynamic_pages').add(pageData);
    res.json({ id: docRef.id, ...pageData });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.put('/dynamic-pages/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    await db.collection('dynamic_pages').doc(id).update({ ...req.body, updatedAt: new Date().toISOString() });
    const doc = await db.collection('dynamic_pages').doc(id).get();
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.delete('/dynamic-pages/:id', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('dynamic_pages').doc(req.params.id).delete();
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/dynamic-pages/:id/assets', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('dynamic_page_assets').where('pageId', '==', req.params.id).get();
    res.json(snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/dynamic-pages/:id/assets', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const assetData = { pageId: req.params.id, ...req.body, createdAt: new Date().toISOString() };
    const docRef = await db.collection('dynamic_page_assets').add(assetData);
    res.json({ id: docRef.id, ...assetData });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/dynamic-pages/:id/set-active', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { assetId } = req.body;
    await db.collection('dynamic_pages').doc(req.params.id).update({ activeAssetId: assetId, updatedAt: new Date().toISOString() });
    res.json({ success: true });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/dynamic/:slug', async (req: Request, res: Response): Promise<void> => {
  try {
    const { slug } = req.params;
    const snapshot = await db.collection('dynamic_pages').where('slug', '==', slug).limit(1).get();
    if (snapshot.empty) { res.status(404).json({ error: 'Page not found' }); return; }
    const page = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
    res.json(page);
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

// --- Misc Admin & Public Routes ---

app.get('/store-product-links', async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('store_product_links').get();
    res.json(snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/store-product-links', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const docRef = await db.collection('store_product_links').add({ ...req.body, createdAt: new Date().toISOString() });
    res.json({ id: docRef.id, ...req.body });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/mockup/priority', requireAuth, async (req: Request, res: Response): Promise<void> => {
  try {
    const { blueprintId, printProviderId, colorName, colorHex, placement, artworkUrl, qrSize = "medium", fulfillmentProvider = "printify" } = req.body;
    if (!blueprintId || !colorName || !artworkUrl) {
      res.status(400).json({ error: "Missing required fields: blueprintId, colorName, artworkUrl" }); return;
    }
    console.log(`[CF Priority Mockup] Generating for: ${colorName} @ ${placement}, provider: ${fulfillmentProvider}`);
    const result = await generateMockupFromPrintful({
      blueprintId: parseInt(blueprintId), printProviderId: parseInt(printProviderId) || 99,
      colorName, colorHex, artworkUrl, artworkVariant: 'black',
      fulfillmentProvider: fulfillmentProvider as 'printify' | 'printful',
      placement: placement || 'front',
      hasCompositeGraphic: true,
    });
    console.log(`[CF Priority Mockup] Generated: ${result.mockupUrl} (cached: ${result.fromCache})`);
    res.json({ success: true, mockupUrl: result.mockupUrl, lifestyleMockupUrl: result.lifestyleMockupUrl, fromCache: result.fromCache, generatedAt: new Date().toISOString() });
  } catch (error: any) {
    console.error("[CF Priority Mockup] Error:", error);
    const bid = parseInt(req.body.blueprintId);
    let fallbackUrl: string | null = null;
    try {
      const bpDoc = await db.collection('printify_blueprints').doc(String(bid)).get();
      if (bpDoc.exists) {
        const bpData = bpDoc.data()!;
        fallbackUrl = bpData.images?.[0] || bpData.image || null;
      }
      if (!fallbackUrl) {
        const memberProds = await db.collection('storeAllowedProducts').doc('member-products').get();
        if (memberProds.exists) {
          const prods = memberProds.data()?.products || [];
          const match = prods.find((p: any) => p.blueprintId === bid);
          if (match?.image) fallbackUrl = match.image;
        }
      }
      if (fallbackUrl) {
        console.log(`[CF Priority Mockup] Using catalog fallback image for blueprint ${bid}`);
      }
    } catch (fbErr: any) {
      console.error("[CF Priority Mockup] Fallback lookup failed:", fbErr.message);
    }
    if (fallbackUrl) {
      res.json({ success: true, mockupUrl: fallbackUrl, lifestyleMockupUrl: null, fromCache: false, fallback: true, generatedAt: new Date().toISOString() });
    } else {
      res.json({ success: false, error: error.message, mockupUrl: null, message: "Mockup generation in progress - check back shortly" });
    }
  }
});

app.get('/admin/api-keys', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json(await new HealthMonitorService(db).getKeyStatus());
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/api-keys', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { provider, apiKey } = req.body;
    if (!provider || !apiKey) { res.status(400).json({ error: 'provider and apiKey are required' }); return; }
    if (provider === 'printful') {
      const testRes = await fetch('https://api.printful.com/stores', {
        headers: { 'Authorization': `Bearer ${apiKey}` },
      });
      if (!testRes.ok) {
        const errText = await testRes.text();
        res.status(400).json({ error: `Printful API key validation failed (${testRes.status}): ${errText}` }); return;
      }
      await db.collection('system_config').doc('api_keys').set({
        printfulApiKey: apiKey,
        printfulUpdatedAt: new Date().toISOString(),
      }, { merge: true });
      updatePrintfulKeyCache(apiKey);
      console.log('[Admin] Printful API key updated via dashboard');
      res.json({ success: true, message: 'Printful API key updated and verified' });
    } else {
      res.status(400).json({ error: `Unsupported provider: ${provider}` });
    }
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/api-keys/test', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const result=await new HealthMonitorService(db).checkProvider(req.body.provider);
    res.json({success:result.isHealthy,status:result.status,stores:result.stores,error:result.errorMessage});
  } catch (error: any) { res.status(500).json({ success: false, error: error.message }); }
});



app.post('/admin/channel-items/seed', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json({ success: true, message: 'Channel items seeded' });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/channel-items/:itemId/regenerate-assets', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    res.json({ success: true, message: 'Asset regeneration queued', itemId: req.params.itemId });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/templates', async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('templates').get();
    res.json(snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/queue/status', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const pendingSnapshot = await db.collection('mockup_jobs').where('status', '==', 'pending').get();
    const processingSnapshot = await db.collection('mockup_jobs').where('status', '==', 'processing').get();
    const completedSnapshot = await db.collection('mockup_jobs').where('status', '==', 'completed').limit(100).get();
    const failedSnapshot = await db.collection('mockup_jobs').where('status', '==', 'failed').limit(100).get();
    res.json({ success: true, queue: { pending: pendingSnapshot.size, processing: processingSnapshot.size, completed: completedSnapshot.size, failed: failedSnapshot.size }, message: `Queue status: ${pendingSnapshot.size} pending, ${processingSnapshot.size} processing` });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/store/products', async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('products').where('isVisible', '==', true).get();
    res.json(snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/partner-stores/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const doc = await db.collection('partner_stores').doc(req.params.id).get();
    if (!doc.exists) { res.status(404).json({ error: 'Partner store not found' }); return; }
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.patch('/admin/partner-stores/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('partner_stores').doc(req.params.id).update({ ...req.body, updatedAt: new Date().toISOString() });
    const doc = await db.collection('partner_stores').doc(req.params.id).get();
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/partner-stores/:id/regenerate-key', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const newKey = `psk-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 12)}`;
    await db.collection('partner_stores').doc(req.params.id).update({ apiKey: newKey, updatedAt: new Date().toISOString() });
    res.json({ success: true, apiKey: newKey });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/email-templates/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const doc = await db.collection('email_templates').doc(req.params.id).get();
    if (!doc.exists) { res.status(404).json({ error: 'Email template not found' }); return; }
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.patch('/admin/email-templates/:id', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    await db.collection('email_templates').doc(req.params.id).update({ ...req.body, updatedAt: new Date().toISOString() });
    const doc = await db.collection('email_templates').doc(req.params.id).get();
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

// /admin/background-assets/migrate — removed (legacy library_assets pipeline purged)

registerFontRoutes(app, '', requireAdmin, () => db);

app.get('/admin/provider-counts', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const printifySnap = await db.collection('printify_catalog').get();
    const printfulSnap = await db.collection('printful_catalog').get();
    res.json({ printify: printifySnap.size, printful: printfulSnap.size });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/sync-blueprints-to-firestore', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json({ success: true, message: 'Blueprint sync to Firestore initiated' });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/sync-providers-to-firestore', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    res.json({ success: true, message: 'Provider sync to Firestore initiated' });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.get('/admin/product-configs', requireAdmin, async (_req: Request, res: Response): Promise<void> => {
  try {
    const snapshot = await db.collection('product_configs').get();
    res.json(snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })));
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.patch('/admin/products/:id/options', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    await db.collection('products').doc(id).update({ options: req.body.options || {}, updatedAt: new Date().toISOString() });
    const doc = await db.collection('products').doc(id).get();
    res.json({ id: doc.id, ...doc.data() });
  } catch (error: any) { res.status(500).json({ error: error.message }); }
});

app.post('/admin/products/:id/sync-printify', requireAdmin, async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const productDoc = await db.collection('products').doc(id).get();
    if (!productDoc.exists) { res.status(404).json({ error: 'Product not found' }); return; }
    const product = { id: productDoc.id, ...productDoc.data() } as any;

    if (!product.blueprintId || !product.printProviderId) {
      res.status(400).json({ error: 'Product missing Printify blueprint or provider IDs' }); return;
    }

    console.log(`[CF ProductSync] Syncing product ${id}, blueprint=${product.blueprintId}, provider=${product.printProviderId}`);

    const variantData = await printifyClient.getVariants(product.blueprintId, product.printProviderId);
    const variants = variantData.variants || [];

    const colorMap = new Map<string, { name: string; hex: string; colors: string[] }>();
    const sizeSet = new Set<string>();
    const placementSet = new Set<string>();

    for (const v of variants) {
      if (v.options?.color && !colorMap.has(v.options.color)) {
        colorMap.set(v.options.color, { name: v.options.color, hex: v.options.colorHex || '#000000', colors: [v.options.colorHex || '#000000'] });
      }
      if (v.options?.size) sizeSet.add(v.options.size);
      if (v.placeholders) {
        for (const ph of v.placeholders) {
          if (ph.position) placementSet.add(ph.position);
        }
      }
    }

    const colors = Array.from(colorMap.values());
    const sizes = Array.from(sizeSet);
    const placements = normalizePlacements('printify', Array.from(placementSet));

    const variantBatch = db.batch();
    for (const v of variants) {
      const variantDocRef = db.collection('product_variants').doc(`${id}_${v.id}`);
      variantBatch.set(variantDocRef, {
        productId: id, printifyVariantId: v.id, title: v.title || '',
        size: v.options?.size || null, color: v.options?.color || null,
        colorHex: v.options?.colorHex || null,
        price: String((v.price || 0) / 100), isEnabled: true,
        isInStock: v.is_available ?? true, updatedAt: new Date().toISOString(),
      }, { merge: true });
    }
    await variantBatch.commit();

    await db.collection('products').doc(id).update({
      availablePlacements: placements, availableColors: colors, availableSizes: sizes,
      metadata: { ...(product.metadata || {}), lastSyncedAt: new Date().toISOString() },
      updatedAt: new Date().toISOString(),
    });

    const updatedDoc = await db.collection('products').doc(id).get();
    console.log(`[CF ProductSync] Synced ${variants.length} variants, ${colors.length} colors, ${sizes.length} sizes, ${placements.length} placements`);

    res.json({
      success: true,
      product: { id: updatedDoc.id, ...updatedDoc.data() },
      syncedData: { placements, colors, sizes, variantsCount: variants.length },
    });
  } catch (error: any) {
    console.error('[CF ProductSync] Error:', error);
    res.status(500).json({ error: error.message });
  }
});



  }
