import { memberProductOptions } from './member-product-options';
import { resolveQrgPrintSpecs } from './qrg-print-specs';
import { CATALOG_SECTIONS } from '../../../shared/catalogs';
import { isValidMasterCatalogDocId } from '../../../shared/qrgCodes';
import { masterCatalogProduct } from '../../../shared/masterCatalog';
import { catalogToSelectItem } from '../../../shared/adapters/catalog.adapter';

/** Member choices derive from QRG masters and saved catalog overrides in both runtimes. */
export async function catalogTierProducts(db: any, section: string) {
  if (!(CATALOG_SECTIONS as readonly string[]).includes(section)) {
    throw Object.assign(new Error('Invalid catalog section.'), { status: 400 });
  }
  const settings = db.collection('systemSettings');
  const [assignmentDoc, defaultsDoc] = await Promise.all([
    settings.doc('catalog-assignments').get(), settings.doc('catalog-defaults').get(),
  ]);
  const catalogId = assignmentDoc.data()?.[section] || defaultsDoc.data()?.defaultCatalogId || null;
  const empty = { hasTiers: false, catalogId, catalogName: '', tiers: {} as Record<string, Record<string, any>>, tierConfig: {} };
  if (!catalogId) return empty;
  const catalogDoc = await db.collection('catalogs').doc(catalogId).get();
  if (!catalogDoc.exists) return empty;
  const catalog = catalogDoc.data();
  const tierConfig = catalog.tierConfig || {};
  const pricing = (await db.collection('testSettings').doc('pricing').get()).data() || {};
  const providerSetting = (await db.collection('settings').doc('admin').get()).data()?.defaultFulfillmentProvider;
  const tiers: Record<string, Record<string, any>> = {};
  const unavailableBlankIds: string[] = [];
  for (const id of catalog.blankIds || []) {
    const tier = catalog.blankTiers?.[id];
    if (!['good', 'better', 'best'].includes(tier)) continue;
    if (!isValidMasterCatalogDocId(id)) { unavailableBlankIds.push(id); continue; }
    const doc = await db.collection('master_catalog').doc(id).get();
    let raw = doc.data();
    if (!doc.exists || raw.isActive === false || raw.status === 'archived') { unavailableBlankIds.push(id); continue; }
    let printSpecsError: string | null = null;
    if (providerSetting === 'printful' && Object.values(raw.qrgVariants || {}).some((v: any) => Number(v.providerVariants?.printful?.variantId) > 0)) {
      try {
        await resolveQrgPrintSpecs(raw, doc.ref);
      } catch (error: any) {
        console.error(`[MemberCatalog] QRG print specifications unavailable for ${id}:`, error.message);
        printSpecsError = 'Product print areas are unavailable. Please try again later.';
      }
    }
    const mappings = raw.providerMappings;
    const mapping = Array.isArray(mappings) ? mappings.find((m: any) => m.provider === providerSetting) : mappings?.[providerSetting];
    if (!printSpecsError && providerSetting === 'printful' && raw.qrgPrintSpecs?.printful?.locations?.some((p: any) => p.id === 'label_inside') &&
        !(typeof mapping?.minPrice === 'number' && Number.isFinite(mapping.minPrice) && mapping.minPrice >= 0)) {
      try {
        const { refreshQrgProviderPricing } = await import('./master-catalog');
        raw = await refreshQrgProviderPricing(db, id, providerSetting);
      } catch (error: any) {
        console.error(`[MemberCatalog] QRG production cost unavailable for ${id}:`, error.message);
        printSpecsError = 'Product pricing is unavailable. Please try again later.';
      }
    }
    const master = masterCatalogProduct(id, raw);
    const item = catalogToSelectItem(master, catalog.blankDescriptions?.[id], catalog.blankTitles?.[id], catalog.blankImages?.[id], catalog.blankColors?.[id]);
    const options = memberProductOptions(raw, item, providerSetting, pricing);
    if (printSpecsError) options.pricingError = printSpecsError;
    const provider = options.provider;
    // Provider IDs are outbound lookup references; canonicalBlankKey is the identity.
    if (!provider) { unavailableBlankIds.push(id); continue; }
    const category = typeof raw.qrgCategory === 'string' && raw.qrgCategory ? raw.qrgCategory : 'Unclassified';
    const { cost, retailPrice, memberEarnings } = options;
    const config = tierConfig[tier] || {};
    tiers[category] ||= {};
    tiers[category][tier] ||= { tier, displayName: config.displayName || tier[0].toUpperCase() + tier.slice(1), description: config.description || '', tagline: config.tagline || '', products: [] };
    tiers[category][tier].products.push({
      blueprintId: provider === 'printful' ? master.printfulId : master.blueprintId,
      canonicalBlankKey: id, qrgBlankId: master.qrgBlankId, 
      title: item.name, providerTitle: item.providerTitle, adminCatalogTitle: item.adminCatalogTitle,
      description: item.description, effectiveDescription: item.description,
      providerDescription: item.providerDescription, adminCatalogDescription: item.adminCatalogDescription,
      brand: item.manufacturer, category, imageUrl: item.primaryImageUrl, images: item.images,
      
      ...options, colors: options.availableColors, sizes: options.availableSizes,
    });
  }
  return { hasTiers: Object.keys(tiers).length > 0, catalogId, catalogName: catalog.name, tiers, tierConfig, unavailableBlankIds };
}


/** Resolve exactly the assigned catalog shown by the member picker. */
export async function memberCatalogProducts(db: any) {
  const catalog = await catalogTierProducts(db, 'member');
  if (catalog.hasTiers) return Object.values(catalog.tiers).flatMap(tiers => Object.values(tiers).flatMap((tier: any) => tier.products));
  const { readStoreProducts } = await import('./store-products');
  return (await readStoreProducts(db, 'member-products', 'member')).products;
}
