import { db, storage, QR_GEAR_BRANDED_TAG_URL } from '../core';
import { createHash } from 'crypto';
import { MEMBER_PACKETS_COLLECTION, QR_DYNAMICS_INSTANCES_COLLECTION } from '../constants';
import { memberDynamicsSlots, dynamicsMode, dynamicsHostingExpiry } from './qr-dynamics';
import { memberCatalogProducts, publicCatalogProducts } from './catalog-tier-products';
import { catalogSaleVariants, selectCatalogSaleVariant } from './catalog-sale-variants';
import { requireFulfillmentProvider } from '../../../shared/fulfillmentSettings';
import { requireBuilderSnapshot, packetBuildFields, buildPacketMockupRequest } from '../../../shared/builderSnapshot';
import { isValidMasterCatalogDocId } from '../../../shared/qrgCodes';
import { priceNewPacket, brandLabelSpec } from './pricing';
import { registerGrfAsset, registerPacketGrfAssets, registerMockupGrfAssets } from './grf-registrar';
import { generateMockupFromPrintful } from './mockup-generator';
import { GRF_PACKET_SLOTS } from '../../../shared/GRF_engine';
import { decodeLibraryImage } from './image-validation';
import { writeBldDefinition, writeAutoAssembly } from './bld-builder';
import { allocateQrgInstance } from './qrg-instance-allocator';
import { validatePacketComposition } from './assembly-store';
import { resolveRuntimeConfig } from '../runtime-config';

function fail(message: string, status = 400): never { throw Object.assign(new Error(message), { status }); }
const modes: Record<string, string> = { 'qr-basic': 'qr_basics', 'qr-plus': 'qr_plus', 'qr-canvas': 'qr_canvas', 'qr-play': 'qr_play', 'qr-compose': 'qr_compose' };

/** A member's Publish action exposes only selected copies, never their upload folder. */
async function publishMemberFileUrls(memberId: string, packetId: string, value: any, copies = new Map<string, string>()): Promise<any> {
  if (Array.isArray(value)) return Promise.all(value.map(item => publishMemberFileUrls(memberId, packetId, item, copies)));
  if (value && typeof value === 'object') {
    const result: Record<string, any> = {};
    for (const [key, item] of Object.entries(value)) result[key] = await publishMemberFileUrls(memberId, packetId, item, copies);
    return result;
  }
  if (typeof value !== 'string' || !/^(?:https?:\/\/|\/api\/)/.test(value)) return value;
  const path = new URL(value, resolveRuntimeConfig().origin).pathname;
  const match = /^\/api\/member-files\/([^/]+)\/([^/]+)$/.exec(path);
  const media = /^\/api\/library-files\/member\/([^/]+)\/([^/]+)\/([^/]+)$/.exec(path);
  if (!match && !media) return value;
  if (copies.has(value)) return copies.get(value);
  const parts = (match || media)!.slice(1).map(decodeURIComponent);
  if (parts.some(part => /[\/\\\u0000-\u001f]/.test(part) || part === '.' || part === '..')) fail('Invalid personal upload path.');
  if (parts[0] !== memberId) fail('You can only publish your own uploads.', 403);
  const filename = parts[parts.length - 1];
  const bucket = storage.bucket();
  let paths: string[];
  if (media) paths = [`library/member/${memberId}/${parts[1]}/${filename}`];
  else {
    const assets = await db.collection('memberLibrary').where('memberId', '==', memberId).where('fileName', '==', filename).limit(1).get();
    const asset = assets.docs[0]?.data();
    if (asset?.isActive === false) fail('This personal upload is no longer available.');
    if (asset?.storageUrl) {
      const source = String(asset.storageUrl).replace(/^gs:\/\/[^/]+\//, '');
      if ((!source.startsWith(`members/${memberId}/`) && !source.startsWith(`library/member/${memberId}/`)) || source.split('/').some(part => part === '..' || part === '.')) fail('This upload belongs to another member.', 403);
      paths = [source];
    } else paths = ['library/backgrounds', 'library/cropped', 'library/videos', 'backgrounds', 'videos', 'cropped'].map(folder => `members/${memberId}/${folder}/${filename}`);
  }
  for (const source of paths) {
    const file = bucket.file(source);
    if (!(await file.exists())[0]) continue;
    const destination = `products/${packetId}/member-assets/${createHash('sha256').update(source).digest('hex')}/${filename}`;
    const target = bucket.file(destination);
    await file.copy(target);
    await target.makePublic();
    const url = `https://storage.googleapis.com/${bucket.name}/${destination.split('/').map(encodeURIComponent).join('/')}`;
    copies.set(value, url);
    return url;
  }
  fail('Your selected personal upload could not be found. Choose it again before publishing.', 404);
}

export async function ownedMemberBuild(memberId: string, id: string, ownerType: 'member' | 'owner' = 'member') {
  if (!id || id.includes('/')) fail('Choose a saved member build.');
  const ref = db.collection('productPackets').doc(id), doc = await ref.get();
  if (!doc.exists) fail('Member build not found.', 404);
  const packet = doc.data()!;
  if (packet.ownerType !== ownerType || (ownerType === 'member' ? packet.memberId : packet.ownerId) !== memberId) fail('This build belongs to another account.', 403);
  return { ref, packet };
}

/** Translate the member editor once; QRG, pricing, BLD, GRF and Assembly remain shared. */
export async function prepareMemberBuild(memberId: string, input: any) { return prepareBuild(memberId, input, 'member'); }
export async function prepareOwnerBuild(ownerId: string, input: any) {
  if (!['qr-basic', 'qr-plus'].includes(input.packetType)) fail('Use the member builder for hosted QR experiences.');
  return prepareBuild(ownerId, input, 'owner');
}
/** Only the authenticated partner service supplies this resolved catalog scope. */
export async function preparePartnerBuild(ownerId: string, input: any, scope: { product: any; packetId: string; partnerId: string; claimId: string }) {
  if (input.packetType !== 'qr-plus') fail('Partner rewards use the existing QR Plus build.');
  const existing = await db.collection('productPackets').doc(scope.packetId).get();
  if (existing.exists) {
    const packet = existing.data()!;
    if (packet.ownerType !== 'owner' || packet.ownerId !== ownerId || packet.partnerId !== scope.partnerId || packet.partnerClaimId !== scope.claimId) fail('Reward build ownership differs.', 403);
    return { packetId: existing.id, memberPacketId: null, builderSnapshot: packet.builderSnapshot, qrContent: packet.qrContent, pricing: packet.pricing };
  }
  return prepareBuild(ownerId, input, 'owner', scope);
}
async function prepareBuild(memberId: string, input: any, ownerType: 'member' | 'owner', scope?: { product: any; packetId: string; partnerId: string; claimId: string }) {
  const sourceMasterId = input.boundProduct?.canonicalBlankKey;
  if (!isValidMasterCatalogDocId(sourceMasterId)) fail('Select a QRG product again before building.');
  const choices = scope ? [scope.product] : await (ownerType === 'member' ? memberCatalogProducts(db) : publicCatalogProducts(db));
  const product = choices.find((p: any) => p.canonicalBlankKey === sourceMasterId);
  if (!product) fail('This product is not enabled in the assigned catalog.');
  const provider = requireFulfillmentProvider(product.fulfillmentProvider);
  const master = (await db.collection('master_catalog').doc(sourceMasterId).get()).data()!;
  const variant = selectCatalogSaleVariant({ enabledColors: product.availableColors, enabledSizes: product.availableSizes }, master, provider, input.selectedShirtSize, input.selectedColor);
  const channel = ownerType === 'member' && input.channelId ? await db.collection('channels').doc(input.channelId).get() : null;
  if (ownerType === 'member' && (!channel?.exists || channel.data()?.ownerId !== memberId)) fail('Choose one of your channels.');
  const mode = modes[input.packetType];
  if (!mode) fail('Choose a QR product type.');
  const compose = input.packetType === 'qr-compose';
  const composeSlots = compose ? await memberDynamicsSlots(memberId, input.composeItems) : null;
  const composeMode = compose ? dynamicsMode(input.composeMode) : 'auto-rotate';
  if (compose && !['1-year', '3-year', '5-year'].includes(input.composeHostingTerm)) fail('Choose a hosting term.');
  const selected = input.selectedPlacements;
  if (!Array.isArray(selected) || !selected.length || selected.some((p: any) => typeof p !== 'string')) fail('Choose a print placement.');
  const locations = master.qrgPrintSpecs?.[provider]?.locations || [];
  const providerLayouts: Record<string, any> = {};
  for (const placement of selected) {
    const spec = locations.find((p: any) => p.id === placement && p.provider === provider);
    if (!spec?.dimensions?.widthPx || !spec?.dimensions?.heightPx || !spec.verifiedVariantIds?.includes(Number(variant.mapping.variantId))) fail(`Refresh the QRG print area for ${placement} before building this selection.`);
    providerLayouts[placement] = spec;
  }
  const title = String(input.title || '').trim();
  if (!title) fail('Give your product a title.');
  if (input.packetType === 'qr-canvas' && !input.background) fail('Choose your QR Canvas background.');
  if (input.packetType === 'qr-play' && !input.videoUrl) fail('Choose your QR Play video.');
  const label = brandLabelSpec(master, provider);
  if (label && !label.verifiedVariantIds?.includes(Number(variant.mapping.variantId))) fail('This variant does not support the selected brand label.');
  const placementSizes = Object.fromEntries(selected.map((placement: string) => {
    const size = input.perPlacementSizes?.[placement] || input.graphicSize || 'medium';
    if (!['small', 'medium', 'large'].includes(size)) fail('Choose a valid graphic size.');
    return [placement, size];
  }));
  const perPlacementConfigs = Object.fromEntries(selected.map((placement: string) => {
    const saved = input.perPlacementConfigs?.[placement] || {};
    const graphicChoice = saved.graphicChoice || 'full';
    if (!['full', 'qr-only'].includes(graphicChoice)) fail('Choose full graphic or QR only for each placement.');
    const value: Record<string, any> = { graphicChoice };
    for (const key of ['qrPositionX', 'qrPositionY']) if (saved[key] != null) {
      if (typeof saved[key] !== 'number' || !Number.isFinite(saved[key]) || saved[key] < 0 || saved[key] > 100) fail('Placement QR positions must be between 0 and 100 percent.');
      value[key] = saved[key];
    }
    return [placement, value];
  }));
  const rawSnapshot = requireBuilderSnapshot({ title, description: String(input.description || ''),
    graphics: { loadedBackground: input.background ? { url: input.background } : null, content: {
      headerStyle: input.headerStyle, footerStyle: input.footerStyle, areaImageUrl: input.areaImageUrl || '',
      areaImageOffsetX: input.areaImageOffsetX ?? 50, areaImageOffsetY: input.areaImageOffsetY ?? 50, areaImageScale: input.areaImageScale ?? 100,
      graphicLayoutMode: input.graphicLayoutMode || 'zone', qrPositionX: input.qrPositionX ?? 50,
      qrPositionY: input.qrPositionY ?? 50, qrSizePercent: input.qrSizePercent ?? 75,
      hostingTierCode: compose ? input.composeHostingTerm.replace('-', '_') : (input.hostingTierCode || '1_year'), playMediaUrl: input.videoUrl || '', qrBasicInputType: input.qrBasicInputType || 'url', areaImageMode: input.areaImageMode || 'cover',
    } },
    qrConfig: { qrProductState: mode, selectedColor: product.availableColors.find((c: any) => c.name === variant.color) },
    layoutConfig: { selectedPlacements: selected, providerLayouts, placementSizes, perPlacementConfigs },
    metadata: { selectedProductDocId: sourceMasterId, fulfillmentProvider: provider, selectedRole: ownerType },
  });
  const priced = await priceNewPacket(db, rawSnapshot, QR_GEAR_BRANDED_TAG_URL);
  if (input.existingPacketId && (typeof input.existingPacketId !== 'string' || input.existingPacketId.includes('/'))) fail('Invalid member product.');
  const memberPacketId = ownerType === 'member' ? (input.existingPacketId || db.collection(MEMBER_PACKETS_COLLECTION).doc().id) : null;
  const previous = memberPacketId ? await db.collection(MEMBER_PACKETS_COLLECTION).doc(memberPacketId).get() : null;
  if (previous?.exists && previous.data()?.memberId !== memberId) fail('This product belongs to another member.', 403);
  const ref = scope ? db.collection('productPackets').doc(scope.packetId) : db.collection('productPackets').doc();
  const origin = resolveRuntimeConfig().origin;
  const hosted = ['qr-canvas', 'qr-play', 'qr-compose'].includes(input.packetType);
  const dynamicsRef = hosted ? db.collection(QR_DYNAMICS_INSTANCES_COLLECTION).doc() : null;
  const landingPageSlug = `${ownerType}-${ref.id}`;
  const qrContent = dynamicsRef ? `${origin}/qr/d/${dynamicsRef.id}` : String(input.qrBasicContent || input.qrDestination || '').trim();
  if (!qrContent) fail('Enter the content for your QR code.');
  const identity = await allocateQrgInstance({ qrgBlankId: master.qrgBlankId, context: ownerType === 'member' ? 'M' : 'O' });
  const now = new Date().toISOString();
  const packet = { ...packetBuildFields(priced.builderSnapshot), ...identity, ownerType, memberId: ownerType === 'member' ? memberId : null, ownerId: ownerType === 'owner' ? memberId : null, memberPacketId,
    composeInstanceId: dynamicsRef?.id || null, composeMode, composeItems: composeSlots,
    sourceMasterId, qrgBlankId: master.qrgBlankId, fulfillmentProvider: provider,
    storeId: null, channelId: null, memberChannelId: ownerType === 'member' ? input.channelId : null,
    title, description: String(input.description || ''), packetType: input.packetType, qrContent,
    selectedColor: variant.color, selectedShirtSize: variant.size, selectedVariantKey: variant.key,
    boundProduct: { canonicalBlankKey: sourceMasterId, title: product.title, imageUrl: product.imageUrl,
      fulfillmentProvider: provider, providerProductId: Number(variant.mapping.productId) },
    landingPageSlug, landingPageTitle: title, landingPageDescription: String(input.description || ''),
    landingPageBackgroundUrl: input.background || null, playMediaUrl: input.videoUrl || null,
    pricing: priced.pricing, placementGraphicUrls: priced.placementGraphicUrls,
    ...(scope ? { partnerId: scope.partnerId, partnerClaimId: scope.claimId } : {}),
    status: 'building', createdAt: now, updatedAt: now };
  const batch = db.batch();
  batch.create(ref, packet);
  if (dynamicsRef) batch.create(dynamicsRef, { instanceId: dynamicsRef.id, ownerId: memberId, ownerType: 'member',
    title, hostingTierCode: priced.builderSnapshot.graphics.content.hostingTierCode,
    packetId: ref.id, qrgBaseCode: identity.qrgBaseCode, qrgBlankId: identity.qrgBlankId,
    status: 'draft', mode: 'loop', composeMode, createdAt: Math.floor(Date.now() / 1000),
    startTimestamp: Math.floor(Date.now() / 1000),
    slots: composeSlots || [{ packetId: ref.id, durationSeconds: 86400, order: 1 }] });
  await batch.commit();
  return { packetId: ref.id, memberPacketId, builderSnapshot: priced.builderSnapshot, qrContent, pricing: priced.pricing };
}

export async function saveMemberArtwork(memberId: string, id: string, placement: string, data: string, ownerType: 'member' | 'owner' = 'member') {
  const { ref, packet } = await ownedMemberBuild(memberId, id, ownerType);
  if (packet.status !== 'building') fail('Generate a new build before changing published artwork.');
  const snapshot = requireBuilderSnapshot(packet.builderSnapshot);
  if (!snapshot.layoutConfig.selectedPlacements.includes(placement) || ['label_inside', 'label_outside'].includes(placement)) fail('Choose a placement in this build.');
  const image = decodeLibraryImage(data, 'image/png'), bytes = Buffer.from(image.imageData, 'base64');
  const dims = snapshot.layoutConfig.providerLayouts[placement]?.dimensions;
  if (bytes.length < 24 || bytes.readUInt32BE(16) !== dims?.widthPx || bytes.readUInt32BE(20) !== dims?.heightPx) fail('Rendered artwork dimensions do not match the saved QRG print area.');
  const asset = await registerGrfAsset({ ...image, ...GRF_PACKET_SLOTS.qrComposite, packetId: id, createdBy: memberId });
  await ref.update({ [`placementGraphicUrls.${placement}`]: asset.publicUrl, updatedAt: new Date().toISOString() });
  return { publicUrl: asset.publicUrl };
}

/** Owned drafts preview the exact artwork that commit will send to Printful. */
export async function previewMemberBuild(memberId: string, id: string, ownerType: 'member' | 'owner' = 'member') {
  const { packet } = await ownedMemberBuild(memberId, id, ownerType);
  const snapshot = requireBuilderSnapshot(packet.builderSnapshot);
  const primary = snapshot.layoutConfig.selectedPlacements.find((p: string) => !['label_inside', 'label_outside'].includes(p));
  const master = (await db.collection('master_catalog').doc(packet.sourceMasterId).get()).data()!;
  const mapping = master.qrgVariants?.[packet.selectedVariantKey]?.providerVariants?.printful;
  if (packet.fulfillmentProvider !== 'printful' || !mapping) fail('This saved build needs its QRG Printful mockup mapping.');
  const result = await generateMockupFromPrintful({ ...buildPacketMockupRequest(packet, master, primary), printfulVariantId: Number(mapping.variantId) });
  return { ...result, productGraphic: packet.placementGraphicUrls[primary] };
}

export async function commitMemberBuild(memberId: string, id: string) {
  const owned = await ownedMemberBuild(memberId, id);
  const ref = owned.ref;
  let packet = owned.packet;
  if (packet.status === 'published') return { id: packet.memberPacketId, ...await memberBuildProjection(packet.memberPacketId) };
  if (packet.status !== 'building') fail('This build is not ready to publish.');
  let snapshot = requireBuilderSnapshot(packet.builderSnapshot);
  for (const placement of snapshot.layoutConfig.selectedPlacements) if (!packet.placementGraphicUrls?.[placement]) fail(`Generate the ${placement} artwork before publishing.`);
  const selectedFiles = await publishMemberFileUrls(memberId, id, { builderSnapshot: snapshot, playMediaUrl: packet.playMediaUrl });
  snapshot = requireBuilderSnapshot(selectedFiles.builderSnapshot);
  const projected = packetBuildFields(snapshot);
  // Only asset references change; preserve the member's saved title, copy,
  // pricing and store/channel fields instead of re-projecting unrelated fields.
  const publishedFields = {
    builderSnapshot: snapshot, headerStyle: projected.headerStyle, footerStyle: projected.footerStyle,
    areaImageUrl: projected.areaImageUrl, backgroundUrl: projected.backgroundUrl,
    landingPageBackgroundUrl: projected.landingPageBackgroundUrl,
    playMediaUrl: selectedFiles.playMediaUrl || null,
  };
  await ref.update(publishedFields);
  packet = { ...packet, ...publishedFields };
  const built = await finalizeBuildArtwork(id, packet);
  const identity = built.qrgBaseCode ? {} : await allocateQrgInstance({ qrgBlankId: packet.qrgBlankId, context: 'M' });
  const memberRef = db.collection(MEMBER_PACKETS_COLLECTION).doc(packet.memberPacketId);
  const now = new Date().toISOString();
  await db.runTransaction(async tx => {
    const old = await tx.get(memberRef);
    if (old.exists && old.data()?.memberId !== memberId) fail('This product belongs to another member.', 403);
    const dynamicsRef = packet.composeInstanceId ? db.collection(QR_DYNAMICS_INSTANCES_COLLECTION).doc(packet.composeInstanceId) : null;
    const dynamic = dynamicsRef ? (await tx.get(dynamicsRef)).data() : null;
    if (dynamicsRef && (!dynamic || dynamic.ownerId !== memberId || dynamic.packetId !== id || dynamic.qrgBaseCode !== built.qrgBaseCode)) fail('QR experience and item identity do not match.', 409);
    tx.update(ref, { ...identity, status: 'published', updatedAt: now });
    if (dynamicsRef) tx.update(dynamicsRef, { status: 'active', startTimestamp: Math.floor(Date.now() / 1000),
      hostingExpiresAt: dynamic!.hostingExpiresAt || dynamicsHostingExpiry(dynamic!.hostingTierCode), updatedAt: now });
    // The member record is an ownership/listing reference; production data is read from its packet.
    tx.set(memberRef, { memberId, id: memberRef.id, packetId: memberRef.id, productionPacketId: id,
      channelId: packet.memberChannelId, packetType: packet.packetType, status: 'published',
      createdAt: old.data()?.createdAt || now, updatedAt: now });
  });
  return { id: memberRef.id, ...await memberBuildProjection(memberRef.id) };
}

export async function memberBuildProjection(id: string): Promise<Record<string, any>> {
  const member = (await db.collection(MEMBER_PACKETS_COLLECTION).doc(id).get()).data();
  if (!member) fail('Member product not found.', 404);
  if (!member.productionPacketId) return { ...member, id };
  const packet = (await db.collection('productPackets').doc(member.productionPacketId).get()).data();
  if (!packet || packet.memberId !== member.memberId || packet.memberPacketId !== id) fail('Member product is not connected to its production packet.');
  const price = packet.pricing?.customerPrice;
  const master = (await db.collection('master_catalog').doc(packet.sourceMasterId).get()).data();
  const sizes = Object.values(master?.qrgVariants || {}).map((v: any) => v.sizeLabel);
  const availableSizes = catalogSaleVariants({ enabledColors: [packet.selectedColor], enabledSizes: sizes }, master, packet.fulfillmentProvider).map(v => v.size);
  return { ...packet, ...member, id, availableSizes, name: packet.title, price, retailPrice: price,
    qrGraphic: packet.qrOnlyUrl, productGraphic: packet.compositeUrl, urlGraphic: packet.landingPageBackgroundUrl,
    background: packet.landingPageBackgroundUrl, videoUrl: packet.playMediaUrl,
    destinationUrl: packet.qrContent, itemImage: packet.mockupUrl || packet.compositeUrl,
    thumbnailUrl: packet.mockupUrl || packet.compositeUrl,
    socialPacket: { title: packet.title, description: packet.description, retailPrice: price,
      itemImage: packet.mockupUrl || packet.compositeUrl, shareUrl: `${resolveRuntimeConfig().origin}/p/${id}` } };
}

/** Both builders finalize through the same GRF, BLD and Assembly engines. */
async function finalizeBuildArtwork(id: string, packet: any) {
  const ref = db.collection('productPackets').doc(id);
  const snapshot = requireBuilderSnapshot(packet.builderSnapshot);
  for (const placement of snapshot.layoutConfig.selectedPlacements) if (!packet.placementGraphicUrls?.[placement]) fail(`Generate the ${placement} artwork before checkout.`);
  const primary = snapshot.layoutConfig.selectedPlacements.find((p: string) => !['label_inside', 'label_outside'].includes(p));
  const compositeUrl = packet.placementGraphicUrls[primary];
  await ref.update({ compositeUrl, productGraphicUrl: compositeUrl });
  const grfs = await registerPacketGrfAssets({ ...packet, compositeUrl }, null, id);
  const master = (await db.collection('master_catalog').doc(packet.sourceMasterId).get()).data()!;
  const mapping = master.qrgVariants?.[packet.selectedVariantKey]?.providerVariants?.printful;
  if (packet.fulfillmentProvider !== 'printful' || !mapping) fail('This saved build needs its QRG Printful mockup mapping.');
  const mockup = await generateMockupFromPrintful({
    ...buildPacketMockupRequest(packet, master, primary), printfulVariantId: Number(mapping.variantId),
  });
  const placementMockupUrls = { [primary]: mockup.mockupUrl };
  const mockupGrfs = await registerMockupGrfAssets(id, mockup.lifestyleMockupUrl || null, placementMockupUrls);
  await ref.update({ mockupUrl: mockup.mockupUrl, lifestyleMockupUrl: mockup.lifestyleMockupUrl || null,
    placementMockupUrls, ...mockupGrfs });
  const bld = await writeBldDefinition({ working: snapshot, packetId: id });
  await writeAutoAssembly({ working: snapshot, qrgId: packet.qrgBlankId, bldId: bld.bldId, sourceSessionId: null, packetId: id, grfIds: { ...grfs, ...mockupGrfs } });
  const built = (await ref.get()).data()!;
  await validatePacketComposition(db, id, built);
  return built;
}

export async function commitOwnerBuild(ownerId: string, id: string) {
  const { ref, packet } = await ownedMemberBuild(ownerId, id, 'owner');
  if (packet.status === 'ready') return packet;
  if (packet.status !== 'building') fail('This build is not ready for checkout.');
  const built = await finalizeBuildArtwork(id, packet);
  await ref.update({ status: 'ready', updatedAt: new Date().toISOString() });
  return { ...built, status: 'ready' };
}
