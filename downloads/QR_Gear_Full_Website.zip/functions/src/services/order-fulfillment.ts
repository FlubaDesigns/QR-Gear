import { assertProductionPayment } from './payment-state';
import { randomUUID } from 'crypto';
import { db } from '../core';
import { printfulClient, PrintfulApiError, type PrintfulOrder, type PrintfulOrderFile } from './printful';
import { requireLiveCommerce } from '../runtime-config';
import { requireBuilderSnapshot } from '../../../shared/builderSnapshot';
import { requireFulfillmentProvider } from '../../../shared/fulfillmentSettings';
import { inspectGrfAsset } from '../../../shared/GRF_engine';
import { requireVerifiedPrintLayout } from '../../../shared/placements';
import { selectCatalogSaleVariant } from './catalog-sale-variants';
import { validatePacketComposition } from './assembly-store';
import { getCatalogInstancePrice, getSizeUpcharges, validateBrandLabel } from './pricing';
import { freezeProductionSource, prepareDynamicsOrderItems } from './dynamics-order';
import { MEMBER_PACKETS_COLLECTION, QR_DYNAMICS_INSTANCES_COLLECTION } from '../constants';

/** Freeze server-owned catalog data, never cart-supplied prices or provider IDs. */
export async function resolveSaleItem(cart: any, ownerBuild?: { packetId: string; ownerId: string }) {
  const c = cart.customization || {};
  const memberPacketId = c.memberPacketId;
  const instanceId = ownerBuild?.packetId || memberPacketId || c.instanceId || c.linkId || c.productId;
  if (typeof instanceId !== 'string' || !instanceId || instanceId.includes('/')) throw new Error('The cart item needs a saved catalog product.');
  if (!Number.isSafeInteger(cart.quantity) || cart.quantity <= 0) throw new Error('Choose a positive whole-number quantity.');
  const instance = (await db.collection(ownerBuild ? 'productPackets' : memberPacketId ? MEMBER_PACKETS_COLLECTION : 'admin_catalog_instances').doc(instanceId).get()).data();
  if (!instance || instance.isVisible === false || instance.isActive === false || ['archived', 'deleted'].includes(instance.status)) throw new Error('This catalog product is unavailable.');
  if (memberPacketId && instance.status !== 'published') throw new Error('This member product is not published.');
  if (ownerBuild && (instance.ownerType !== 'owner' || instance.ownerId !== ownerBuild.ownerId || instance.status !== 'ready')) throw new Error('This owner build is not ready for your checkout.');
  const packetId = ownerBuild ? instanceId : memberPacketId ? instance.productionPacketId : instance.currentPacketId;
  if (!packetId) throw new Error('Product has no saved production packet.');
  const packet = (await db.collection('productPackets').doc(packetId).get()).data();
  if (!packet) throw new Error('Production packet is missing.');
  if (memberPacketId && (packet.status !== 'published' || packet.memberId !== instance.memberId || packet.memberPacketId !== memberPacketId)) throw new Error('Member production ownership does not match.');
  const composition = await validatePacketComposition(db, packetId, packet);
  const snapshot = requireBuilderSnapshot(packet.builderSnapshot);
  const provider = requireFulfillmentProvider(snapshot.metadata.fulfillmentProvider);
  if (packet.fulfillmentProvider !== provider) throw new Error('Saved product provider differs from its production packet.');
  // Adapter availability is a capability check, never a default or a reroute.
  if (provider !== 'printful') throw new Error(`The ${provider} checkout handoff needs validation before this product can be sold. Select a Printful build or finish that integration.`);
  const masterId = snapshot.metadata.selectedProductDocId;
  const master = (await db.collection('master_catalog').doc(masterId).get()).data();
  if (!master || master.isActive === false) throw new Error('Product blank is unavailable.');
  validateBrandLabel(master, snapshot);
  const size = c.productSize, color = c.productColor;
  if (typeof size !== 'string' || !size || typeof color !== 'string' || !color) throw new Error('Choose a size and color.');
  const { key: variantKey, mapping } = selectCatalogSaleVariant(ownerBuild || memberPacketId ? { enabledColors: [packet.selectedColor], enabledSizes: [size] } : instance, master, provider, size, color);
  const files: PrintfulOrderFile[] = [];
  for (const placement of snapshot.layoutConfig.selectedPlacements) {
    const layout = snapshot.layoutConfig.providerLayouts?.[placement];
    const spec = requireVerifiedPrintLayout(master, placement, layout, Number(mapping.variantId));
    const target = spec.dimensions;
    const grfId = packet.placementGrfIds?.[placement];
    const asset = grfId ? (await db.collection('grf_assets').doc(grfId).get()).data() : null;
    const url = packet.placementGraphicUrls?.[placement];
    if (!asset || asset.isActive === false || inspectGrfAsset(asset).length || asset.grfId !== grfId || asset.publicUrl !== url || !/^https:\/\//.test(url)) throw new Error(`Registered print artwork is missing for ${placement}.`);
    if (files.some(file => file.type === spec.providerPlacementId)) throw new Error('Multiple files target the same print area.');
    files.push({ type: spec.providerPlacementId, url, position: { area_width: target.widthPx, area_height: target.heightPx, width: target.widthPx, height: target.heightPx, top: 0, left: 0 } });
  }
  if (!files.length) throw new Error('Product has no production artwork.');
  if (ownerBuild && (size !== packet.selectedShirtSize || color !== packet.selectedColor)) throw new Error('Checkout must use the reviewed size and color.');
  const price = ownerBuild ? Number(packet.pricing?.customerPrice) + Number(packet.pricing?.sizeUpcharges?.[size]) : memberPacketId ? Number(packet.pricing?.customerPrice) + ((await getSizeUpcharges())[size] ?? 0) : await getCatalogInstancePrice(instanceId, size);
  if (price === null || !Number.isFinite(price) || price <= 0) throw new Error('Product has no saved sale price.');
  const unitAmount = Math.round(price * 100);
  const productTitle = instance.resolved?.title || packet.adminCatalogTitle || packet.title;
  if (!productTitle) throw new Error('Product needs a saved title.');
  const dynamics = packet.composeInstanceId ? (await db.collection(QR_DYNAMICS_INSTANCES_COLLECTION).doc(packet.composeInstanceId).get()).data() : null;
  if (snapshot.qrConfig.qrProductState === 'qr_compose' && (!dynamics || dynamics.status !== 'active')) throw new Error('The QR Compose sequence is unavailable.');
  const frozenProduction = freezeProductionSource(packet, composition.assembly.qrgId);
  return { frozenProduction, cartItemId: cart.id, productId: instanceId, packetId, masterId, assemblyId: packet.assemblyId,
    qrExperience: { version: 2, sourceHash: frozenProduction.sourceHash, composeMode: dynamics?.composeMode || 'auto-rotate', slots: dynamics?.slots || [] },
    productCost: Number(packet.pricing?.subtotal || 0), creatorMemberId: memberPacketId ? instance.memberId : '',
    productTitle, quantity: cart.quantity, unitAmount, price: (unitAmount / 100).toFixed(2),
    customization: { productSize: size, productColor: color, instanceId, packetId },
    fulfillment: { provider, variantKey, productId: Number(mapping.productId), variantId: Number(mapping.variantId), files } };
}

export async function verifyProviderItems(items: Awaited<ReturnType<typeof resolveSaleItem>>[]) {
  const products = new Map<number, Awaited<ReturnType<typeof printfulClient.getProduct>>>();
  for (const item of items) {
    const id = item.fulfillment.productId;
    if (!products.has(id)) products.set(id, await printfulClient.getProduct(id));
    const product = products.get(id)!;
    const variant = product.variants?.find(v => v.id === item.fulfillment.variantId);
    if (!variant || variant.in_stock === false) throw new Error(`${item.productTitle}: the selected Printful variant is unavailable.`);
    const placements = product.product?.files;
    if (!Array.isArray(placements) || item.fulfillment.files.some(file => !placements.some(p => p.type === file.type))) throw new Error(`${item.productTitle}: Printful no longer supports a saved print placement. Refresh the build before selling it.`);
  }
}

function providerUpdates(remote: PrintfulOrder) {
  if (!remote?.id || !remote.status) throw new Error('Printful returned an incomplete order.');
  const states: Record<string, string> = { draft: 'paid', pending: 'routed', inprocess: 'in_production', partial: 'partially_shipped', fulfilled: 'shipped', failed: 'fulfillment_failed', canceled: 'cancelled', onhold: 'on_hold' };
  const shipments = remote.shipments || [];
  return { providerOrderId: String(remote.id), routedProvider: 'printful', providerStatus: remote.status,
    status: states[remote.status] || 'on_hold', shipments,
    trackingNumber: shipments[0]?.tracking_number || null, trackingUrl: shipments[0]?.tracking_url || null,
    carrier: shipments[0]?.carrier || null, lastSyncedAt: new Date().toISOString() };
}

/** One durable order ID also identifies the remote order; retries recover, never recreate. */
export async function fulfillOrder(orderId: string) {
  requireLiveCommerce('Order production');
  const ref = db.collection('orders').doc(orderId), token = randomUUID();
  const order = await db.runTransaction(async tx => {
    const value = (await tx.get(ref)).data();
    if (!value || value.checkoutVersion !== 1 || value.paymentStatus !== 'paid' || !value.paymentVerifiedAt) throw new Error('Order must have a verified payment and frozen checkout items.');
    if (value.fulfillmentState === 'submitted') return null;
    if (value.productionHold || value.status === 'cancelled' || value.status === 'refunded') throw new Error('Cancelled/refunded orders cannot enter production.');
    if (value.fulfillmentLeaseUntil > Date.now()) throw new Error('Fulfillment is already in progress. Retry shortly.');
    tx.update(ref, { fulfillmentLease: token, fulfillmentLeaseUntil: Date.now() + 120000, fulfillmentState: 'submitting', fulfillmentError: null });
    return value;
  });
  if (!order) return { success: true, alreadySubmitted: true };
  const release = async (updates: Record<string, any>) => db.runTransaction(async tx => {
    const latest = (await tx.get(ref)).data();
    if (latest?.fulfillmentLease !== token) throw new Error('Fulfillment lease changed; refresh this order before retrying.');
    tx.update(ref, { ...updates, ...(latest.productionHold ? { status: latest.status, fulfillmentError: 'Payment changed while provider work was in progress; review the provider order.' } : {}), fulfillmentLease: null, fulfillmentLeaseUntil: 0, updatedAt: new Date().toISOString() });
  });
  try {
    await assertProductionPayment(order);
    const items = (await db.collection('orderItems').where('orderId', '==', orderId).get()).docs.map(d => d.data());
    if (!items.length || items.some(item => item.fulfillment?.provider !== 'printful')) throw new Error('Order has missing or unsupported provider items.');
    const address = order.shippingAddress;
    if (!address?.name || !address.address1 || !address.city || !address.zip || !address.country) throw new Error('A complete shipping address is required.');
    let remote: PrintfulOrder | null = null;
    try { remote = await printfulClient.getOrder(`@${orderId}`); }
    catch (error) { if (!(error instanceof PrintfulApiError) || error.status !== 404) throw error; }
    if (!remote) {
      const individualItems = await prepareDynamicsOrderItems(orderId, order.userId, async () => {
        await db.runTransaction(async tx => {
          const current = (await tx.get(ref)).data();
          if (current?.paymentStatus !== 'paid' || current?.productionHold) throw new Error('Payment changed during production preparation.');
          if (current?.fulfillmentLease !== token) throw new Error('Fulfillment lease changed; retry this order.');
          tx.update(ref, { fulfillmentLeaseUntil: Date.now() + 120000 });
        });
      });
      await assertProductionPayment((await ref.get()).data());
      remote = await printfulClient.createOrder({ external_id: orderId,
      recipient: { name: address.name, address1: address.address1, address2: address.address2 || '', city: address.city,
        state_code: address.region || '', country_code: address.country, zip: address.zip, email: order.customerEmail || '', phone: address.phone || '' },
      items: individualItems });
    }
    if (remote.external_id !== orderId) throw new Error('Printful returned an order with a different external ID.');
    await ref.update({ providerOrderId: String(remote.id), routedProvider: 'printful', providerStatus: remote.status });
    if (remote.status === 'draft') {
      await assertProductionPayment((await ref.get()).data());
      remote = await printfulClient.confirmOrder(String(remote.id));
    }
    if (!['pending', 'inprocess', 'partial', 'fulfilled'].includes(remote.status)) throw new Error(`Printful order needs attention: ${remote.status}.`);
    await release({ ...providerUpdates(remote), fulfillmentState: 'submitted', fulfillmentError: null });
    return { success: true, providerOrderId: String(remote.id) };
  } catch (error: any) {
    await release({ fulfillmentState: 'failed', fulfillmentError: error.message });
    throw error;
  }
}

export async function syncFulfillment(orderId: string) {
  const ref = db.collection('orders').doc(orderId), order = (await ref.get()).data();
  if (!order || order.routedProvider !== 'printful' || !order.providerOrderId) throw new Error('No Printful order has been submitted.');
  const remote = await printfulClient.getOrder(String(order.providerOrderId));
  if (remote.external_id !== orderId) throw new Error('Provider order identity does not match.');
  return db.runTransaction(async tx => {
    const current = (await tx.get(ref)).data();
    if (!current || current.routedProvider !== 'printful' || String(current.providerOrderId) !== String(remote.id)) throw new Error('Provider order binding changed; refresh before syncing.');
    const updates = providerUpdates(remote);
    // A refund may arrive while the provider request is in flight. Keep its hold/status.
    if (current.productionHold || ['refunded', 'refund_review', 'cancelled'].includes(current.status) || ['refunded', 'partially_refunded'].includes(current.paymentStatus)) updates.status = typeof current.status === 'string' ? current.status : current.paymentStatus === 'refunded' ? 'refunded' : 'on_hold';
    tx.update(ref, updates);
    return updates;
  });
}
