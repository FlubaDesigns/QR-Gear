import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest';
import { database } from './composition-fixture';
import { parseGrfId } from '../../../../shared/GRF_engine';
const m = vi.hoisted(() => ({ db: null as any, composition: vi.fn(), payment: vi.fn() }));
vi.mock('../../core', () => ({ QR_GEAR_BRANDED_TAG_URL: 'https://files.example/brand.png', get db() { return m.db; }, admin: { firestore: { FieldValue: { serverTimestamp: () => "fixture-time" } } } }));
vi.mock('../assembly-store', () => ({ validatePacketComposition: m.composition }));
vi.mock('../fluba-provider-keys', () => ({ readFlubaProviderKey: async () => 'fixture' }));
vi.mock('stripe', () => ({ default: class { paymentIntents = { retrieve: m.payment }; } }));
// Storage/image/assembly adapters are covered separately; retain real per-unit allocation here.
vi.mock('../brand-label-artwork', () => ({ renderUnitBrandLabel: async () => Buffer.from('label-fixture') }));
vi.mock('../grf-registrar', () => ({ registerGrfAsset: async (input: any) => ({ publicUrl: `https://files.example/label-${input.packetId}.png` }), registerPacketGrfAssets: async () => ({}) }));
vi.mock('../bld-builder', () => ({ writeAutoAssembly: async () => ({}) }));
vi.mock('../qr-artwork', () => ({ personalizeQrArtwork: async () => Buffer.from('verified-unit-art') }));
import { printfulClient, PrintfulApiError } from '../printful';
import { fulfillOrder, syncFulfillment } from '../order-fulfillment';
import { prepareCartOrder, finalizeCartPayment, readCartQuote } from '../order-service';
import { saveBundle } from '../product-bundles';
import { saleItemProof } from '../product-proof';
vi.mock('../mockup-generator', () => ({ generateMockupFromPrintful: async () => ({ mockupUrl: 'https://files.example/review.png' }) }));
import { MEMBER_PACKETS_COLLECTION } from '../../constants';
let store: Map<string, any>;
const grfId = 'GRF-11442-000001';
const cart = { userId: 'buyer', quantity: 2, price: '0.01', customization: { productId: 'instance', productSize: 'M', productColor: 'Navy', printifyVariantId: 999, productName: 'Untrusted name' } };
const layout = { provider: 'printful', providerPlacementId: 'back', dimensions: { widthPx: 3600, heightPx: 4800, dpi: 300 } };
const insideLayout={provider:'printful',providerPlacementId:'label_inside',dimensions:{widthPx:900,heightPx:900,dpi:300}};
const insideId='GRF-11442-000002';
const payment = (id: string, extra = {}) => ({ id: 'cs_test', metadata: { source: 'direct_cart', orderId: id, userId: 'buyer' }, payment_status: 'paid', amount_total: 6800, currency: 'usd', payment_intent: 'pi_test',
  customer_details: { email: 'buyer@example.test', name: 'Test Buyer' }, shipping_details: { name: 'Test Buyer', address: { line1: '1 Test St', city: 'Test City', state: 'CA', postal_code: '90001', country: 'US' } }, ...extra } as any);
const getOrder = vi.spyOn(printfulClient, 'getOrder'), createOrder = vi.spyOn(printfulClient, 'createOrder'), confirmOrder = vi.spyOn(printfulClient, 'confirmOrder');
const getProduct = vi.spyOn(printfulClient, 'getProduct');
beforeEach(() => {
  vi.stubEnv('QRGEAR_ENVIRONMENT', 'production'); vi.stubEnv('GCLOUD_PROJECT', 'qrgear-c1ffd'); vi.resetAllMocks();
  const f = database({
    'cartItems/cart': cart, 'settings/admin': { defaultFulfillmentProvider: 'printify' },
    'testSettings/pricing': { sizeUpcharges: { M: 4 } },
    'admin_catalog_instances/instance': { currentPacketId: 'packet', enabledSizes: ['M'], enabledColors: ['Navy'], resolved: { title: 'Saved Navy Shirt', pricing: { customerPrice: 30 } } },
    'productPackets/packet': { qrContent: 'https://example.test', assemblyId: 'ASM-000001', fulfillmentProvider: 'printful', placementGrfIds: { back: grfId, label_inside:insideId }, placementGraphicUrls: { back: 'https://files.example/art.png', label_inside:'https://files.example/label.png' },
      builderSnapshot: { graphics: { content: { graphicLayoutMode: 'zone', qrSizePercent: 70 } }, qrConfig: { selectedColor: { name: 'Navy' } },
        metadata: { selectedProductDocId: 'qrg_11111', fulfillmentProvider: 'printful' }, layoutConfig: { selectedPlacements: ['back','label_inside'], providerLayouts: { back: layout, label_inside:insideLayout } } } },
    [`grf_assets/${insideId}`]:{...parseGrfId(insideId),grfId:insideId,publicUrl:'https://files.example/label.png'},
    [`grf_assets/${grfId}`]: { ...parseGrfId(grfId), grfId, publicUrl: 'https://files.example/art.png' },
    'master_catalog/qrg_11111': { qrgVariants: { '0403': { colorLabel: 'Navy', sizeLabel: 'M', providerVariants: { printful: { productId: 71, variantId: 123 } } } }, qrgPrintSpecs: { printful: { locations: [{ ...layout, id: 'back', verifiedVariantIds: [123] },{...insideLayout,id:'label_inside',verifiedVariantIds:[123]}] } } },
  }); m.db = f.db; store = f.store;
  m.db.batch = () => { const writes: Array<() => Promise<any>> = []; return { update: (ref: any, value: any) => writes.push(() => ref.update(value)), commit: async () => { for (const write of writes) await write(); } }; };
  m.composition.mockResolvedValue({ assembly: { qrgId: '11111' } });
  m.payment.mockImplementation(async () => { const order = [...store.entries()].find(([key]) => key.startsWith('orders/'))?.[1]; return { status: 'succeeded', amount_received: order.amountTotalCents, currency: 'usd', latest_charge: { id: 'ch_test', payment_intent: 'pi_test', paid: true, amount_refunded: 0 } }; });
  getOrder.mockRejectedValue(new PrintfulApiError(404, 'Not found'));
  getProduct.mockResolvedValue({ product: { files: [{ type: 'back' },{type:'label_inside'}] }, variants: [{ id: 123, in_stock: true }] } as any);
  createOrder.mockImplementation(async body => ({ id: 77, external_id: body.external_id, status: 'draft' }));
  confirmOrder.mockImplementation(async () => ({ id: 77, external_id: [...store.keys()].find(k => k.startsWith('orders/'))!.split('/')[1], status: 'pending' }));
});
afterEach(() => vi.unstubAllEnvs());
async function reviewedOrder(selection?: any, token?: string) {
  const quote = await readCartQuote('buyer', selection);
  const approvals = Object.fromEntries(await Promise.all(quote.items.map(async item => [item.cartItemId, { approved:true, proofId:(await saleItemProof(item)).proofId }])));
  return prepareCartOrder('buyer', '', selection, token || quote.quoteToken, approvals);
}
async function paidOrder() { const prepared = await reviewedOrder(); await finalizeCartPayment(payment(prepared.orderId)); return prepared; }
describe('Store sale to Printful production', () => {
  it('requires each buyer proof, invalidates changed selections, and freezes the approval with production', async () => {
    const quote = await readCartQuote('buyer');
    const proof = await saleItemProof(quote.items[0]);
    for (const approval of [undefined, {approved:false,proofId:proof.proofId}, {approved:true,proofId:'stale'}]) {
      await expect(prepareCartOrder('buyer', '', undefined, quote.quoteToken, {cart:approval})).rejects.toThrow('approve this proof');
      expect([...store.keys()].some(key => key.startsWith('orders/'))).toBe(false);
    }
    const prepared = await prepareCartOrder('buyer', '', undefined, quote.quoteToken, {cart:{approved:true,proofId:proof.proofId}});
    const approval = store.get(`orderItems/${prepared.orderId}_0`).proofApproval;
    expect(approval).toMatchObject({approved:true,approvedBy:'buyer',actorType:'customer',proofId:proof.proofId,method:'proof_checkbox',selectedColor:'Navy',selectedSize:'M'});
    expect(store.get(`orderProductionSources/${prepared.orderId}_0`).packet.proofApproval).toEqual(approval);
    expect(createOrder).not.toHaveBeenCalled();
  });
  it('quotes a published member product from the canonical member collection', async () => {
    store.set(`${MEMBER_PACKETS_COLLECTION}/member`, { status: 'published', memberId: 'seller', productionPacketId: 'packet' });
    Object.assign(store.get('productPackets/packet'), { status: 'published', memberId: 'seller', memberPacketId: 'member', title: 'Member shirt', selectedColor: 'Navy', pricing: { customerPrice: 30 } });
    store.get('cartItems/cart').customization.memberPacketId = 'member';
    const quote = await readCartQuote('buyer');
    expect(quote.amount).toBe(6800); expect(quote.items[0].productTitle).toBe('Member shirt');
    store.get('productPackets/packet').memberId = 'different-owner';
    await expect(readCartQuote('buyer')).rejects.toThrow('ownership does not match');
  });
  it('freezes real price, exact variant and artwork, pays and submits once despite webhook replay/cart edits', async () => {
    const { orderId, items, amount } = await reviewedOrder();
    expect(amount).toBe(6800); expect(items[0].productTitle).toBe('Saved Navy Shirt');
    expect(items[0].fulfillment).toMatchObject({ provider: 'printful', variantId: 123 });
    expect(m.composition).toHaveBeenCalledWith(m.db, 'packet', expect.anything());
    store.get('cartItems/cart').quantity = 9; store.get('productPackets/packet').placementGraphicUrls.back = 'https://files.example/edited.png';
    await finalizeCartPayment(payment(orderId)); await fulfillOrder(orderId);
    const production = createOrder.mock.calls[0][0];
    expect(production.external_id).toBe(orderId); expect(production.items).toHaveLength(2);
    for (const item of production.items) {
      expect(item).toMatchObject({ variant_id: 123, quantity: 1 });
      expect(item.files?.[0]).toMatchObject({ type: 'back', url: 'https://files.example/art.png', position: { area_width: 3600, area_height: 4800, width: 3600, height: 4800, top: 0, left: 0 } });
      expect(item.files?.[1]).toMatchObject({ type: 'label_inside', url: expect.stringMatching(/^https:\/\/files.example\/label-auto-/) });
    }
    expect(production.items[0].files?.[1].url).not.toBe(production.items[1].files?.[1].url);
    expect(store.get('orders/' + orderId)).toMatchObject({ paymentStatus: 'paid', fulfillmentState: 'submitted', providerOrderId: '77', status: 'routed' });
    await finalizeCartPayment(payment(orderId)); await fulfillOrder(orderId);
    expect(createOrder).toHaveBeenCalledTimes(1); expect(confirmOrder).toHaveBeenCalledTimes(1); expect(store.get('cartItems/cart').quantity).toBe(9);
  });
  it.each([{ payment_status: 'unpaid' }, { amount_total: 1 }, { currency: 'eur' }, { metadata: { source: 'direct_cart', userId: 'other', orderId: 'auto-1' } }])('rejects bad payment %j', async overrides => {
    const { orderId } = await reviewedOrder(); await expect(finalizeCartPayment(payment(orderId, overrides))).rejects.toThrow();
    await expect(fulfillOrder(orderId)).rejects.toThrow('verified payment'); expect(createOrder).not.toHaveBeenCalled();
  });
  it('clears purchased rows and preserves new cart rows', async () => {
    const { orderId } = await reviewedOrder(); store.set('cartItems/later', { ...cart });
    await finalizeCartPayment(payment(orderId)); expect(store.has('cartItems/cart')).toBe(false); expect(store.has('cartItems/later')).toBe(true);
  });
  it('recovers a draft after confirmation failure without a second create', async () => {
    const { orderId } = await paidOrder(); confirmOrder.mockRejectedValueOnce(new Error('temporary outage'));
    await expect(fulfillOrder(orderId)).rejects.toThrow('temporary outage');
    expect(store.get('orders/' + orderId)).toMatchObject({ fulfillmentState: 'failed', fulfillmentError: 'temporary outage', providerOrderId: '77' });
    getOrder.mockResolvedValue({ id: 77, external_id: orderId, status: 'draft' });
    await fulfillOrder(orderId); expect(createOrder).toHaveBeenCalledTimes(1); expect(confirmOrder).toHaveBeenCalledTimes(2);
  });
  it('recovers a timed-out create by external ID', async () => {
    const { orderId } = await paidOrder(); createOrder.mockRejectedValueOnce(new Error('timeout after create'));
    await expect(fulfillOrder(orderId)).rejects.toThrow('timeout'); getOrder.mockResolvedValue({ id: 77, external_id: orderId, status: 'pending' });
    await fulfillOrder(orderId); expect(createOrder).toHaveBeenCalledTimes(1); expect(confirmOrder).not.toHaveBeenCalled();
  });
  it('does not create after auth/network lookup failure or during an active lease', async () => {
    const { orderId } = await paidOrder(); getOrder.mockRejectedValue(new PrintfulApiError(401, 'Unauthorized'));
    await expect(fulfillOrder(orderId)).rejects.toThrow('Unauthorized'); expect(createOrder).not.toHaveBeenCalled();
    store.get('orders/' + orderId).fulfillmentLeaseUntil = Date.now() + 10000; await expect(fulfillOrder(orderId)).rejects.toThrow('already in progress');
  });
  it('never calls a commerce provider in sandbox', async () => {
    const { orderId } = await paidOrder(); vi.stubEnv('QRGEAR_ENVIRONMENT', 'sandbox');
    await expect(fulfillOrder(orderId)).rejects.toThrow('disabled'); expect(getOrder).not.toHaveBeenCalled();
  });
  it('syncs shipments and status to the same order', async () => {
    const { orderId } = await paidOrder(); await fulfillOrder(orderId);
    getOrder.mockResolvedValue({ id: 77, external_id: orderId, status: 'fulfilled', shipments: [{ carrier: 'USPS', tracking_number: 'track-1', tracking_url: 'https://tracking.example/1' }] });
    await syncFulfillment(orderId); expect(store.get('orders/' + orderId)).toMatchObject({ status: 'shipped', trackingNumber: 'track-1', trackingUrl: 'https://tracking.example/1' });
  });
  it.each(['price', 'variant', 'artwork', 'layout', 'inside-label', 'disabled-color', 'provider', 'composition'])('blocks invalid %s before checkout', async issue => {
    if (issue === 'inside-label') store.get('productPackets/packet').builderSnapshot.layoutConfig.selectedPlacements=['back'];
    if (issue === 'price') store.get('admin_catalog_instances/instance').resolved.pricing = {};
    if (issue === 'variant') store.get('master_catalog/qrg_11111').qrgVariants = {};
    if (issue === 'artwork') store.get('productPackets/packet').placementGraphicUrls = {};
    if (issue === 'layout') store.get('master_catalog/qrg_11111').qrgPrintSpecs.printful.locations = [];
    if (issue === 'disabled-color') store.get('admin_catalog_instances/instance').enabledColors = ['Black'];
    if (issue === 'provider') store.get('productPackets/packet').builderSnapshot.metadata.fulfillmentProvider = 'printify';
    if (issue === 'composition') m.composition.mockRejectedValue(new Error('Assembly is not linked'));
    await expect(prepareCartOrder('buyer')).rejects.toThrow(); expect([...store.keys()].some(key => key.startsWith('orders/'))).toBe(false); expect(createOrder).not.toHaveBeenCalled();
  });
});

describe('reviewed bundle orders', () => {
  it('freezes the discounted amount and verifies payment against that snapshot', async () => {
    store.set('admin_catalog_instances/second', { ...structuredClone(store.get('admin_catalog_instances/instance')), resolved: { title: 'Second shirt', pricing: { customerPrice: 44.83 } } });
    store.set('cartItems/second', { ...structuredClone(cart), quantity: 1, customization: { ...cart.customization, productId: 'second' } });
    const bundle = await saveBundle(m.db, { name: 'Pair', bundleType: 'fixed', pricingType: 'discount_percent', discountPercent: 10,
      items: [{ catalogInstanceId: 'instance', quantity: 1 }, { catalogInstanceId: 'second', quantity: 1 }] });
    const selection = { bundleId: bundle.id }; const quote = await readCartQuote('buyer', selection);
    expect(quote.amount).toBe(10935); expect(quote.subtotalCents).toBe(11683);
    const prepared = await reviewedOrder(selection, quote.quoteToken);
    expect(store.get('orders/' + prepared.orderId).bundle.discountCents).toBe(748);
    expect(prepared.items.reduce((sum, item) => sum + item.lineTotalCents, 0)).toBe(10935);
    await saveBundle(m.db, { discountPercent: 90 }, bundle.id);
    await expect(finalizeCartPayment(payment(prepared.orderId, { amount_total: 11683 }))).rejects.toThrow();
    await finalizeCartPayment(payment(prepared.orderId, { amount_total: 10935 }));
    expect(store.get('orders/' + prepared.orderId)).toMatchObject({ paymentStatus: 'paid', bundle: { discountCents: 748 } });
  });
  it('rejects a stale review before creating an order', async () => {
    const quote = await readCartQuote('buyer'); store.get('cartItems/cart').quantity = 3;
    await expect(prepareCartOrder('buyer', '', undefined, quote.quoteToken)).rejects.toThrow('changed');
    expect([...store.keys()].some(key => key.startsWith('orders/'))).toBe(false);
  });
});

it('a signed-in quantity-two hosted purchase allocates two emailed codes with no running term', async () => {
  const packet = store.get('productPackets/packet');
  packet.qrContent = 'https://qrgear.com/m/source';
  packet.builderSnapshot.qrConfig.qrProductState = 'qr_canvas';
  packet.builderSnapshot.graphics.content.hostingTierCode = '1_year';
  const prepared = await paidOrder();
  await fulfillOrder(prepared.orderId);
  const units = [...store.entries()].filter(([key]) => key.startsWith('qr_dynamics_instances/')).map(([, value]) => value);
  expect(units).toHaveLength(2);
  expect(new Set(units.map(unit => unit.qrgBaseCode)).size).toBe(2);
  expect(new Set(units.map(unit => unit.claimCode)).size).toBe(2);
  for (const unit of units) {
    expect(unit).toMatchObject({ ownerId: null, claimedAt: null, hostingExpiresAt: null, hostingTierCode: '1_year', status: 'active' });
    expect(store.get('claimCodes/' + unit.claimCode).instanceId).toBe(unit.instanceId);
  }
  getOrder.mockResolvedValue({ id: 77, external_id: prepared.orderId, status: 'pending' });
  await fulfillOrder(prepared.orderId);
  expect([...store.keys()].filter(key => key.startsWith('qr_dynamics_instances/'))).toHaveLength(2);
});

it('uses the selected method area for production and rejects a stale template or another placement of the same method', async () => {
  const master = store.get('master_catalog/qrg_11111');
  const packet = store.get('productPackets/packet');
  const dtf = { method: 'dtf', providerName: 'back_dtf', technique: 'DTFILM', dimensions: { widthPx: 1500, heightPx: 600, dpi: 300 }, verifiedVariantIds: [123], printfileIds: { '123': 9 } };
  master.qrgPrintSpecs.printful.locations[0].methods = [{ method: 'dtg', providerName: 'back', ...layout }, dtf];
  packet.builderSnapshot.layoutConfig.providerLayouts.back = { provider: 'printful', providerPlacementId: 'back_dtf', ...dtf };
  const quote = await readCartQuote('buyer');
  expect(quote.items[0].fulfillment.files[0]).toMatchObject({ type: 'back_dtf', position: { area_width: 1500, area_height: 600 } });
  packet.builderSnapshot.layoutConfig.providerLayouts.back.printfileIds = { '123': 8 };
  await expect(readCartQuote('buyer')).rejects.toThrow('Refresh and regenerate');
  packet.builderSnapshot.layoutConfig.providerLayouts.back.printfileIds = { '123': 9 };
  packet.builderSnapshot.layoutConfig.providerLayouts.back.providerPlacementId = 'front_dtf';
  await expect(readCartQuote('buyer')).rejects.toThrow('Refresh and regenerate');
});
