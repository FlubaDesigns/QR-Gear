import { readFlubaProviderKey } from './fluba-provider-keys';
import { isSandboxRuntime, requireLiveCommerce } from '../runtime-config';
import { db } from '../core';

  // ============ PRINTFUL CLIENT (No Replit Dependencies) ============

const PRINTFUL_API_BASE = 'https://api.printful.com';

let _cachedPrintfulStoreId: string | null = null;
const PRINTFUL_KEY_CACHE_TTL = 60000;
async function getPrintfulApiKeyAsync(mockupOnly = false): Promise<string> {
  if (!mockupOnly) requireLiveCommerce('Printful requests');
  const key = await readFlubaProviderKey('PRINTFUL_API_KEY');
  if (!key) throw Object.assign(new Error('Printful is not configured in Fluba'), {status:503});
  const doc = await db.collection('system_config').doc('api_keys').get();
  _cachedPrintfulStoreId = doc.data()?.printfulStoreId ? String(doc.data()!.printfulStoreId) : null;
  return key;
}
const getPrintfulApiKey = getPrintfulApiKeyAsync;
const getPrintfulApiKeyFromFirestore = getPrintfulApiKeyAsync;

// Get Printful Store ID - fallback for Cloud Functions environment
function getPrintfulStoreId(): string {
  return _cachedPrintfulStoreId || process.env.PRINTFUL_STORE_ID || '';
}

interface PrintfulMockupTask {
  task_key: string;
  status: 'pending' | 'completed' | 'failed';
  mockups?: { placement: string; variant_ids: number[]; mockup_url: string; extra?: any[] }[];
  error?: string;
}

interface PrintfulVariant {
  id: number;
  product_id: number;
  name: string;
  size: string;
  color: string;
  color_code: string;
  image: string;
  price: string;
  in_stock: boolean;
}

export interface PrintfulOrderFile {
  type: string; url: string;
  position: { area_width: number; area_height: number; width: number; height: number; top: number; left: number };
}
export interface PrintfulOrder {
  id: number; external_id: string; status: string;
  shipments?: Array<{ carrier: string; tracking_number: string; tracking_url: string; shipped_at?: number; delivered_at?: number }>;
}
export class PrintfulApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

class PrintfulClient {
  private async getHeaders(mockupOnly = false) {
    const key = await getPrintfulApiKeyAsync(mockupOnly);
    return {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json',
      ...(getPrintfulStoreId() ? { 'X-PF-Store-Id': getPrintfulStoreId() } : {}),
    };
  }

  get isConfigured(): Promise<boolean> { return this.checkConfigured(); }

  private async checkConfigured(): Promise<boolean> {
    if (isSandboxRuntime()) return false;
    return !!(await readFlubaProviderKey('PRINTFUL_API_KEY'));
  }

  private async request<T>(method: string, endpoint: string, body?: any): Promise<T> {
    const mockupOnly = (method === 'GET' && /^\/products(?:\/\d+)?$/.test(endpoint)) ||
      (method === 'GET' && /^\/mockup-generator\/printfiles\/\d+(?:\?|$)/.test(endpoint)) ||
      (method === 'POST' && /^\/mockup-generator\/create-task\/\d+(?:\?|$)/.test(endpoint)) ||
      (method === 'GET' && endpoint.startsWith('/mockup-generator/task?'));
    if (!mockupOnly) requireLiveCommerce('Printful catalog or commerce request');
    const url = `${PRINTFUL_API_BASE}${endpoint}`;
    const headers = await this.getHeaders(mockupOnly);
    const options: RequestInit = { method, headers };
    if (body) options.body = JSON.stringify(body);
    for (let attempt = 0; ; attempt++) {
      const response = await fetch(url, { ...options, signal: AbortSignal.timeout(30000) });
      if (response.ok) {
        const data = await response.json();
        return data.result as T;
      }
      const errorText = await response.text();
      // Retry only rejected catalog/mockup work. Order writes retain their
      // existing reconciliation policy and are never replayed here.
      if (mockupOnly && response.status === 429 && attempt < 2) {
        const retryAfter = response.headers?.get('Retry-After');
        const seconds = retryAfter !== null && retryAfter !== undefined && retryAfter !== ''
          ? Number(retryAfter) : Number(errorText.match(/try again after (\d+) seconds?/i)?.[1] ?? 60);
        if (Number.isFinite(seconds) && seconds >= 0 && seconds <= 60) {
          const delay = Math.max(1000, seconds * 1000) + 250 + Math.floor(Math.random() * 500);
          console.warn('[Printful] Rate limited; retrying', method, endpoint.split('?')[0], 'after', delay, 'ms');
          await new Promise(resolve => setTimeout(resolve, delay));
          continue;
        }
      }
      throw new PrintfulApiError(response.status, `Printful API error: ${response.status} - ${errorText}`);
    }
  }

  async createOrder(body: { external_id: string; recipient: Record<string, string>; items: Array<{ variant_id: number; quantity: number; files: PrintfulOrderFile[] }> }): Promise<PrintfulOrder> {
    return this.request('POST', '/orders?confirm=false', body);
  }

  async getOrder(id: string): Promise<PrintfulOrder> {
    return this.request('GET', `/orders/${encodeURIComponent(id)}`);
  }

  async confirmOrder(id: string): Promise<PrintfulOrder> {
    return this.request('POST', `/orders/${encodeURIComponent(id)}/confirm`);
  }

  async getProduct(productId: number): Promise<{ product: any; variants: PrintfulVariant[] }> {
    return this.request<{ product: any; variants: PrintfulVariant[] }>('GET', `/products/${productId}`);
  }

  async getCatalogProducts(): Promise<any[]> {
    return this.request<any[]>('GET', '/products');
  }

  async getPrintfiles(productId: number, technique?: string): Promise<any> {
    const storeId = getPrintfulStoreId();
    const query = new URLSearchParams();
    if (storeId) query.set('store_id', storeId);
    if (technique) query.set('technique', technique);
    return this.request<any>('GET', `/mockup-generator/printfiles/${productId}${query.size ? '?' + query : ''}`);
  }

  async getVariantsByColor(productId: number, colorName: string): Promise<PrintfulVariant[]> {
    const productData = await this.getProduct(productId);
    console.log(`[Printful] Product ${productId} has ${productData?.variants?.length || 0} variants`);
    
    if (!productData?.variants || productData.variants.length === 0) {
      console.log(`[Printful] No variants found for product ${productId}`);
      return [];
    }
    
    const lowerColor = colorName.toLowerCase().replace(/^solid\s+/i, '').trim();
    console.log(`[Printful] Searching for color: "${lowerColor}" in product ${productId}`);
    
    // First try exact and partial matches
    let matches = productData.variants.filter(v => 
      v.color.toLowerCase() === lowerColor || 
      v.color.toLowerCase().includes(lowerColor) ||
      lowerColor.includes(v.color.toLowerCase()) ||
      v.name.toLowerCase().includes(lowerColor)
    );
    
    console.log(`[Printful] Found ${matches.length} exact matches for color "${colorName}"`);
    
    // If no matches and we have variants, fall back to first variant
    if (matches.length === 0 && productData.variants.length > 0) {
      console.log(`[Printful] No exact color match for "${colorName}" in product ${productId}, using first variant: ${productData.variants[0].color}`);
      matches = [productData.variants[0]];
    }
    
    return matches;
  }

  async createMockupTask(
    productId: number,
    variantIds: number[],
    files: Array<{ placement: string; image_url: string; position?: any }>,
    format: 'jpg' | 'png' = 'jpg',
    optionGroups?: string[]
  ): Promise<PrintfulMockupTask> {
    const body: any = { variant_ids: variantIds, format, files };
    if (optionGroups?.length) body.option_groups = optionGroups;
    const storeId = getPrintfulStoreId();
    const storeParam = storeId ? `?store_id=${storeId}` : '';
    console.log('[Printful] Creating mockup task for product', productId, 'store_id:', storeId, 'variant_ids:', variantIds);
    console.log('[Printful] Request body:', JSON.stringify(body));
    return this.request<PrintfulMockupTask>('POST', `/mockup-generator/create-task/${productId}${storeParam}`, body);
  }

  async getMockupTaskResult(taskKey: string): Promise<PrintfulMockupTask> {
    const storeId = getPrintfulStoreId();
    const storeParam = storeId ? `&store_id=${storeId}` : '';
    return this.request<PrintfulMockupTask>('GET', `/mockup-generator/task?task_key=${encodeURIComponent(taskKey)}${storeParam}`);
  }

  async waitForMockupTask(taskKey: string, maxWaitMs: number = 60000): Promise<PrintfulMockupTask> {
    const startTime = Date.now();
    while (Date.now() - startTime < maxWaitMs) {
      const result = await this.getMockupTaskResult(taskKey);
      if (result.status === 'completed') return result;
      if (result.status === 'failed') throw new Error(`Printful mockup failed: ${result.error}`);
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    throw new Error(`Printful mockup task timed out after ${maxWaitMs}ms`);
  }
}

const printfulClient = new PrintfulClient();


export function updatePrintfulKeyCache(_apiKey: string): never {
  throw Object.assign(new Error('Manage provider keys in Fluba Cortex.'), {status:409});
}

export { printfulClient, PrintfulClient, getPrintfulApiKey, getPrintfulApiKeyAsync, getPrintfulApiKeyFromFirestore, getPrintfulStoreId, PRINTFUL_API_BASE, PRINTFUL_KEY_CACHE_TTL };
export type { PrintfulMockupTask, PrintfulVariant };
