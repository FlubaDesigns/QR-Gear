# QR Gear — Complete Route Map

## Frontend Routes (Client-Side)

### Public Pages
| Route | Component | Description |
|-------|-----------|-------------|
| `/` | Home | Landing page |
| `/store` | Store | Product storefront |
| `/gallery` | Gallery | Product gallery |
| `/cart` | Cart | Shopping cart |
| `/build` | BuildPage | Product builder |
| `/build/success` | BuildSuccess | Build confirmation |
| `/earn` | EarnPage | Earn/affiliate page |
| `/checkout` | Checkout | Checkout flow |
| `/checkout/success` | CheckoutSuccess | Checkout confirmation |
| `/customize` | Customize | Product customization |
| `/login` | Login | Login page |
| `/register` | Register | Registration page |
| `/gifts` | GiftShop | Gift shop |
| `/gift/redeem` | GiftRedeem | Gift redemption |
| `/gift/redeem/:code` | GiftRedeem | Gift redemption with code |
| `/widget` | Widget | Embeddable widget |
| `/account` | Account | User account |
| `/privacy` | PrivacyPolicy | Privacy policy |
| `/terms` | TermsOfService | Terms of service |
| `/logo-preview` | LogoPreview | Logo preview tool |

### Dynamic Public Pages
| Route | Component | Description |
|-------|-----------|-------------|
| `/view/:id` | ViewImage | View image |
| `/dynamic/:slug` | ViewDynamic | Dynamic QR resolution |
| `/customs/:id` | Customs | Custom design viewer |
| `/p/:id` | Packet | Product packet view |
| `/play/:packetId` | PlayLanding | Play surface landing |
| `/i/:slug` | ProductLanding | Product landing (image) |
| `/e/:slug` | ProductLanding | Product landing (experience) |
| `/m/:slug` | ProductLanding | Product landing (member) |
| `/renew/:instanceId` | RenewPage | Renewal page |
| `/renew/:instanceId/success` | RenewPage | Renewal success |
| `/claim/:claimCode` | ClaimPage | Claim code page |
| `/shop/:storeType/:storeName` | ShopSegment | Shop segment |
| `/shop/:storeType/:storeName/:segment` | ShopSegment | Shop sub-segment |

### Protected Member Pages
| Route | Component | Auth |
|-------|-----------|------|
| `/members` | Members | ProtectedRoute |
| `/member` | Member | ProtectedRoute |

### Admin Pages (AdminRoute = ProtectedRoute + AdminAuthProvider)
| Route | Component | Auth |
|-------|-----------|------|
| `/admin` | Admin | AdminRoute |
| `/admin/products` | AdminProducts | AdminRoute |
| `/admin/pricing` | AdminPricing | AdminRoute |
| `/admin/library` | LibraryPage | AdminRoute |
| `/admin/videos` | AdminVideos | AdminRoute |
| `/admin/categories` | AdminCategories | AdminRoute |
| `/admin/tags` | AdminTags | AdminRoute |
| `/admin/partners` | AdminPartners | AdminRoute |
| `/admin/orchestration` | AdminOrchestration | AdminRoute |
| `/admin/orders` | AdminOrders | AdminRoute |
| `/admin/gifts` | AdminGifts | AdminRoute |
| `/admin/dashboard` | AdminDashboard | AdminRoute |
| `/admin/coupons` | AdminCoupons | AdminRoute |
| `/admin/health` | AdminHealth | AdminRoute |
| `/admin/customers` | AdminCustomers | AdminRoute |
| `/admin/email-templates` | AdminEmailTemplates | AdminRoute |
| `/admin/email-health` | AdminEmailHealth | AdminRoute |
| `/admin/manual` | AdminManual | AdminRoute |
| `/admin/sales/build` | StoreBuild | AdminRoute |
| `/admin/dynamics` | AdminDynamics | AdminRoute |
| `/admin/store-builder` | AdminStoreBuilder | AdminRoute |
| `/admin/store-library` | AdminStoreLibrary | AdminRoute |
| `/admin/ar-demo` | AdminARDemo | AdminRoute |
| `/admin/fonts` | FontManagement | AdminRoute |

### SEO / Marketing Landing Pages
| Route | Component |
|-------|-----------|
| `/qr-basics` | QRBasics |
| `/qr-plus` | QRPlus |
| `/qr-canvas` | QRCanvas |
| `/qr-play` | QRPlay |
| `/qr-dynamics` | QRDynamics |
| `/qr-history` | QRHistory |
| `/wedding-qr-shirts` | WeddingQRShirts |
| `/family-reunion-shirts` | FamilyReunionShirts |
| `/artist-qr-apparel` | ArtistQRApparel |
| `/memorial-qr-gifts` | MemorialQRGifts |
| `/musician-merch` | MusicianMerch |
| `/website-qr-shirts` | WebsiteQRShirts |
| `/office-qr-mug` | OfficeQRMug |
| `/lost-found-qr` | LostFoundQR |
| `/networking-qr-shirts` | NetworkingQRShirts |
| `/medical-alert-qr` | MedicalAlertQR |
| `/personal-items-qr` | PersonalItemsQR |
| `/event-qr-shirts` | EventQRShirts |
| `/everyday-qr` | EverydayQR |
| `/business-qr-plus` | BusinessQRPlus |
| `/memorial-video-shirts` | MemorialVideoShirts |
| `/family-video-messages` | FamilyVideoMessages |
| `/video-time-capsule` | VideoTimeCapsule |
| `/advent-qr-shirts` | AdventQRShirts |
| `/band-dynamic-merch` | BandDynamicMerch |
| `/realtor-qr-shirts` | RealtorQRShirts |
| `/business-analytics-qr` | BusinessAnalyticsQR |

---

## Backend API Routes (Server-Side)

### Auth Routes (`auth.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/auth/login` | Public |
| POST | `/api/auth/register` | Public |
| GET | `/api/auth/me` | Authenticated |

### Admin — Products & Catalog (`admin.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/products` | Admin |
| PATCH | `/api/admin/products/:id` | Admin |
| PATCH | `/api/admin/products/:id/toggle` | Admin |
| PATCH | `/api/admin/products/:id/options` | Admin |
| DELETE | `/api/admin/products/:id` | Admin |
| POST | `/api/admin/products/:id/regenerate-mockups` | Admin |
| POST | `/api/admin/products/:id/generate-all-mockups` | Admin |
| POST | `/api/admin/products/apply-costs` | Admin |
| GET | `/api/admin/products/:id/variants` | Admin |
| PATCH | `/api/admin/variants/:id/toggle` | Admin |
| GET | `/api/admin/fulfillment-providers` | Admin |
| GET | `/api/admin/settings` | Admin |
| PUT | `/api/admin/settings` | Admin |
| GET | `/api/admin/printify/blueprints` | Admin |
| GET | `/api/admin/printify/catalog` | Admin |
| GET | `/api/admin/printify/catalog/:blueprintId` | Admin |
| POST | `/api/admin/printify/catalog/batch-details` | Admin |
| GET | `/api/admin/printify/blueprints/:id/providers` | Admin |
| GET | `/api/admin/printify/blueprints/:blueprintId/providers/:providerId/variants` | Admin |
| GET | `/api/admin/catalog/blueprints` | Admin |
| GET | `/api/admin/catalog/blueprints/:id` | Admin |
| GET | `/api/admin/catalog/providers/:blueprintId/:providerId` | Admin |
| GET | `/api/admin/catalog/sync-status` | Admin |
| GET | `/api/admin/catalog/sync-history` | Admin |
| POST | `/api/admin/catalog/sync` | Admin |
| DELETE | `/api/admin/catalog/clear` | Admin |
| POST | `/api/admin/catalog/fetch-costs` | Admin |
| POST | `/api/admin/catalog/sync-all-costs` | Admin |
| GET | `/api/admin/catalog/cost-sync-status` | Admin |
| POST | `/api/admin/catalog/cancel-cost-sync` | Admin |
| POST | `/api/admin/catalog/refresh-color-hex` | Admin |
| POST | `/api/admin/catalog/sync-printful` | Admin |
| GET | `/api/admin/catalog/printful-status` | Admin |
| GET | `/api/admin/catalog/printful-products` | Admin |

### Admin — Pricing (`pricing.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/pricing-rules` | Admin |
| POST | `/api/admin/pricing-rules` | Admin |
| PUT | `/api/admin/pricing-rules/:id` | Admin |
| DELETE | `/api/admin/pricing-rules/:id` | Admin |
| GET | `/api/admin/hosting-tiers` | Admin |
| POST | `/api/admin/hosting-tiers` | Admin |
| PUT | `/api/admin/hosting-tiers/:id` | Admin |
| DELETE | `/api/admin/hosting-tiers/:id` | Admin |
| POST | `/api/admin/hosting-tiers/seed` | Admin |

### Admin — Packets (`packets.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/admin/packets` | Admin |
| GET | `/api/admin/packets` | Admin |
| PATCH | `/api/admin/packets/:packetId` | Admin |
| DELETE | `/api/admin/packets/:packetId` | Admin |

### Admin — Library (`admin-library.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/library` | Admin |
| GET | `/api/admin/library/admin` | Admin |
| GET | `/api/admin/library/templates` | Admin |
| GET | `/api/admin/library/:id` | Admin |
| POST | `/api/admin/library/upload` | Admin |
| GET | `/api/admin/template-categories` | Admin |
| GET | `/api/admin/template-categories/by-parent` | Admin |
| POST | `/api/admin/template-categories` | Admin |
| PUT | `/api/admin/template-categories/:id` | Admin |
| DELETE | `/api/admin/template-categories/:id` | Admin |
| GET | `/api/admin/graphic-sets` | Admin |
| GET | `/api/admin/graphic-sets/:id` | Admin |
| GET | `/api/admin/graphic-sets/category/:categoryId` | Admin |
| POST | `/api/admin/graphic-sets` | Admin |
| PUT | `/api/admin/graphic-sets/:id` | Admin |
| DELETE | `/api/admin/graphic-sets/:id` | Admin |
| POST | `/api/admin/graphic-sets/:id/use` | Admin |
| POST | `/api/admin/graphics/save` | Admin |
| GET | `/api/admin/images` | Admin |
| POST | `/api/admin/content/upload` | Admin |
| GET | `/api/admin/background-assets` | Admin |
| POST | `/api/admin/background-assets` | Admin |
| DELETE | `/api/admin/background-assets/:id` | Admin |
| POST | `/api/admin/background-assets/sync` | Admin |
| POST | `/api/admin/background-assets/migrate` | Admin |
| GET | `/api/admin/fonts` | Admin |

### Admin — Orchestration (`orchestration.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/orchestration/master-products` | Admin |
| GET | `/api/admin/orchestration/master-products/:id` | Admin |
| POST | `/api/admin/orchestration/master-products` | Admin |
| PUT | `/api/admin/orchestration/master-products/:id` | Admin |
| DELETE | `/api/admin/orchestration/master-products/:id` | Admin |
| GET | `/api/admin/orchestration/master-products/:id/design-versions` | Admin |
| GET | `/api/admin/orchestration/master-products/:id/publish-states` | Admin |
| GET | `/api/admin/orchestration/bundles` | Admin |
| POST | `/api/admin/orchestration/bundles` | Admin |
| PUT | `/api/admin/orchestration/bundles/:id` | Admin |
| DELETE | `/api/admin/orchestration/bundles/:id` | Admin |
| PATCH | `/api/admin/orchestration/bundles/:id/toggle` | Admin |
| POST | `/api/admin/orchestration/bulk-publish` | Admin |
| GET | `/api/admin/orchestration/bulk-publish/:jobId` | Admin |
| GET | `/api/admin/orchestration/bulk-publish-jobs` | Admin |
| GET | `/api/admin/orchestration/channel-configs` | Admin |
| PUT | `/api/admin/orchestration/channel-configs/:channelType` | Admin |
| GET/POST | `/api/admin/orchestration/profit/*` | Admin |
| GET/POST | `/api/admin/orchestration/repricing/*` | Admin |
| GET/POST | `/api/admin/orchestration/routing/*` | Admin |
| GET | `/api/admin/orchestration/provider-health` | Admin |
| POST | `/api/admin/orchestration/provider-health/check` | Admin |
| GET | `/api/admin/orchestration/qr-analytics/*` | Admin |

### Admin — Orders (`admin.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/orders-unified` | Admin |
| GET | `/api/admin/orders-unified/:id` | Admin |
| PUT | `/api/admin/orders-unified/:id` | Admin |

### Admin — Gifts (`gifts.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/gifts/packages` | Admin |
| POST | `/api/admin/gifts/packages` | Admin |
| PATCH | `/api/admin/gifts/packages/:id` | Admin |
| DELETE | `/api/admin/gifts/packages/:id` | Admin |
| GET | `/api/admin/gifts/codes` | Admin |
| GET | `/api/admin/gifts/redemptions` | Admin |
| PATCH | `/api/admin/gifts/redemptions/:id` | Admin |

### Admin — Coupons, Customers, Dashboard, Health, Email
| Method | Endpoint | Auth |
|--------|----------|------|
| GET/POST | `/api/admin/coupons` | Admin |
| PUT/DELETE | `/api/admin/coupons/:id` | Admin |
| GET | `/api/admin/customers` | Admin |
| GET | `/api/admin/customers/:id` | Admin |
| GET | `/api/admin/dashboard/metrics` | Admin |
| GET | `/api/admin/health` | Admin |
| GET | `/api/admin/email-templates` | Admin |
| PUT | `/api/admin/email-templates/:id` | Admin |
| GET | `/api/admin/email-logs` | Admin |
| GET/POST | `/api/admin/nexusmail/*` | Admin |

### Admin — Dynamics & Compose
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/admin/dynamics/surfaces` | Admin |
| POST | `/api/admin/compose/publish` | Admin |

### Admin — Mockups
| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/admin/mockups/pre-generate` | Admin |
| POST | `/api/admin/mockup/priority` | Admin |
| POST | `/api/admin/mockup-jobs/worker/:action` | Admin |

### Admin — Stores & Channels
| Method | Endpoint | Auth |
|--------|----------|------|
| GET/POST | `/api/admin/channel-items/seed` | Admin |
| POST | `/api/admin/channel-items/:itemId/regenerate-assets` | Admin |
| GET/POST | `/api/admin/collections/:collectionId/items` | Admin |
| DELETE | `/api/admin/collections/:collectionId/items/:itemId` | Admin |
| PUT | `/api/admin/collections/:collectionId/items/reorder` | Admin |

### Public API Routes
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/public/packets` | Public |
| GET | `/api/public/packets/:packetId` | Public |
| PATCH | `/api/public/packets/:tempPacketId` | Public |
| POST | `/api/public/packets/:tempPacketId/complete` | Public |
| DELETE | `/api/public/packets/cleanup/expired` | Public |
| GET | `/api/public/landing/:slug` | Public |
| POST | `/api/public/checkout` | Public |
| GET | `/api/public/checkout/verify/:sessionId` | Public |
| GET | `/api/public/dynamics/resolve/:surfaceId` | Public |
| POST | `/api/public/generate-mockup` | Public |
| POST | `/api/public/generate-product-graphic` | Public |

### Authenticated User Routes
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/designs` | Authenticated |
| GET | `/api/designs/:id` | Authenticated |
| POST | `/api/designs` | Authenticated |
| PUT | `/api/designs/:id` | Authenticated |
| DELETE | `/api/designs/:id` | Authenticated |
| GET | `/api/members/*` | Authenticated |
| POST | `/api/members/*` | Authenticated |

### General / Utility Routes
| Method | Endpoint | Auth |
|--------|----------|------|
| GET | `/api/packets` | Public |
| GET | `/api/packets/:packetId` | Public |
| POST | `/api/packets` | Admin |
| GET | `/api/templates` | Public |
| GET | `/api/stores` | Public |
| GET | `/api/stores/:storeId` | Public |
| GET | `/api/stores/by-id/:storeId` | Public |
| GET | `/api/store/products` | Public |
| GET | `/api/store-product-links` | Public |
| GET | `/api/store/:storeType/:storeName` | Public |
| GET/POST | `/api/stores/:storeId/channels/*` | Public/Admin |
| POST | `/api/qr/generate` | Public |
| GET | `/api/qr/image` | Public |
| POST | `/api/qr/scan` | Public |
| GET | `/api/resolve/:instanceId` | Public |
| GET | `/api/render/config` | Public |
| GET | `/api/render/preview` | Public |
| POST | `/api/render/png` | Admin |
| POST | `/api/render/png/download` | Admin |
| POST | `/api/upload` | Public |
| POST | `/api/uploads/request-url` | Public |
| GET | `/api/proxy-image` | Public |
| GET | `/api/storage/health` | Public |
| POST | `/api/storefront/generate-mockup` | Public |
| GET | `/api/stripe/publishable-key` | Public |
| GET | `/api/customs/:id` | Public |
| GET | `/api/gifts/redeem/:code` | Public |
| POST | `/api/gifts/redeem/:code` | Public |

### Widget Routes (`widget.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/widget/token` | Public |
| POST | `/api/widget/verify` | Public |
| GET | `/api/widget/session` | Widget Auth |
| GET | `/api/widget/stores/:slug` | Widget Auth |
| GET | `/api/widget/stores/:storeId/programs` | Widget Auth |
| GET | `/api/widget/programs` | Widget Auth |
| GET | `/api/widget/programs/:programId` | Widget Auth |
| GET | `/api/widget/programs/:programId/moments` | Widget Auth |
| GET | `/api/widget/items` | Widget Auth |
| POST | `/api/widget/events` | Widget Auth |

### Cart & Checkout (`cart-checkout.routes.ts`)
| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/cart/checkout` | Public |
| GET | `/api/cart/verify/:sessionId` | Public |

---

## Auth Architecture Summary

- **AdminRoute** = `ProtectedRoute` + `AdminAuthProvider (apiBase="/api/admin")`
- All `/admin/*` client routes wrapped with `AdminRoute` in `App.tsx`
- All admin API calls use `authFetch` + `getAuthHeaders` from `useAdminAuth()` hook
- `LibraryPage.tsx` overrides with own `AdminAuthProvider (apiBase="/api")` for library-specific endpoints
- `nexusTests.ts` (non-component) uses local Firebase auth helper
- Zero direct `fetch()` calls to `/api/admin/*` endpoints remain

