# QR Gear Test Pages Package

## Overview
This package contains all test pages and shared components for QR Gear.

## QR Dynamics Feature (Primary Focus)

### What It Does
QR Dynamics allows users to create rotating product experiences. When a QR code is scanned, content rotates on a schedule (daily, weekly, or monthly).

### Architecture
Uses the Viewer -> View -> Skin pattern:
- Viewer: Orchestrates layout and state
- View: Handles behavior/layout (grids, lightboxes, scrolling)
- Skin: Pure visual styling (cards, details)

### Current Implementation
1. Store/Channel Selection - Auto-populates with QR Gear store
2. Media Grid - 4-column grid using GridScrollView
3. Collection Management - Create/select collections inline
4. Add to Collection - Click media to add to collection
5. Collection Display - Shows items with order numbers and remove buttons
6. QR Dynamics Scan Lightbox - Click collection item to set rotation interval

### Key Files
- test-dynamics.tsx - Main test page
- QRDynamicsScanLightbox.tsx - Lightbox view
- QRDynamicsScanSkin.tsx - Rotation interval selector
- GridScrollView.tsx - Grid layout
- ChannelItemSkin.tsx - Media card skin
- CollectionItemSkinV2.tsx - Collection item skin

### Pending
- Reorder items (drag-drop)
- QR code generation
- Rotation logic when QR scanned
