/**
 * surface-generator.ts
 *
 * Converts a committed admin_catalog_instance (+ its linked productPacket)
 * into a canonical NormalizedProduct, then builds a Surface draft payload
 * ready for insertion into the surfaces collection.
 *
 * Two-stage contract:
 *   Stage A — normalizeProductForPublishing(instanceId, db)  → NormalizedProduct
 *   Stage B — createSurfaceDraftFromNormalizedProduct(normalized, marketplace, defaults?) → surface payload
 *
 * Data precedence (highest wins):
 *   1. instance.resolved   — single source of truth: title / description / images / brand / colors / sizes / category
 *   2. instance.enabledColors / enabledSizes  — admin-curated subset (overrides resolved.colors/sizes when set)
 *   3. packet.pricing.customerPrice           — retail price
 *   4. packet.options                         — structured option groups for variants
 */

import type { firestore } from 'firebase-admin';
import { PRODUCT_PACKETS_COLLECTION } from '../constants';

// ─────────────────────────────────────────────────────────────────────────────
// Collection names (local — admin_catalog_instances not yet in constants)
// ─────────────────────────────────────────────────────────────────────────────

const ADMIN_INSTANCES_COLLECTION = 'admin_catalog_instances';

// ─────────────────────────────────────────────────────────────────────────────
// Public types
// ─────────────────────────────────────────────────────────────────────────────

export interface NormalizedProduct {
  instanceId: string;
  packetId: string | null;
  sourceMasterId: string | null;
  title: string;
  description: string;
  sku: string;
  slug: string | null;
  retailPrice: number;
  compareAtPrice: number | null;
  images: string[];
  colors: string[];
  sizes: string[];
  brand: string | null;
  category: string | null;
  department: string;
  originCountry: string | null;
  options: Array<{
    name: string;
    type: string;
    displayType?: string;
    values: Array<{ value: string; label: string; hex?: string | null }>;
  }>;
  storeId: string | null;
  channelId: string | null;
  collectionId: string | null;
  bulletPoints: string[];
  tags: string[];
  keywords: string[];
  printifyBlueprintId: string | null;
  printfulProductId: string | null;
  manufacturer: string | null;
}

export type SupportedMarketplace = 'ebay' | 'etsy' | 'amazon';

export interface EbayGenerateDefaults {
  categoryId?: string;
  conditionId?: string;
  listingFormat?: 'FIXED_PRICE' | 'AUCTION';
  bestOfferEnabled?: boolean;
  handlingTime?: number;
  shippingPolicyId?: string;
  returnsPolicyId?: string;
  paymentPolicyId?: string;
  packageWeightLbs?: number;
  quantity?: number;
}

export interface GenerateDefaults {
  ebay?: EbayGenerateDefaults;
}

// ─────────────────────────────────────────────────────────────────────────────
// Private helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Extract plain URL strings from the resolved.images array.
 * Entries may be ImageRecord objects { url, alt, … } or plain strings.
 */
function extractImageUrls(images: unknown[]): string[] {
  return (images ?? [])
    .map((img: any) => {
      if (typeof img === 'string') return img.trim();
      if (img && typeof img === 'object' && img.url) return String(img.url).trim();
      return null;
    })
    .filter((u): u is string => !!u && u.length > 0);
}

/**
 * Derive a listing department from a category string using keyword matching.
 * Default: Unisex (safest for POD apparel).
 */
function deriveDepartment(category: string | null | undefined): string {
  if (!category) return 'Unisex';
  const cat = category.toLowerCase();
  if (/\b(women|ladies|girl|female|womens)\b/.test(cat)) return 'Women';
  if (/\b(men|man|male|boys|mens)\b/.test(cat)) return 'Men';
  if (/\b(kids|child|youth|baby|toddler|infant)\b/.test(cat)) return 'Kids';
  return 'Unisex';
}

/**
 * Derive a product type label from category string for eBay item specifics.
 */
function deriveType(category: string | null | undefined): string | null {
  if (!category) return null;
  const cat = category.toLowerCase();
  if (/\b(t.?shirt|tee|top)\b/.test(cat)) return 'T-Shirt';
  if (/\b(hoodie|hooded)\b/.test(cat)) return 'Hoodie';
  if (/\b(sweatshirt)\b/.test(cat)) return 'Sweatshirt';
  if (/\b(hat|cap)\b/.test(cat)) return 'Hat';
  if (/\b(beanie)\b/.test(cat)) return 'Beanie';
  if (/\b(mug|cup)\b/.test(cat)) return 'Mug';
  if (/\b(bag|tote)\b/.test(cat)) return 'Bag';
  if (/\b(poster|print)\b/.test(cat)) return 'Poster';
  if (/\b(phone|case)\b/.test(cat)) return 'Phone Case';
  return null;
}

/**
 * Derive the SKU for a normalized product.
 * Priority:
 *   1. instance.qrgPacketCode  — full QRG-[STNNN]-[C]-[IIIIII] assigned at creation
 *   2. instance.qrgBlankId + instance.qrgContext + instance.instanceNumber — build it
 *   3. Stable fallback: no Firestore IDs baked in, no old formats
 */
function deriveSkuFromInstance(instance: any, instanceId: string): string {
  if (instance.qrgPacketCode && /^QRG-[1-6][1-9][0-9]{3}-[IMEO]-\d{6}$/.test(instance.qrgPacketCode)) {
    return instance.qrgPacketCode;
  }
  if (instance.qrgBlankId && instance.qrgContext && instance.instanceNumber) {
    return `QRG-${instance.qrgBlankId}-${instance.qrgContext}-${String(instance.instanceNumber).padStart(6, '0')}`;
  }
  // Fallback: stable prefix derived from master doc ID (qrg_STNNN) if available
  const masterId: string | null = instance.sourceMasterId || null;
  if (masterId && /^qrg_[1-6][1-9][0-9]{3}$/.test(masterId)) {
    const blank = masterId.slice(4);
    return `QRG-${blank}-I-PENDING`;
  }
  return `QRG-UNASSIGNED-${instanceId.slice(-8).toUpperCase()}`;
}

/**
 * Auto-generate listing bullet points from normalized product attributes.
 */
function generateBullets(
  colors: string[],
  sizes: string[],
  brand: string | null,
): string[] {
  const bullets: string[] = [];
  bullets.push('Unique QR code design printed directly on the product');
  if (colors.length > 0) {
    bullets.push(`Available in ${colors.length} color${colors.length > 1 ? 's' : ''}`);
  }
  if (sizes.length > 0) {
    bullets.push(`Multiple sizes available: ${sizes.join(', ')}`);
  }
  if (brand) {
    bullets.push(`Brand: ${brand}`);
  }
  bullets.push('Makes a great personalized gift for any occasion');
  return bullets;
}

/**
 * Auto-generate short tags (Etsy max 13) from product attributes.
 */
function generateTags(
  category: string | null,
  brand: string | null,
  department: string,
  colors: string[],
): string[] {
  const tags = new Set<string>();
  tags.add('qr code');
  tags.add('custom');
  tags.add('personalized');
  if (category) {
    const cat = category.toLowerCase().replace(/[^a-z0-9 ]/g, '').trim();
    if (cat) tags.add(cat);
  }
  if (brand) tags.add(brand.toLowerCase());
  tags.add(department.toLowerCase());
  const type = deriveType(category);
  if (type) tags.add(type.toLowerCase());
  for (const color of colors.slice(0, 3)) {
    tags.add(color.toLowerCase());
  }
  return Array.from(tags).slice(0, 13);
}

/**
 * Auto-generate longer search keyword phrases.
 */
function generateKeywords(
  category: string | null,
  brand: string | null,
): string[] {
  const kws: string[] = ['custom qr code', 'personalized gift', 'unique design'];
  const type = deriveType(category);
  if (type) kws.push(`custom ${type.toLowerCase()}`);
  if (brand) kws.push(`${brand.toLowerCase()} ${(type || 'product').toLowerCase()}`);
  return kws;
}

// ─────────────────────────────────────────────────────────────────────────────
// Stage A — normalizeProductForPublishing
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Loads an admin_catalog_instance by ID plus its linked productPacket and
 * returns a canonical NormalizedProduct ready for Surface draft generation.
 *
 * Throws with a descriptive message if the instance is not found.
 * Packet load is best-effort — missing packet is non-fatal.
 */
export async function normalizeProductForPublishing(
  instanceId: string,
  db: firestore.Firestore,
): Promise<NormalizedProduct> {
  // 1. Load the admin instance
  const instanceDoc = await db
    .collection(ADMIN_INSTANCES_COLLECTION)
    .doc(instanceId)
    .get();

  if (!instanceDoc.exists) {
    throw new Error(
      `[SurfaceGenerator] admin_catalog_instance not found: ${instanceId}`,
    );
  }

  const instance = instanceDoc.data() as any;
  const resolved = instance.resolved || {};
  const baseSnapshot = instance.baseSnapshot || {};

  // 2. Load linked packet (best-effort — non-fatal if missing)
  let packet: any = null;
  const packetId: string | null = instance.currentPacketId || null;
  if (packetId) {
    try {
      const packetDoc = await db
        .collection(PRODUCT_PACKETS_COLLECTION)
        .doc(packetId)
        .get();
      if (packetDoc.exists) {
        packet = packetDoc.data() as any;
      } else {
        console.warn(
          `[SurfaceGenerator] packet ${packetId} not found for instance ${instanceId} — continuing without packet data`,
        );
      }
    } catch (err: any) {
      console.warn(
        `[SurfaceGenerator] could not load packet ${packetId} for instance ${instanceId}: ${err.message}`,
      );
    }
  }

  // 3. Title + description — always from resolved (the canonical merged state)
  const title = (resolved.title || '').trim() || 'Untitled Product';
  const description = (resolved.description || '').trim() || '';

  // 4. Images — resolved.images already has the generated mockup prepended as hero
  const images = extractImageUrls(resolved.images || []);

  // 5. Colors + sizes
  //    Prefer admin-curated enabledColors/Sizes (set from builder commit step)
  //    over the full resolved set — they represent the operator's curation intent
  const resolvedColors: string[] = resolved.colors || [];
  const resolvedSizes: string[] = resolved.sizes || [];
  const adminColors: string[] | null =
    Array.isArray(instance.enabledColors) && instance.enabledColors.length > 0
      ? instance.enabledColors
      : null;
  const adminSizes: string[] | null =
    Array.isArray(instance.enabledSizes) && instance.enabledSizes.length > 0
      ? instance.enabledSizes
      : null;
  const colors = adminColors ?? resolvedColors;
  const sizes = adminSizes ?? resolvedSizes;

  // 6. Retail price
  //    Priority: resolved.pricing.customerPrice → packet.pricing.customerPrice
  //              → baseSnapshot.maxPrice → baseSnapshot.minPrice → 0
  let retailPrice = 0;
  const resolvedPricing = resolved.pricing || null;
  const packetPricing = packet?.pricing || null;
  if (resolvedPricing?.customerPrice) {
    retailPrice = parseFloat(resolvedPricing.customerPrice) || 0;
  } else if (packetPricing?.customerPrice) {
    retailPrice = parseFloat(packetPricing.customerPrice) || 0;
  } else if (baseSnapshot.maxPrice) {
    retailPrice = parseFloat(baseSnapshot.maxPrice) || 0;
  } else if (baseSnapshot.minPrice) {
    retailPrice = parseFloat(baseSnapshot.minPrice) || 0;
  }

  // 7. Structured options — from packet.options (built by the product builder)
  const options = packet?.options || [];

  // 8. Folder hierarchy
  const storeId: string | null = instance.storeId || null;
  const channelId: string | null = instance.channelId || null;
  const collectionId: string | null = instance.collectionId || null;

  // 9. Provider metadata
  const printifyBlueprintId: string | null =
    baseSnapshot.printifyBlueprintId || packet?.blueprintId || null;
  const printfulProductId: string | null = baseSnapshot.printfulProductId || null;
  const manufacturer: string | null = packet?.manufacturer || null;
  const originCountry: string | null = baseSnapshot.originCountry || null;

  // 10. Core attributes
  const brand: string | null = resolved.brand || null;
  const category: string | null =
    resolved.category || packet?.category || null;
  const slug: string | null = packet?.landingPageSlug || null;
  const sourceMasterId: string | null = instance.sourceMasterId || null;
  const sku = deriveSkuFromInstance(instance, instanceId);
  const department = deriveDepartment(category);

  // 11. Auto-generated listing content
  const bulletPoints = generateBullets(colors, sizes, brand);
  const tags = generateTags(category, brand, department, colors);
  const keywords = generateKeywords(category, brand);

  return {
    instanceId,
    packetId,
    sourceMasterId,
    title,
    description,
    sku,
    slug,
    retailPrice,
    compareAtPrice: null,
    images,
    colors,
    sizes,
    brand,
    category,
    department,
    originCountry,
    options,
    storeId,
    channelId,
    collectionId,
    bulletPoints,
    tags,
    keywords,
    printifyBlueprintId,
    printfulProductId,
    manufacturer,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Stage B — createSurfaceDraftFromNormalizedProduct
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Converts a NormalizedProduct into a Surface document payload.
 * The returned object can be written directly to the surfaces Firestore collection.
 *
 * Auto-populates eBay item specifics from the normalized product attributes.
 * All policy IDs and identifiers that require external lookup are left null
 * so the operator can review and fill them in the Surface editor.
 */
export function createSurfaceDraftFromNormalizedProduct(
  normalized: NormalizedProduct,
  marketplace: SupportedMarketplace,
  defaults: GenerateDefaults = {},
): Record<string, any> {
  const now = new Date().toISOString();
  const ebayDefs = defaults.ebay || {};
  const wantsEbay = marketplace === 'ebay';
  const type = deriveType(normalized.category);

  // Auto-populate eBay item specifics from normalized attributes
  const autoItemSpecifics: Record<string, string> = {};
  autoItemSpecifics['Brand'] = normalized.brand || 'QR Gear';
  autoItemSpecifics['Department'] = normalized.department;
  if (type) autoItemSpecifics['Type'] = type;
  if (normalized.colors.length === 1) {
    autoItemSpecifics['Color'] = normalized.colors[0];
  }
  if (normalized.originCountry) {
    autoItemSpecifics['Country/Region of Manufacture'] = normalized.originCountry;
  }

  // eBay-specific block — null when marketplace is not eBay
  const ebayBlock = wantsEbay
    ? {
        categoryId: ebayDefs.categoryId || null,
        conditionId: ebayDefs.conditionId || '1000',
        listingFormat: ebayDefs.listingFormat || 'FIXED_PRICE',
        subtitle: null,
        bestOfferEnabled: ebayDefs.bestOfferEnabled ?? false,
        itemSpecifics: autoItemSpecifics,
        shippingPolicyId: ebayDefs.shippingPolicyId || null,
        returnsPolicyId: ebayDefs.returnsPolicyId || null,
        paymentPolicyId: ebayDefs.paymentPolicyId || null,
        handlingTime: ebayDefs.handlingTime ?? 3,
        packageWeightLbs: ebayDefs.packageWeightLbs ?? null,
        packageDimensionsInches: null,
        upc: null,
        ean: null,
        mpn: null,
        brand: normalized.brand || 'QR Gear',
        priceOverride: null,
        quantity: ebayDefs.quantity ?? 100,
      }
    : null;

  return {
    // ── Lineage ─────────────────────────────────────────────────────────────
    masterProductId: normalized.instanceId,
    productId: normalized.sourceMasterId || '',
    artifactId: normalized.packetId || '',
    mosaicId: '',

    // ── Core listing content ─────────────────────────────────────────────────
    title: normalized.title.slice(0, 80), // eBay enforces 80-char title limit
    subtitle: '',
    description: normalized.description,
    bulletPoints: normalized.bulletPoints,
    tags: normalized.tags,
    keywords: normalized.keywords,
    images: normalized.images,
    mockupImages: normalized.images.slice(0, 1),

    // ── Pricing ──────────────────────────────────────────────────────────────
    retailPrice: normalized.retailPrice,
    compareAtPrice: normalized.compareAtPrice ?? undefined,
    currency: 'USD',
    sku: normalized.sku,
    defaultSkuPrefix: normalized.sku,

    // ── Channel enablement ───────────────────────────────────────────────────
    enabledPlatforms: [marketplace],
    supportsEmbedStore: false,
    supportsEmbedProduct: false,
    supportsEmbedBuilder: false,
    supportsEtsy: marketplace === 'etsy',
    supportsEbay: wantsEbay,
    supportsAmazon: marketplace === 'amazon',

    // ── Folder hierarchy ─────────────────────────────────────────────────────
    storeId: normalized.storeId || '',
    channelId: normalized.channelId || '',
    collectionId: normalized.collectionId || '',

    // ── Marketplace-common fields ────────────────────────────────────────────
    brand: normalized.brand,
    condition: 'new',
    material: null,
    department: normalized.department,
    shippingProfileRef: null,
    returnsProfileRef: null,

    // ── eBay block ───────────────────────────────────────────────────────────
    ebay: ebayBlock,

    // ── Status ───────────────────────────────────────────────────────────────
    status: 'draft',
    readinessErrors: [],
    isActive: true,
    createdAt: now,
    updatedAt: now,
  };
}
