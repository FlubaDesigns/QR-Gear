# QR Gear — Members Area Complete Reference

## File Map

### Frontend — Members Components
| File | Purpose |
|:---|:---|
| `frontend/members/MembersPage.tsx` | Main members dashboard with all views (Home, Channels, QR Dynamics, Earnings, Social, Wizard) |
| `frontend/members/SuperSimpleWizard.tsx` | Guided wizard with tutorial blackboards (default for new users) |
| `frontend/members/SimpleWizard.tsx` | Standard wizard (Quick Create tier) |
| `frontend/members/AdvancedWizard.tsx` | Advanced wizard with font slider, placement coordinates, quick start |
| `frontend/members/StudioMode.tsx` | Studio tier placeholder |
| `frontend/members/WizardContext.tsx` | Shared state, API calls, step transitions for ALL wizards |
| `frontend/members/SocialHubView.tsx` | Social media hub: profiles, content calendar, ready-to-post queue |

### Frontend — Shared Wizard Step Components
| File | Purpose |
|:---|:---|
| `frontend/shared/wizardTypes.ts` | Step arrays, type definitions, step IDs for all flows |
| `frontend/shared/ChannelStep.tsx` | Channel selection/creation step |
| `frontend/shared/ProductSteps.tsx` | Product selection, color, size steps |
| `frontend/shared/TypeAndSurfaceSteps.tsx` | QR type selection (Basic/Plus/Canvas/Play/Compose) |
| `frontend/shared/PlacementSteps.tsx` | Placement count, graphic size, placement config |
| `frontend/shared/TextSteps.tsx` | Header/footer text editing steps |
| `frontend/shared/QRBasicSteps.tsx` | QR Basic flow (URL/text input, mockup, confirm) |
| `frontend/shared/QRPlusSteps.tsx` | QR Plus flow (mockup, save choice, confirm) |
| `frontend/shared/CanvasSteps.tsx` | QR Canvas flow (image upload, preview, publish) |
| `frontend/shared/PlaySteps.tsx` | QR Play flow (video source, preview, publish) |
| `frontend/shared/ComposeSteps.tsx` | QR Compose flow (pick items, durations, order, publish) |
| `frontend/shared/PreviewAndPublishSteps.tsx` | Shirt preview and publish steps |
| `frontend/shared/BlackboardExplainer.tsx` | Tutorial overlay cards for SuperSimple wizard |
| `frontend/shared/WizardProgressBars.tsx` | Progress indicators |
| `frontend/shared/ShareKitHandoff.tsx` | Post-publish sharing kit with social links, copy, download |
| `frontend/shared/VideoSourcePicker.tsx` | Video upload/URL entry component |

### Backend — Cloud Functions
| File | Purpose |
|:---|:---|
| `backend/index.ts` | ALL Cloud Functions (Express app) — the single API codebase |

---

## Dashboard Views (MembersPage.tsx)

### Home (viewMode = 'index')
- Component: `MemberIndexView`
- Shows: Product count, Channel count, Earnings total, Published count
- Wizard launch cards for all tiers

### Channels (viewMode = 'channels')
- Component: `ChannelsView`
- API: `GET /api/members/:id/channels`, `GET /api/members/:id/products`
- Features: Create/delete channels, view items, remove items from channel (unlink, not delete)

### QR Dynamics (viewMode = 'collections')
- Component: `CollectionsView`
- API: `GET /api/members/:id/published-items?types=qr-compose`
- Shows: Compose items with title, item count, rotation mode, instance ID
- Naming: "QR Compose" = the wizard process; "QR Dynamics" = the resulting stitched item

### Earnings (viewMode = 'earnings')
- Component: `EarningsView`
- API: `GET /api/members/:id/earnings`
- Shows: Total, Pending, Paid, Profit Share (25%)

### Social Hub (viewMode = 'social')
- Component: `SocialHubView` (lazy loaded)
- Features: Social profiles, content calendar, ready-to-post queue, email reminders

### Wizard (viewMode = 'wizard')
- Renders one of: SuperSimpleWizard, SimpleWizard, AdvancedWizard, StudioMode
- Selected via `wizardTier` state
- All wizards share WizardContext for state/logic

---

## Wizard Flows — Step-by-Step

### Common Steps (All Flows)
1. `channel` — Select or create a channel
2. `product` — Pick base product (T-shirt, Hoodie, etc.)
3. `product-congrats` — Shows earnings potential
4. `color` — Pick color
5. `size` — Pick size
6. `type` — Choose QR type (Basic/Plus/Canvas/Play/Compose)
7. `placement-count` — Front, Back, or Both
8. `graphic-size` — Size of QR graphic on garment
9. `generate` — Add header/footer text?

### QR Basic Flow
10. `qr-basic-type` — URL or plain text
11. `qr-basic-input` — Enter content
12. `qr-basic-mockup` — Preview mockup
13. `qr-basic-save-choice` — Save options
14. `qr-basic-confirm` — Done (ShareKitHandoff)

### QR Plus Flow (adds text to product)
10. `text-choice` — Header, Footer, or Both
11. `text-edit-header` — Edit header text
12. `text-edit-footer` — Edit footer text
13. `placement-config` — QR vs full graphic per placement
14. `shirt-preview` — Preview on shirt
15. `canvas-fork` — Branch point
16. `qr-plus-mockup` — Final mockup
17. `qr-plus-save-choice` — Save options
18. `qr-plus-confirm` — Done (ShareKitHandoff)

### QR Canvas Flow (image landing page)
Steps 10-15 same as Plus, then:
16. `url-explainer` — Explains canvas concept
17. `url-source-choice` — Upload or pick from library
18. `url-library-pick` — Browse library
19. `url-title` — Enter title
20. `url-description` — Enter description
21. `url-preview` — Preview landing page
22. `canvas-mockup` — Product mockup
23. `url-publish` — Publish
24. `canvas-confirm` — Done (ShareKitHandoff)

### QR Play Flow (video)
Steps 10-15 same as Plus, then:
16. `play-video-source` — Upload video or enter URL
17. `play-preview` — Preview video
18. `play-mockup` — Product mockup
19. `play-publish` — Publish
20. `play-save-choice` — Done (ShareKitHandoff)

### QR Compose Flow (stitch multiple items)
Steps 10-15 same as Plus, then:
16. `compose-pick-items` — Select Canvas/Play items (min 2)
17. `compose-mode` — Auto-rotate or scan-to-reveal
18. `compose-durations` — Set timing per item
19. `compose-order` — Reorder items
20. `compose-hosting` — Hosting term
21. `compose-mockup` — Product mockup
22. `compose-preview` — Summary preview
23. `compose-publish` — Publish
24. `compose-confirm` — Done (ShareKitHandoff)

---

## Wizard Tier Differences

| Feature | SuperSimple | Simple (Quick Create) | Advanced |
|:---|:---|:---|:---|
| Tutorial Blackboards | Yes | No | No |
| Color Theme | Emerald | Green | Blue |
| Unlocked By | Default | Default | 1+ Publishes |
| Quick Start Resume | No | No | Yes |
| Font Size Slider | No | No | Yes |
| Vertical Offset | No | No | Yes |
| Placement Coordinates | No | No | Yes |
| X/Y Offset Adjusters | No | No | Yes |

---

## Cloud Function Routes (Member-Related)

### Member Packets & Products
| Method | Path | Purpose |
|:---|:---|:---|
| GET | `/members/:memberId/published-items` | List published items, filter by `types` query |
| POST | `/members/:memberId/packets` | Create draft packet |
| PATCH | `/members/:memberId/packets/:packetId` | Update packet |
| POST | `/members/:memberId/products` | Publish product (unified endpoint for all QR types) |

### Member Channels
| Method | Path | Purpose |
|:---|:---|:---|
| GET | `/members/:memberId/channels` | List channels |
| POST | `/members/:memberId/channels` | Create channel |
| DELETE | `/members/:memberId/channels/:channelId` | Delete channel (unlinks items) |
| PUT | `/members/:memberId/channels/:channelId/remove-item` | Remove item from channel |

### Member Earnings
| Method | Path | Purpose |
|:---|:---|:---|
| GET | `/members/:memberId/earnings` | Get earnings with summary |

### Member Profile & Social
| Method | Path | Purpose |
|:---|:---|:---|
| GET | `/members/profile` | Get member profile |
| POST | `/members/profile` | Create/update profile |
| GET | `/members/check-status` | Check membership status |
| PUT | `/members/:memberId/social-handles` | Update social media handles |
| PUT | `/members/:memberId/contact-info` | Update email/phone |

### Content Calendar
| Method | Path | Purpose |
|:---|:---|:---|
| GET | `/members/:memberId/social-schedule` | List scheduled posts |
| POST | `/members/:memberId/social-schedule` | Create scheduled post |
| PUT | `/members/:memberId/social-schedule/:scheduleId` | Update schedule |
| DELETE | `/members/:memberId/social-schedule/:scheduleId` | Delete schedule |
| POST | `/members/:memberId/social-schedule/:scheduleId/mark-posted` | Mark as posted |
| POST | `/members/:memberId/social-schedule/send-reminders` | Send email reminders |

### Media & Library
| Method | Path | Purpose |
|:---|:---|:---|
| POST | `/members/:memberId/media` | Upload video (multipart) |
| GET | `/members/:memberId/library` | List library assets |
| POST | `/members/:memberId/library` | Save asset to library |
| POST | `/members/:memberId/library/upload` | Upload asset reference |
| GET | `/members/:memberId/graphics` | List user graphics |

### Mockups & Pricing
| Method | Path | Purpose |
|:---|:---|:---|
| POST | `/mockups/generate` | Generate product mockup |
| POST | `/mockups/get-or-generate` | Get cached or generate mockup |
| GET | `/pricing-settings` | Get pricing rules (markups, upcharges) |
| GET | `/members/allowed-products` | Products available to members with earnings info |

---

## Post-Publish Flow

When any wizard completes:
1. Back/Next footer is hidden (FINAL_CONFIRM_STEPS)
2. ShareKitHandoff component shows:
   - Share URL with referral code (`?ref=memberId`)
   - Copy link, copy caption
   - Social share buttons (X, Facebook, LinkedIn, WhatsApp, Email)
   - Download assets (square image, link preview)
   - **Dashboard** button → navigates to member home
   - **Create Another** button → resets wizard, stays in wizard mode

---

## Earnings Model

- Creator gets **25% of profit** (retail price - manufacturing cost)
- Stored in `member_earnings` collection
- Referral earnings: separate 25% when referrer is different from creator
- Pricing snapshot stored in packet at publish time for audit trail

---

## Naming Convention

- **QR Compose** = the wizard process of stitching Canvas + Play items together
- **QR Dynamics** = the resulting stitched item that rotates content when scanned
- The dashboard tab is labeled "QR Dynamics"
- The wizard type selection says "QR Compose"
- Backend stores: `packetType: 'qr-compose'`, instance in `qr_dynamics_instances`
