# Critical Bug: Dashboard Pages Stuck on "Loading..."

## Issue Summary
All role-based dashboards (member, business-admin, church-admin) are stuck showing "Loading your dashboard..." for logged-in users. The homepage correctly detects authentication, and other dashboards (sales, admin, marketing-manager) work fine.

## Environment
- Production: kingdomconnects.org
- Firebase Hosting + Firestore
- User testing on mobile (Samsung S21 Plus)

## What Works
- Homepage (`/index.html`) - correctly shows logged-in user via `js/homepage-enhancements.js`
- Admin dashboard (`/admin/`) - loads correctly
- Sales dashboard (`/sales/`) - loads correctly  
- Marketing dashboard (`/marketing-manager/`) - loads correctly

## What's Broken
- Member dashboard (`/member/`) - stuck on "Loading your dashboard..."
- Business Admin dashboard (`/business-admin/`) - stuck on "Loading your dashboard..."
- Church Admin dashboard (`/church-admin/`) - stuck on "Loading your dashboard..."

## Key Files

### js/auth/access-control.js (the auth guard all dashboards use)
```javascript
import { auth } from "../firebase-config.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const LOGIN_URL = '/login.html';
const HOME_URL = '/index.html';

function waitForAuth() {
  return new Promise((resolve) => {
    let resolved = false;
    let timeoutId = null;
    
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (resolved) return;
      
      if (user) {
        resolved = true;
        if (timeoutId) clearTimeout(timeoutId);
        unsubscribe();
        resolve(user);
      } else {
        timeoutId = setTimeout(() => {
          if (resolved) return;
          resolved = true;
          unsubscribe();
          resolve(null);
        }, 1500);
      }
    });
  });
}

export async function requireAuth(options, callback) {
  const user = await waitForAuth();
  
  if (!user) {
    const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
    window.location.href = `${LOGIN_URL}?returnUrl=${returnUrl}`;
    return;
  }
  
  // ... role checking logic, then calls callback(userContext, user)
}

export function requireMember(callback) {
  return requireAuth({ roles: ['member', 'business_owner', 'church_admin', 'sales_agent', 'sales_director', 'marketing_manager', 'admin'] }, callback);
}
```

### js/firebase-config.js
```javascript
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyBxxxxxxxx",
  authDomain: "kingdom-commerce.firebaseapp.com",
  projectId: "kingdom-commerce",
  storageBucket: "kingdom-commerce.appspot.com",
  messagingSenderId: "xxxxx",
  appId: "xxxxx"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
```

### member/js/member-dashboard.js (broken)
```javascript
import { db } from "../../js/firebase-config.js";
import { requireMember } from "../../js/auth/access-control.js";

requireMember((userContext, firebaseUser) => {
  currentUser = firebaseUser;
  loadDashboard(firebaseUser);  // THIS NEVER GETS CALLED
});
```

### sales/js/dashboard.js (works)
```javascript
import { db } from "../../js/firebase-config.js";
import { requireSalesAgent } from "../../js/auth/access-control.js";

requireSalesAgent(async (userContext, firebaseUser) => {
  currentUser = firebaseUser;
  // This DOES get called
});
```

### js/homepage-enhancements.js (works - different pattern)
```javascript
import { auth, db } from "./firebase-config.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
  if (user) {
    // Show logged-in UI - THIS WORKS
  }
});
```

## What We've Tried
1. Made Firebase config synchronous (embedded config instead of fetch)
2. Created waitForAuth() wrapper with 1500ms timeout
3. Removed demo-mode.js from broken pages
4. Various cache busting attempts

## Architect Analysis
The architect tool suggested that `waitForAuth()` with timeout is the problem:
- When session restores, `onAuthStateChanged` fires with `null` first
- The 1500ms timeout fires before the real user event arrives
- `requireAuth` redirects to login or the callback never executes

Recommended fix: Use `auth.authStateReady()` instead of timeout-based approach.

## The Mystery
Why do sales/admin/marketing work but member/business/church don't? They all use the same `access-control.js` file with the same `requireAuth` function.

Possible differences to investigate:
1. Script loading order in HTML
2. Role-checking logic differences (requireMember vs requireSalesAgent vs requireAdmin)
3. Something about the user's specific roles/permissions

## Suggested Next Steps
1. Add console.log debugging to production to trace exact auth flow
2. Try `auth.authStateReady()` approach instead of timeout
3. Compare exact role-checking paths between working/broken dashboards
4. Check if user's Firestore user document has correct role fields
