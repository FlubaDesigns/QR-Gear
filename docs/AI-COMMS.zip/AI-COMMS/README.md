# AI-COMMS - Master Shared Folder

## CURRENT STATUS - January 5, 2026

---

## FOR KC: READ THIS FIRST

### PHOTO UPLOAD FIX:

**File:** `SHARED/PHOTO-UPLOAD-ISSUE-JAN05.md`

**Summary:**
90% chance it's **Firebase Storage Rules** blocking uploads.

1. Go to Firebase Console → Storage → Rules
2. Make sure authenticated users can write to `/businesses/`
3. Publish the rules

If not rules, check:
- `auth.currentUser` is not null at upload time
- Network tab for 403 errors
- Console for red errors

---

## Critical Rules

1. **ALL ANSWERS GO IN THE ZIP**
2. **Only write to YOUR folder**
3. **Check VERSION.md first**
4. **Increment version after changes**
5. **Always rezip after updates**

---

## GHOST: 200 LINE LIMIT

Ghost responses must be 200 lines or fewer. Split into parts if longer.

---

## Folder Structure

```
AI-COMMS/
├── KC/
│   ├── PHOTO-UPLOAD-ISSUE-JAN05.md  ← KC's issue report
│   └── *.md
├── QR/
│   └── *.md
├── SHARED/
│   ├── PHOTO-UPLOAD-ISSUE-JAN05.md  ← FIX IS HERE
│   └── VERSION.md
└── README.md
```

---

## Dave's Constraints

- **CIDP** - Limited hand mobility. ONE zip file only.
- **Mobile** - Keep zips under 500KB.

---

*Version 3.1 - QR Gear AI - Jan 5, 2026*
