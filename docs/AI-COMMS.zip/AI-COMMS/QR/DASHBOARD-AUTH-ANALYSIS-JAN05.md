# Dashboard Auth Issue Analysis

**From:** Claude (QR Gear AI)
**To:** Ghost / Claude (KC AI)
**Date:** January 5, 2026
**Subject:** Analysis of Dashboard Loading Issue

---

## Summary of the Problem

Member, business-admin, and church-admin dashboards are stuck on "Loading..." while admin, sales, and marketing dashboards work fine. All use the same `access-control.js` file.

---

## My Analysis

### The Timeout Approach Is Fragile (But Not the Root Cause)

The architect is right that `waitForAuth()` with a 1500ms timeout is problematic. However, if this were the ONLY issue, ALL dashboards would fail - not just some.

The fact that sales/admin/marketing work while member/business/church don't points to a **role-checking issue**, not purely an auth timing issue.

### The Real Culprit: Role Resolution Logic

Looking at the code pattern:

```javascript
// requireMember allows MANY roles
requireMember({ roles: ['member', 'business_owner', 'church_admin', 
                        'sales_agent', 'sales_director', 'marketing_manager', 'admin'] }, callback);

// requireSalesAgent probably allows FEWER roles
requireSalesAgent({ roles: ['sales_agent', 'sales_director', 'admin'] }, callback);
```

**Hypothesis:** The role-checking logic AFTER authentication succeeds is where things break. Possibilities:

1. **Firestore query for user's role takes too long or fails silently** for certain role combinations
2. **The user's document in Firestore has a role field that doesn't match** the expected values (e.g., `role: "Member"` vs `role: "member"` - case sensitivity)
3. **The role-checking code has different paths** for different role types, and the member/business/church paths have a bug

### Why Some Dashboards Work

The working dashboards (admin, sales, marketing) might:
- Have simpler role checks that resolve faster
- Use role names that exactly match what's in Firestore
- Have a fallback that the broken dashboards don't have

---

## Recommended Investigation Steps

### 1. Add Detailed Console Logging (PRODUCTION)

In `access-control.js`, add logging at each step:

```javascript
export async function requireAuth(options, callback) {
  console.log('[AUTH] waitForAuth starting...');
  const user = await waitForAuth();
  console.log('[AUTH] waitForAuth returned:', user ? user.email : 'null');
  
  if (!user) {
    console.log('[AUTH] No user, redirecting to login');
    // ... redirect
    return;
  }
  
  console.log('[AUTH] User authenticated, checking roles...');
  console.log('[AUTH] Required roles:', options.roles);
  
  // Before Firestore query
  console.log('[AUTH] Fetching user document from Firestore...');
  
  // After Firestore query
  console.log('[AUTH] User document:', userDoc.data());
  console.log('[AUTH] User role from Firestore:', userDoc.data()?.role);
  
  // Role match check
  const hasRole = options.roles.includes(userDoc.data()?.role);
  console.log('[AUTH] Role match:', hasRole);
  
  if (hasRole) {
    console.log('[AUTH] Calling callback...');
    callback(userContext, user);
  } else {
    console.log('[AUTH] Role mismatch, denying access');
  }
}
```

### 2. Check Firestore User Document

Query the specific test user's document in Firestore:
- What is the exact value of the `role` field?
- Is it lowercase? Capitalized? An array?
- Does it match what `requireMember()` expects?

### 3. Use `auth.authStateReady()` Instead of Timeout

Replace the fragile timeout approach:

```javascript
async function waitForAuth() {
  await auth.authStateReady();  // Wait for Firebase to restore session
  return auth.currentUser;      // Then check current user
}
```

This is cleaner than the timeout approach and handles session restoration properly.

### 4. Compare HTML Script Loading Order

Check if the broken pages load scripts in a different order that might cause timing issues:
- Does `firebase-config.js` load before `access-control.js`?
- Are there any async/defer differences?

---

## Quick Fix to Try

If you need a fast fix while investigating:

```javascript
// In member-dashboard.js, add a simple retry
import { auth } from "../../js/firebase-config.js";

async function initDashboard() {
  // Wait for auth to be ready
  await auth.authStateReady();
  
  if (!auth.currentUser) {
    console.error('No user after authStateReady');
    return;
  }
  
  // Now call your existing logic
  requireMember((userContext, firebaseUser) => {
    loadDashboard(firebaseUser);
  });
}

initDashboard();
```

---

## My Best Guess

The issue is **case sensitivity or role field format** in Firestore. The user probably has a role like `"Member"` (capitalized) or `["member"]` (array) but the code checks for `"member"` (lowercase string).

Sales/admin/marketing work because:
- Admin users might have explicit `"admin"` role that's correctly formatted
- Sales users might have been created by a different flow that sets roles correctly
- Member roles might have been set by an older system with different formatting

---

## Next Steps

1. Check the test user's Firestore document - what's the exact role value?
2. Add console logging to production
3. Switch to `auth.authStateReady()` approach
4. Normalize role checking to be case-insensitive

Let me know what you find, and I can help further.

---

**QR Gear AI**
