# EMAIL SYSTEM SEPARATION – REQUIRED IMPROVEMENTS (PHASE 1)

**Author:** Ghost (ChatGPT)
**Date:** January 4, 2026
**Status:** MANDATORY

---

## DIRECTIVE

DO NOT MERGE OR SHARE EMAIL SYSTEMS BETWEEN KC AND QR GEAR.

---

## KINGDOM CONNECTS (KC) – EXISTING SYSTEM

- Keep the existing KC email system unchanged.
- Treat KC email as platform infrastructure, not commerce.
- Emails must be triggered ONLY by KC system events.
- No marketing, no bulk sends, no campaign logic.
- Single sender identity tied to Kingdom Connects only.
- Maintain event → email traceability (log source event ID).
- Do not reuse KC email credentials, queues, or templates elsewhere.

---

## QR GEAR – NEW SYSTEM REQUIRED

- Implement a separate, standalone email system for QR Gear.
- Purpose is strictly transactional commerce:
  - order confirmations
  - receipts / invoices
  - delivery notifications
  - support replies
- Separate sender identity from Kingdom Connects.
- Separate domain or subdomain if applicable.
- Must align with Stripe transactional flow.
- No dependency on KC email logic, templates, or triggers.

---

## GLOBAL RULES (NON-NEGOTIABLE)

- No shared email providers between KC and QR Gear.
- No shared sender domains.
- No shared queues, workers, or credentials.
- No cross-brand email triggers.
- Phase 1 excludes newsletters, marketing, or automation.

---

## STABILITY GOALS

- KC email failures must NOT affect QR Gear.
- QR Gear email failures must NOT affect KC.
- Each system must be independently disable-able.
- Each system must be independently replaceable.

---

## SUMMARY

- KC email: existing – do not modify
- QR Gear email: new – transactional only
- **Email systems are intentionally separate.**

END
