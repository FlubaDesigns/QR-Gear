# Ghost's Dashboard Diagnosis Checklist

**From:** Ghost
**To:** Claude 1 (KC AI)
**Date:** January 5, 2026
**Subject:** KC Dashboard "Loading..." Fix

---

## What This Usually Means (Highest Probability)

**A)** Those dashboard folders/pages are NOT actually deployed to Firebase Hosting (or are being served as HTML via a rewrite), so the JS never runs → page sits on "Loading…"

**B)** The role-gate code runs, but the user doc / role fields can't be read (rules or missing fields) → page never resolves.

---

## DO THIS CHECKLIST IN ORDER (Fastest to Isolate)

### 1) Verify the Pages Exist on Hosting (Deployment Check)

Open these URLs in a browser:
- https://kingdomconnects.org/member/
- https://kingdomconnects.org/business/
- https://kingdomconnects.org/church/

If any show a blank / "Loading…" forever:
- Open DevTools → Console + Network
- Look for either:
  - **404 on a JS module** (dashboard.js, firebase-config.js, etc.)
  - **"Unexpected token <"** (means a JS file request returned HTML → usually rewrite or missing file)

---

### 2) If You See 404s → The Folders Are Not Deployed

In Firebase Console → Hosting → "View" / "Files"

Confirm these folders exist in the deployed site:
- `/member/`
- `/business/`
- `/church/`

**If they DO NOT exist:**

Fix is simple: they must be inside the directory defined by `firebase.json` "public".

Example:
```
firebase.json → "hosting": { "public": "public" }
```

Therefore you must physically have:
```
public/member/index.html
public/member/js/dashboard.js
public/business/index.html
public/church/index.html
```

Then redeploy:
```bash
firebase deploy --only hosting
```

---

### 3) If You See "Unexpected token <" (JS File Returning HTML)

That means your request for a .js module is being rewritten to `/index.html` (or the file is missing so the rewrite catches it).

**Fix:**
- **(a)** Make sure the JS file really exists under the hosting public directory.
- **(b)** Make sure `firebase.json` isn't rewriting ALL routes in a way that intercepts real files.

**Typical safe setup:**
- Keep rewrites only for routes that don't map to real files
- Or ensure your dashboards are real folder sites with real `index.html` files (no SPA rewrite needed)

---

### 4) If Files Exist and Load (No 404 / No token<), But Still "Loading…"

Then it's **AUTH / ROLE GATING**:

**Check Firestore user doc:**
- Collection: `users`
- Doc ID: (the auth uid)

**Confirm it has the correct role fields** that the dashboard expects.
- Example issue: dashboard expects `role="member"` but doc has `role="Member"` or uses a different field name

**Confirm Firestore Rules** allow the signed-in user to read their own doc:
```
users/{uid} must be readable by request.auth.uid == uid
```
If user doc can't be read, the role checks never resolve.

---

### 5) Quick "Tell Me Which Bucket It Is" Test (No Guessing)

On the stuck dashboard page, DevTools → Network:

- **If you see missing JS/CSS** → DEPLOYMENT/PATH problem (Step 2)
- **If you see JS loads fine but Firestore calls fail** (permission denied / missing doc) → AUTH/RULES/FIELDS problem (Step 4)

---

## Most Likely Fix Based on Your Symptom

Member/Business/Church dashboards are not in the deployed Hosting "public" output (or their JS files are missing), so the page renders but the scripts never execute correctly.

---

## Quick Diagnosis

**If you paste the first Console error line (exact text) from the stuck page, Ghost can tell you which step is the real cause in 5 seconds.**

---

*Ghost - January 5, 2026*
