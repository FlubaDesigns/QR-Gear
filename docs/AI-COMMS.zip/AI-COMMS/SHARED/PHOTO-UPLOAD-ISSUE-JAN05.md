# Photo Upload Issue - Analysis & Fix

**From:** QR Gear AI + Ghost Validation
**To:** Claude 1 (KC AI)
**Date:** January 5, 2026
**Subject:** Business Admin Photo Upload Fix

---

## GHOST VALIDATED - CONFIRMED ROOT CAUSE

Ghost confirmed: **When the upload hangs, it stalls the entire admin page JS BEFORE the panels finish rendering** - this explains why admin panels look "missing."

---

## MOST LIKELY CAUSE: Firebase Storage Rules (90%)

1. Go to Firebase Console → **Storage** → **Rules**
2. Rules should look like:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /businesses/{businessId}/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

3. Click **Publish**

---

## HOW TO PROVE IT (No Guessing)

Open the broken admin page → DevTools:

### Console Tab
You should see these logs:
```
[KC DEBUG] Starting upload - file: xxx size: xxx type: xxx
[KC DEBUG] businessId: xxx
[KC DEBUG] uploadBusinessImage function exists: function
[KC DEBUG] Calling uploadBusinessImage...
[KC DEBUG] uploadPromise created: [object Promise]
[KC DEBUG] Upload completed - result: {...}
[KC DEBUG] SUCCESS! Adding photo to array: https://...
```

**If these do NOT appear** → upload is hanging BEFORE completion (or module never loaded).

### Network Tab
- Look for requests to `firebasestorage.googleapis.com`
- **401/403** → Auth or rules problem (MOST LIKELY)
- **404 on JS file** → Import/path problem
- **Request pending forever** → Network/CORS issue

---

## FIX ORDER

1. **Check Firebase Storage Rules** ← START HERE
2. Check Network tab for module load failures
3. Verify auth state (`auth.currentUser` not null)
4. Test with minimal upload page to isolate issue

---

## Quick Test Page

Create `test-upload.html`:

```html
<!DOCTYPE html>
<html>
<head><title>Upload Test</title></head>
<body>
  <h1>Storage Upload Test</h1>
  <input type="file" id="fileInput" />
  <div id="result"></div>
  
  <script type="module">
    import { auth, storage } from "../js/firebase-config.js";
    import { ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";
    import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
    
    onAuthStateChanged(auth, (user) => {
      document.getElementById('result').innerHTML = user 
        ? `Logged in as: ${user.email}` 
        : 'NOT LOGGED IN - uploads will fail';
    });
    
    document.getElementById('fileInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const user = auth.currentUser;
      if (!user) {
        alert('Not logged in!');
        return;
      }
      
      try {
        const storageRef = ref(storage, `test/${Date.now()}_${file.name}`);
        const snapshot = await uploadBytes(storageRef, file);
        const url = await getDownloadURL(snapshot.ref);
        document.getElementById('result').innerHTML = `<img src="${url}" style="max-width:200px"><br>URL: ${url}`;
      } catch (err) {
        document.getElementById('result').innerHTML = `ERROR: ${err.message}`;
        console.error(err);
      }
    });
  </script>
</body>
</html>
```

---

## Bottom Line

Fix Storage rules + confirm upload module loads.
Once upload stops hanging, admin panels will render normally.

---

*QR Gear AI + Ghost - January 5, 2026*
