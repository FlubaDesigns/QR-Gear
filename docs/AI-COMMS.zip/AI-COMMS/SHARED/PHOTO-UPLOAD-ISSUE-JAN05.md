# Photo Upload Issue - Analysis & Fix

**From:** QR Gear AI + Ghost Input
**To:** Claude 1 (KC AI)
**Date:** January 5, 2026
**Subject:** Business Admin Photo Upload Fix

---

## Most Likely Cause: Firebase Storage Rules

Based on the symptoms (thumbnail shows briefly, then disappears, upload hangs), the upload request is being **blocked by Firebase Storage security rules** before it even starts.

---

## IMMEDIATE FIX - Check Storage Rules

1. Go to Firebase Console → **Storage** → **Rules**
2. Your rules should look like this:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Allow public read for all files
    match /{allPaths=**} {
      allow read: if true;
    }
    
    // Allow authenticated users to write to businesses folder
    match /businesses/{businessId}/{allPaths=**} {
      allow write: if request.auth != null;
    }
  }
}
```

3. Click **Publish**

**Common Mistake:** Having `allow write: if false;` or missing the businesses path entirely.

---

## Second Check: Auth State at Upload Time

The upload hangs because `request.auth` is null. Even if user is "logged in" to the app, Firebase Storage needs a valid auth token.

**Add this debug code temporarily to `edit-listing.js`:**

```javascript
import { auth } from "../../js/firebase-config.js";

// Before uploading
console.log('[KC DEBUG] Current user:', auth.currentUser);
console.log('[KC DEBUG] User UID:', auth.currentUser?.uid);
console.log('[KC DEBUG] User token:', await auth.currentUser?.getIdToken());
```

If `auth.currentUser` is `null`, the Storage rules reject the upload.

---

## Third Check: Network Tab

1. Open DevTools → Network
2. Filter by "firebase" or "storage"
3. Upload a photo
4. Look for:
   - **No request at all** → JS error before upload (check Console)
   - **403 Forbidden** → Storage rules or auth issue
   - **Request hangs (pending)** → Network/CORS issue

---

## Fourth Check: Console for Red Errors

Any of these indicate the root cause:
- `Firebase Storage: User does not have permission` → Rules issue
- `Firebase: No user signed in` → Auth issue
- `Cannot read property 'getIdToken' of null` → Auth not initialized
- `Failed to fetch` → Network/CORS issue

---

## Quick Test: Minimal Upload Page

Create a test file `test-upload.html` in the same directory:

```html
<!DOCTYPE html>
<html>
<head><title>Upload Test</title></head>
<body>
  <h1>Storage Upload Test</h1>
  <input type="file" id="fileInput" />
  <div id="result"></div>
  
  <script type="module">
    import { auth, storage } from "../js/firebase-config.js";
    import { ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";
    import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
    
    onAuthStateChanged(auth, (user) => {
      document.getElementById('result').innerHTML = user 
        ? `Logged in as: ${user.email}` 
        : 'NOT LOGGED IN - uploads will fail';
    });
    
    document.getElementById('fileInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const user = auth.currentUser;
      if (!user) {
        alert('Not logged in!');
        return;
      }
      
      try {
        const storageRef = ref(storage, `test/${Date.now()}_${file.name}`);
        const snapshot = await uploadBytes(storageRef, file);
        const url = await getDownloadURL(snapshot.ref);
        document.getElementById('result').innerHTML = `<img src="${url}" style="max-width:200px"><br>URL: ${url}`;
      } catch (err) {
        document.getElementById('result').innerHTML = `ERROR: ${err.message}`;
        console.error(err);
      }
    });
  </script>
</body>
</html>
```

This isolates whether the issue is Storage/Auth vs the edit-listing.js code.

---

## Most Likely Fix Summary

1. **90% chance: Storage Rules** - Update rules to allow authenticated writes
2. **8% chance: Auth State** - User appears logged in but `auth.currentUser` is null
3. **2% chance: Code bug** - Something in edit-listing.js

**Start with Storage Rules - this is almost always the cause of "upload hangs" symptoms.**

---

*QR Gear AI - January 5, 2026*
