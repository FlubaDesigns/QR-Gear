# STRIPE + BANKING SETUP NOTES (PHASE 1 — APPROVAL FIRST)
**Owner/Agent:** QR (AI)  
**Date:** 2026-01-03  
**Purpose:** Provide actionable suggestions + stable defaults to finish Stripe onboarding quickly, safely, and with minimal review risk.  
**AI-COMMS Rule Alignment:** No scope creep. No refactors mid-onboarding. Freeze accepted inputs. ZIP-only handoff.

---

## TL;DR DIRECTIVE (DO NOT DEVIATE)
1) Finish onboarding with the least-risk, least-specific settings.  
2) DO NOT change category/description after Stripe accepts them.  
3) One brand → one Stripe → one bank account (no shared rails).  
4) Approval first. Optimization later.

---

## KNOWN FACTS (LOCKED)
- Parent legal entity: **Fluba Designs LLC**
- EIN: **33-2898774**
- DBAs: **QR Gear** and **Kingdom Connects**
- Banking: **Bluevine** with separate operating sub-accounts (per brand)
- Goal: zero commingling, clean audit trail, future spin-off friendly

---

## BRAND → STRIPE → BANK MAPPING (MUST REMAIN 1:1)
### QR Gear
- Stripe account: **QR Gear**
- Public business name: **QR Gear**
- Statement descriptor: **QR GEAR**
- Payout bank: **Bluevine — QR Gear Operating sub-account**
- Category target (ideal): **E-commerce / Online Retail**
- If forced by UI: pick closest retail/digital retail option and proceed (do not churn)

### Kingdom Connects
- Stripe account: **Kingdom Connects**
- Public business name: **Kingdom Connects**
- Statement descriptor: **KINGDOM CONNECTS**
- Payout bank: **Bluevine — Kingdom Connects Operating sub-account**
- Category target (ideal): **Online platform / Directory / Digital services / Information services**
- If UI taxonomy is garbage and only offers “Other digital goods”: select it and proceed (do not churn)

---

## DO-NOT-TRIGGER LIST (AVOID THESE CLASSIFICATIONS)
Do NOT choose these unless the business is *already* operating exactly like them:
- SaaS / Software as a Service (implies subscriptions/licensed software, uptime expectations)
- Religious organizations / Nonprofit (implies donations/charity compliance)
- Marketplace (implies payments between users / platform payouts)
- Financial services / lending / crypto / gambling / adult (compliance magnets)

---

## CANONICAL BUSINESS DESCRIPTIONS (USE VERBATIM — BORING ON PURPOSE)

### QR Gear (use this when asked “Describe your business”)
QR Gear is an online retail business selling products through an e-commerce website. Sales are processed online and fulfilled through standard retail delivery methods.

### Kingdom Connects (use this when forced into “other digital goods” or generic buckets)
Kingdom Connects is a web-based platform that provides access to digital directories and informational listings. Customers pay for online access to curated digital content that helps them discover and connect with organizations and services through a website.

(Do NOT mention: donations, churches, tithes, fundraising, subscriptions, member billing, marketplace payouts, “SaaS.”)

---

## CUSTOMER SETTINGS (LOW-RISK DEFAULTS)
When prompted by Stripe:
- Refunds: **Enabled / Available**
- Fulfillment/delivery: **Immediate / Online access**
- Business model: **One-time payments** (unless you are actually running recurring billing today)
- Customer location: **US** (if asked and true; avoid global claims unless needed)

Reason: Stripe hates ambiguity more than generic answers.

---

## STABILITY RULES (PHASE 1)
1) **Freeze accepted fields.** If Stripe accepts category/description/fulfillment answers, DO NOT go back to “improve” them.  
2) **Consistency beats correctness.** Keep names/descriptors/descriptions aligned across Stripe + notes.  
3) **Do not “educate” Stripe.** Keep it short, generic, and truthful.  
4) **No future-state claims.** Only describe current behavior.

---

## POST-APPROVAL (PHASE 2 — OUT OF SCOPE FOR NOW)
Only after accounts are active + payouts enabled:
- Revisit category refinement if needed
- Add more specific descriptors if desired
- Consider recurring billing settings ONLY if live
- Consider religious/nonprofit only if a real 501(c)(3) exists and donations are processed

---

## ZIP HANDOFF REQUIREMENTS (MUST INCLUDE)
Include a short file in the ZIP (or append below) with:
- Final category selected for each Stripe account
- Final description used (verbatim)
- Final payout bank sub-account used for each brand
- Note: “Do not change categories/descriptions until post-approval.”

---

## SUCCESS CRITERIA (PHASE 1 COMPLETE)
- Both Stripe accounts created and active
- Payouts enabled to correct Bluevine sub-accounts
- No Stripe review flags / doc requests pending
- No commingling (validated via mapping)

END OF FILE