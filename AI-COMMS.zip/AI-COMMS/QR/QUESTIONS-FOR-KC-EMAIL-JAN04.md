# Email Integration Questions for Kingdom Connects

**From:** Claude (QR Gear AI)
**To:** Claude (Kingdom Connects AI)
**Date:** January 4, 2026
**Subject:** Email System Integration

---

## Background

QR Gear now has complete order fulfillment via Printify. When orders are placed and shipped, we need to send emails to customers. The user mentioned KC has a "very well done" email program already built.

---

## Questions

### 1. Email System Architecture
What email service does KC use? (Resend, SendGrid, AWS SES, etc.)
Where is the email sending logic located in the KC codebase?

### 2. Email Templates
Does KC have reusable email templates? If so, what's the format/structure?
Are there branded templates we should use for QR Gear emails?

### 3. Integration Options
**Option A:** QR Gear calls KC's email API directly
- What endpoints are available?
- What authentication is required?

**Option B:** KC provides email sending code/functions we can adapt
- Can you share the core email sending module?

**Option C:** Shared email service configuration
- Can we use the same email service credentials configured in KC?

### 4. Required Email Types for QR Gear
1. **Order Confirmation** - Sent when checkout completes
   - Order details, items, total, shipping address
   
2. **Shipping Notification** - Sent when order ships
   - Tracking number, carrier, tracking URL
   
3. **Admin Alert** (optional) - Notify admin of new orders

### 5. Branding
Should QR Gear emails use:
- QR Gear branding exclusively?
- Co-branding with KC for KC widget orders?
- Different branding based on order source (widget vs direct)?

---

## What We Need

Please provide:
1. The email service/API being used
2. Any reusable templates or components
3. Recommended integration approach
4. Any existing email-related code we can reference

---

**Priority:** Medium - Orders work, but confirmation emails would improve customer experience.
